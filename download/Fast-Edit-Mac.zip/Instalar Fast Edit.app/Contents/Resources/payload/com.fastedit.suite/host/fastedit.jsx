/*
 * FAST EDIT — Host (ExtendScript / ES3)
 * Camada de integração com o Adobe Premiere Pro.
 * Todas as funções recebem um objeto de argumentos e retornam dados;
 * o despachante $._FE.run() embrulha tudo em {ok, data|error}.
 * IMPORTANTE: manter este arquivo em ES3 (sem let/const, arrow, trailing commas).
 */

/* ------------------------------------------------------------------ JSON (polyfill mínimo) */
if (typeof $._FEJSON === 'undefined') {
    $._FEJSON = (function () {
        function esc(s) {
            return '"' + String(s)
                .replace(/\\/g, '\\\\')
                .replace(/"/g, '\\"')
                .replace(/\n/g, '\\n')
                .replace(/\r/g, '\\r')
                .replace(/\t/g, '\\t')
                .replace(/[\u0000-\u001f]/g, function (c) {
                    var h = c.charCodeAt(0).toString(16);
                    return '\\u' + ('0000' + h).slice(-4);
                }) + '"';
        }
        function str(v) {
            var t = typeof v, i, out, k;
            if (v === null || v === undefined) { return 'null'; }
            if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
            if (t === 'boolean') { return v ? 'true' : 'false'; }
            if (t === 'string') { return esc(v); }
            if (t === 'function') { return 'null'; }
            if (v instanceof Array) {
                out = [];
                for (i = 0; i < v.length; i++) { out.push(str(v[i])); }
                return '[' + out.join(',') + ']';
            }
            out = [];
            for (k in v) {
                if (v.hasOwnProperty(k)) {
                    if (typeof v[k] === 'function' || v[k] === undefined) { continue; }
                    out.push(esc(k) + ':' + str(v[k]));
                }
            }
            return '{' + out.join(',') + '}';
        }
        return {
            stringify: str,
            parse: function (s) {
                if (!s) { return {}; }
                return eval('(' + s + ')');
            }
        };
    })();
}

/* ------------------------------------------------------------------ Constantes & utilitários */
var FE_TPS = 254016000000;
var FE_EPS = 0.0005;
var FE_BIN_MAIN = 'Fast Edit';
var FE_BIN_SFX = 'Fast Edit SFX';
var FE_GUIDE_PREFIX = 'FE_Guide_';

function fe_err(msg) { throw new Error(msg); }

function fe_seq() {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var s = app.project.activeSequence;
    if (!s) { fe_err('Abra uma sequência na timeline primeiro.'); }
    return s;
}

function fe_frameDur(seq) {
    var tb = parseFloat(seq.timebase);
    if (!tb || tb <= 0) { return 1 / 30; }
    return tb / FE_TPS;
}

function fe_time(sec) {
    var t = new Time();
    t.seconds = sec;
    return t;
}

function fe_secOf(v) {
    if (v === null || v === undefined) { return 0; }
    if (typeof v === 'number') { return v; }
    if (typeof v === 'string') { return parseFloat(v) / FE_TPS; }
    if (v.seconds !== undefined) { return v.seconds; }
    return 0;
}

function fe_normPath(p) {
    return String(p || '').replace(/\\/g, '/').toLowerCase();
}

function fe_extOf(p) {
    var m = String(p || '').match(/\.([a-z0-9]+)$/i);
    return m ? m[1].toLowerCase() : '';
}

function fe_qe() {
    try { app.enableQE(); } catch (e) {}
    if (typeof qe === 'undefined' || !qe.project) { fe_err('QE DOM indisponível nesta versão do Premiere.'); }
    return qe;
}

function fe_qeSeq() {
    var q = fe_qe();
    var s = q.project.getActiveSequence();
    if (!s) { fe_err('Sequência QE não encontrada.'); }
    return s;
}

function fe_toList(v) {
    var out = [], i;
    if (!v) { return out; }
    if (typeof v === 'string') {
        var parts = v.split(/[\n,]/);
        for (i = 0; i < parts.length; i++) { if (parts[i]) { out.push(parts[i]); } }
        return out;
    }
    if (v.length !== undefined) {
        for (i = 0; i < v.length; i++) { out.push(String(v[i])); }
    }
    return out;
}

function fe_timecode(frames, fps) {
    var f = Math.max(1, Math.round(frames));
    var r = Math.max(1, Math.round(fps));
    var ff = f % r;
    var totalSec = Math.floor(f / r);
    var ss = totalSec % 60;
    var mm = Math.floor(totalSec / 60) % 60;
    var hh = Math.floor(totalSec / 3600);
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return p(hh) + ':' + p(mm) + ':' + p(ss) + ':' + p(ff);
}

/* ------------------------------------------------------------------ Coleta de clipes */
function fe_eachClip(seq, fn) {
    var t, c, tr, clip;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        tr = seq.videoTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) {
            clip = tr.clips[c];
            if (fn(clip, t, true, tr) === false) { return; }
        }
    }
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        tr = seq.audioTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) {
            clip = tr.clips[c];
            if (fn(clip, t, false, tr) === false) { return; }
        }
    }
}

/* Retorna [{clip, track, video, start, end}] dos clipes selecionados. kind: 'video'|'audio'|'all' */
function fe_selected(seq, kind) {
    var out = [];
    var useIsSel = true;
    try {
        if (seq.videoTracks.numTracks > 0 && seq.videoTracks[0].clips.numItems > 0) {
            seq.videoTracks[0].clips[0].isSelected();
        }
    } catch (e) { useIsSel = false; }

    if (useIsSel) {
        fe_eachClip(seq, function (clip, t, isV) {
            if (kind === 'video' && !isV) { return; }
            if (kind === 'audio' && isV) { return; }
            var sel = false;
            try { sel = clip.isSelected(); } catch (e2) {}
            if (sel) {
                out.push({ clip: clip, track: t, video: isV, start: clip.start.seconds, end: clip.end.seconds });
            }
        });
    } else {
        var s = seq.getSelection();
        var ids = {};
        var i;
        for (i = 0; i < s.length; i++) { ids[s[i].nodeId] = true; }
        fe_eachClip(seq, function (clip, t, isV) {
            if (kind === 'video' && !isV) { return; }
            if (kind === 'audio' && isV) { return; }
            if (ids[clip.nodeId]) {
                out.push({ clip: clip, track: t, video: isV, start: clip.start.seconds, end: clip.end.seconds });
            }
        });
    }
    out.sort(function (a, b) { return a.start - b.start; });
    return out;
}

function fe_requireSel(seq, kind) {
    var s = fe_selected(seq, kind);
    if (!s.length) {
        fe_err(kind === 'audio' ? 'Selecione clipes de áudio na timeline.' : 'Selecione um ou mais clipes na timeline.');
    }
    return s;
}

/* ------------------------------------------------------------------ Projeto & bins */
function fe_findBin(parent, name) {
    var i, ch;
    for (i = 0; i < parent.children.numItems; i++) {
        ch = parent.children[i];
        if (ch && ch.type === ProjectItemType.BIN && ch.name === name) { return ch; }
    }
    return null;
}

function fe_getOrCreateBin(parent, name) {
    var b = fe_findBin(parent, name);
    if (b) { return b; }
    var r = null;
    try { r = parent.createBin(name); } catch (e) {}
    if (r && r.type === ProjectItemType.BIN) { return r; }
    b = fe_findBin(parent, name);
    if (!b) { fe_err('Não foi possível criar o bin "' + name + '".'); }
    return b;
}

function fe_findItemByPath(bin, normPath, depth) {
    var i, ch, p, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findItemByPath(ch, normPath, depth + 1);
            if (f) { return f; }
        } else {
            p = '';
            try { p = ch.getMediaPath(); } catch (e) {}
            if (p && fe_normPath(p) === normPath) { return ch; }
        }
    }
    return null;
}

/* Importa um arquivo uma única vez (reaproveita se já estiver no projeto). */
function fe_importOnce(path, binName) {
    var root = app.project.rootItem;
    var np = fe_normPath(path);
    var bin = fe_getOrCreateBin(root, binName);
    var item = fe_findItemByPath(bin, np, 0);
    if (item) { return item; }
    item = fe_findItemByPath(root, np, 0);
    if (item) { return item; }
    var f = new File(path);
    if (!f.exists) { fe_err('Arquivo não encontrado: ' + path); }
    app.project.importFiles([f.fsName], true, bin, false);
    item = fe_findItemByPath(bin, np, 0);
    if (!item) { item = fe_findItemByPath(root, np, 0); }
    if (!item) { fe_err('Falha ao importar: ' + path); }
    return item;
}

function fe_findByNodeId(bin, id, depth) {
    var i, ch, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.nodeId === id) { return ch; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findByNodeId(ch, id, depth + 1);
            if (f) { return f; }
        }
    }
    return null;
}

var FE_ADJ_RX = /adjust|ajuste|einstellung|calque|regola|correcci|aanpassing|korekc|調整|조정/i;

function fe_isSequenceItem(it) {
    try { return it.isSequence(); } catch (e) { return false; }
}

function fe_findAdjustment(bin, depth) {
    var i, ch, f, p;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findAdjustment(ch, depth + 1);
            if (f) { return f; }
        } else if (ch.type === ProjectItemType.CLIP && !fe_isSequenceItem(ch)) {
            var isAdj = null;
            try { isAdj = ch.isAdjustmentLayer(); } catch (e0) { isAdj = null; }
            if (isAdj === true) { return ch; }
            if (isAdj === null) {
                p = '';
                try { p = ch.getMediaPath(); } catch (e) {}
                if (!p && FE_ADJ_RX.test(ch.name)) { return ch; }
            }
        }
    }
    return null;
}

/* ------------------------------------------------------------------ Trilhas */
function fe_trackFree(track, start, end, ignoreNode) {
    var i, c;
    for (i = 0; i < track.clips.numItems; i++) {
        c = track.clips[i];
        if (ignoreNode && c.nodeId === ignoreNode) { continue; }
        if (c.start.seconds < end - FE_EPS && c.end.seconds > start + FE_EPS) { return false; }
    }
    return true;
}

function fe_addVideoTrack(seq) {
    var n = seq.videoTracks.numTracks;
    var q = fe_qeSeq();
    try { q.addTracks(1, n, 0); } catch (e) {
        try { q.addTracks(1, n, 0, 0, 0, 0, 0); } catch (e2) { fe_err('Não foi possível adicionar trilha de vídeo.'); }
    }
    return seq.videoTracks.numTracks - 1;
}

function fe_addAudioTrack(seq) {
    var n = seq.audioTracks.numTracks;
    var q = fe_qeSeq();
    var ok = false;
    try { q.addTracks(0, 0, 1, 1, n, 0, 0); ok = true; } catch (e) {}
    if (!ok) { try { q.addTracks(0, 0, 1); ok = true; } catch (e2) {} }
    if (!ok || seq.audioTracks.numTracks === n) { fe_err('Não foi possível adicionar trilha de áudio.'); }
    return seq.audioTracks.numTracks - 1;
}

function fe_freeVideoTrack(seq, fromIdx, start, end) {
    var i;
    for (i = Math.max(0, fromIdx); i < seq.videoTracks.numTracks; i++) {
        if (fe_trackFree(seq.videoTracks[i], start, end)) { return i; }
    }
    return fe_addVideoTrack(seq);
}

function fe_freeAudioTrack(seq, fromIdx, start, end) {
    var i;
    for (i = Math.max(0, fromIdx); i < seq.audioTracks.numTracks; i++) {
        if (fe_trackFree(seq.audioTracks[i], start, end)) { return i; }
    }
    return fe_addAudioTrack(seq);
}

function fe_clipAt(track, startSec, tol) {
    var i, c, best = null, bd = 1e9, d;
    for (i = 0; i < track.clips.numItems; i++) {
        c = track.clips[i];
        d = Math.abs(c.start.seconds - startSec);
        if (d < bd) { bd = d; best = c; }
    }
    return (best && bd <= tol) ? best : null;
}

/* Coloca projectItem em track no tempo start, ajustando a duração (se dur > 0). */
function fe_place(seq, track, item, start, dur) {
    var fd = fe_frameDur(seq);
    track.overwriteClip(item, start);
    var clip = fe_clipAt(track, start, fd * 0.75);
    if (clip && dur && dur > 0) {
        try { clip.end = fe_time(start + dur); } catch (e) {}
    }
    return clip;
}

/* ------------------------------------------------------------------ QE helpers */
function fe_qeItem(qeSeq, isVideo, trackIdx, clip) {
    var tr = isVideo ? qeSeq.getVideoTrackAt(trackIdx) : qeSeq.getAudioTrackAt(trackIdx);
    if (!tr) { return null; }
    var i, it, s, target = clip.start.seconds, tTicks = String(clip.start.ticks);
    for (i = 0; i < tr.numItems; i++) {
        it = tr.getItemAt(i);
        if (!it || it.type === 'Empty') { continue; }
        try { if (String(it.start.ticks) === tTicks) { return it; } } catch (e) {}
        try {
            s = it.start.secs;
            if (s !== undefined && Math.abs(s - target) < 0.002) { return it; }
        } catch (e2) {}
    }
    return null;
}

/* ------------------------------------------------------------------ Keyframes / Motion */
function fe_comp(clip, matchName) {
    var i, c;
    for (i = 0; i < clip.components.numItems; i++) {
        c = clip.components[i];
        if (c && c.matchName === matchName) { return c; }
    }
    return null;
}

function fe_params(clip) {
    var m = fe_comp(clip, 'AE.ADBE Motion');
    var o = fe_comp(clip, 'AE.ADBE Opacity');
    var r = { pos: null, scale: null, rot: null, opacity: null };
    if (m) {
        r.pos = m.properties[0] || null;
        r.scale = m.properties[1] || null;
        r.rot = m.properties[4] || null;
    }
    if (o) { r.opacity = o.properties[0] || null; }
    return r;
}

function fe_baseVal(param, t) {
    if (!param) { return null; }
    var v = null;
    try {
        if (param.isTimeVarying()) { v = param.getValueAtTime(t); }
    } catch (e) {}
    if (v === null || v === undefined) {
        try { v = param.getValue(); } catch (e2) {}
    }
    return v;
}

function fe_clearRange(param, t0, t1) {
    try {
        if (param.isTimeVarying()) { param.removeKeyRange(t0 - 0.0001, t1 + 0.0001, true); }
    } catch (e) {}
}

function fe_setKey(param, t, value, ease) {
    try { if (!param.isTimeVarying()) { param.setTimeVarying(true); } } catch (e) {}
    param.addKey(t);
    param.setValueAtKey(t, value, true);
    try { param.setInterpolationTypeAtKey(t, ease ? 5 : 0, true); } catch (e2) {}
}

/* Presets de animação. Cada preset descreve keyframes da ENTRADA: lista de
   {p: 'pos'|'scale'|'rot'|'opacity', k: [[u (0..1), fn(base, ctx)]]}.
   A SAÍDA é a entrada espelhada no tempo. */
function fe_px(b, ctx, dx, dy) {
    return [b[0] + dx * ctx.ux, b[1] + dy * ctx.uy];
}

var FE_PRESETS = {
    fade: [{ p: 'opacity', k: [[0, function () { return 0; }], [1, function (b) { return b; }]] }],
    zoom_in: [
        { p: 'scale', k: [[0, function (b, c) { return b * (1 - 0.4 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.6, function (b) { return b; }]] }
    ],
    zoom_out: [
        { p: 'scale', k: [[0, function (b, c) { return b * (1 + 0.6 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.6, function (b) { return b; }]] }
    ],
    pop: [
        { p: 'scale', k: [[0, function () { return 0; }], [0.65, function (b, c) { return b * (1 + 0.15 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.3, function (b) { return b; }]] }
    ],
    bounce: [
        { p: 'scale', k: [[0, function () { return 0; }], [0.45, function (b, c) { return b * (1 + 0.22 * c.I); }], [0.72, function (b, c) { return b * (1 - 0.1 * c.I); }], [1, function (b) { return b; }]] }
    ],
    slide_l: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, -1 * c.I, 0); }], [1, function (b) { return b; }]] }],
    slide_r: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 1 * c.I, 0); }], [1, function (b) { return b; }]] }],
    slide_u: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, -1 * c.I); }], [1, function (b) { return b; }]] }],
    slide_d: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, 1 * c.I); }], [1, function (b) { return b; }]] }],
    rise: [
        { p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, 0.08 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.7, function (b) { return b; }]] }
    ],
    drop: [
        { p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, -0.12 * c.I); }], [0.7, function (b, c) { return fe_px(b, c, 0, 0.015 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.4, function (b) { return b; }]] }
    ],
    spin: [
        { p: 'rot', k: [[0, function (b, c) { return b - 180 * c.I; }], [1, function (b) { return b; }]] },
        { p: 'scale', k: [[0, function () { return 0; }], [1, function (b) { return b; }]] }
    ],
    swing: [
        { p: 'rot', k: [[0, function (b, c) { return b - 25 * c.I; }], [0.55, function (b, c) { return b + 8 * c.I; }], [0.8, function (b, c) { return b - 3 * c.I; }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.3, function (b) { return b; }]] }
    ]
};

/* Presets "únicos" (não têm entrada/saída) */
var FE_SINGLE = { punch: true, kenburns: true, shake: true, pulse: true };

function fe_ctxFor(seq, posBase, intensity) {
    var px = posBase && (Math.abs(posBase[0]) > 2 || Math.abs(posBase[1]) > 2);
    return {
        ux: px ? seq.frameSizeHorizontal : 1,
        uy: px ? seq.frameSizeVertical : 1,
        I: intensity || 1
    };
}

/* Aplica um preset em um clipe. phase: 'in'|'out'. Retorna nº de keyframes. */
function fe_animate(seq, clip, preset, phase, durSec, ease, replace, intensity, offsetSec, samples) {
    var def = FE_PRESETS[preset];
    if (!def) { fe_err('Preset desconhecido: ' + preset); }
    var P = fe_params(clip);
    var clipLen = clip.end.seconds - clip.start.seconds;
    var d = Math.min(durSec, clipLen * (phase === 'both' ? 0.5 : 1));
    var mediaIn = clip.inPoint.seconds;
    var t0 = phase === 'out' ? mediaIn + clipLen - d : mediaIn + (offsetSec || 0);
    if (phase !== 'out' && (offsetSec || 0) + d > clipLen) { d = Math.max(0.02, clipLen - (offsetSec || 0)); }
    var t1 = t0 + d;
    var count = 0, i, j, tr, param, base, ctx, u, t, keys;
    for (i = 0; i < def.length; i++) {
        tr = def[i];
        param = P[tr.p];
        if (!param) { continue; }
        base = fe_baseVal(param, phase === 'out' ? t0 : t1);
        if (base === null || base === undefined) { continue; }
        ctx = fe_ctxFor(seq, tr.p === 'pos' ? base : null, intensity);
        if (replace) { fe_clearRange(param, t0, t1); }
        keys = tr.k;
        for (j = 0; j < keys.length; j++) {
            u = keys[j][0];
            t = phase === 'out' ? t0 + (1 - u) * d : t0 + u * d;
            fe_setKey(param, t, keys[j][1](base, ctx), samples ? false : ease);
            count++;
        }
        if (samples) { fe_bakeRange(param, t0, t1, samples, fe_frameDur(seq)); }
    }
    return count;
}

function fe_animateSingle(seq, clip, preset, durSec, ease, replace, intensity, atSec) {
    var P = fe_params(clip);
    var clipLen = clip.end.seconds - clip.start.seconds;
    var mediaIn = clip.inPoint.seconds;
    var count = 0, base, ctx, t0, t1, i, n, fd, decay, amp;
    var I = intensity || 1;
    if (preset === 'kenburns') {
        t0 = mediaIn; t1 = mediaIn + clipLen;
        if (P.scale) {
            base = fe_baseVal(P.scale, t0);
            if (replace) { fe_clearRange(P.scale, t0, t1); }
            fe_setKey(P.scale, t0, base, false);
            fe_setKey(P.scale, t1 - 0.001, base * (1 + 0.12 * I), false);
            count += 2;
        }
        if (P.pos) {
            base = fe_baseVal(P.pos, t0);
            ctx = fe_ctxFor(seq, base, I);
            if (replace) { fe_clearRange(P.pos, t0, t1); }
            fe_setKey(P.pos, t0, base, false);
            fe_setKey(P.pos, t1 - 0.001, fe_px(base, ctx, 0.02 * I, -0.01 * I), false);
            count += 2;
        }
        return count;
    }
    var rel = (atSec !== undefined && atSec !== null) ? atSec - clip.start.seconds : 0;
    if (rel < 0 || rel > clipLen) { rel = 0; }
    t0 = mediaIn + rel;
    var d = Math.min(durSec, clipLen - rel);
    t1 = t0 + d;
    if (preset === 'punch' || preset === 'pulse') {
        if (!P.scale) { return 0; }
        base = fe_baseVal(P.scale, t0);
        if (replace) { fe_clearRange(P.scale, t0, t1); }
        var peak = preset === 'punch' ? 1 + 0.18 * I : 1 + 0.08 * I;
        if (preset === 'punch') {
            fe_setKey(P.scale, t0, base * peak, ease);
            fe_setKey(P.scale, t1, base, ease);
            count += 2;
        } else {
            fe_setKey(P.scale, t0, base, ease);
            fe_setKey(P.scale, t0 + d * 0.35, base * peak, ease);
            fe_setKey(P.scale, t1, base, ease);
            count += 3;
        }
        return count;
    }
    if (preset === 'shake') {
        if (!P.pos) { return 0; }
        base = fe_baseVal(P.pos, t0);
        ctx = fe_ctxFor(seq, base, I);
        if (replace) { fe_clearRange(P.pos, t0, t1); }
        fd = fe_frameDur(seq);
        n = Math.max(3, Math.floor(d / (fd * 2)));
        for (i = 0; i <= n; i++) {
            decay = 1 - i / n;
            amp = 0.025 * I * decay;
            var dx = (i === n) ? 0 : (Math.random() * 2 - 1) * amp;
            var dy = (i === n) ? 0 : (Math.random() * 2 - 1) * amp * 0.8;
            fe_setKey(P.pos, t0 + (d * i / n), fe_px(base, ctx, dx, dy), false);
            count++;
        }
        if (P.scale) {
            var sb = fe_baseVal(P.scale, t0);
            if (replace) { fe_clearRange(P.scale, t0, t1); }
            fe_setKey(P.scale, t0, sb * (1 + 0.06 * I), false);
            fe_setKey(P.scale, t1, sb, false);
            count += 2;
        }
        return count;
    }
    fe_err('Preset desconhecido: ' + preset);
    return 0;
}

/* ------------------------------------------------------------------ Curvas (bake) */
/* A API do Premiere não expõe as alças de bezier dos keyframes. Para aplicar uma
   curva personalizada, geramos keyframes intermediários (lineares) que seguem a curva.
   samples: array com N+1 valores y da curva em u = i/N (y pode passar de 0..1: overshoot). */
if (!$._FE_BAKED) { $._FE_BAKED = {}; }

function fe_curveAt(samples, u) {
    var n = samples.length - 1;
    if (u <= 0) { return samples[0]; }
    if (u >= 1) { return samples[n]; }
    var x = u * n, i = Math.floor(x), f = x - i;
    return samples[i] + (samples[i + 1] - samples[i]) * f;
}

function fe_lerpVal(a, b, e) {
    var i, out;
    if (a instanceof Array) {
        out = [];
        for (i = 0; i < a.length; i++) { out.push(a[i] + (b[i] - a[i]) * e); }
        return out;
    }
    return a + (b - a) * e;
}

function fe_isNumVal(v) {
    if (typeof v === 'number') { return true; }
    if (v instanceof Array && v.length && typeof v[0] === 'number') { return true; }
    return false;
}

function fe_keyTimes(param) {
    var out = [], ks, i, t;
    try { ks = param.getKeys(); } catch (e) { ks = null; }
    if (!ks) { return out; }
    for (i = 0; i < ks.length; i++) {
        t = ks[i];
        out.push(typeof t === 'number' ? t : (t.seconds !== undefined ? t.seconds : parseFloat(t)));
    }
    out.sort(function (a, b) { return a - b; });
    return out;
}

/* assa a curva em um segmento [a,b] de um parâmetro */
function fe_bakeSegment(param, a, b, samples, step) {
    var v0 = param.getValueAtKey(a), v1 = param.getValueAtKey(b);
    if (!fe_isNumVal(v0) || !fe_isNumVal(v1)) { return 0; }
    var n = Math.max(2, Math.round((b - a) / step));
    var j, u, t, cnt = 0;
    try { param.removeKeyRange(a + 0.0005, b - 0.0005, true); } catch (e0) {}
    for (j = 1; j < n; j++) {
        u = j / n;
        t = a + u * (b - a);
        param.addKey(t);
        param.setValueAtKey(t, fe_lerpVal(v0, v1, fe_curveAt(samples, u)), true);
        try { param.setInterpolationTypeAtKey(t, 0, true); } catch (e1) {}
        cnt++;
    }
    try { param.setInterpolationTypeAtKey(a, 0, true); param.setInterpolationTypeAtKey(b, 0, true); } catch (e2) {}
    return cnt;
}

/* keyframes "principais" de um parâmetro (ignora os que o Fast Edit criou ao assar) */
function fe_mainKeys(regKey, param) {
    var cur = fe_keyTimes(param);
    var orig = $._FE_BAKED[regKey];
    if (orig && orig.length >= 2) {
        var ok = true, i, j, found;
        for (i = 0; i < orig.length && ok; i++) {
            found = false;
            for (j = 0; j < cur.length; j++) { if (Math.abs(cur[j] - orig[i]) < 0.0015) { found = true; break; } }
            if (!found) { ok = false; }
        }
        if (ok) { return orig; }
    }
    return cur;
}

/* aplica a curva em todos os parâmetros animados de um clipe */
function fe_curveClip(seq, clip, a) {
    var fd = fe_frameDur(seq);
    var step = fd * (a.step || 1);
    var res = { params: 0, segments: 0, keys: 0 };
    var ppMedia = null;
    if (a.segment === 'playhead') {
        try { ppMedia = clip.inPoint.seconds + (seq.getPlayerPosition().seconds - clip.start.seconds); } catch (e) {}
    }
    var ci, pi, comp, param, keys, k, regKey, did;
    for (ci = 0; ci < clip.components.numItems; ci++) {
        comp = clip.components[ci];
        if (!comp) { continue; }
        if (a.scope !== 'all' && comp.matchName !== 'AE.ADBE Motion' && comp.matchName !== 'AE.ADBE Opacity') { continue; }
        for (pi = 0; pi < comp.properties.numItems; pi++) {
            param = comp.properties[pi];
            if (!param) { continue; }
            try { if (!param.isTimeVarying()) { continue; } } catch (e1) { continue; }
            regKey = clip.nodeId + '|' + ci + '|' + pi;
            keys = fe_mainKeys(regKey, param);
            if (keys.length < 2) { continue; }
            did = false;
            for (k = 0; k < keys.length - 1; k++) {
                if (ppMedia !== null && !(ppMedia >= keys[k] - 0.001 && ppMedia <= keys[k + 1] + 0.001)) { continue; }
                if (keys[k + 1] - keys[k] < step * 1.5) { continue; }
                try {
                    if (a.remove) {
                        param.removeKeyRange(keys[k] + 0.0005, keys[k + 1] - 0.0005, true);
                        try { param.setInterpolationTypeAtKey(keys[k], 5, true); param.setInterpolationTypeAtKey(keys[k + 1], 5, true); } catch (e3) {}
                    } else {
                        res.keys += fe_bakeSegment(param, keys[k], keys[k + 1], a.samples, step);
                    }
                    res.segments++;
                    did = true;
                } catch (e2) {}
            }
            if (did) {
                res.params++;
                $._FE_BAKED[regKey] = a.remove ? null : keys;
            }
        }
    }
    return res;
}

/* usado pelos presets de animação: assa a curva entre os keys recém-criados */
function fe_bakeRange(param, t0, t1, samples, fd) {
    var keys = fe_keyTimes(param), i, list = [];
    for (i = 0; i < keys.length; i++) { if (keys[i] >= t0 - 0.0015 && keys[i] <= t1 + 0.0015) { list.push(keys[i]); } }
    for (i = 0; i < list.length - 1; i++) {
        if (list[i + 1] - list[i] >= fd * 1.5) { fe_bakeSegment(param, list[i], list[i + 1], samples, fd); }
    }
}

/* ------------------------------------------------------------------ API */
var FE_API = {};

FE_API.ping = function () {
    return { version: app.version, build: app.build || '', project: app.project ? app.project.name : null };
};

FE_API.info = function () {
    var r = { version: app.version, project: null, projectPath: null, seq: null };
    if (!app.project) { return r; }
    r.project = app.project.name;
    r.projectPath = app.project.path;
    var s = app.project.activeSequence;
    if (s) {
        var fd = fe_frameDur(s);
        var clips = 0;
        var sel = 0;
        fe_eachClip(s, function (c) {
            clips++;
            try { if (c.isSelected()) { sel++; } } catch (e) {}
        });
        var pp = 0;
        try { pp = s.getPlayerPosition().seconds; } catch (e2) {}
        r.seq = {
            name: s.name,
            id: s.sequenceID,
            w: s.frameSizeHorizontal,
            h: s.frameSizeVertical,
            fps: Math.round((1 / fd) * 100) / 100,
            duration: fe_secOf(s.end),
            playhead: pp,
            vTracks: s.videoTracks.numTracks,
            aTracks: s.audioTracks.numTracks,
            clips: clips,
            selected: sel
        };
    }
    return r;
};

/* --- ANIMATE: Motion presets ----------------------------------------------- */
FE_API.motion = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var dur = (a.frames || 12) * fd;
    var ease = a.ease !== false;
    var replace = a.replace !== false;
    var I = a.intensity || 1;
    var stagger = (a.stagger || 0) * fd;
    var keys = 0, i, pp = null;
    try { pp = seq.getPlayerPosition().seconds; } catch (e) {}
    for (i = 0; i < sel.length; i++) {
        var clip = sel[i].clip;
        if (FE_SINGLE[a.preset]) {
            keys += fe_animateSingle(seq, clip, a.preset, dur, ease, replace, I, a.atPlayhead ? pp : null);
        } else {
            var where = a.where || 'in';
            if (where === 'in' || where === 'both') { keys += fe_animate(seq, clip, a.preset, 'in', dur, ease, replace, I, stagger * i, a.samples || null); }
            if (where === 'out' || where === 'both') { keys += fe_animate(seq, clip, a.preset, 'out', dur, ease, replace, I, 0, a.samples || null); }
        }
    }
    return { clips: sel.length, keys: keys };
};

/* Remove keyframes de Motion/Opacity dos selecionados (reset) */
FE_API.resetMotion = function () {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var i, P, k, p;
    for (i = 0; i < sel.length; i++) {
        P = fe_params(sel[i].clip);
        for (k in P) {
            if (!P.hasOwnProperty(k)) { continue; }
            p = P[k];
            if (!p) { continue; }
            try {
                if (p.isTimeVarying()) {
                    var v = p.getValueAtTime(sel[i].clip.inPoint.seconds);
                    p.setTimeVarying(false);
                    if (k === 'opacity') { p.setValue(100, true); }
                    else if (k === 'scale') { p.setValue(100, true); }
                    else if (k === 'rot') { p.setValue(0, true); }
                    else if (v) { p.setValue(v, true); }
                }
            } catch (e) {}
        }
    }
    return { clips: sel.length };
};

/* --- ANIMATE: Curvas -------------------------------------------------------- */
FE_API.applyCurve = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, a.scope === 'all' ? 'all' : 'video');
    if (!a.remove && (!a.samples || a.samples.length < 3)) { fe_err('Curva inválida.'); }
    var tot = { clips: sel.length, params: 0, segments: 0, keys: 0 }, i, r;
    for (i = 0; i < sel.length; i++) {
        r = fe_curveClip(seq, sel[i].clip, a);
        tot.params += r.params; tot.segments += r.segments; tot.keys += r.keys;
    }
    if (!tot.segments) {
        fe_err(a.segment === 'playhead' ? 'Nenhum par de keyframes sob o playhead nos clipes selecionados.' : 'Os clipes selecionados não têm keyframes (precisa de pelo menos 2 numa propriedade).');
    }
    return tot;
};

/* --- ANIMATE: Caption animator --------------------------------------------- */
FE_API.captions = function (a) {
    var seq = fe_seq();
    var sel = fe_selected(seq, 'video');
    var targets = [];
    var i;
    if (a.wholeTrack) {
        if (!sel.length) { fe_err('Selecione ao menos uma legenda/texto na trilha desejada.'); }
        var tr = seq.videoTracks[sel[0].track];
        for (i = 0; i < tr.clips.numItems; i++) { targets.push(tr.clips[i]); }
    } else {
        if (!sel.length) { fe_err('Selecione as legendas/textos (clipes gráficos) na timeline.'); }
        for (i = 0; i < sel.length; i++) { targets.push(sel[i].clip); }
    }
    var fd = fe_frameDur(seq);
    var inDur = (a.inFrames || 6) * fd;
    var outDur = (a.outFrames || 4) * fd;
    var keys = 0;
    for (i = 0; i < targets.length; i++) {
        keys += fe_animate(seq, targets[i], a.preset || 'pop', 'in', inDur, true, true, a.intensity || 1, 0);
        if (a.outPreset && a.outPreset !== 'none') {
            keys += fe_animate(seq, targets[i], a.outPreset, 'out', outDur, true, true, a.intensity || 1, 0);
        }
    }
    return { clips: targets.length, keys: keys };
};

/* --- ANIMATE: Transições por keyframe (entre clipes adjacentes) ------------- */
var FE_KTRANS = {
    push_l: { a: [{ p: 'pos', dx: -1, dy: 0 }], b: [{ p: 'pos', dx: 1, dy: 0 }] },
    push_r: { a: [{ p: 'pos', dx: 1, dy: 0 }], b: [{ p: 'pos', dx: -1, dy: 0 }] },
    push_u: { a: [{ p: 'pos', dx: 0, dy: -1 }], b: [{ p: 'pos', dx: 0, dy: 1 }] },
    push_d: { a: [{ p: 'pos', dx: 0, dy: 1 }], b: [{ p: 'pos', dx: 0, dy: -1 }] },
    zoom: { a: [{ p: 'scale', m: 2.6 }], b: [{ p: 'scale', m: 0.35 }] },
    zoom_out: { a: [{ p: 'scale', m: 0.35 }], b: [{ p: 'scale', m: 2.6 }] },
    spin: { a: [{ p: 'rot', r: 90 }, { p: 'scale', m: 1.6 }], b: [{ p: 'rot', r: -90 }, { p: 'scale', m: 1.6 }] },
    flash_zoom: { a: [{ p: 'scale', m: 1.35 }, { p: 'opacity', o: 0 }], b: [{ p: 'scale', m: 1.35 }, { p: 'opacity', o: 0 }] }
};

function fe_ktransSide(seq, clip, specs, isOut, d, I, samples) {
    var P = fe_params(clip);
    var len = clip.end.seconds - clip.start.seconds;
    var dd = Math.min(d, len * 0.5);
    var mediaIn = clip.inPoint.seconds;
    var tA = isOut ? mediaIn + len - dd : mediaIn;
    var tB = tA + dd;
    var n = 0, i, s, param, base, ctx, moved;
    for (i = 0; i < specs.length; i++) {
        s = specs[i];
        param = P[s.p];
        if (!param) { continue; }
        base = fe_baseVal(param, isOut ? tA : tB);
        if (base === null || base === undefined) { continue; }
        fe_clearRange(param, tA, tB);
        if (s.p === 'pos') {
            ctx = fe_ctxFor(seq, base, I);
            moved = fe_px(base, ctx, s.dx * I, s.dy * I);
        } else if (s.p === 'scale') {
            moved = base * (1 + (s.m - 1) * I);
        } else if (s.p === 'rot') {
            moved = base + s.r * I;
        } else {
            moved = s.o;
        }
        if (isOut) {
            fe_setKey(param, tA, base, !samples);
            fe_setKey(param, tB - 0.0005, moved, !samples);
        } else {
            fe_setKey(param, tA, moved, !samples);
            fe_setKey(param, tB, base, !samples);
        }
        if (samples) { fe_bakeRange(param, tA, tB, isOut ? samples : samples, fe_frameDur(seq)); }
        n += 2;
    }
    return n;
}

FE_API.ktransition = function (a) {
    var seq = fe_seq();
    var spec = FE_KTRANS[a.type];
    if (!spec) { fe_err('Transição desconhecida.'); }
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var half = Math.max(2, a.frames || 8) * fd;
    var I = a.intensity || 1;
    var pairs = [];
    var i, j, tr, A, B;
    var byTrack = {};
    for (i = 0; i < sel.length; i++) {
        if (!byTrack[sel[i].track]) { byTrack[sel[i].track] = []; }
        byTrack[sel[i].track].push(sel[i]);
    }
    var t;
    for (t in byTrack) {
        if (!byTrack.hasOwnProperty(t)) { continue; }
        var arr = byTrack[t];
        tr = seq.videoTracks[parseInt(t, 10)];
        if (arr.length === 1) {
            /* um clipe: transição com o clipe anterior (corte de entrada) */
            for (j = 0; j < tr.clips.numItems; j++) {
                if (Math.abs(tr.clips[j].end.seconds - arr[0].start) < fd * 0.6) {
                    pairs.push([tr.clips[j], arr[0].clip]);
                    break;
                }
            }
            if (!pairs.length) {
                for (j = 0; j < tr.clips.numItems; j++) {
                    if (Math.abs(tr.clips[j].start.seconds - arr[0].end) < fd * 0.6) {
                        pairs.push([arr[0].clip, tr.clips[j]]);
                        break;
                    }
                }
            }
        } else {
            for (j = 0; j < arr.length - 1; j++) {
                if (Math.abs(arr[j].end - arr[j + 1].start) < fd * 0.6) {
                    pairs.push([arr[j].clip, arr[j + 1].clip]);
                }
            }
        }
    }
    if (!pairs.length) { fe_err('Nenhum corte encontrado. Selecione clipes vizinhos (colados) na mesma trilha.'); }
    var keys = 0, cuts = [];
    for (i = 0; i < pairs.length; i++) {
        A = pairs[i][0]; B = pairs[i][1];
        keys += fe_ktransSide(seq, A, spec.a, true, half, I, a.samples || null);
        keys += fe_ktransSide(seq, B, spec.b, false, half, I, a.samples || null);
        cuts.push(B.start.seconds);
    }
    return { cuts: cuts, keys: keys };
};

/* --- ANIMATE: Transições nativas (QE) -------------------------------------- */
FE_API.listTransitions = function () {
    var q = fe_qe();
    var v = [], au = [];
    try { v = fe_toList(q.project.getVideoTransitionList()); } catch (e) {}
    try { au = fe_toList(q.project.getAudioTransitionList()); } catch (e2) {}
    return { video: v, audio: au };
};

function fe_addTransition(qi, tr, atStart, frames, fps) {
    var tc = fe_timecode(frames, fps);
    try { qi.addTransition(tr, atStart, tc, '00:00:00:00', 0.5, false, true); return true; } catch (e) {}
    try { qi.addTransition(tr, atStart, String(frames)); return true; } catch (e2) {}
    try { qi.addTransition(tr, atStart); return true; } catch (e3) {}
    return false;
}

FE_API.nativeTransition = function (a) {
    var seq = fe_seq();
    var q = fe_qe();
    var qs = fe_qeSeq();
    var isAudio = !!a.audio;
    var tr = isAudio ? q.project.getAudioTransitionByName(a.name) : q.project.getVideoTransitionByName(a.name);
    if (!tr) { fe_err('Transição "' + a.name + '" não encontrada.'); }
    var sel = fe_requireSel(seq, isAudio ? 'audio' : 'video');
    var fd = fe_frameDur(seq);
    var fps = 1 / fd;
    var frames = a.frames || 15;
    var where = a.where || 'both';
    var n = 0, fail = 0, i, qi;
    for (i = 0; i < sel.length; i++) {
        qi = fe_qeItem(qs, !isAudio, sel[i].track, sel[i].clip);
        if (!qi) { fail++; continue; }
        if (where === 'start' || where === 'both') { if (fe_addTransition(qi, tr, true, frames, fps)) { n++; } else { fail++; } }
        if (where === 'end' || where === 'both') { if (fe_addTransition(qi, tr, false, frames, fps)) { n++; } else { fail++; } }
    }
    return { added: n, failed: fail };
};

/* --- ANIMATE: Efeitos (QE) ------------------------------------------------- */
FE_API.listEffects = function () {
    var q = fe_qe();
    var v = [], au = [];
    try { v = fe_toList(q.project.getVideoEffectList()); } catch (e) {}
    try { au = fe_toList(q.project.getAudioEffectList()); } catch (e2) {}
    return { video: v, audio: au };
};

function fe_applyEffectsTo(qs, list, names, isAudio) {
    var q = fe_qe();
    var applied = 0, missing = {}, i, j, qi, eff;
    var cache = {};
    for (j = 0; j < names.length; j++) {
        try {
            eff = isAudio ? q.project.getAudioEffectByName(names[j]) : q.project.getVideoEffectByName(names[j]);
        } catch (e) { eff = null; }
        cache[names[j]] = eff;
    }
    for (i = 0; i < list.length; i++) {
        qi = fe_qeItem(qs, !isAudio, list[i].track, list[i].clip);
        if (!qi) { continue; }
        for (j = 0; j < names.length; j++) {
            eff = cache[names[j]];
            if (!eff) { missing[names[j]] = true; continue; }
            try {
                if (isAudio) { qi.addAudioEffect(eff); } else { qi.addVideoEffect(eff); }
                applied++;
            } catch (e2) { missing[names[j]] = true; }
        }
    }
    var miss = [], k;
    for (k in missing) { if (missing.hasOwnProperty(k)) { miss.push(k); } }
    return { applied: applied, missing: miss };
}

FE_API.applyEffects = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var names = a.names || [];
    if (!names.length) { fe_err('Nenhum efeito escolhido.'); }
    var isAudio = !!a.audio;
    var sel = fe_requireSel(seq, isAudio ? 'audio' : 'video');
    var r = fe_applyEffectsTo(qs, sel, names, isAudio);
    r.clips = sel.length;
    return r;
};

/* --- WORKFLOW: Overlays (Adjustment Layer / Color Matte / PNG) ------------- */
FE_API.findAdjustment = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var it = null;
    if (a && a.nodeId) { it = fe_findByNodeId(app.project.rootItem, a.nodeId, 0); }
    if (!it) { it = fe_findAdjustment(app.project.rootItem, 0); }
    return it ? { nodeId: it.nodeId, name: it.name } : null;
};

FE_API.adjustmentFromSelection = function () {
    var seq = app.project.activeSequence;
    var it = null;
    if (seq) {
        var sel = fe_selected(seq, 'video');
        if (sel.length) { it = sel[0].clip.projectItem; }
    }
    if (!it) {
        try {
            var v = app.getCurrentProjectViewSelection();
            if (v && v.length) { it = v[0]; }
        } catch (e) {}
    }
    if (!it) { fe_err('Selecione uma Adjustment Layer na timeline ou no painel Project.'); }
    return { nodeId: it.nodeId, name: it.name };
};

/* garante uma camada de ajuste no projeto: usa a existente ou importa o modelo do Fast Edit */
function fe_ensureAdjustment(nodeId, template) {
    var item = null;
    if (nodeId) { item = fe_findByNodeId(app.project.rootItem, nodeId, 0); }
    if (item) { try { if (item.isAdjustmentLayer() === false) { item = null; } } catch (e0) {} }
    if (!item) { item = fe_findAdjustment(app.project.rootItem, 0); }
    if (!item && template) {
        var f = new File(template);
        if (f.exists) {
            var bin = fe_getOrCreateBin(app.project.rootItem, FE_BIN_MAIN);
            try { app.project.importFiles([f.fsName], true, bin, false); } catch (e1) {}
            item = fe_findAdjustment(bin, 0) || fe_findAdjustment(app.project.rootItem, 0);
            if (item) { try { item.moveBin(bin); } catch (e2) {} }
        }
    }
    return item;
}

/* efeitos do After: camadas de ajuste com preset no clipe mestre, vindas do molde FE_Efeitos.prproj */
var FE_BIN_FX = 'Fast Edit \u00b7 Efeitos';
function fe_findByName(bin, name, depth) {
    var i, ch, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type !== ProjectItemType.BIN && ch.name === name) { return ch; }
        if (ch.type === ProjectItemType.BIN) { f = fe_findByName(ch, name, depth + 1); if (f) { return f; } }
    }
    return null;
}
function fe_ensureFx(name, tpl) {
    var root = app.project.rootItem, bin = fe_getOrCreateBin(root, FE_BIN_FX), it = fe_findByName(bin, name, 0);
    if (it) { return it; }
    var f = new File(tpl);
    if (!f.exists) { fe_err('Efeito não encontrado na instalação. Reinstale o Fast Edit.'); }
    app.project.importFiles([f.fsName], true, bin, false);
    it = fe_findByName(bin, name, 0);
    if (!it) { fe_err('Não consegui trazer o efeito “' + name + '” para o projeto.'); }
    return it;
}

FE_API.overlay = function (a) {
    var seq = fe_seq();
    var item = null;
    if (a.kind === 'fx') {
        item = fe_ensureFx(a.fxItem, a.fxTemplate);
    } else if (a.kind === 'adjustment') {
        item = fe_ensureAdjustment(a.nodeId, a.template);
        if (!item) { fe_err('Não consegui criar a camada de ajuste neste projeto.'); }
    } else {
        item = fe_importOnce(a.path, FE_BIN_MAIN);
    }
    var fd = fe_frameDur(seq);
    var ranges = [];
    var i, j, sel;
    var mode = a.mode || 'selection';
    var snap = function (t) { return Math.round(t / fd) * fd; };
    var lenSec = (a.frames ? a.frames * fd : (a.seconds || 5));
    /* trilha mais alta ocupada num instante (para a camada ir por cima de tudo) */
    var topAt = function (t) {
        var k, top = -1;
        for (k = 0; k < seq.videoTracks.numTracks; k++) {
            if (!fe_trackFree(seq.videoTracks[k], t, t + fd * 0.5)) { top = k; }
        }
        return top;
    };
    if (mode === 'auto') {
        sel = fe_selected(seq, 'video');
        if (sel.length) { mode = 'perClip'; }
        else { mode = 'playhead'; }
    }
    if (mode === 'playhead') {
        var pp = snap(a.atSec !== undefined && a.atSec !== null ? a.atSec : seq.getPlayerPosition().seconds);
        ranges.push({ s: pp, e: pp + lenSec, from: topAt(pp) + 1 });
    } else if (mode === 'centerPlayhead') {
        var pc = snap(seq.getPlayerPosition().seconds - lenSec / 2);
        ranges.push({ s: Math.max(0, pc), e: Math.max(0, pc) + lenSec, from: topAt(pc + lenSec / 2) + 1 });
    } else if (mode === 'clipStart') {
        sel = fe_requireSel(seq, 'video');
        for (i = 0; i < sel.length; i++) { ranges.push({ s: sel[i].start, e: Math.min(sel[i].end, sel[i].start + lenSec), from: sel[i].track + 1 }); }
    } else if (mode === 'full') {
        ranges.push({ s: 0, e: fe_secOf(seq.end), from: seq.videoTracks.numTracks });
    } else if (mode === 'cuts') {
        sel = fe_selected(seq, 'video');
        if (sel.length < 2) { fe_err('Selecione 2 ou mais takes colados para marcar os cortes entre eles.'); }
        var seen = {}, cut, key;
        for (i = 0; i < sel.length; i++) {
            for (j = 0; j < sel.length; j++) {
                if (i === j) { continue; }
                if (Math.abs(sel[i].end - sel[j].start) < fd * 0.6) {
                    cut = snap(sel[j].start);
                    key = String(Math.round(cut / fd));
                    if (seen[key]) { continue; }
                    seen[key] = true;
                    var half = snap(lenSec / 2);
                    var st = Math.max(0, cut - half);
                    ranges.push({ s: st, e: st + Math.max(fd, snap(lenSec)), from: Math.max(sel[i].track, sel[j].track, topAt(cut)) + 1 });
                }
            }
        }
        if (!ranges.length) { fe_err('Nenhum corte entre os takes selecionados (eles precisam estar colados).'); }
    } else {
        sel = fe_requireSel(seq, 'video');
        if (mode === 'perClip') {
            for (i = 0; i < sel.length; i++) { ranges.push({ s: sel[i].start, e: sel[i].end, from: sel[i].track + 1 }); }
        } else {
            var s0 = 1e9, e0 = -1, top = 0;
            for (i = 0; i < sel.length; i++) {
                if (sel[i].start < s0) { s0 = sel[i].start; }
                if (sel[i].end > e0) { e0 = sel[i].end; }
                if (sel[i].track > top) { top = sel[i].track; }
            }
            ranges.push({ s: s0, e: e0, from: top + 1 });
        }
    }
    var placed = [], ti, clip, qs = null;
    for (i = 0; i < ranges.length; i++) {
        if (ranges[i].e - ranges[i].s < fd) { continue; }
        ti = fe_freeVideoTrack(seq, ranges[i].from, ranges[i].s, a.natural ? ranges[i].s + fd : ranges[i].e);
        clip = fe_place(seq, seq.videoTracks[ti], item, ranges[i].s, a.natural ? 0 : ranges[i].e - ranges[i].s);
        if (clip) {
            if (a.label) { try { clip.name = a.label; } catch (e1) {} }
            placed.push({ clip: clip, track: ti, video: true });
        }
    }
    var lastEnd = null;
    for (i = 0; i < placed.length; i++) { try { lastEnd = placed[i].clip.end.seconds; } catch (eL) {} }
    if (a.fit && placed.length) {
        try {
            var qsf = fe_qeSeq(), qif;
            for (i = 0; i < placed.length; i++) {
                qif = fe_qeItem(qsf, true, placed[i].track, placed[i].clip);
                if (qif) { try { qif.setScaleToFrameSize(); } catch (eF) {} }
            }
        } catch (eQ) {}
    }
    /* opacidade animada do preset (não cabe no clipe mestre): aplica na camada colocada */
    if (a.opacity && a.opacity.length) {
        for (i = 0; i < placed.length; i++) {
            try {
                var oc = fe_comp(placed[i].clip, 'AE.ADBE Opacity'), op = oc ? oc.properties[0] : null, t0o = placed[i].clip.inPoint.seconds, kk;
                if (!op) { continue; }
                op.setTimeVarying(true);
                for (kk = 0; kk < a.opacity.length; kk++) {
                    op.addKey(t0o + a.opacity[kk][0]);
                    op.setValueAtKey(t0o + a.opacity[kk][0], a.opacity[kk][1], kk === a.opacity.length - 1);
                }
            } catch (eO) {}
        }
    }
    var fx = null;
    if (a.effects && a.effects.length && placed.length) {
        try { qs = fe_qeSeq(); fx = fe_applyEffectsTo(qs, placed, a.effects, false); } catch (e2) {}
    }
    return { placed: placed.length, item: item.name, effects: fx, mode: mode, lastEnd: lastEnd };
};

/* --- WORKFLOW: Project Setup ----------------------------------------------- */
function fe_buildTree(parent, nodes, stats) {
    var i, b, existed;
    for (i = 0; i < nodes.length; i++) {
        if (!nodes[i] || !nodes[i].name) { continue; }
        existed = fe_findBin(parent, nodes[i].name);
        b = existed || fe_getOrCreateBin(parent, nodes[i].name);
        if (existed) { stats.skipped++; } else { stats.created++; }
        if (nodes[i].children && nodes[i].children.length) { fe_buildTree(b, nodes[i].children, stats); }
    }
}

FE_API.projectSetup = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var stats = { created: 0, skipped: 0 };
    fe_buildTree(app.project.rootItem, a.tree || [], stats);
    return stats;
};

/* --- WORKFLOW: Project Organizer ------------------------------------------- */
var FE_EXT = {
    video: 'mp4,mov,mxf,avi,mkv,m4v,mts,m2ts,wmv,mpg,mpeg,r3d,braw,webm,3gp,dv,vob,flv,crm,ari',
    audio: 'wav,mp3,aif,aiff,m4a,aac,flac,ogg,wma,bwf',
    image: 'png,jpg,jpeg,tif,tiff,psd,ai,eps,gif,bmp,heic,webp,exr,dpx,tga,svg,dng,cr2,nef,arw',
    graphic: 'mogrt,aegraphic,prtl,aep,aepx,motn'
};

function fe_classify(it) {
    if (fe_isSequenceItem(it)) { return 'seq'; }
    var p = '';
    try { p = it.getMediaPath(); } catch (e) {}
    if (!p) { return 'graphic'; }
    var ext = fe_extOf(p), k;
    for (k in FE_EXT) {
        if (FE_EXT.hasOwnProperty(k) && (',' + FE_EXT[k] + ',').indexOf(',' + ext + ',') >= 0) { return k; }
    }
    return 'other';
}

function fe_collectItems(bin, nested, skipNames, out, depth) {
    var i, ch;
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            if (nested && !skipNames[ch.name] && depth < 10) { fe_collectItems(ch, nested, skipNames, out, depth + 1); }
        } else if (ch.type === ProjectItemType.CLIP || ch.type === ProjectItemType.FILE) {
            out.push(ch);
        }
    }
}

FE_API.organize = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var root = app.project.rootItem;
    var bins = a.bins || {};
    var skip = {}, k;
    for (k in bins) { if (bins.hasOwnProperty(k) && bins[k]) { skip[bins[k]] = true; } }
    skip[FE_BIN_MAIN] = true;
    skip[FE_BIN_SFX] = true;
    var items = [];
    fe_collectItems(root, !!a.nested, skip, items, 0);
    var plan = {}, i, cat;
    for (i = 0; i < items.length; i++) {
        cat = fe_classify(items[i]);
        if (!bins[cat]) { continue; }
        if (!plan[cat]) { plan[cat] = { bin: bins[cat], count: 0, samples: [] }; }
        plan[cat].count++;
        if (plan[cat].samples.length < 4) { plan[cat].samples.push(items[i].name); }
        if (a.apply) {
            var target = fe_getOrCreateBin(root, bins[cat]);
            try { items[i].moveBin(target); } catch (e) {}
        }
    }
    return { plan: plan, total: items.length, applied: !!a.apply };
};

/* --- WORKFLOW: Batch -------------------------------------------------------- */
FE_API.batch = function (a) {
    var seq = fe_seq();
    var op = a.op;
    var kind = (op === 'speed' || op === 'reverse' || op === 'removeEffects' || op === 'label' || op === 'disable' || op === 'enable' || op === 'toggle') ? 'all' : 'video';
    var sel = fe_requireSel(seq, kind);
    var n = 0, fail = 0, i, c, qs = null, qi;
    if (op === 'unlink' || op === 'link') {
        try { if (op === 'unlink') { seq.unlinkSelection(); } else { seq.linkSelection(); } n = sel.length; }
        catch (e0) { fe_err('Sua versão do Premiere não suporta essa operação via script.'); }
        return { done: n, failed: 0 };
    }
    if (op === 'removeEffects' || op === 'scaleToFrame' || op === 'speed' || op === 'reverse') { qs = fe_qeSeq(); }
    for (i = 0; i < sel.length; i++) {
        c = sel[i].clip;
        try {
            if (op === 'disable') { c.disabled = true; }
            else if (op === 'enable') { c.disabled = false; }
            else if (op === 'toggle') { c.disabled = !c.disabled; }
            else if (op === 'label') { c.projectItem.setColorLabel(a.value || 0); }
            else {
                qi = fe_qeItem(qs, sel[i].video, sel[i].track, c);
                if (!qi) { fail++; continue; }
                if (op === 'removeEffects') {
                    try { qi.removeEffects(true, true, true, true, true); } catch (e1) { qi.removeEffects(); }
                } else if (op === 'scaleToFrame') {
                    qi.setScaleToFrameSize();
                } else if (op === 'speed') {
                    qi.setSpeed((a.value || 100) / 100, '', false, !!a.ripple, true);
                } else if (op === 'reverse') {
                    try { qi.setReverse(true); } catch (e2) { qi.setSpeed(1, '', true, false, true); }
                }
            }
            n++;
        } catch (e) { fail++; }
    }
    return { done: n, failed: fail };
};

/* --- WORKFLOW: Sort clips (sem subclipes, preserva efeitos) ---------------- */
function fe_natCmp(a, b) {
    var ax = String(a).toLowerCase().match(/(\d+|\D+)/g) || [];
    var bx = String(b).toLowerCase().match(/(\d+|\D+)/g) || [];
    var i, x, y, nx, ny;
    for (i = 0; i < Math.min(ax.length, bx.length); i++) {
        x = ax[i]; y = bx[i];
        nx = parseInt(x, 10); ny = parseInt(y, 10);
        if (!isNaN(nx) && !isNaN(ny)) { if (nx !== ny) { return nx - ny; } }
        else if (x !== y) { return x < y ? -1 : 1; }
    }
    return ax.length - bx.length;
}

function fe_linked(clip) {
    var out = [];
    try {
        var l = clip.getLinkedItems();
        var i;
        if (l) { for (i = 0; i < l.numItems; i++) { if (l[i].nodeId !== clip.nodeId) { out.push(l[i]); } } }
    } catch (e) {}
    return out;
}

/* Move clip por delta segundos; move vinculados se o Premiere não os mover junto. */
function fe_moveWithLinked(clip, linked, delta) {
    var before = [], i;
    for (i = 0; i < linked.length; i++) { before.push(linked[i].start.seconds); }
    clip.move(fe_time(delta));
    for (i = 0; i < linked.length; i++) {
        if (Math.abs(linked[i].start.seconds - before[i]) < FE_EPS) {
            try { linked[i].move(fe_time(delta)); } catch (e) {}
        }
    }
}

FE_API.sortClips = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var track = sel[0].track, i;
    for (i = 0; i < sel.length; i++) {
        if (sel[i].track !== track) { fe_err('Selecione clipes de UMA única trilha de vídeo.'); }
    }
    if (sel.length < 2) { fe_err('Selecione pelo menos 2 clipes.'); }
    if (typeof sel[0].clip.move !== 'function') { fe_err('Sua versão do Premiere não permite mover clipes via script (requer 2019+).'); }
    var items = [];
    for (i = 0; i < sel.length; i++) {
        items.push({ clip: sel[i].clip, name: sel[i].clip.name, dur: sel[i].end - sel[i].start, linked: fe_linked(sel[i].clip), r: Math.random() });
    }
    var origStart = sel[0].start;
    var mode = a.mode || 'name';
    if (mode === 'name') { items.sort(function (x, y) { return fe_natCmp(x.name, y.name); }); }
    else if (mode === 'nameDesc') { items.sort(function (x, y) { return fe_natCmp(y.name, x.name); }); }
    else if (mode === 'duration') { items.sort(function (x, y) { return x.dur - y.dur; }); }
    else if (mode === 'durationDesc') { items.sort(function (x, y) { return y.dur - x.dur; }); }
    else if (mode === 'shuffle') { items.sort(function (x, y) { return x.r - y.r; }); }
    else if (mode === 'reverse') { items.reverse(); }
    var D = fe_secOf(seq.end) + 30 - origStart;
    for (i = 0; i < items.length; i++) { fe_moveWithLinked(items[i].clip, items[i].linked, D); }
    var cursor = origStart;
    for (i = 0; i < items.length; i++) {
        fe_moveWithLinked(items[i].clip, items[i].linked, cursor - items[i].clip.start.seconds);
        cursor += items[i].dur;
    }
    return { sorted: items.length };
};

/* --- WORKFLOW: Timeline cleaner -------------------------------------------- */
function fe_allClips(seq) {
    var out = [];
    fe_eachClip(seq, function (c, t, v) { out.push({ clip: c, track: t, video: v }); });
    return out;
}

FE_API.closeGaps = function (a) {
    var seq = fe_seq();
    var all = fe_allClips(seq);
    if (!all.length) { return { gaps: 0, seconds: 0 }; }
    if (typeof all[0].clip.move !== 'function') { fe_err('Sua versão do Premiere não permite mover clipes via script (requer 2019+).'); }
    var iv = [], i;
    for (i = 0; i < all.length; i++) { iv.push([all[i].clip.start.seconds, all[i].clip.end.seconds]); }
    iv.sort(function (x, y) { return x[0] - y[0]; });
    var merged = [iv[0].slice(0)];
    for (i = 1; i < iv.length; i++) {
        var last = merged[merged.length - 1];
        if (iv[i][0] <= last[1] + FE_EPS) { if (iv[i][1] > last[1]) { last[1] = iv[i][1]; } }
        else { merged.push(iv[i].slice(0)); }
    }
    var fd = fe_frameDur(seq);
    var minGap = (a && a.minFrames ? a.minFrames : 1) * fd - FE_EPS;
    var gaps = [];
    if (a && a.fromStart && merged[0][0] > minGap) { gaps.push([0, merged[0][0]]); }
    for (i = 1; i < merged.length; i++) {
        if (merged[i][0] - merged[i - 1][1] > minGap) { gaps.push([merged[i - 1][1], merged[i][0]]); }
    }
    var total = 0, g, snap, j, len;
    for (g = gaps.length - 1; g >= 0; g--) {
        len = gaps[g][1] - gaps[g][0];
        all = fe_allClips(seq);
        snap = [];
        for (j = 0; j < all.length; j++) {
            if (all[j].clip.start.seconds >= gaps[g][1] - FE_EPS) { snap.push({ c: all[j].clip, s: all[j].clip.start.seconds }); }
        }
        snap.sort(function (x, y) { return x.s - y.s; });
        for (j = 0; j < snap.length; j++) {
            if (Math.abs(snap[j].c.start.seconds - snap[j].s) > FE_EPS) { continue; }
            try { snap[j].c.move(fe_time(-len)); } catch (e) {}
        }
        total += len;
    }
    return { gaps: gaps.length, seconds: Math.round(total * 100) / 100 };
};

FE_API.removeDisabled = function () {
    var seq = fe_seq();
    var all = fe_allClips(seq), n = 0, i;
    for (i = all.length - 1; i >= 0; i--) {
        if (all[i].clip.disabled) { try { all[i].clip.remove(false, false); n++; } catch (e) {} }
    }
    return { removed: n };
};

FE_API.removeShort = function (a) {
    var seq = fe_seq();
    var fd = fe_frameDur(seq);
    var lim = (a.frames || 3) * fd + FE_EPS;
    var all = fe_allClips(seq), n = 0, i;
    for (i = all.length - 1; i >= 0; i--) {
        var c = all[i].clip;
        if (c.end.seconds - c.start.seconds < lim) { try { c.remove(false, false); n++; } catch (e) {} }
    }
    return { removed: n };
};

FE_API.removeEmptyTracks = function () {
    fe_seq();
    var q = fe_qeSeq(), ok = 0;
    try { q.removeEmptyVideoTracks(); ok++; } catch (e) {}
    try { q.removeEmptyAudioTracks(); ok++; } catch (e2) {}
    if (!ok) { fe_err('Sua versão do Premiere não suporta remover trilhas vazias via script.'); }
    return { ok: true };
};

/* --- WORKFLOW: Social ------------------------------------------------------- */
/* multiplica a escala (Movimento > Escala, inclusive keyframes) de todos os clipes de vídeo */
function fe_scaleSeqClips(seq, k) {
    var t, j, c, m, sp, keys, x, n = 0;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        for (j = 0; j < seq.videoTracks[t].clips.numItems; j++) {
            c = seq.videoTracks[t].clips[j];
            m = c ? fe_comp(c, 'AE.ADBE Motion') : null;
            if (!m) { continue; }
            sp = m.properties[1];
            try {
                if (sp.isTimeVarying()) {
                    keys = fe_keyTimes(sp);
                    for (x = 0; x < keys.length; x++) { sp.setValueAtKey(keys[x], sp.getValueAtKey(keys[x]) * k, x === keys.length - 1); }
                } else {
                    sp.setValue(sp.getValue() * k, true);
                }
                n++;
            } catch (e) {}
        }
    }
    return n;
}

/* deixa a sequência em resolução cheia (ex.: 1080x1920) sem mudar o enquadramento */
function fe_fullRes(ns, w, h) {
    var st = ns.getSettings();
    var ow = st.videoFrameWidth, oh = st.videoFrameHeight;
    if (ow === w && oh === h) { return { w: w, h: h, scaled: 0 }; }
    var k = Math.max(w / ow, h / oh);
    st.videoFrameWidth = w;
    st.videoFrameHeight = h;
    try { if (st.previewFrameWidth !== undefined) { st.previewFrameWidth = w; st.previewFrameHeight = h; } } catch (e0) {}
    ns.setSettings(st);
    return { w: w, h: h, from: ow + 'x' + oh, scaled: fe_scaleSeqClips(ns, k) };
}

FE_API.socialSequence = function (a) {
    var seq = fe_seq();
    var name = a.name || (seq.name + ' ' + a.label);
    var before = {}, i, ns = null, method = 'clone';
    for (i = 0; i < app.project.sequences.numSequences; i++) { before[app.project.sequences[i].sequenceID] = true; }
    var findNew = function () {
        var j, found = null;
        for (j = 0; j < app.project.sequences.numSequences; j++) {
            if (!before[app.project.sequences[j].sequenceID]) { found = app.project.sequences[j]; }
        }
        return found;
    };
    if (a.autoReframe && typeof seq.autoReframeSequence === 'function') {
        try { ns = seq.autoReframeSequence(a.num, a.den, 'default', name, false); } catch (e) { ns = null; }
        if (ns && !ns.getSettings) { ns = findNew(); }
        if (ns) { method = 'autoReframe'; }
    }
    if (!ns) {
        seq.clone();
        ns = findNew();
        if (!ns) { fe_err('Não foi possível duplicar a sequência.'); }
        try { ns.name = name; } catch (e1) {}
    }
    var res = null;
    try { res = fe_fullRes(ns, a.w, a.h); } catch (e2) { res = null; }
    try { app.project.openSequence(ns.sequenceID); } catch (e3) {}
    return { name: name, method: method, size: res ? res.w + 'x' + res.h : '', from: res && res.from ? res.from : '' };
};

function fe_guideClips(seq) {
    var all = fe_allClips(seq), out = [], i, nm;
    for (i = 0; i < all.length; i++) {
        nm = '';
        try { nm = all[i].clip.projectItem.name; } catch (e) {}
        if (nm.indexOf(FE_GUIDE_PREFIX) === 0 || all[i].clip.name.indexOf(FE_GUIDE_PREFIX) === 0) { out.push(all[i].clip); }
    }
    return out;
}

FE_API.guidesState = function () {
    var seq = app.project ? app.project.activeSequence : null;
    if (!seq) { return { count: 0, visible: false }; }
    var g = fe_guideClips(seq), vis = false, i;
    for (i = 0; i < g.length; i++) { if (!g[i].disabled) { vis = true; } }
    return { count: g.length, visible: vis };
};

/* esconde/mostra as guias (desativa o clipe — não apaga nada) */
FE_API.toggleGuides = function (a) {
    var seq = fe_seq();
    var g = fe_guideClips(seq), i;
    if (!g.length) { fe_err('Não há guia nesta sequência. Adicione uma primeiro.'); }
    var visible = (a && a.visible !== undefined) ? !!a.visible : !!g[0].disabled;
    for (i = 0; i < g.length; i++) { try { g[i].disabled = !visible; } catch (e) {} }
    return { count: g.length, visible: visible };
};

FE_API.removeGuides = function () {
    var seq = fe_seq();
    var all = fe_allClips(seq), n = 0, i, nm;
    for (i = all.length - 1; i >= 0; i--) {
        nm = '';
        try { nm = all[i].clip.projectItem.name; } catch (e) {}
        if (nm.indexOf(FE_GUIDE_PREFIX) === 0 || all[i].clip.name.indexOf(FE_GUIDE_PREFIX) === 0) {
            try { all[i].clip.remove(false, false); n++; } catch (e2) {}
        }
    }
    return { removed: n };
};

/* --- Copiar frame -------------------------------------------------------------- */
/* --- ANIMATE: Rastro de luz (Time Blur) ------------------------------------
   Eco nativo (frames anteriores somados) + desfoque leve. O comprimento do
   rastro e o brilho seguem a curva do look, assada em keyframes por frame. */
function fe_findVideoEffect(rx, fallbackRx) {
    var q = fe_qe(), list = [], i, eff;
    try { list = fe_toList(q.project.getVideoEffectList()); } catch (e) {}
    for (i = 0; i < list.length; i++) { if (rx.test(list[i])) { eff = q.project.getVideoEffectByName(list[i]); if (eff) { return eff; } } }
    if (fallbackRx) {
        for (i = 0; i < list.length; i++) { if (fallbackRx.test(list[i])) { eff = q.project.getVideoEffectByName(list[i]); if (eff) { return eff; } } }
    }
    return null;
}

function fe_lastComp(clip, mrx, nrx) {
    var i, c, found = null;
    for (i = 0; i < clip.components.numItems; i++) {
        c = clip.components[i];
        if (!c) { continue; }
        if (mrx.test(c.matchName || '') || (nrx && nrx.test(c.displayName || ''))) { found = c; }
    }
    return found;
}

function fe_tbNoise(i) {
    var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
}

/* valor suave de ruído (interpolado) para o tremido rápido */
function fe_tbSmooth(t, rate) {
    var x = t * rate, i = Math.floor(x), f = x - i;
    f = f * f * (3 - 2 * f);
    return fe_tbNoise(i) + (fe_tbNoise(i + 1) - fe_tbNoise(i)) * f;
}

function fe_tbClearParam(p) {
    try { if (p.isTimeVarying()) { p.setTimeVarying(false); } } catch (e) {}
}

function fe_tbKeys(p, times, vals) {
    var i;
    try { p.setTimeVarying(true); } catch (e) { return 0; }
    try { p.removeKeyRange(times[0] - 0.001, times[times.length - 1] + 0.001, true); } catch (e1) {}
    for (i = 0; i < times.length; i++) {
        try {
            p.addKey(times[i]);
            p.setValueAtKey(times[i], vals[i], (i === times.length - 1));
            p.setInterpolationTypeAtKey(times[i], 0, false);
        } catch (e2) {}
    }
    return times.length;
}

/* desfoque do rastro: Fast Blur > Gaussian Blur (Legacy) > Gaussian Blur. Reconhece pelo matchName e acha o
   controle de intensidade pelo NOME (a ordem dos parâmetros muda entre versões). */
var FE_TB_BLUR_MN = /ADBE Fast Blur|ADBE Gaussian Blur|Impact_Blur_FX|ADBE Box Blur/i;
function fe_tbBlurEffect() {
    var order = [/^fast blur$/i, /^desfoque r[aá]pido$/i, /^gaussian blur \(legacy\)$/i, /^desfoque gaussiano \((herdado|legado)\)$/i, /^gaussian blur$/i, /^desfoque gaussiano$/i], i, e;
    for (i = 0; i < order.length; i++) { e = fe_findVideoEffect(order[i], null); if (e) { return e; } }
    return null;
}
function fe_tbBlurParam(comp) {
    var i, p, nm, first = null, v;
    if (!comp) { return null; }
    for (i = 0; i < comp.properties.numItems; i++) {
        p = comp.properties[i]; nm = '';
        try { nm = p.displayName || ''; } catch (e) {}
        if (/blurriness|desfoque|amount|quantidade|intensidade|radius|raio/i.test(nm)) { return p; }
        if (!first) { try { v = p.getValue(); if (typeof v === 'number' && !/seed|angle|[aâ]ngulo|version|width|height|mode|ratio/i.test(nm)) { first = p; } } catch (e2) {} }
    }
    return first;
}

/* depois de adicionar efeito via QE, o objeto do clipe pode ter a lista de efeitos antiga: relê pelo nodeId */
function fe_refetch(seq, trackIdx, clip) {
    var tr = seq.videoTracks[trackIdx], j, c, id = clip.nodeId;
    if (!tr) { return clip; }
    for (j = 0; j < tr.clips.numItems; j++) { c = tr.clips[j]; if (c && c.nodeId === id) { return c; } }
    return clip;
}

FE_API.timeBlur = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var echoRx = /ADBE Echo/i, echoName = /^(echo|eco)$/i;
    var blurRx = FE_TB_BLUR_MN;
    var res = { clips: 0, keys: 0, missing: false };
    var echoEff = null, blurEff = null, i, j;

    if (a.remove) {
        /* Desligar = tira o Eco e o desfoque do rastro do clipe (QE component.remove) */
        for (i = 0; i < sel.length; i++) {
            var qr = fe_qeItem(qs, true, sel[i].track, sel[i].clip), removed = 0, ci, qc, mn;
            if (!qr) { continue; }
            for (ci = qr.numComponents - 1; ci >= 0; ci--) {
                qc = qr.getComponentAt(ci); mn = '';
                try { mn = qc.matchName || ''; } catch (eq) {}
                if (/ADBE Echo/i.test(mn) || FE_TB_BLUR_MN.test(mn)) { try { qc.remove(); removed++; } catch (er) {} }
            }
            if (!removed) {   /* versões sem remove(): neutraliza */
                var ce = fe_lastComp(sel[i].clip, echoRx, echoName);
                if (ce) { fe_tbClearParam(ce.properties[0]); try { ce.properties[1].setValue(0, true); } catch (er1) {} removed++; }
            }
            if (removed) { res.clips++; }
        }
        return res;
    }

    var S = a.samples || [0, 1];
    var period = a.period || 2;
    var maxF = Math.max(1, a.streak || 2.5);           /* distância entre ecos (frames) no pico */
    var minF = 1;
    var pulse = a.pulse === undefined ? 1 : a.pulse;      /* quanto a curva move o rastro */
    var shimmer = a.shimmer === undefined ? 0.12 : a.shimmer;
    var n = Math.max(1, Math.round(a.echoes || 6));
    var mix = a.mix === undefined ? 0.5 : a.mix;
    var glow = a.glow || 0;
    var step = Math.max(1, a.step || 1);
    var decay = a.decay || Math.min(0.92, 0.5 + 0.4 * mix);
    var sum = 0, k;
    for (k = 0; k <= n; k++) { sum += Math.pow(decay, k); }
    var gain = a.light ? (1.05 + 0.45 * mix) : 1;
    var startI = Math.min(1, gain / sum);

    for (i = 0; i < sel.length; i++) {
        var clip = sel[i].clip;
        var qi = null;
        var comp = fe_lastComp(clip, echoRx, echoName);
        /* o desfoque entra ANTES do eco: o rastro sai borrado (desfoque de movimento) */
        if (!comp && glow > 0 && !fe_lastComp(clip, blurRx, null)) {
            if (!blurEff) { blurEff = fe_tbBlurEffect(); }
            qi = fe_qeItem(qs, true, sel[i].track, clip);
            try { if (qi && blurEff) { qi.addVideoEffect(blurEff); clip = fe_refetch(seq, sel[i].track, clip); } } catch (eb) {}
        }
        if (!comp) {
            if (!echoEff) { echoEff = fe_findVideoEffect(echoName, /echo|\beco\b/i); }
            if (!echoEff) { res.missing = true; fe_err('Efeito Eco (Echo) não encontrado no Premiere.'); }
            if (!qi) { qi = fe_qeItem(qs, true, sel[i].track, clip); }
            if (!qi) { continue; }
            try { qi.addVideoEffect(echoEff); } catch (e0) { continue; }
            clip = fe_refetch(seq, sel[i].track, clip);
            comp = fe_lastComp(clip, echoRx, echoName);
            if (!comp) { continue; }
        }
        var P = comp.properties;
        /* operador: Máximo = só as partes claras deixam rastro (destaques); Mistura = rastro em tudo.
           Ordem do menu: Add, Maximum, Minimum, Screen, Comp. atrás, Comp. frente, Blend. Descobre se começa em 0 ou 1. */
        try {
            var opP = P[4], cur = opP.getValue();
            if ($._FE_ECHO_BASE === undefined) { $._FE_ECHO_BASE = (cur === 0) ? 0 : 1; }
            opP.setValue((a.light ? 1 : 6) + $._FE_ECHO_BASE, true);
        } catch (e1) {}
        try { P[1].setValue(n, true); } catch (e2) {}
        try { P[2].setValue(a.light ? 1 : startI, true); } catch (e3) {}

        /* tempos (mídia) e valores */
        var t0 = clip.inPoint.seconds, t1 = clip.outPoint.seconds;
        var len = Math.max(fd, t1 - t0);
        var times = [], echoV = [], blurV = [], decV = [], t, u, p, f, q;
        var count = Math.round(len / (fd * step));
        if (count > 1500) { step = Math.ceil(len / fd / 1500); count = Math.round(len / (fd * step)); }
        for (j = 0; j <= count; j++) {
            t = t0 + Math.min(len, j * fd * step);
            u = a.loop === false ? (t - t0) / len : ((t - t0) / period) % 1;
            p = fe_curveAt(S, u);
            p = p + shimmer * (fe_tbSmooth(t - t0, 9) - 0.5) * 2;
            p = Math.max(0, Math.min(1.2, p));
            q = Math.min(1, 1 - pulse + pulse * p);       /* 0 = sem rastro, 1 = rastro cheio */
            f = minF + (maxF - minF) * q;
            times.push(t);
            echoV.push(-f * fd);
            decV.push(0.08 + (decay - 0.08) * q);          /* a força do rastro "respira" com a curva */
            blurV.push(glow * (0.15 + 0.85 * q));
        }
        res.keys += fe_tbKeys(P[0], times, echoV);
        res.keys += fe_tbKeys(P[3], times, decV);

        if (glow > 0) {
            var bc = fe_lastComp(clip, blurRx, null);
            if (!bc) {
                if (!blurEff) { blurEff = fe_tbBlurEffect(); }
                if (blurEff) {
                    var qi2 = fe_qeItem(qs, true, sel[i].track, clip);
                    try { if (qi2) { qi2.addVideoEffect(blurEff); } } catch (e5) {}
                    clip = fe_refetch(seq, sel[i].track, clip);
                    bc = fe_lastComp(clip, blurRx, null);
                }
            }
            var bcp = fe_tbBlurParam(bc);
            if (bcp) { res.keys += fe_tbKeys(bcp, times, blurV); }
        } else {
            var bc0 = fe_lastComp(clip, blurRx, null);
            var bp0 = fe_tbBlurParam(bc0);
            if (bp0) { fe_tbClearParam(bp0); try { bp0.setValue(0, true); } catch (e6) {} }
        }
        res.clips++;
    }
    return res;
};

/* --- AFTER MOVIE: efeito em cada marcador (batida) -------------------------- */
FE_API.beatFx = function (a) {
    var seq = fe_seq();
    var fd = fe_frameDur(seq);
    var times = [], m = seq.markers.getFirstMarker();
    while (m) { times.push(m.start.seconds); m = seq.markers.getNextMarker(m); }
    if (!times.length) { fe_err('Marque as batidas com a tecla M na timeline.'); }
    var dur = (a.frames || 6) * fd, I = a.intensity || 1, preset = a.preset || 'punch';
    var done = 0, skipped = 0, i, t, ti, c, j, clip, tr;
    for (i = 0; i < times.length; i++) {
        t = times[i] + 0.0005;
        clip = null;
        for (ti = seq.videoTracks.numTracks - 1; ti >= 0 && !clip; ti--) {
            tr = seq.videoTracks[ti];
            for (j = 0; j < tr.clips.numItems; j++) {
                c = tr.clips[j];
                if (!c || c.start.seconds > t || c.end.seconds <= t) { continue; }
                try { if (c.disabled) { continue; } } catch (e0) {}
                try { if (c.projectItem && c.projectItem.isAdjustmentLayer && c.projectItem.isAdjustmentLayer()) { continue; } } catch (e1) {}
                if (fe_comp(c, 'AE.ADBE Motion')) { clip = c; break; }
            }
        }
        if (!clip) { skipped++; continue; }
        try { fe_animateSingle(seq, clip, preset, dur, true, false, I, times[i]); done++; } catch (e2) { skipped++; }
    }
    return { markers: times.length, done: done, skipped: skipped, times: times };
};

/* --- AFTER MOVIE: Transição em grid (quadrículas trocando de A para B) -------------------
   Cópia do take B por cima, revelada em blocos (Block Dissolve com bloco = tela/colunas x tela/filas);
   embaixo dela, depois do corte, uma cópia do fim do take A mostra os blocos que ainda não trocaram.
   Linhas = PNG de grade por cima. Clarão = Tint animado nos blocos já trocados. */
function fe_param(comp, rx) {
    var i, p;
    if (!comp) { return null; }
    for (i = 0; i < comp.properties.numItems; i++) { p = comp.properties[i]; try { if (rx.test(p.displayName)) { return p; } } catch (e) {} }
    return null;
}
function fe_addFx(seq, trackIdx, clip, name) {
    var qs = fe_qeSeq(), qi = fe_qeItem(qs, true, trackIdx, clip), eff = fe_findVideoEffect(new RegExp('^' + name.replace(/[&()]/g, '.') + '$', 'i'), null);
    if (!qi || !eff) { return null; }
    try { qi.addVideoEffect(eff); } catch (e) { return null; }
    clip = fe_refetch(seq, trackIdx, clip);
    var i, c, found = null;
    for (i = 0; i < clip.components.numItems; i++) { c = clip.components[i]; if (c && c.displayName === name) { found = c; } }
    return { clip: clip, comp: found };
}
function fe_setKeys(p, pts) {
    var i;
    try { p.setTimeVarying(true); } catch (e) { return; }
    for (i = 0; i < pts.length; i++) { try { p.addKey(pts[i][0]); p.setValueAtKey(pts[i][0], pts[i][1], i === pts.length - 1); } catch (e2) {} }
}
/* coloca um trecho de mídia (srcIn..srcIn+dur) de um item, só vídeo, na trilha/tempo */
function fe_placeRange(seq, trackIdx, item, start, srcIn, dur) {
    var oi = null, oo = null, clip = null, fd = fe_frameDur(seq);
    try { oi = item.getInPoint(1).seconds; oo = item.getOutPoint(1).seconds; } catch (e) {}
    try { item.setInPoint(srcIn, 4); item.setOutPoint(srcIn + dur, 4); } catch (e1) {}
    var aBefore = fe_audioSnapshot(seq);
    seq.videoTracks[trackIdx].overwriteClip(item, start);
    clip = fe_clipAt(seq.videoTracks[trackIdx], start, fd * 0.75);
    fe_dropNewAudio(seq, aBefore);
    try { if (oi !== null) { item.setInPoint(oi, 4); item.setOutPoint(oo, 4); } } catch (e2) {}
    if (clip) { try { clip.end = fe_time(start + dur); } catch (e3) {} }
    return clip;
}
/* garante que nenhum áudio novo fique na timeline (overwriteClip pode trazer o áudio junto) */
function fe_audioSnapshot(seq) {
    var t, j, snap = {};
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        for (j = 0; j < seq.audioTracks[t].clips.numItems; j++) { snap[seq.audioTracks[t].clips[j].nodeId] = true; }
    }
    return snap;
}
function fe_dropNewAudio(seq, snap) {
    var t, j, c;
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        for (j = seq.audioTracks[t].clips.numItems - 1; j >= 0; j--) {
            c = seq.audioTracks[t].clips[j];
            if (!snap[c.nodeId]) { try { c.remove(false, false); } catch (e) {} }
        }
    }
}

/* ordem em que as quadrículas trocam */
function fe_gridOrder(cols, rows, pattern, seed) {
    var cells = [], r, c, i, j, t, x = (seed || 1) >>> 0;
    var rnd = function () { x = (x * 1664525 + 1013904223) % 4294967296; return x / 4294967296; };
    for (r = 0; r < rows; r++) { for (c = 0; c < cols; c++) { cells.push({ c: c, r: r, k: 0 }); } }
    var cx = (cols - 1) / 2, cy = (rows - 1) / 2;
    for (i = 0; i < cells.length; i++) {
        c = cells[i].c; r = cells[i].r;
        if (pattern === 'center') { cells[i].k = -Math.sqrt((c - cx) * (c - cx) + (r - cy) * (r - cy)) + rnd() * 0.3; }
        else if (pattern === 'out') { cells[i].k = Math.sqrt((c - cx) * (c - cx) + (r - cy) * (r - cy)) + rnd() * 0.3; }
        else if (pattern === 'left') { cells[i].k = c + rnd() * 0.5; }
        else if (pattern === 'top') { cells[i].k = r + rnd() * 0.5; }
        else if (pattern === 'diag') { cells[i].k = c + r + rnd() * 0.5; }
        else { cells[i].k = rnd(); }
    }
    for (i = 1; i < cells.length; i++) { t = cells[i]; j = i - 1; while (j >= 0 && cells[j].k > t.k) { cells[j + 1] = cells[j]; j--; } cells[j + 1] = t; }
    return cells;
}

FE_API.gridTransition = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq);
    var cols = Math.max(1, Math.min(12, a.cols || 5)), rows = Math.max(1, Math.min(12, a.rows || 5));
    var d = Math.max(4, a.frames || 18) * fd;
    var sel = fe_requireSel(seq, 'video'), pairs = [], i, j, k;
    for (i = 0; i < sel.length; i++) {
        for (j = 0; j < sel.length; j++) {
            if (i !== j && sel[i].track === sel[j].track && Math.abs(sel[i].end - sel[j].start) < fd * 0.6) { pairs.push([sel[i], sel[j]]); }
        }
    }
    if (!pairs.length) { fe_err('Selecione 2 ou mais takes colados na mesma trilha.'); }
    var snap = function (t) { return Math.round(t / fd) * fd; };
    var lines = null, done = 0, warn = 0;
    if (a.linesPng) { try { lines = fe_importOnce(a.linesPng, FE_BIN_MAIN); } catch (eL) { lines = null; } }
    var bin = fe_getOrCreateBin(app.project.rootItem, 'Fast Edit · Grid');
    var mainId = seq.sequenceID;
    var copyMotion = function (src, dst) {
        var ms = fe_comp(src, 'AE.ADBE Motion'), md = fe_comp(dst, 'AE.ADBE Motion'), q;
        if (!ms || !md) { return; }
        for (q = 0; q < ms.properties.numItems && q < md.properties.numItems; q++) {
            try { if (!ms.properties[q].isTimeVarying()) { md.properties[q].setValue(ms.properties[q].getValue(), true); } } catch (em) {}
        }
    };
    for (i = 0; i < pairs.length; i++) {
        var A = pairs[i][0].clip, B = pairs[i][1].clip, tr = pairs[i][0].track, cut = snap(B.start.seconds);
        var half = snap(d / 2), hA = 0;
        try { hA = A.projectItem.getOutPoint(1).seconds - A.outPoint.seconds; } catch (eh) { hA = 0; }
        var pre = Math.min(half, snap(Math.max(0, B.inPoint.seconds))), post = Math.min(half, snap(Math.max(0, hA)));
        if (pre < half || post < half) { warn++; }
        var D = pre + post;
        if (D < fd * 3) { continue; }
        var T0 = cut - pre, aIn = A.outPoint.seconds - pre, bIn = B.inPoint.seconds - pre;
        /* sequência aninhada com as quadrículas */
        var ns = app.project.createNewSequenceFromClips('Grid ' + cols + 'x' + rows, [A.projectItem], bin);
        if (!ns) { fe_err('Não consegui criar a sequência do grid.'); }
        try { ns.setSettings(seq.getSettings()); } catch (eS) {}
        app.project.openSequence(ns.sequenceID);
        var t, c2;
        for (t = 0; t < ns.videoTracks.numTracks; t++) { for (c2 = ns.videoTracks[t].clips.numItems - 1; c2 >= 0; c2--) { ns.videoTracks[t].clips[c2].remove(false, false); } }
        for (t = 0; t < ns.audioTracks.numTracks; t++) { for (c2 = ns.audioTracks[t].clips.numItems - 1; c2 >= 0; c2--) { ns.audioTracks[t].clips[c2].remove(false, false); } }
        var cells = fe_gridOrder(cols, rows, a.pattern || 'random', a.seed || 7), N = cells.length;
        var need = N + (lines ? 2 : 1);
        while (ns.videoTracks.numTracks < need) { if (fe_addVideoTrack(ns) < 0) { break; } }
        /* base: A inteiro durante a janela */
        var base = fe_placeRange(ns, 0, A.projectItem, 0, aIn, D);
        if (base) { copyMotion(A, base); }
        var spanEnd = Math.max(fd, D - Math.max(1, a.flashFrames || 4) * fd - fd);
        var col = a.flashColor || [140, 220, 40], inten = a.flashIntensity === undefined ? 100 : a.flashIntensity, ff = Math.max(1, a.flashFrames || 4) * fd;
        for (k = 0; k < N; k++) {
            var tk = snap((N > 1 ? k / (N - 1) : 0) * spanEnd);
            if (tk >= D - fd) { tk = D - fd; }
            var tile = fe_placeRange(ns, k + 1, B.projectItem, tk, bIn + tk, D - tk);
            if (!tile) { continue; }
            copyMotion(B, tile);
            var cr = fe_addFx(ns, k + 1, tile, 'Crop');
            if (cr && cr.comp) {
                tile = cr.clip;
                var cc = cells[k];
                var pl = fe_param(cr.comp, /^left|esquerd/i), pt = fe_param(cr.comp, /^top|superior/i), pr = fe_param(cr.comp, /^right|direit/i), pb = fe_param(cr.comp, /^bottom|inferior/i);
                try { pl.setValue(cc.c / cols * 100, true); pr.setValue((cols - cc.c - 1) / cols * 100, true); pt.setValue(cc.r / rows * 100, true); pb.setValue((rows - cc.r - 1) / rows * 100, true); } catch (eC) {}
            }
            if (a.flash !== false && inten > 0) {
                var rt = fe_addFx(ns, k + 1, tile, 'Tint');
                if (rt && rt.comp) {
                    var m0 = rt.clip.inPoint.seconds;
                    var p1 = fe_param(rt.comp, /black|preto/i), p2 = fe_param(rt.comp, /white|branco/i), pa = fe_param(rt.comp, /amount|quantidade/i);
                    try { p1.setColorValue(255, col[0], col[1], col[2], true); p2.setColorValue(255, col[0], col[1], col[2], true); } catch (e6) {}
                    if (pa) { fe_setKeys(pa, [[m0, inten], [m0 + ff, 0]]); }
                }
            }
        }
        if (lines) {
            var cl = fe_place(ns, ns.videoTracks[N + 1], lines, 0, D);
            if (cl) { try { cl.name = 'Linhas'; } catch (eN) {} }
        }
        /* volta para a sequência principal e põe o grid por cima do corte */
        app.project.openSequence(mainId);
        seq = app.project.activeSequence;
        var ti = fe_freeVideoTrack(seq, tr + 1, T0, T0 + D);
        var snapA = fe_audioSnapshot(seq);
        var nest = fe_place(seq, seq.videoTracks[ti], ns.projectItem, T0, D);
        fe_dropNewAudio(seq, snapA);
        if (nest) { try { nest.name = 'Grid ' + cols + 'x' + rows; } catch (eN2) {} done++; }
    }
    return { cuts: done, clipped: warn };
};

/* o Premiere exige caminho nativo (\\ no Windows) e sempre acrescenta ".png" */
function fe_exportPNG(qs, tc, path) {
    var base = String(path).replace(/\.png$/i, '');
    qs.exportFramePNG(tc, new File(base).fsName);
    return base + '.png';
}
FE_API.exportFrame = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var f = new File(a.path);
    try { if (f.exists) { f.remove(); } } catch (e0) {}
    var tc = null;
    try { tc = seq.CTI.timecode; } catch (e1) {}
    var ok = false, lastErr = '';
    if (tc) { try { fe_exportPNG(qs, tc, a.path); ok = true; } catch (e2) { lastErr = e2.message; } }
    if (!ok) {
        try {
            var fd = fe_frameDur(seq);
            var fr = Math.round(seq.getPlayerPosition().seconds / fd);
            fe_exportPNG(qs, fe_timecode(fr, 1 / fd), a.path);
            ok = true;
        } catch (e3) { lastErr = e3.message; }
    }
    if (!ok) { fe_err('Sua versão do Premiere não permite exportar frame via script. ' + lastErr); }
    return { path: a.path, w: seq.frameSizeHorizontal, h: seq.frameSizeVertical };
};

/* --- SFX -------------------------------------------------------------------- */
FE_API.placeSfx = function (a) {
    var seq = fe_seq();
    var item = fe_importOnce(a.path, FE_BIN_SFX);
    var fd = fe_frameDur(seq);
    var off = (a.offsetFrames || 0) * fd;
    var times = [], i;
    var mode = a.mode || 'playhead';
    if (mode === 'playhead') {
        times.push(seq.getPlayerPosition().seconds);
    } else if (mode === 'selection') {
        var sel = fe_requireSel(seq, 'video');
        var seen = {};
        for (i = 0; i < sel.length; i++) {
            var k = String(Math.round(sel[i].start / fd));
            if (!seen[k]) { seen[k] = true; times.push(sel[i].start); }
        }
    } else if (mode === 'markers') {
        var m = seq.markers.getFirstMarker();
        while (m) {
            times.push(m.start.seconds);
            m = seq.markers.getNextMarker(m);
        }
        if (!times.length) { fe_err('A sequência não tem marcadores.'); }
    } else if (mode === 'times') {
        times = a.times || [];
    }
    var dur = 1;
    try { dur = item.getOutPoint().seconds - item.getInPoint().seconds; } catch (e) {}
    if (!dur || dur <= 0) { dur = 1; }
    var pref = Math.max(0, (a.track || 1) - 1);
    var placed = 0, t, ti;
    for (i = 0; i < times.length; i++) {
        t = Math.max(0, times[i] + off);
        ti = fe_freeAudioTrack(seq, pref, t, t + dur);
        seq.audioTracks[ti].overwriteClip(item, t);
        placed++;
        if (a.gainDb) {
            var c = fe_clipAt(seq.audioTracks[ti], t, fd);
            if (c) {
                try {
                    var vol = fe_comp(c, 'audioeffect.volume') || c.components[0];
                    var lvl = vol.properties[1];
                    var cur = lvl.getValue();
                    lvl.setValue(cur * Math.pow(10, a.gainDb / 20), true);
                } catch (e2) {}
            }
        }
    }
    return { placed: placed, item: item.name };
};

FE_API.addMarker = function (a) {
    var seq = fe_seq(), t = seq.getPlayerPosition().seconds, m = seq.markers.createMarker(t);
    try { if (a && a.name) { m.name = a.name; } } catch (e) {}
    return { at: t };
};

FE_API.markerTimes = function () {
    var seq = fe_seq(), out = [];
    var m = seq.markers.getFirstMarker();
    while (m) { out.push(m.start.seconds); m = seq.markers.getNextMarker(m); }
    return out;
};

/* ------------------------------------------------------------------ Match cut */
function fe_findClipNode(seq, id) {
    var t, c, tr;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        tr = seq.videoTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) { if (tr.clips[c].nodeId === id) { return { clip: tr.clips[c], track: t }; } }
    }
    return null;
}
function fe_copyMotion(src, dst) {
    var ms = fe_comp(src, 'AE.ADBE Motion'), md = fe_comp(dst, 'AE.ADBE Motion'), q;
    if (!ms || !md) { return; }
    for (q = 0; q < ms.properties.numItems && q < md.properties.numItems; q++) {
        try { md.properties[q].setValue(fe_baseVal(ms.properties[q], src.inPoint.seconds), true); } catch (em) {}
    }
}
/* lê os takes selecionados e exporta o primeiro frame de cada um (para achar o assunto) */
FE_API.matchRead = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), qs = fe_qeSeq();
    var sel = fe_requireSel(seq, 'video'), out = [], seen = {}, i, s, path, f, tc, ok;
    var cti = seq.getPlayerPosition().ticks;
    try { var fo = new Folder(a.dir); if (!fo.exists) { fo.create(); } } catch (eF) {}
    for (i = 0; i < sel.length && out.length < 40; i++) {
        s = sel[i];
        if (seen[s.clip.nodeId] || !s.clip.projectItem) { continue; }
        seen[s.clip.nodeId] = true;
        path = a.dir + '/mc_' + out.length + '_' + (new Date().getTime() % 100000) + '.png';
        f = new File(path);
        try { if (f.exists) { f.remove(); } } catch (e0) {}
        ok = false;
        try {
            seq.setPlayerPosition(String(Math.round((Math.round(s.start / fd) + 0.5) * fd * FE_TPS)));
            tc = qs.CTI.timecode;
            path = fe_exportPNG(qs, tc, path); ok = true;
        } catch (e1) {}
        out.push({ id: s.clip.nodeId, name: s.clip.name, track: s.track, start: s.start, dur: s.end - s.start, png: ok ? path : '' });
    }
    try { seq.setPlayerPosition(cti); } catch (e2) {}
    if (out.length < 2) { fe_err('Selecione 2 ou mais takes de vídeo na timeline.'); }
    return { takes: out, w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, fps: 1 / fd, at: seq.getPlayerPosition().seconds, markers: FE_API.markerTimes() };
};
/* monta o match cut no cursor: cuts = [{id, frames, k, c:[x,y], t:[x,y]}] (c e t de 0 a 1) */
FE_API.matchCut = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), cuts = a.cuts || [], i, total = 0;
    if (cuts.length < 2) { fe_err('Leia os takes primeiro.'); }
    for (i = 0; i < cuts.length; i++) { total += Math.max(1, cuts[i].frames) * fd; }
    var T0 = Math.round(seq.getPlayerPosition().seconds / fd) * fd, T = T0;
    var trackIdx = fe_freeVideoTrack(seq, a.track || 0, T0, T0 + total);
    var used = {}, placed = 0, tooShort = 0, cut, src, dur, srcIn, clip, P, sP, k, s0, p0, ctx, nx, ny, avail;
    for (i = 0; i < cuts.length; i++) {
        cut = cuts[i]; dur = Math.max(1, cut.frames) * fd;
        src = fe_findClipNode(seq, cut.id);
        if (!src || !src.clip.projectItem) { T += dur; continue; }
        srcIn = src.clip.inPoint.seconds + (used[cut.id] || 0);
        avail = src.clip.end.seconds - src.clip.start.seconds - (used[cut.id] || 0);
        if (avail < dur - fd * 0.5) { srcIn = src.clip.inPoint.seconds; if (src.clip.end.seconds - src.clip.start.seconds < dur) { tooShort++; } }
        used[cut.id] = (srcIn - src.clip.inPoint.seconds) + dur;
        clip = fe_placeRange(seq, trackIdx, src.clip.projectItem, T, srcIn, dur);
        if (clip) {
            placed++;
            fe_copyMotion(src.clip, clip);
            if (cut.k && cut.c && cut.t) {
                P = fe_params(clip);
                k = cut.k;
                if (P.scale) { s0 = fe_baseVal(P.scale, clip.inPoint.seconds); try { P.scale.setValue(s0 * k, true); } catch (e1) {} }
                if (P.pos) {
                    p0 = fe_baseVal(P.pos, clip.inPoint.seconds);
                    ctx = fe_ctxFor(seq, p0, 1);
                    nx = cut.t[0] - k * (cut.c[0] - p0[0] / ctx.ux);
                    ny = cut.t[1] - k * (cut.c[1] - p0[1] / ctx.uy);
                    try { P.pos.setValue([nx * ctx.ux, ny * ctx.uy], true); } catch (e2) {}
                }
            }
        }
        T += dur;
    }
    return { placed: placed, start: T0, end: T, track: trackIdx + 1, tooShort: tooShort };
};

/* ------------------------------------------------------------------ Despachante */
$._FE = {
    version: '2.18.1',
    run: function (name, argStr) {
        var J = $._FEJSON;
        try {
            var fn = FE_API[name];
            if (!fn) { return J.stringify({ ok: false, error: 'Função desconhecida: ' + name }); }
            var args = argStr ? J.parse(argStr) : {};
            var data = fn(args || {});
            return J.stringify({ ok: true, data: data === undefined ? null : data });
        } catch (e) {
            return J.stringify({ ok: false, error: String(e && e.message ? e.message : e), line: e && e.line ? e.line : null });
        }
    }
};

'FastEdit host ready';
