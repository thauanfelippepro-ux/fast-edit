/* Fast Edit 2.12.1 — feito por @odalluz */
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
if (!Object.assign) {
  Object.assign = function (t) {
    for (var i = 1; i < arguments.length; i++) {
      var s = arguments[i];
      if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) t[k] = s[k];
    }
    return t;
  };
}
if (!Object.values) Object.values = function (o) {
  return Object.keys(o).map(function (k) {
    return o[k];
  });
};
if (!Array.prototype.find) Array.prototype.find = function (f) {
  for (var i = 0; i < this.length; i++) if (f(this[i], i)) return this[i];
};
if (!Array.prototype.findIndex) Array.prototype.findIndex = function (f) {
  for (var i = 0; i < this.length; i++) if (f(this[i], i)) return i;
  return -1;
};
if (!Array.prototype.includes) Array.prototype.includes = function (v) {
  return this.indexOf(v) >= 0;
};
if (!String.prototype.includes) String.prototype.includes = function (v) {
  return this.indexOf(v) >= 0;
};
if (!String.prototype.startsWith) String.prototype.startsWith = function (v) {
  return this.indexOf(v) === 0;
};
if (!Array.from) Array.from = function (a) {
  return Array.prototype.slice.call(a);
};
if (window.NodeList && !NodeList.prototype.forEach) NodeList.prototype.forEach = Array.prototype.forEach;
if (window.Element && !Element.prototype.matches) Element.prototype.matches = Element.prototype.webkitMatchesSelector;
if (window.Element && !Element.prototype.closest) {
  Element.prototype.closest = function (s) {
    var el = this;
    while (el && el.nodeType === 1) {
      if (el.matches(s)) return el;
      el = el.parentElement;
    }
    return null;
  };
}
var APP_VERSION = '2.12.1';
var $ = function $(s, r) {
  return (r || document).querySelector(s);
};
var $$ = function $$(s, r) {
  return Array.from((r || document).querySelectorAll(s));
};
var esc = function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[c];
  });
};
var clamp = function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
};
var pad2 = function pad2(n) {
  return (n < 10 ? '0' : '') + n;
};
function fmtDur(sec, withSec) {
  sec = Math.max(0, Math.floor(sec || 0));
  var h = Math.floor(sec / 3600),
    m = Math.floor(sec % 3600 / 60),
    s = sec % 60;
  return withSec === false ? "".concat(h, "h ").concat(pad2(m), "m") : "".concat(pad2(h), ":").concat(pad2(m), ":").concat(pad2(s));
}
function fmtMoney(v, cur) {
  var n = (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',');
  return "".concat(cur || 'R$', " ").concat(n.replace(/\B(?=(\d{3})+(?!\d))/g, '.'));
}
function debounce(fn, ms) {
  var t;
  return function () {
    var a = arguments;
    clearTimeout(t);
    t = setTimeout(function () {
      return fn.apply(null, a);
    }, ms);
  };
}
function dayKey(ts) {
  var d = new Date(ts);
  return "".concat(d.getFullYear(), "-").concat(pad2(d.getMonth() + 1), "-").concat(pad2(d.getDate()));
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
var FE = {
  inCEP: !!window.__adobe_cep__,
  hostReady: false,
  hostVersion: '',
  sysPath: function sysPath(type) {
    if (!this.inCEP) return '';
    var p = window.__adobe_cep__.getSystemPath(type) || '';
    p = decodeURIComponent(p.replace(/^file:\/\//, ''));
    if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return p;
  },
  get isWin() {
    return navigator.platform.indexOf('Win') >= 0;
  },
  evalScript: function evalScript(script) {
    var _this = this;
    return new Promise(function (resolve) {
      if (!_this.inCEP) {
        resolve('EvalScript error.');
        return;
      }
      window.__adobe_cep__.evalScript(script, function (r) {
        return resolve(r);
      });
    });
  },
  ensureHost: function ensureHost() {
    var _this2 = this;
    if (!this.inCEP) {
      this.hostReady = true;
      return Promise.resolve(true);
    }
    return this.evalScript('typeof $._FE === "object" ? $._FE.version : "no"').then(function (r) {
      if (r && r !== 'no' && r.indexOf('rror') < 0 && r === APP_VERSION) {
        _this2.hostReady = true;
        _this2.hostVersion = r;
        return true;
      }
      var file = (_this2.sysPath('extension') + '/host/fastedit.jsx').replace(/\\/g, '/');
      return _this2.evalScript("try{$.evalFile(".concat(JSON.stringify(file), ");\"ok\"}catch(e){\"ERR:\"+e.message+\" @\"+e.line}")).then(function (r2) {
        if (r2 === 'ok' || r2 && r2.indexOf('ready') >= 0) {
          _this2.hostReady = true;
          return true;
        }
        _this2.hostReady = false;
        _this2.lastHostError = r2;
        return false;
      });
    });
  },
  call: function call(name, args) {
    var _this3 = this;
    if (!this.inCEP) return MOCK.call(name, args || {});
    var payload = JSON.stringify(JSON.stringify(args || {}));
    return this.ensureHost().then(function (ok) {
      if (!ok) throw new Error('Não foi possível carregar o script do Fast Edit no Premiere. ' + (_this3.lastHostError || ''));
      return _this3.evalScript("$._FE.run(".concat(JSON.stringify(name), ", ").concat(payload, ")"));
    }).then(function (raw) {
      var r;
      try {
        r = JSON.parse(raw);
      } catch (e) {
        throw new Error('Resposta inválida do Premiere: ' + String(raw).slice(0, 120));
      }
      if (!r.ok) throw new Error(r.error || 'Erro desconhecido');
      return r.data;
    });
  },
  openURL: function openURL(url) {
    if (this.inCEP) window.__adobe_cep__.invokeSync('openURLInDefaultBrowser', url);else window.open(url);
  },
  reload: function reload() {
    location.reload();
  }
};
var FS = {
  ok: !!(window.cep && window.cep.fs),
  read: function read(path) {
    if (!this.ok) return null;
    var r = window.cep.fs.readFile(path);
    return r.err === 0 ? r.data : null;
  },
  write: function write(path, data, base64) {
    if (!this.ok) return false;
    this.mkdirp(path.replace(/[\\/][^\\/]*$/, ''));
    var r = base64 ? window.cep.fs.writeFile(path, data, window.cep.encoding.Base64) : window.cep.fs.writeFile(path, data);
    return r.err === 0;
  },
  exists: function exists(path) {
    if (!this.ok) return false;
    return window.cep.fs.stat(path).err === 0;
  },
  mkdirp: function mkdirp(dir) {
    if (!this.ok || !dir || this.exists(dir)) return;
    this.mkdirp(dir.replace(/[\\/][^\\/]*$/, ''));
    window.cep.fs.makedir(dir);
  },
  list: function list(dir) {
    if (!this.ok) return [];
    var r = window.cep.fs.readdir(dir);
    return r.err === 0 ? r.data : [];
  },
  isDir: function isDir(path) {
    if (!this.ok) return false;
    var r = window.cep.fs.stat(path);
    return r.err === 0 && r.data.isDirectory();
  },
  remove: function remove(path) {
    if (this.ok) window.cep.fs.deleteFile(path);
  },
  pickFolder: function pickFolder(title) {
    if (!this.ok) return null;
    var r = window.cep.fs.showOpenDialog(false, true, title || 'Escolher pasta', '');
    return r.err === 0 && r.data && r.data.length ? r.data[0] : null;
  },
  pickFile: function pickFile(title, types) {
    if (!this.ok) return null;
    var r = window.cep.fs.showOpenDialog(false, false, title || 'Escolher arquivo', '', types || []);
    return r.err === 0 && r.data && r.data.length ? r.data[0] : null;
  },
  saveDialog: function saveDialog(title, name, types) {
    if (!this.ok) return null;
    var r;
    if (window.cep.fs.showSaveDialogEx) r = window.cep.fs.showSaveDialogEx(title, '', types || [], name);
    return r && r.err === 0 && r.data ? r.data : null;
  },
  fileURL: function fileURL(p) {
    p = String(p).replace(/\\/g, '/');
    var parts = p.split('/').map(function (seg, i) {
      return i === 0 && /^[A-Za-z]:$/.test(seg) ? seg : encodeURIComponent(seg);
    });
    return 'file://' + (p[0] === '/' ? '' : '/') + parts.join('/');
  }
};
var DEFAULTS = {
  settings: {
    frames: 12,
    intensity: 1,
    ease: true,
    replace: true,
    where: 'in',
    transFrames: 8,
    transIntensity: 1,
    transWhoosh: false,
    nativeFrames: 15,
    nativeWhere: 'both',
    capPreset: 'pop',
    capOut: 'none',
    capIn: 6,
    capOutFrames: 4,
    capTrack: false,
    hourlyRate: 80,
    currency: 'R$',
    margin: 0,
    autoTimer: true,
    idleMinutes: 5,
    sfxFolders: [],
    sfxWhoosh: '',
    sfxTrack: 3,
    sfxOffset: 0,
    sfxMode: 'playhead',
    sfxGain: 0,
    sfxVolume: 0.8,
    adjNodeId: '',
    overlayMode: 'selection',
    overlayType: 'adjustment',
    overlaySeconds: 5,
    matteColor: '#000000',
    matteAlpha: 100,
    orgBins: {
      seq: '01 Sequências',
      video: '02 Vídeo',
      audio: '03 Áudio',
      image: '04 Imagens',
      graphic: '05 Gráficos',
      other: '06 Outros'
    },
    orgNested: false,
    customTemplates: [],
    theme: 'cream',
    autoUpdate: true,
    updateUrl: '',
    shelfMode: 'carousel',
    stackFrames: 3,
    stackEffect: '',
    stackTips: true,
    clipSeconds: 3,
    clipFit: true,
    clipDir: '',
    frameSave: false,
    frameDir: '',
    tbLook: 'respiro',
    tbLevel: 'media',
    tbStreak: 1,
    tbPulse: 0.8,
    tbMix: 0.5,
    tbLight: true,
    tbGlow: true,
    tbFav: [],
    beatPreset: 'punch',
    beatFrames: 6,
    beatIntensity: 1,
    beatSfx: false,
    flashFrames: 4
  },
  onboarded: false,
  favorites: ['motion', 'transitions', 'stack', 'sfx'],
  effectFavs: [],
  transFavs: [],
  stacks: [],
  sfxFavs: [],
  usage: {},
  history: [],
  time: {
    running: null,
    sessions: [],
    projects: {}
  }
};
var Store = {
  data: null,
  path: '',
  init: function init() {
    var base = FE.sysPath('userData');
    this.path = base ? base.replace(/\\/g, '/') + '/FastEdit/fastedit-data.json' : '';
    var raw = this.path ? FS.read(this.path) : null;
    if (!raw) {
      try {
        raw = localStorage.getItem('fastedit-data');
      } catch (e) {
        raw = null;
      }
    }
    var d = {};
    try {
      d = raw ? JSON.parse(raw) : {};
    } catch (e) {
      d = {};
    }
    this.data = this.merge(JSON.parse(JSON.stringify(DEFAULTS)), d);
  },
  merge: function merge(def, d) {
    var _this4 = this;
    Object.keys(d || {}).forEach(function (k) {
      if (def[k] && _typeof(def[k]) === 'object' && !Array.isArray(def[k]) && d[k] && _typeof(d[k]) === 'object' && !Array.isArray(d[k])) {
        def[k] = _this4.merge(def[k], d[k]);
      } else def[k] = d[k];
    });
    return def;
  },
  get dataDir() {
    return this.path ? this.path.replace(/\/[^/]*$/, '') : '';
  },
  save: null,
  saveNow: function saveNow() {
    var raw = JSON.stringify(this.data);
    if (this.path) FS.write(this.path, raw);
    try {
      localStorage.setItem('fastedit-data', raw);
    } catch (e) {}
  },
  get s() {
    return this.data.settings;
  },
  set: function set(key, val) {
    this.data.settings[key] = val;
    this.save();
  }
};
Store.save = debounce(function () {
  return Store.saveNow();
}, 400);
var ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
  animate: '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
  workflow: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  sfx: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  time: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
  chev: '<path d="m9 6 6 6-6 6"/>',
  play: '<path d="M7 4v16l13-8z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  insert: '<path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  folder: '<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.8-3.5L3 10"/><path d="M3 4v6h6"/><path d="M4 13a8 8 0 0 0 14.8 3.5L21 14"/><path d="M21 20v-6h-6"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
  motion: '<path d="M4 17c4 0 4-10 8-10s4 10 8 10"/><circle cx="4" cy="17" r="1.5"/><circle cx="20" cy="17" r="1.5"/>',
  transition: '<rect x="3" y="6" width="8" height="12" rx="1.5"/><rect x="13" y="6" width="8" height="12" rx="1.5"/><path d="m9 12 6 0M13 10l2 2-2 2"/>',
  caption: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 14h4M13 14h4M7 10h10"/>',
  fx: '<path d="M5 20 19 6"/><path d="m15 4 1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/><path d="m6 5 .7 1.3L8 7l-1.3.7L6 9l-.7-1.3L4 7l1.3-.7z"/>',
  bins: '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M8 13h8"/>',
  organize: '<path d="M4 6h16M4 12h10M4 18h6"/><path d="m17 15 3 3-3 3"/>',
  sort: '<path d="M7 4v16M3 16l4 4 4-4"/><path d="M14 6h7M14 11h5M14 16h3"/>',
  batch: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  clean: '<path d="M3 21h18"/><path d="m14 4 6 6-8 8H6v-6z"/>',
  social: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  upload: '<path d="M12 20V8M7 13l5-5 5 5M4 4h16"/>',
  wand: '<path d="m4 20 11-11"/><path d="m14 4 1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',
  money: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  paste: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M9 11h6M9 15h4"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  adjust: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/>',
  blur: '<path d="M4 12h3M4 8h5M4 16h5" opacity=".5"/><circle cx="15" cy="12" r="5"/><path d="M10 12h0"/>',
  curve: '<path d="M4 19C11 19 12 5 20 5"/><circle cx="4" cy="19" r="1.6"/><circle cx="20" cy="5" r="1.6"/><path d="M4 19h5M20 5h-5" stroke-dasharray="1.5 2"/>'
};
var icon = function icon(n, cls) {
  return "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"i ".concat(cls || '', "\">").concat(ICONS[n] || '', "</svg>");
};
var UI = {
  toast: function toast(msg, type) {
    var box = $('#toasts');
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'ok');
    el.innerHTML = icon(type === 'err' ? 'x' : type === 'info' ? 'info' : 'check') + '<span>' + esc(msg) + '</span>';
    box.appendChild(el);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () {
        return el.remove();
      }, 300);
    }, type === 'err' ? 6500 : 3200);
  },
  confirm: function confirm(title, text, okLabel) {
    return new Promise(function (resolve) {
      var bg = document.createElement('div');
      bg.className = 'modal-bg';
      bg.innerHTML = "<div class=\"modal\"><h4>".concat(esc(title), "</h4><p>").concat(esc(text), "</p><div class=\"btns\"><button class=\"btn ghost\" data-r=\"0\">Cancelar</button><button class=\"btn primary\" data-r=\"1\">").concat(esc(okLabel || 'Confirmar'), "</button></div></div>");
      document.body.appendChild(bg);
      bg.addEventListener('click', function (e) {
        var b = e.target.closest('[data-r]');
        if (!b && e.target !== bg) return;
        bg.remove();
        resolve(b ? b.getAttribute('data-r') === '1' : false);
      });
    });
  },
  prompt: function prompt(title, value, okLabel) {
    return new Promise(function (resolve) {
      var bg = document.createElement('div');
      bg.className = 'modal-bg';
      bg.innerHTML = "<div class=\"modal\"><h4>".concat(esc(title), "</h4><input class=\"input\" style=\"width:100%;margin:6px 0 14px\" value=\"").concat(esc(value || ''), "\"><div class=\"btns\"><button class=\"btn ghost\" data-r=\"0\">Cancelar</button><button class=\"btn primary\" data-r=\"1\">").concat(esc(okLabel || 'OK'), "</button></div></div>");
      document.body.appendChild(bg);
      var inp = $('input', bg);
      inp.focus();
      inp.select();
      var done = function done(ok) {
        var v = inp.value.trim();
        bg.remove();
        resolve(ok && v ? v : null);
      };
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') done(true);
        if (e.key === 'Escape') done(false);
      });
      bg.addEventListener('click', function (e) {
        var b = e.target.closest('[data-r]');
        if (b) done(b.getAttribute('data-r') === '1');else if (e.target === bg) done(false);
      });
    });
  },
  run: function run(btn, label, name, args, okMsg) {
    if (btn) btn.classList.add('busy');
    return FE.call(name, args).then(function (data) {
      var msg = typeof okMsg === 'function' ? okMsg(data) : okMsg || 'Feito';
      if (msg) UI.toast(msg, 'ok');
      App.log(true, "".concat(label, ": ").concat(msg || 'ok'));
      return data;
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, "".concat(label, ": ").concat(e.message));
      e._shown = true;
      throw e;
    }).then(function (d) {
      if (btn) btn.classList.remove('busy');
      return d;
    }, function (e) {
      if (btn) btn.classList.remove('busy');
      return Promise.reject(e);
    });
  },
  seg: function seg(name, options, value) {
    return "<div class=\"seg\" data-seg=\"".concat(name, "\">").concat(options.map(function (o) {
      return "<button data-v=\"".concat(esc(o[0]), "\" class=\"").concat(String(o[0]) === String(value) ? 'on' : '', "\">").concat(esc(o[1]), "</button>");
    }).join(''), "</div>");
  },
  range: function range(name, min, max, step, value, suffix) {
    return "<div class=\"range\"><input type=\"range\" data-range=\"".concat(name, "\" min=\"").concat(min, "\" max=\"").concat(max, "\" step=\"").concat(step, "\" value=\"").concat(value, "\"><output data-out=\"").concat(name, "\">").concat(value).concat(suffix || '', "</output></div>");
  },
  toggle: function toggle(name, label, checked) {
    return "<label class=\"toggle\"><input type=\"checkbox\" data-toggle=\"".concat(name, "\"").concat(checked ? ' checked' : '', "><i></i>").concat(esc(label), "</label>");
  },
  select: function select(name, options, value, cls) {
    return "<select class=\"select ".concat(cls || '', "\" data-select=\"").concat(name, "\">").concat(options.map(function (o) {
      return "<option value=\"".concat(esc(o[0]), "\"").concat(String(o[0]) === String(value) ? ' selected' : '', ">").concat(esc(o[1]), "</option>");
    }).join(''), "</select>");
  },
  bindSettings: function bindSettings(root, onChange) {
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-seg] button');
      if (!b) return;
      var seg = b.parentNode;
      $$('button', seg).forEach(function (x) {
        return x.classList.toggle('on', x === b);
      });
      var key = seg.getAttribute('data-seg');
      var v = b.getAttribute('data-v');
      if (/^-?\d+(\.\d+)?$/.test(v)) v = parseFloat(v);
      if (key.indexOf('_') !== 0) Store.set(key, v);
      if (onChange) onChange(key, v);
    });
    root.addEventListener('input', function (e) {
      var r = e.target.getAttribute('data-range');
      if (r) {
        var v = parseFloat(e.target.value);
        var out = $("[data-out=\"".concat(r, "\"]"), root);
        if (out) out.textContent = out.textContent.replace(/^[\d.,-]+/, String(v));
        if (r.indexOf('_') !== 0) Store.set(r, v);
        if (onChange) onChange(r, v);
      }
    });
    root.addEventListener('change', function (e) {
      var t = e.target.getAttribute('data-toggle');
      if (t) {
        if (t.indexOf('_') !== 0) Store.set(t, e.target.checked);
        if (onChange) onChange(t, e.target.checked);
      }
      var s = e.target.getAttribute('data-select');
      if (s) {
        var v = e.target.value;
        if (/^-?\d+(\.\d+)?$/.test(v)) v = parseFloat(v);
        if (s.indexOf('_') !== 0) Store.set(s, v);
        if (onChange) onChange(s, v);
      }
    });
  }
};
var Gen = {
  dir: function dir() {
    return (Store.dataDir || '') + '/generated';
  },
  savePNG: function savePNG(canvas, name) {
    var path = this.dir() + '/' + name;
    if (FS.exists(path)) return path;
    var b64 = canvas.toDataURL('image/png').split(',')[1];
    if (!FS.write(path, b64, true)) throw new Error('Não foi possível salvar a imagem gerada.');
    return path;
  },
  canvas: function canvas(w, h) {
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  },
  matte: function matte(w, h, color, alpha) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    g.globalAlpha = alpha / 100;
    g.fillStyle = color;
    g.fillRect(0, 0, w, h);
    return this.savePNG(c, "FE_Matte_".concat(color.replace('#', ''), "_").concat(alpha, "_").concat(w, "x").concat(h, ".png"));
  },
  letterbox: function letterbox(w, h, ratio) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    g.fillStyle = '#000';
    var frame = w / h;
    if (ratio > frame) {
      var ih = Math.round(w / ratio),
        bar = Math.round((h - ih) / 2);
      g.fillRect(0, 0, w, bar);
      g.fillRect(0, h - bar, w, bar);
    } else {
      var iw = Math.round(h * ratio),
        _bar = Math.round((w - iw) / 2);
      g.fillRect(0, 0, _bar, h);
      g.fillRect(w - _bar, 0, _bar, h);
    }
    return this.savePNG(c, "FE_Letterbox_".concat(String(ratio).replace('.', '_'), "_").concat(w, "x").concat(h, ".png"));
  },
  guideCanvas: function guideCanvas(w, h, platform, opts) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    if (platform === 'generic') this.grid(g, w, h);else GuideArt.draw(g, w, h, platform, opts || {});
    return c;
  },
  guide: function guide(w, h, platform, opts) {
    opts = opts || {};
    var c = this.guideCanvas(w, h, platform, opts);
    return this.savePNG(c, "FE_Guide_".concat(platform, "_").concat(opts.zones ? 'z' : '').concat(opts.crop ? 'c' : '', "_v4_").concat(w, "x").concat(h, ".png"));
  },
  grid: function grid(g, w, h) {
    var lw = Math.max(2, Math.round(Math.min(w, h) / 360));
    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = lw;
    for (var i = 1; i < 3; i++) {
      g.beginPath();
      g.moveTo(w * i / 3, 0);
      g.lineTo(w * i / 3, h);
      g.stroke();
      g.beginPath();
      g.moveTo(0, h * i / 3);
      g.lineTo(w, h * i / 3);
      g.stroke();
    }
    g.strokeStyle = 'rgba(35,64,200,0.9)';
    g.setLineDash([lw * 4, lw * 3]);
    g.strokeRect(w * 0.05, h * 0.05, w * 0.9, h * 0.9);
    g.setLineDash([]);
    g.beginPath();
    g.moveTo(w / 2 - 20 * lw, h / 2);
    g.lineTo(w / 2 + 20 * lw, h / 2);
    g.moveTo(w / 2, h / 2 - 20 * lw);
    g.lineTo(w / 2, h / 2 + 20 * lw);
    g.stroke();
  }
};
var MOCK = {
  call: function call(name, a) {
    var d = {
      info: {
        version: '25.6',
        project: 'Projeto Demo.prproj',
        projectPath: 'C:/Projetos/Projeto Demo.prproj',
        seq: {
          name: 'Sequência 01',
          w: 1920,
          h: 1080,
          fps: 29.97,
          duration: 184.5,
          playhead: 42.1,
          vTracks: 4,
          aTracks: 4,
          clips: 57,
          selected: 3
        }
      },
      listEffects: {
        video: ['Lumetri Color', 'Gaussian Blur', 'Transform', 'Crop', 'Warp Stabilizer', 'Ultra Key', 'Sharpen', 'Noise', 'Mirror', 'Directional Blur', 'Basic 3D', 'Drop Shadow'],
        audio: ['DeNoise', 'Parametric Equalizer', 'Hard Limiter', 'Reverb']
      },
      _x: 0,
      listTransitions: {
        video: ['Cross Dissolve', 'Dip to Black', 'Dip to White', 'Film Dissolve', 'Push', 'Slide', 'Iris Round', 'Morph Cut'],
        audio: ['Constant Power', 'Constant Gain']
      },
      findAdjustment: null,
      organize: {
        plan: {
          video: {
            bin: '02 Vídeo',
            count: 34,
            samples: ['A001_C003.mov', 'DJI_0042.mp4']
          },
          audio: {
            bin: '03 Áudio',
            count: 8,
            samples: ['trilha.wav']
          },
          image: {
            bin: '04 Imagens',
            count: 5,
            samples: ['logo.png']
          }
        },
        total: 47,
        applied: !!a.apply
      },
      markerTimes: [2, 5.5, 9]
    }[name];
    return new Promise(function (res, rej) {
      return setTimeout(function () {
        if (name === 'motion' || name === 'captions') res({
          clips: 3,
          keys: 12
        });else if (name === 'guidesState' || name === 'toggleGuides') res({
          count: 1,
          visible: name === 'toggleGuides' ? !!a.visible : true
        });else if (name === 'beatFx') res({
          markers: 8,
          done: 8,
          skipped: 0,
          times: [1, 2, 3]
        });else if (name === 'timeBlur') res({
          clips: 3,
          keys: 270
        });else if (name === 'applyCurve') res({
          clips: 3,
          params: 4,
          segments: 6,
          keys: 84
        });else if (d !== undefined) res(d);else res({
          placed: 1,
          done: 3,
          clips: 3,
          added: 2,
          applied: 2,
          missing: [],
          removed: 0,
          gaps: 2,
          seconds: 3.4,
          sorted: 4,
          created: 6,
          skipped: 0,
          cuts: [1, 2],
          name: 'Seq 9:16',
          method: 'clone'
        });
      }, 250);
    });
  }
};
var ART = {
  mascot: "\n  <g class=\"ink\">\n    <!-- pernas -->\n    <path d=\"M86 150 C84 162 80 172 74 182\"/>\n    <path d=\"M74 182 C70 184 62 185 58 183\"/>\n    <path d=\"M116 150 C120 160 126 170 134 178\"/>\n    <path d=\"M134 178 C138 181 146 181 150 178\"/>\n    <!-- corpo (claquete) -->\n    <path d=\"M58 82 C57 104 58 128 60 150 C86 152 116 152 142 150 C144 128 145 104 143 82 C114 80 86 80 58 82 Z\" class=\"fill\"/>\n    <!-- tampa aberta -->\n    <path d=\"M58 80 L66 52 C92 50 118 52 146 56 L143 80\" class=\"fill\"/>\n    <path d=\"M66 66 L76 51 M84 66 L94 51 M102 66 L112 52 M120 67 L130 53 M137 68 L145 57\" stroke-width=\"6\"/>\n    <path d=\"M62 66 C88 64 116 66 145 69\" />\n    <!-- \xF3culos -->\n    <path d=\"M72 100 C72 94 92 94 93 100 C94 110 74 112 72 100 Z\" class=\"solid\"/>\n    <path d=\"M106 100 C106 94 127 94 128 100 C128 111 107 112 106 100 Z\" class=\"solid\"/>\n    <path d=\"M93 99 C97 97 102 97 106 99\"/>\n    <path d=\"M72 99 L64 96 M128 99 L136 95\"/>\n    <!-- sorriso -->\n    <path d=\"M88 124 C96 132 108 132 116 123\"/>\n    <!-- bra\xE7o esquerdo acenando -->\n    <path d=\"M58 112 C46 108 38 98 34 86\"/>\n    <path d=\"M34 86 C30 82 31 76 35 74 M34 86 C29 85 26 81 28 77\"/>\n    <!-- bra\xE7o direito com caf\xE9 -->\n    <path d=\"M143 114 C154 112 162 104 164 94\"/>\n    <path d=\"M154 70 L176 70 L172 98 L158 98 Z\" class=\"fill\"/>\n    <path d=\"M152 70 C152 64 178 64 178 70\"/>\n    <path d=\"M160 64 C162 60 168 60 170 64\"/>\n    <path d=\"M157 82 L174 82\"/>\n    <path d=\"M164 56 C161 52 167 49 164 44 M171 56 C168 52 174 49 171 44\"/>\n  </g>",
  timeline: "\n  <g class=\"ink\">\n    <rect x=\"20\" y=\"40\" width=\"160\" height=\"96\" rx=\"10\" class=\"fill\"/>\n    <path d=\"M20 62 L180 62\"/>\n    <rect x=\"34\" y=\"74\" width=\"46\" height=\"18\" rx=\"4\" class=\"solid\"/>\n    <rect x=\"84\" y=\"74\" width=\"38\" height=\"18\" rx=\"4\"/>\n    <rect x=\"126\" y=\"74\" width=\"40\" height=\"18\" rx=\"4\" class=\"solid\"/>\n    <rect x=\"50\" y=\"100\" width=\"62\" height=\"14\" rx=\"4\"/>\n    <rect x=\"116\" y=\"100\" width=\"34\" height=\"14\" rx=\"4\"/>\n    <path d=\"M102 50 L102 128\"/>\n    <path d=\"M96 46 L108 46 L102 54 Z\" class=\"solid\"/>\n    <!-- cursor -->\n    <path d=\"M140 118 L140 150 L148 142 L156 158 L162 155 L154 140 L166 140 Z\" class=\"fill\"/>\n  </g>",
  magic: "\n  <g class=\"ink\">\n    <path d=\"M40 160 L130 70\"/>\n    <path d=\"M124 64 L136 76\" stroke-width=\"7\"/>\n    <path d=\"M140 30 L146 46 L162 52 L146 58 L140 74 L134 58 L118 52 L134 46 Z\" class=\"fill\"/>\n    <path d=\"M70 46 L73 54 L81 57 L73 60 L70 68 L67 60 L59 57 L67 54 Z\" class=\"solid\"/>\n    <path d=\"M160 104 L163 110 L169 113 L163 116 L160 122 L157 116 L151 113 L157 110 Z\" class=\"solid\"/>\n  </g>",
  clock: "\n  <g class=\"ink\">\n    <circle cx=\"100\" cy=\"104\" r=\"56\" class=\"fill\"/>\n    <path d=\"M100 66 L100 104 L126 120\"/>\n    <path d=\"M86 40 L114 40 M100 40 L100 48\"/>\n    <path d=\"M150 60 L160 50\"/>\n    <path d=\"M100 56 L100 62 M148 104 L142 104 M100 152 L100 146 M52 104 L58 104\"/>\n    <path d=\"M40 168 C70 160 130 160 160 168\"/>\n  </g>",
  waves: "\n  <g class=\"ink\">\n    <path d=\"M30 100 C40 70 50 70 60 100 C70 130 80 130 90 100 C100 70 110 70 120 100 C130 130 140 130 150 100 C160 70 170 70 176 90\"/>\n    <path d=\"M70 160 L70 60 L140 46 L140 146\"/>\n    <ellipse cx=\"58\" cy=\"160\" rx=\"14\" ry=\"10\" class=\"solid\"/>\n    <ellipse cx=\"128\" cy=\"146\" rx=\"14\" ry=\"10\" class=\"solid\"/>\n  </g>"
};
var SKETCH_FILTER = "<svg width=\"0\" height=\"0\" style=\"position:absolute\"><defs>\n  <filter id=\"sketch\" x=\"-5%\" y=\"-5%\" width=\"110%\" height=\"110%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"3\"/><feDisplacementMap in=\"SourceGraphic\" scale=\"2.2\"/></filter>\n</defs></svg>";
function art(name, cls) {
  return "<svg viewBox=\"0 0 200 200\" class=\"art ".concat(cls || '', "\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\">").concat(ART[name], "</svg>");
}
var GUIDE_SPECS = {
  reels: {
    name: 'Instagram Reels',
    vh: 1600,
    vw: 900,
    off: 80,
    items: [['status'], ['plus', 48, 125, 36], ['text', 183, 138, 'Reels', 38, 700, 1], ['text', 318, 138, 'Amigos', 38, 700, 0.55], ['heart', 686, 833, 44], ['label', 686, 892, 'Curtidas'], ['comment', 686, 955, 42], ['label', 686, 1013, '69'], ['repost', 686, 1083, 42], ['label', 686, 1146, '85'], ['send', 686, 1210, 40], ['menu', 686, 1285, 36], ['thumb', 687, 1366, 50], ['avatar', 66, 1256, 32, true], ['text', 118, 1265, 'seuperfil', 25, 700, 1], ['pill', 297, 1236, 100, 40, 'Seguir', false], ['text', 28, 1336, 'Legenda do seu vídeo aparece aqui…', 23, 400, 1], ['text', 124, 1391, 'Seguido por amigo e outras 9 pessoas', 19, 400, 0.85], ['faces', 28, 1383], ['bar', 28, 1430, 684]],
    zones: [[630, 780, 110, 640], [0, 1215, 640, 230], [0, 0, 740, 170]]
  },
  shorts: {
    name: 'YouTube Shorts',
    vh: 1455,
    vw: 818,
    off: 39,
    items: [['status'], ['sparkle', 438, 122, 36], ['comment', 521, 122, 36], ['search', 604, 122, 36], ['dots', 687, 122, 34], ['heart', 684, 862, 44], ['label', 684, 909, '13 mil'], ['comment', 684, 965, 40], ['label', 684, 1013, '418'], ['bookmark', 684, 1070, 40], ['label', 684, 1116, 'Salvar'], ['share', 684, 1173, 40], ['label', 684, 1220, 'Compartilhar'], ['remix', 684, 1277, 40], ['label', 684, 1324, 'Remix'], ['thumb', 684, 1392, 52], ['avatar', 55, 1354, 27, false], ['text', 97, 1363, '@seucanal', 23, 700, 1], ['pill', 282, 1328, 168, 52, 'Inscrever-se', true], ['text', 28, 1420, 'Título do seu Short #hashtag', 23, 400, 1], ['bar', 0, 1450, 740]],
    zones: [[630, 820, 110, 620], [0, 1310, 630, 145], [380, 80, 360, 90]]
  },
  tiktok: {
    name: 'TikTok',
    vh: 1455,
    vw: 818,
    off: 39,
    items: [['status'], ['live', 48, 140, 40], ['text', 320, 152, 'Seguindo', 25, 600, 0.6], ['text', 455, 152, 'Loja', 25, 600, 0.6], ['text', 524, 152, 'Para você', 25, 700, 1], ['underline', 563, 172, 40], ['search', 690, 140, 38], ['avatar', 685, 810, 36, false], ['follow', 685, 850], ['heart', 685, 933, 46, true], ['label', 685, 983, '12,3 mil'], ['bubble', 685, 1045, 44], ['label', 685, 1095, '1.234'], ['bookmark', 685, 1160, 40, true], ['label', 685, 1209, '980'], ['share', 685, 1273, 42, true], ['label', 685, 1322, 'Compartilhar'], ['disc', 685, 1397, 32], ['text', 22, 1309, 'Seu Perfil', 27, 700, 1], ['text', 22, 1352, 'Legenda do vídeo aparece aqui e pode', 23, 400, 1], ['text', 22, 1387, 'ocupar até duas linhas… mais', 23, 400, 1], ['text', 22, 1434, '♫ som original - seuperfil', 21, 400, 1]],
    zones: [[630, 760, 110, 680], [0, 1270, 630, 185], [0, 90, 740, 100]]
  }
};
var GuideArt = {
  icon: function icon(g, kind, cx, cy, px, filled) {
    var s = px / 24;
    g.save();
    g.translate(cx - 12 * s, cy - 12 * s);
    g.scale(s, s);
    g.lineWidth = 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    g.strokeStyle = '#fff';
    g.fillStyle = '#fff';
    var P = function P(d, fill) {
      var p = new Path2D(d);
      if (fill) g.fill(p);
      g.stroke(p);
    };
    switch (kind) {
      case 'heart':
        P('M12 20.5s-8-4.9-8-11A4.5 4.5 0 0 1 12 6.6 4.5 4.5 0 0 1 20 9.5c0 6.1-8 11-8 11z', filled);
        break;
      case 'comment':
        P('M20 11.5a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.5z');
        break;
      case 'bubble':
        P('M12 4c4.9 0 8.5 3.1 8.5 7s-3.6 7-8.5 7c-.9 0-1.8-.1-2.6-.3L5 20l.9-3.7C4.4 15 3.5 13.1 3.5 11c0-3.9 3.6-7 8.5-7z', true);
        g.fillStyle = 'rgba(0,0,0,.55)';
        [8.5, 12, 15.5].forEach(function (x) {
          g.beginPath();
          g.arc(x, 11, 1.2, 0, 7);
          g.fill();
        });
        break;
      case 'repost':
        P('M7 7h11l-3-3M18 7v4M17 17H6l3 3M6 17v-4');
        break;
      case 'send':
        P('M21 3 3 10l7 3 3 7z');
        P('M10 13l11-10');
        break;
      case 'menu':
        P('M5 9h14M5 15h9');
        break;
      case 'plus':
        P('M12 4v16M4 12h16');
        break;
      case 'search':
        P('M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM16 16l5 5');
        break;
      case 'dots':
        [6, 12, 18].forEach(function (x) {
          g.beginPath();
          g.arc(x, 12, 1.6, 0, 7);
          g.fill();
        });
        break;
      case 'sparkle':
        P('M12 3c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7z', true);
        break;
      case 'bookmark':
        P('M6 3h12v18l-6-4.5L6 21z', filled);
        break;
      case 'share':
        if (filled) P('M13 5l8 7-8 7v-4c-5 0-8 1.5-10 5 .7-5.5 3.5-9.5 10-10.5z', true);else P('M14 5l7 7-7 7v-4c-5 0-8 1.5-10 4.5.8-5 3.8-8.8 10-9.5z');
        break;
      case 'remix':
        P('M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4M12 9v6M9 12h6');
        break;
      case 'live':
        P('M4 8h16v11H4zM9 4l3 3 3-3');
        g.font = '700 6.5px sans-serif';
        g.textAlign = 'center';
        g.fillText('LIVE', 12, 16);
        break;
      case 'home':
        P('M4 10.5 12 4l8 6.5V20h-5v-5h-6v5H4z');
        break;
      case 'reel':
        P('M5 5h14v14H5z');
        P('M10 9l5 3-5 3z', true);
        break;
      default:
        break;
    }
    g.restore();
  },
  draw: function draw(g, W, H, platform, opts) {
    var _this5 = this;
    var spec = GUIDE_SPECS[platform];
    var fw = W,
      fh = H;
    if (Math.abs(W / H - 9 / 16) > 0.01) {
      if (W / H > 9 / 16) fw = Math.round(H * 9 / 16);else fh = Math.round(W * 16 / 9);
    }
    var fx = Math.round((W - fw) / 2),
      fy = Math.round((H - fh) / 2);
    if (fx > 0 || fy > 0) {
      g.fillStyle = 'rgba(0,0,0,0.72)';
      if (fx > 0) {
        g.fillRect(0, 0, fx, H);
        g.fillRect(fx + fw, 0, W - fx - fw, H);
      }
      if (fy > 0) {
        g.fillRect(0, 0, W, fy);
        g.fillRect(0, fy + fh, W, H - fy - fh);
      }
    }
    var S = fh / spec.vh;
    var X = function X(x) {
      return fx + (x + spec.off) / spec.vw * fw;
    };
    var Y = function Y(y) {
      return fy + y / spec.vh * fh;
    };
    var font = function font(px, wt) {
      return "".concat(wt || 400, " ").concat(Math.round(px * S), "px \"DM Sans\", \"Segoe UI\", Arial, sans-serif");
    };
    if (opts.zones) {
      spec.zones.forEach(function (z) {
        g.fillStyle = 'rgba(255,59,48,0.20)';
        g.fillRect(X(z[0]), Y(z[1]), z[2] / spec.vw * fw, z[3] / spec.vh * fh);
        g.strokeStyle = 'rgba(255,59,48,0.75)';
        g.lineWidth = Math.max(2, 2 * S);
        g.setLineDash([8 * S, 6 * S]);
        g.strokeRect(X(z[0]), Y(z[1]), z[2] / spec.vw * fw, z[3] / spec.vh * fh);
        g.setLineDash([]);
      });
    }
    if (opts.crop) {
      g.strokeStyle = 'rgba(255,255,255,0.55)';
      g.lineWidth = Math.max(2, 2 * S);
      g.setLineDash([14 * S, 10 * S]);
      [X(0), X(740)].forEach(function (x) {
        g.beginPath();
        g.moveTo(x, fy);
        g.lineTo(x, fy + fh);
        g.stroke();
      });
      g.setLineDash([]);
    }
    g.save();
    g.shadowColor = 'rgba(0,0,0,0.45)';
    g.shadowBlur = 6 * S;
    g.shadowOffsetY = 1 * S;
    spec.items.forEach(function (it) {
      var k = it[0];
      if (k === 'status') {
        g.fillStyle = '#fff';
        g.font = font(30, 600);
        g.textAlign = 'left';
        g.fillText('9:41', X(80), Y(56));
        var bx = X(628),
          by = Y(34);
        g.strokeStyle = '#fff';
        g.lineWidth = 2 * S;
        g.strokeRect(bx, by, 50 * S, 22 * S);
        g.fillRect(bx + 3 * S, by + 3 * S, 36 * S, 16 * S);
        for (var i = 0; i < 4; i++) g.fillRect(X(560) + i * 9 * S, Y(56) - (6 + i * 4) * S, 6 * S, (6 + i * 4) * S);
      } else if (k === 'text') {
        g.globalAlpha = it[6];
        g.fillStyle = '#fff';
        g.font = font(it[4], it[5]);
        g.textAlign = 'left';
        g.fillText(it[3], X(it[1]), Y(it[2]));
        g.globalAlpha = 1;
      } else if (k === 'label') {
        g.fillStyle = '#fff';
        g.font = font(20, 600);
        g.textAlign = 'center';
        g.fillText(it[3], X(it[1]), Y(it[2]));
      } else if (k === 'avatar') {
        var r = it[3] * S,
          cx = X(it[1]),
          cy = Y(it[2]);
        if (it[4]) {
          var gr = g.createLinearGradient(cx - r, cy + r, cx + r, cy - r);
          gr.addColorStop(0, '#f9ce34');
          gr.addColorStop(0.5, '#ee2a7b');
          gr.addColorStop(1, '#6228d7');
          g.strokeStyle = gr;
          g.lineWidth = 4 * S;
          g.beginPath();
          g.arc(cx, cy, r + 4 * S, 0, 7);
          g.stroke();
        }
        g.fillStyle = '#9aa3b5';
        g.beginPath();
        g.arc(cx, cy, r, 0, 7);
        g.fill();
        g.strokeStyle = '#fff';
        g.lineWidth = 2.5 * S;
        g.stroke();
        g.fillStyle = '#d7dbe4';
        g.beginPath();
        g.arc(cx, cy - r * 0.18, r * 0.36, 0, 7);
        g.fill();
        g.beginPath();
        g.arc(cx, cy + r * 0.75, r * 0.62, Math.PI, 0);
        g.fill();
      } else if (k === 'follow') {
        g.fillStyle = '#fe2c55';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), 14 * S, 0, 7);
        g.fill();
        g.shadowBlur = 0;
        _this5.icon(g, 'plus', X(it[1]), Y(it[2]), 18 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'pill') {
        var x = X(it[1]),
          y = Y(it[2]),
          w = it[3] * S,
          h = it[4] * S;
        g.beginPath();
        g.moveTo(x + h / 2, y);
        g.arcTo(x + w, y, x + w, y + h, h / 2);
        g.arcTo(x + w, y + h, x, y + h, h / 2);
        g.arcTo(x, y + h, x, y, h / 2);
        g.arcTo(x, y, x + w, y, h / 2);
        g.closePath();
        if (it[6]) {
          g.fillStyle = '#fff';
          g.fill();
        } else {
          g.strokeStyle = 'rgba(255,255,255,.8)';
          g.lineWidth = 2 * S;
          g.stroke();
        }
        g.shadowBlur = 0;
        g.fillStyle = it[6] ? '#0f0f0f' : '#fff';
        g.font = font(22, 600);
        g.textAlign = 'center';
        g.fillText(it[5], x + w / 2, y + h / 2 + 8 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'thumb') {
        var s2 = it[3] * S;
        g.fillStyle = '#5b6474';
        g.strokeStyle = '#fff';
        g.lineWidth = 3 * S;
        g.fillRect(X(it[1]) - s2 / 2, Y(it[2]) - s2 / 2, s2, s2);
        g.strokeRect(X(it[1]) - s2 / 2, Y(it[2]) - s2 / 2, s2, s2);
      } else if (k === 'disc') {
        var _r = it[3] * S;
        g.fillStyle = '#222';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), _r, 0, 7);
        g.fill();
        g.fillStyle = '#7d8696';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), _r * 0.55, 0, 7);
        g.fill();
      } else if (k === 'faces') {
        for (var _i = 0; _i < 3; _i++) {
          g.fillStyle = ['#7d8696', '#5b6474', '#a3abb9'][_i];
          g.beginPath();
          g.arc(X(it[1] + 14 + _i * 26), Y(it[2]), 14 * S, 0, 7);
          g.fill();
          g.strokeStyle = '#fff';
          g.lineWidth = 2 * S;
          g.stroke();
        }
      } else if (k === 'bar') {
        g.shadowBlur = 0;
        g.fillStyle = 'rgba(255,255,255,0.35)';
        g.fillRect(X(it[1]), Y(it[2]), it[3] / spec.vw * fw, 3 * S);
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]), Y(it[2]), 40 * S, 3 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'underline') {
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]) - it[3] * S / 2, Y(it[2]), it[3] * S, 4 * S);
      } else if (k === 'nav') {
        var _x = X(it[1]),
          _y = Y(it[2]),
          _w = it[3] * S,
          _h = it[4] * S;
        g.shadowBlur = 0;
        g.fillStyle = 'rgba(40,40,40,0.55)';
        g.beginPath();
        g.moveTo(_x + _h / 2, _y);
        g.arcTo(_x + _w, _y, _x + _w, _y + _h, _h / 2);
        g.arcTo(_x + _w, _y + _h, _x, _y + _h, _h / 2);
        g.arcTo(_x, _y + _h, _x, _y, _h / 2);
        g.arcTo(_x, _y, _x + _w, _y, _h / 2);
        g.fill();
        g.fillStyle = 'rgba(255,255,255,0.18)';
        var ax = X(it[5][it[6]]);
        g.beginPath();
        g.arc(ax, _y + _h / 2, _h * 0.42, 0, 7);
        g.fill();
        it[5].forEach(function (cx, i) {
          var icn = it[7][i];
          if (icn === 'me') {
            g.fillStyle = '#9aa3b5';
            g.beginPath();
            g.arc(X(cx), _y + _h / 2, 20 * S, 0, 7);
            g.fill();
          } else _this5.icon(g, icn, X(cx), _y + _h / 2, 40 * S, icn === 'reel');
        });
        g.shadowBlur = 6 * S;
      } else if (k === 'homebar') {
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]), Y(it[2]), it[3] / spec.vw * fw, 6 * S);
      } else {
        _this5.icon(g, k, X(it[1]), Y(it[2]), it[3] * S, it[4]);
      }
    });
    g.restore();
    g.strokeStyle = 'rgba(35,64,200,0.9)';
    g.lineWidth = Math.max(2, 3 * S);
    g.strokeRect(fx + 1, fy + 1, fw - 2, fh - 2);
  }
};
var MODULES = [{
  id: 'home',
  title: 'Início',
  icon: 'home'
}, {
  id: 'animate',
  title: 'Animar',
  icon: 'animate',
  h1: 'Dê vida aos',
  hand: 'seus clipes',
  p: ''
}, {
  id: 'workflow',
  title: 'Editar',
  icon: 'workflow',
  h1: 'Edição sem',
  hand: 'trabalho chato',
  p: ''
}, {
  id: 'after',
  title: 'After',
  icon: 'blur',
  h1: 'After movie e',
  hand: 'same day',
  p: ''
}, {
  id: 'sfx',
  title: 'Sons',
  icon: 'sfx'
}, {
  id: 'time',
  title: 'Tempo',
  icon: 'time'
}];
var NEEDS = {
  clips: function clips(s) {
    return s && s.selected ? ["".concat(s.selected, " clipe").concat(s.selected > 1 ? 's' : '', " selecionado").concat(s.selected > 1 ? 's' : ''), 'ok'] : ['Selecione clipes na timeline do Premiere', 'warn'];
  },
  seq: function seq(s) {
    return s ? ["Sequ\xEAncia: ".concat(s.name), 'ok'] : ['Abra uma sequência na timeline', 'warn'];
  },
  project: function project(s, i) {
    return i && i.project ? ["Projeto: ".concat(i.project.replace(/\.prproj$/i, '')), 'ok'] : ['Abra um projeto no Premiere', 'warn'];
  }
};
var App = {
  tools: [],
  current: 'home',
  page: null,
  info: null,
  connected: null,
  listeners: [],
  registerTool: function registerTool(t) {
    this.tools.push(t);
  },
  tool: function tool(id) {
    return this.tools.find(function (t) {
      return t.id === id;
    });
  },
  onInfo: function onInfo(fn) {
    this.listeners.push(fn);
  },
  log: function log(ok, msg) {
    var h = Store.data.history;
    h.unshift({
      t: Date.now(),
      ok: ok,
      msg: msg
    });
    if (h.length > 40) h.length = 40;
    Store.save();
    if (this.current === 'home' && !this.page) Home.renderLog();
  },
  init: function init() {
    var _this6 = this;
    Store.init();
    Theme.apply(Store.s.theme);
    this.renderShell();
    Splash.show();
    this.go('home');
    this.poll();
    setInterval(function () {
      return _this6.poll();
    }, 2000);
    Timer.init();
    Updater.init();
    document.addEventListener('keydown', function (e) {
      if (e.key === 'k' && (e.ctrlKey || e.metaKey) || e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
        e.preventDefault();
        $('#q').focus();
      }
      if (e.key === 'Escape' && _this6.page && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) _this6.go(_this6.tool(_this6.page).module);
    });
    window.addEventListener('beforeunload', function () {
      Timer.persist();
      Store.saveNow();
    });
  },
  renderShell: function renderShell() {
    var _this7 = this;
    $('#app').innerHTML = "\n      ".concat(SKETCH_FILTER, "\n      <div class=\"header\">\n        <div class=\"avatar\" title=\"Fast Edit\">").concat(art('mascot'), "</div>\n        <div class=\"who\" id=\"who\"><b>Fast Edit</b><span><i class=\"dot\"></i>conectando\u2026</span></div>\n        <div class=\"hbtn timer\" id=\"timerChip\" title=\"Cron\xF4metro\"><i></i><span>0:00</span></div>\n        <div class=\"hbtn\" id=\"gear\" title=\"Ajustes\">").concat(icon('settings'), "</div>\n      </div>\n      <div class=\"searchwrap\">\n        <div class=\"search\">").concat(icon('search'), "<input id=\"q\" placeholder=\"O que voc\xEA quer fazer?\" autocomplete=\"off\"><kbd>Ctrl K</kbd></div>\n        <div class=\"results\" id=\"results\"></div>\n      </div>\n      <div class=\"view\" id=\"view\"></div>\n      <div class=\"tabbar\">").concat(MODULES.map(function (m) {
      return "<div class=\"tab\" data-go=\"".concat(m.id, "\" title=\"").concat(m.title, "\">").concat(icon(m.icon), "<span>").concat(m.title, "</span></div>");
    }).join(''), "</div>\n      <div class=\"toasts\" id=\"toasts\"></div>");
    $('.tabbar').addEventListener('click', function (e) {
      var n = e.target.closest('[data-go]');
      if (n) _this7.go(n.getAttribute('data-go'));
    });
    $('#who').addEventListener('click', function () {
      FE.hostReady = false;
      _this7.poll(true);
    });
    $('#timerChip').addEventListener('click', function () {
      return _this7.go('time');
    });
    $('#gear').addEventListener('click', function () {
      return _this7.go('settings');
    });
    this.bindSearch();
  },
  go: function go(id) {
    var _this8 = this;
    this.current = id;
    this.page = null;
    $$('.tab').forEach(function (n) {
      return n.classList.toggle('active', n.getAttribute('data-go') === id);
    });
    var view = this.freshView();
    if (id === 'home') return Home.render(view);
    if (id === 'settings') return Settings.render(view);
    var m = MODULES.find(function (x) {
      return x.id === id;
    });
    var tools = this.tools.filter(function (t) {
      return t.module === id;
    });
    if (tools.length === 1 && tools[0].full) {
      tools[0].render(view);
      return;
    }
    view.innerHTML = "<div class=\"hero\"><h1>".concat(m.h1, "<span class=\"hand\">").concat(m.hand, "</span></h1>").concat(m.p ? "<p>".concat(m.p, "</p>") : '', "</div>").concat(this.connBanner()) + tools.map(function (t) {
      return _this8.rowHTML(t);
    }).join('');
    view.addEventListener('click', function (e) {
      var star = e.target.closest('[data-star]');
      if (star) {
        e.stopPropagation();
        _this8.toggleFav(star.getAttribute('data-star'));
        star.classList.toggle('on');
        return;
      }
      var r = e.target.closest('[data-open]');
      if (r) _this8.openTool(r.getAttribute('data-open'));
    });
  },
  freshView: function freshView() {
    var old = $('#view');
    var v = old.cloneNode(false);
    old.parentNode.replaceChild(v, old);
    v.scrollTop = 0;
    return v;
  },
  rowHTML: function rowHTML(t) {
    var fav = Store.data.favorites.includes(t.id);
    return "<div class=\"tool-row\" data-open=\"".concat(t.id, "\">\n      <div class=\"ticon\">").concat(icon(t.icon), "</div>\n      <div class=\"tt\"><b>").concat(esc(t.title), "</b><span>").concat(esc(t.desc), "</span></div>\n      <div class=\"star ").concat(fav ? 'on' : '', "\" data-star=\"").concat(t.id, "\" title=\"Fixar no In\xEDcio\">").concat(icon('star'), "</div>\n      <div class=\"go\">").concat(icon('chev'), "</div></div>");
  },
  openTool: function openTool(id) {
    var _this9 = this;
    var t = this.tool(id);
    if (!t) return;
    if (t.full) {
      this.go(t.module);
      return;
    }
    this.current = t.module;
    this.page = id;
    $$('.tab').forEach(function (n) {
      return n.classList.toggle('active', n.getAttribute('data-go') === t.module);
    });
    var view = this.freshView();
    var fav = Store.data.favorites.includes(t.id);
    view.innerHTML = "\n      <div class=\"page-head\"><div class=\"back\" data-back title=\"Voltar (Esc)\">".concat(icon('back'), "</div>\n        <h2>").concat(esc(t.title), "<small>").concat(esc(t.desc), "</small></h2>\n        <div class=\"star ").concat(fav ? 'on' : '', "\" data-star=\"").concat(t.id, "\" title=\"Fixar no In\xEDcio\">").concat(icon('star'), "</div></div>\n      ").concat(t.needs ? '<div class="ctx" id="ctx"></div>' : '', "\n      <div class=\"panel\" id=\"toolBody\"></div>");
    $('[data-back]', view).addEventListener('click', function () {
      return _this9.go(t.module);
    });
    $('[data-star]', view).addEventListener('click', function (e) {
      _this9.toggleFav(t.id);
      e.currentTarget.classList.toggle('on');
    });
    this.updateCtx();
    t.render($('#toolBody', view));
  },
  updateCtx: function updateCtx() {
    var el = $('#ctx');
    if (!el || !this.page) return;
    var t = this.tool(this.page);
    if (this.connected === false) {
      el.className = 'ctx warn';
      el.innerHTML = icon('info') + 'Premiere desconectado — toque no nome do projeto lá em cima';
      return;
    }
    var r = NEEDS[t.needs](this.info && this.info.seq, this.info);
    el.className = 'ctx ' + r[1];
    el.innerHTML = icon(r[1] === 'ok' ? 'check' : 'info') + esc(r[0]);
  },
  toggleFav: function toggleFav(id) {
    var f = Store.data.favorites,
      i = f.indexOf(id);
    if (i >= 0) f.splice(i, 1);else f.push(id);
    Store.save();
  },
  connBanner: function connBanner() {
    if (this.connected !== false) return '';
    return "<div class=\"banner\"><b>N\xE3o estou falando com o Premiere.</b>Abra um projeto e toque no nome l\xE1 em cima para reconectar.".concat(FE.lastHostError ? "<br><span class=\"mono\" style=\"font-size:10.5px\">".concat(esc(FE.lastHostError), "</span>") : '', "</div>");
  },
  bindSearch: function bindSearch() {
    var _this0 = this;
    var q = $('#q'),
      box = $('#results');
    var sel = 0,
      items = [];
    var norm = function norm(s) {
      s = String(s).toLowerCase();
      return s.normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g, '') : s;
    };
    var draw = function draw() {
      var term = norm(q.value.trim());
      if (!term) {
        box.classList.remove('show');
        return;
      }
      items = _this0.tools.filter(function (x) {
        return norm("".concat(x.title, " ").concat(x.desc, " ").concat(x.keywords || '')).includes(term);
      });
      sel = 0;
      box.innerHTML = items.length ? items.map(function (x, i) {
        return "<div class=\"result ".concat(i === 0 ? 'sel' : '', "\" data-id=\"").concat(x.id, "\"><div class=\"ri\">").concat(icon(x.icon), "</div><div><b>").concat(esc(x.title), "</b><span>").concat(esc(x.desc), "</span></div></div>");
      }).join('') : '<div class="empty">Nada por aqui. Tente “zoom”, “legenda”, “whoosh”…</div>';
      box.classList.add('show');
    };
    var pick = function pick(id) {
      q.value = '';
      box.classList.remove('show');
      q.blur();
      _this0.openTool(id);
    };
    q.addEventListener('input', draw);
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        sel = clamp(sel + (e.key === 'ArrowDown' ? 1 : -1), 0, items.length - 1);
        $$('.result', box).forEach(function (r, i) {
          return r.classList.toggle('sel', i === sel);
        });
      } else if (e.key === 'Enter' && items[sel]) pick(items[sel].id);else if (e.key === 'Escape') {
        q.value = '';
        box.classList.remove('show');
        q.blur();
      }
    });
    box.addEventListener('mousedown', function (e) {
      var r = e.target.closest('[data-id]');
      if (r) {
        e.preventDefault();
        pick(r.getAttribute('data-id'));
      }
    });
    q.addEventListener('blur', function () {
      return setTimeout(function () {
        return box.classList.remove('show');
      }, 150);
    });
  },
  poll: function poll(manual) {
    var _this1 = this;
    if (this.polling) return;
    this.polling = true;
    FE.call('info').then(function (info) {
      var was = _this1.connected;
      _this1.connected = true;
      _this1.info = info;
      if (was === false && !_this1.page) _this1.go(_this1.current);
      if (manual) UI.toast('Conectado ao Premiere ' + (info.version || ''), 'info');
    }).catch(function (e) {
      var was = _this1.connected;
      _this1.connected = false;
      _this1.info = null;
      if (manual) UI.toast('Sem conexão: ' + e.message, 'err');
      if (was !== false && !_this1.page) _this1.go(_this1.current);
    }).then(function () {
      _this1.polling = false;
      Splash.ready();
      _this1.renderWho();
      _this1.updateCtx();
      _this1.listeners.forEach(function (fn) {
        try {
          fn(_this1.info);
        } catch (e) {}
      });
    });
  },
  renderWho: function renderWho() {
    var w = $('#who'),
      i = this.info;
    if (!this.connected) {
      w.innerHTML = "<b>Fast Edit</b><span><i class=\"dot off\"></i>Premiere desconectado \xB7 toque para tentar</span>";
      return;
    }
    if (!i.project) {
      w.innerHTML = "<b>Fast Edit</b><span><i class=\"dot on\"></i>Premiere ".concat(esc(String(i.version).split('.').slice(0, 2).join('.')), " \xB7 nenhum projeto</span>");
      return;
    }
    var s = i.seq;
    w.innerHTML = "<b>".concat(esc(i.project.replace(/\.prproj$/i, '')), "</b><span><i class=\"dot on\"></i>").concat(s ? "".concat(esc(s.name), " \xB7 ").concat(s.w, "\xD7").concat(s.h, " \xB7 ").concat(s.fps, "fps") : 'nenhuma sequência aberta', "</span>");
  }
};
var QUICK = [{
  k: 'adj',
  name: 'Camada',
  hand: 'de ajuste',
  icon: 'adjust'
}, {
  k: 'matte',
  name: 'Matte',
  hand: 'na agulha',
  icon: 'layers'
}, {
  k: 'paste',
  name: 'Colar',
  hand: 'imagem',
  icon: 'paste'
}, {
  k: 'frame',
  name: 'Copiar',
  hand: 'frame',
  icon: 'camera'
}, {
  k: 'setup',
  name: 'Iniciar',
  hand: 'projeto',
  icon: 'bins'
}];
var Home = {
  render: function render(view) {
    var _this10 = this;
    view.innerHTML = "\n      ".concat(App.connBanner(), "\n      <div id=\"homeUpdate\"></div>\n      <div class=\"feature inv\"><div class=\"ft\"><h2>Bora editar!</h2><p>Selecione na timeline e escolha uma a\xE7\xE3o.</p></div>").concat(art('mascot'), "</div>\n      <div id=\"homeStats\"></div>\n      <div class=\"section\"><h3>Atalhos</h3><div class=\"shelf-ctl\"><span class=\"sbtn\" data-shelf=\"-1\" title=\"Anterior\">").concat(icon('back'), "</span><span class=\"sbtn\" data-shelf=\"1\" title=\"Pr\xF3ximo\">").concat(icon('chev'), "</span><a data-shelfmode></a></div></div>\n      <div class=\"shelf\" id=\"homeQA\">").concat(QUICK.map(function (q) {
      return "<div class=\"qcard\" data-qa=\"".concat(q.k, "\"><div class=\"qn\">").concat(q.name, "</div><div class=\"qh hand\">").concat(q.hand, "</div><div class=\"qa\">").concat(icon(q.icon), "</div><div class=\"qf\">usar agora").concat(icon('chev'), "</div></div>");
    }).join(''), "</div>\n      <div class=\"shelf-dots\" id=\"shelfDots\"></div>\n      <div class=\"section\"><h3>Favoritos</h3></div>\n      <div id=\"homeFavs\"></div>\n      <div class=\"madeby hand\">feito com \u2615 por <b data-credit>@odalluz</b></div>");
    this.renderStats(App.info);
    this.renderFavs();
    this.renderLog();
    this.renderUpdate();
    this.bindShelf(view);
    view.addEventListener('click', function (e) {
      if (e.target.closest('[data-credit]')) return FE.openURL(CREDIT_URL);
      var up = e.target.closest('[data-update]');
      if (up) return Updater.install(up);
      var q = e.target.closest('[data-qa]');
      if (q) {
        if (_this10.dragged) return;
        return _this10.quick(q.getAttribute('data-qa'), q);
      }
      var star = e.target.closest('[data-star]');
      if (star) {
        e.stopPropagation();
        App.toggleFav(star.getAttribute('data-star'));
        _this10.renderFavs();
        return;
      }
      var r = e.target.closest('[data-open]');
      if (r) App.openTool(r.getAttribute('data-open'));
    });
  },
  bindShelf: function bindShelf(view) {
    var _this11 = this;
    var shelf = $('#homeQA', view),
      dots = $('#shelfDots', view),
      modeBtn = $('[data-shelfmode]', view);
    var apply = function apply() {
      var grid = Store.s.shelfMode === 'grid';
      shelf.classList.toggle('grid', grid);
      view.querySelector('.shelf-ctl').classList.toggle('grid', grid);
      modeBtn.textContent = grid ? 'carrossel' : 'ver todos';
      upd();
    };
    var upd = function upd() {
      if (Store.s.shelfMode === 'grid') {
        dots.innerHTML = '';
        return;
      }
      var max = shelf.scrollWidth - shelf.clientWidth;
      var n = Math.max(1, Math.ceil(shelf.scrollWidth / Math.max(1, shelf.clientWidth)));
      var at = max > 0 ? Math.round(shelf.scrollLeft / max * (n - 1)) : 0;
      dots.innerHTML = n > 1 ? Array.from({
        length: n
      }, function (_, i) {
        return "<i class=\"".concat(i === at ? 'on' : '', "\"></i>");
      }).join('') : '';
    };
    var go = function go(dir) {
      var to = shelf.scrollLeft + dir * Math.max(140, shelf.clientWidth * 0.8);
      var from = shelf.scrollLeft,
        t0 = Date.now();
      var _step = function step() {
        var k = Math.min(1, (Date.now() - t0) / 260);
        shelf.scrollLeft = from + (to - from) * (1 - Math.pow(1 - k, 3));
        if (k < 1) requestAnimationFrame(_step);else upd();
      };
      requestAnimationFrame(_step);
    };
    var down = false,
      sx = 0,
      sl = 0;
    shelf.addEventListener('mousedown', function (e) {
      if (Store.s.shelfMode === 'grid') return;
      down = true;
      _this11.dragged = false;
      sx = e.clientX;
      sl = shelf.scrollLeft;
      shelf.classList.add('dragging');
      e.preventDefault();
    });
    document.addEventListener('mousemove', function (e) {
      if (!down) return;
      var dx = e.clientX - sx;
      if (Math.abs(dx) > 5) _this11.dragged = true;
      shelf.scrollLeft = sl - dx;
    });
    document.addEventListener('mouseup', function () {
      if (!down) return;
      down = false;
      shelf.classList.remove('dragging');
      upd();
      setTimeout(function () {
        _this11.dragged = false;
      }, 0);
    });
    shelf.addEventListener('wheel', function (e) {
      if (Store.s.shelfMode === 'grid') return;
      var d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      var max = shelf.scrollWidth - shelf.clientWidth;
      if (d > 0 && shelf.scrollLeft < max - 1 || d < 0 && shelf.scrollLeft > 0) {
        shelf.scrollLeft += d;
        e.preventDefault();
        upd();
      }
    });
    shelf.addEventListener('scroll', upd);
    view.querySelectorAll('[data-shelf]').forEach(function (b) {
      return b.addEventListener('click', function () {
        return go(parseInt(b.getAttribute('data-shelf'), 10));
      });
    });
    modeBtn.addEventListener('click', function () {
      Store.set('shelfMode', Store.s.shelfMode === 'grid' ? 'carousel' : 'grid');
      apply();
    });
    window.addEventListener('resize', upd);
    setTimeout(apply, 0);
  },
  renderUpdate: function renderUpdate() {
    var el = $('#homeUpdate');
    if (!el) return;
    var u = Updater.available;
    el.innerHTML = u ? "<div class=\"update-card\"><div class=\"ut\"><b>Vers\xE3o ".concat(esc(u.version), " chegou \u2728</b><span>").concat(esc((u.notes || 'Melhorias e correções.').split('\n')[0]), "</span></div><button class=\"btn primary sm\" data-update>Atualizar</button></div>") : '';
  },
  renderStats: function renderStats(info) {
    var el = $('#homeStats');
    if (!el) return;
    var s = info && info.seq;
    var today = info && info.project ? Timer.todayFor(Timer.keyFor(info)) : 0;
    var h = Math.floor(today / 3600),
      m = Math.floor(today % 3600 / 60);
    el.innerHTML = "<div class=\"stats\">\n      <div class=\"stat\"><b>".concat(s ? s.selected : '–', "</b><span>selecionados</span></div>\n      <div class=\"stat\"><b>").concat(s ? s.clips : '–', "</b><span>clipes</span></div>\n      <div class=\"stat\"><b>").concat(s ? fmtDur(s.duration).replace(/^00:/, '') : '–', "</b><span>dura\xE7\xE3o</span></div>\n      <div class=\"stat\"><b>").concat(h, "h").concat(pad2(m), "</b><span>hoje</span></div></div>");
  },
  renderFavs: function renderFavs() {
    var el = $('#homeFavs');
    var favs = Store.data.favorites.map(function (id) {
      return App.tool(id);
    }).filter(Boolean);
    el.innerHTML = favs.length ? favs.map(function (t) {
      return App.rowHTML(t);
    }).join('') : '<div class="hint">Toque na ☆ de uma ferramenta para fixar aqui.</div>';
  },
  renderLog: function renderLog() {
    var el = $('#homeLog');
    if (!el) return;
    var h = Store.data.history.slice(0, 6);
    el.innerHTML = h.length ? h.map(function (x) {
      return "<div class=\"li\" style=\"cursor:default\"><span class=\"ic\" style=\"color:".concat(x.ok ? 'var(--ok)' : 'var(--bad)', "\">").concat(icon(x.ok ? 'check' : 'x'), "</span><span class=\"nm\">").concat(esc(x.msg), "</span><span class=\"sub\">").concat(new Date(x.t).toTimeString().slice(0, 5), "</span></div>");
    }).join('') : "<div class=\"empty\">".concat(art('magic'), "Nada por aqui ainda.</div>");
  },
  quick: function quick(k, btn) {
    var s = Store.s;
    if (k === 'pop') UI.run(btn, 'Pop', 'motion', {
      preset: 'pop',
      where: 'in',
      frames: s.frames,
      ease: true,
      replace: true,
      intensity: s.intensity
    }, function (d) {
      return "Pop aplicado em ".concat(d.clips, " clipe(s)");
    }).catch(function () {});
    if (k === 'adj') Stack.apply('adjustment', !!(window.event && window.event.shiftKey), btn);
    if (k === 'matte') Stack.apply('matte', !!(window.event && window.event.shiftKey), btn);
    if (k === 'setup') App.openTool('setup');
    if (k === 'whoosh') {
      var w = SFX.whoosh();
      if (!w) {
        UI.toast('Nenhum whoosh nas suas pastas. Escolha um na aba Sons.', 'info');
        App.go('sfx');
        return;
      }
      UI.run(btn, 'Som', 'placeSfx', {
        path: w,
        mode: 'playhead',
        track: s.sfxTrack,
        offsetFrames: 0
      }, 'Whoosh inserido no cursor').catch(function () {});
    }
    if (k === 'gaps') UI.confirm('Fechar espaços vazios', 'Remove os buracos entre clipes na sequência inteira, sem dessincronizar as trilhas.', 'Fechar').then(function (ok) {
      if (ok) UI.run(btn, 'Limpar timeline', 'closeGaps', {
        minFrames: 1
      }, function (d) {
        return d.gaps ? "".concat(d.gaps, " espa\xE7o(s) removido(s) \xB7 ").concat(d.seconds, "s") : 'Nenhum espaço vazio';
      }).catch(function () {});
    });
    if (k === 'organize') App.openTool('organizer');
    if (k === 'paste') Clip.paste(btn);
    if (k === 'frame') Clip.copyFrame(btn);
    if (k === 'guide') FE.call('guidesState').then(function (st) {
      if (!st.count) {
        App.openTool('social');
        return;
      }
      return FE.call('toggleGuides', {}).then(function (r) {
        return UI.toast(r.visible ? 'Guia visível' : 'Guia escondida', 'info');
      });
    }).catch(function (er) {
      return UI.toast(er.message, 'err');
    });
  }
};
App.onInfo(function (info) {
  if (App.current === 'home' && !App.page) Home.renderStats(info);
});
var Theme = {
  apply: function apply(t) {
    var link = $('link[rel=stylesheet]');
    if (!link) return;
    var want = t === 'cobalt' ? 'css/fastedit-cobalt.css' : t === 'neon' ? 'css/fastedit-neon.css' : 'css/fastedit.css';
    if (link.getAttribute('href') !== want) link.setAttribute('href', want);
  }
};
var Splash = {
  el: null,
  pct: 0,
  t0: 0,
  done: false,
  show: function show() {
    var _this12 = this;
    this.t0 = Date.now();
    var el = document.createElement('div');
    el.className = 'splash walk';
    el.innerHTML = "".concat(art('mascot'), "<h1>Fast Edit</h1><div class=\"tagline\">edite r\xE1pido, fique pelo caf\xE9</div><div class=\"pct\">0%</div><div class=\"credit\">feito por @odalluz \xB7 v").concat(APP_VERSION, "</div>");
    document.body.appendChild(el);
    this.el = el;
    this.timer = setInterval(function () {
      var target = _this12.done ? 100 : 86;
      _this12.pct = Math.min(target, _this12.pct + (_this12.done ? 9 : 3 + Math.random() * 4));
      $('.pct', el).textContent = Math.round(_this12.pct) + '%';
      if (_this12.pct >= 100 && Date.now() - _this12.t0 > 900) _this12.hide();
    }, 60);
  },
  ready: function ready() {
    this.done = true;
  },
  hide: function hide() {
    clearInterval(this.timer);
    if (!this.el) return;
    var el = this.el;
    this.el = null;
    el.classList.add('hide');
    setTimeout(function () {
      el.remove();
      if (!Store.data.onboarded) Onboarding.show();
    }, 380);
  }
};
var Onboarding = {
  themes: function themes() {
    var cur = Store.s.theme || 'cream';
    var opt = function opt(id, name, bg, fg, acc) {
      return "<div class=\"theme-opt ".concat(cur === id ? 'on' : '', "\" data-theme=\"").concat(id, "\">\n      <div class=\"theme-sw\" style=\"background:").concat(bg, "\"><i style=\"background:").concat(acc, "\"></i><b style=\"background:").concat(fg, "\"></b><b style=\"background:").concat(fg, ";width:60%\"></b><u style=\"background:").concat(acc, "\"></u></div><span>").concat(name, "</span></div>");
    };
    return "<div class=\"theme-pick\">".concat(opt('cream', 'Creme', '#F3EEE4', 'rgba(35,64,200,.25)', '#2340C8')).concat(opt('cobalt', 'Cobalto', '#2340C8', 'rgba(245,240,230,.3)', '#F5F0E6')).concat(opt('neon', 'Neon', '#0B0B0B', '#232323', '#C4F82A'), "</div>");
  },
  slides: [{
    art: 'timeline',
    t: 'Selecione na timeline',
    p: 'O Fast Edit sempre age nos clipes que você selecionou no Premiere. O topo de cada ferramenta mostra quantos estão selecionados.'
  }, {
    art: 'magic',
    t: 'Escolha e pronto',
    p: 'Abra uma ferramenta, ajuste se quiser e aplique. Errou? Ctrl+Z no Premiere desfaz.'
  }, {
    art: 'clock',
    t: 'Seu tempo conta',
    p: 'O cronômetro registra sozinho as horas de cada projeto e calcula quanto cobrar.'
  }, {
    theme: true,
    t: 'Escolha seu visual',
    p: 'Dá para trocar quando quiser em Ajustes (engrenagem).'
  }],
  show: function show() {
    var _this13 = this;
    var i = 0;
    var el = document.createElement('div');
    el.className = 'onb';
    document.body.appendChild(el);
    var close = function close() {
      Store.data.onboarded = true;
      Store.save();
      el.remove();
    };
    var draw = function draw() {
      var s = _this13.slides[i];
      el.innerHTML = "<div class=\"oart\">".concat(s.theme ? Onboarding.themes() : art(s.art), "</div>\n        <div class=\"dots\">").concat(_this13.slides.map(function (x, j) {
        return "<i class=\"".concat(j === i ? 'on' : '', "\"></i>");
      }).join(''), "</div>\n        <h2>").concat(s.t, "</h2><p>").concat(s.p, "</p>\n        <div class=\"onav\"><a data-skip>Pular</a><button class=\"btn primary\" data-next>").concat(i === _this13.slides.length - 1 ? 'Começar' : 'Próximo', "</button></div>");
    };
    el.addEventListener('click', function (e) {
      var th = e.target.closest('[data-theme]');
      if (th) {
        Store.set('theme', th.getAttribute('data-theme'));
        Theme.apply(Store.s.theme);
        draw();
        return;
      }
      if (e.target.closest('[data-skip]')) close();
      if (e.target.closest('[data-next]')) {
        if (i < _this13.slides.length - 1) {
          i++;
          draw();
        } else close();
      }
    });
    draw();
  }
};
var MOTION_PRESETS = [['fade', 'Fade'], ['zoom_in', 'Zoom In'], ['zoom_out', 'Zoom Out'], ['pop', 'Pop'], ['bounce', 'Bounce'], ['slide_l', 'Slide ←'], ['slide_r', 'Slide →'], ['slide_u', 'Slide ↑'], ['slide_d', 'Slide ↓'], ['rise', 'Rise'], ['drop', 'Drop'], ['spin', 'Spin'], ['swing', 'Swing']];
var FE_SINGLE_UI = {
  punch: 1,
  pulse: 1,
  shake: 1,
  kenburns: 1
};
var SINGLE_PRESETS = [['punch', 'Punch Zoom'], ['pulse', 'Pulse'], ['shake', 'Shake'], ['kenburns', 'Ken Burns']];
var KTRANS = [['push_l', 'Push ←'], ['push_r', 'Push →'], ['push_u', 'Push ↑'], ['push_d', 'Push ↓'], ['zoom', 'Zoom In'], ['zoom_out', 'Zoom Out'], ['spin', 'Spin'], ['flash_zoom', 'Flash Zoom']];
var Animate = {
  effects: null,
  transitions: null,
  loadEffects: function loadEffects(force) {
    var _this14 = this;
    if (this.effects && !force) return Promise.resolve(this.effects);
    return FE.call('listEffects').then(function (d) {
      _this14.effects = d;
      return d;
    });
  },
  loadTransitions: function loadTransitions(force) {
    var _this15 = this;
    if (this.transitions && !force) return Promise.resolve(this.transitions);
    return FE.call('listTransitions').then(function (d) {
      _this15.transitions = d;
      return d;
    });
  }
};
App.registerTool({
  id: 'motion',
  module: 'animate',
  icon: 'motion',
  title: 'Animações',
  desc: 'Entradas, saídas e ênfases com keyframes de verdade',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha entrada ou saída', 'Toque em um estilo'],
  keywords: 'animação keyframe zoom pop slide fade escala posição rotação entrada saída shake punch ken burns',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Aplicar em</label>".concat(UI.seg('where', [['in', 'Entrada'], ['out', 'Saída'], ['both', 'Ambos']], s.where), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('frames', 2, 60, 1, s.frames, ' fr'), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('intensity', 0.2, 2, 0.1, s.intensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('ease', 'Movimento suave', s.ease)).concat(UI.toggle('replace', 'Substituir animação anterior', s.replace), "</div>\n        <div class=\"row\"><label class=\"l\">Curva</label>").concat(UI.seg('motionCurve', [['std', 'Padrão'], ['editor', 'Minha curva']], s.motionCurve || 'std'), "</div>\n      </div></details>\n      <div class=\"tiles\">").concat(MOTION_PRESETS.map(function (p) {
      return "<div class=\"tile\" data-preset=\"".concat(p[0], "\"><div class=\"pv pv-").concat(p[0], "\"><b></b></div><span>").concat(p[1], "</span></div>");
    }).join(''), "</div>\n      <div class=\"section-label\">\xCAnfase</div>\n      <div class=\"row\" style=\"display:none\">").concat(UI.toggle('_atPlayhead', 'Na agulha', true), "</div>\n      <div class=\"tiles\">").concat(SINGLE_PRESETS.map(function (p) {
      return "<div class=\"tile\" data-preset=\"".concat(p[0], "\"><div class=\"pv pv-").concat(p[0], "\"><b></b></div><span>").concat(p[1], "</span></div>");
    }).join(''), "</div>\n      <div class=\"btns\"><button class=\"btn sm\" data-reset>").concat(icon('refresh'), "Limpar anima\xE7\xE3o</button></div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-gocurve]')) return App.openTool('curves');
      var t = e.target.closest('[data-preset]');
      if (t) {
        var s2 = Store.s;
        var preset = t.getAttribute('data-preset');
        var label = (MOTION_PRESETS.concat(SINGLE_PRESETS).find(function (p) {
          return p[0] === preset;
        }) || [0, preset])[1];
        UI.run(t, 'Motion', 'motion', {
          preset: preset,
          where: s2.where,
          frames: s2.frames,
          ease: s2.ease,
          replace: s2.replace,
          intensity: s2.intensity,
          atPlayhead: $('[data-toggle="_atPlayhead"]', el).checked,
          samples: s2.motionCurve === 'editor' && !FE_SINGLE_UI[preset] ? Curves.samples(Curves.current()) : null
        }, function (d) {
          return "".concat(label, " em ").concat(d.clips, " clipe(s) \xB7 ").concat(d.keys, " keyframes");
        });
      }
      if (e.target.closest('[data-reset]')) UI.run(e.target.closest('[data-reset]'), 'Motion', 'resetMotion', {}, function (d) {
        return "Anima\xE7\xE3o removida de ".concat(d.clips, " clipe(s)");
      });
    });
  }
});
App.registerTool({
  id: 'transitions',
  module: 'animate',
  icon: 'transition',
  title: 'Transições de movimento',
  desc: 'Push, zoom e spin no corte entre dois clipes',
  needs: 'clips',
  steps: ['Selecione 2+ clipes colados', 'Ajuste a duração', 'Toque em uma transição'],
  keywords: 'transição push slide whip zoom spin corte vertical horizontal movimento',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>".concat(UI.range('transFrames', 2, 30, 1, s.transFrames, ' fr'), "</div>\n      <div class=\"row\">").concat(UI.toggle('transWhoosh', 'Whoosh no corte', s.transWhoosh), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('transIntensity', 0.3, 1.5, 0.1, s.transIntensity, '×'), "</div>\n        <div class=\"row\"><label class=\"l\">Curva</label>").concat(UI.seg('transCurve', [['std', 'Padrão'], ['editor', 'Minha curva']], s.transCurve || 'std'), "</div>\n      </div></details>\n      <div class=\"tiles\">").concat(KTRANS.map(function (p) {
      return "<div class=\"tile\" data-kt=\"".concat(p[0], "\"><div class=\"pvt pvt-").concat(p[0], "\"><i></i><u></u></div><span>").concat(p[1], "</span></div>");
    }).join(''), "</div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var kt = e.target.closest('[data-kt]');
      if (!kt) return;
      var s2 = Store.s,
        type = kt.getAttribute('data-kt');
      UI.run(kt, 'Transição', 'ktransition', {
        type: type,
        frames: s2.transFrames,
        intensity: s2.transIntensity,
        samples: s2.transCurve === 'editor' ? Curves.samples(Curves.current()) : null
      }, function (d) {
        return "".concat((KTRANS.find(function (k) {
          return k[0] === type;
        }) || [])[1], " em ").concat(d.cuts.length, " corte(s)");
      }).then(function (d) {
        var wh = s2.transWhoosh ? SFX.whoosh() : null;
        if (s2.transWhoosh && !wh) UI.toast('Nenhum whoosh encontrado nas suas pastas de sons.', 'info');
        if (wh && d && d.cuts && d.cuts.length) {
          FE.call('placeSfx', {
            path: wh,
            mode: 'times',
            times: d.cuts,
            offsetFrames: -s2.transFrames,
            track: s2.sfxTrack
          }).then(function (r) {
            return UI.toast("".concat(r.placed, " whoosh(es) adicionados"), 'info');
          }).catch(function (er) {
            return UI.toast(er.message, 'err');
          });
        }
      }).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'native',
  module: 'animate',
  icon: 'zap',
  title: 'Transições do Premiere',
  desc: 'Qualquer transição instalada, em vários clipes de uma vez',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha a transição', 'Toque em Aplicar'],
  keywords: 'transição nativa cross dissolve dip to black lote premiere',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><input class=\"input grow\" data-filter placeholder=\"Buscar transi\xE7\xE3o\u2026\"><button class=\"btn sm\" data-load title=\"Recarregar\">".concat(icon('refresh'), "</button></div>\n      <div class=\"list\" data-tlist><div class=\"empty\">Carregando transi\xE7\xF5es\u2026</div></div>\n      <div class=\"row\"><label class=\"l\">Onde</label>").concat(UI.seg('nativeWhere', [['start', 'Início'], ['end', 'Fim'], ['both', 'Os dois']], s.nativeWhere), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"300\" data-nf value=\"").concat(s.nativeFrames, "\"><span class=\"muted\">frames</span></div>\n      <button class=\"btn primary block\" data-apply disabled>Escolha uma transi\xE7\xE3o na lista</button>");
    UI.bindSettings(el);
    var chosen = null,
      isAudio = false;
    var list = $('[data-tlist]', el),
      filter = $('[data-filter]', el),
      apply = $('[data-apply]', el);
    var draw = function draw() {
      if (!Animate.transitions) return;
      var f = filter.value.trim().toLowerCase(),
        favs = Store.data.transFavs;
      var all = Animate.transitions.video.map(function (n) {
        return [n, false];
      }).concat(Animate.transitions.audio.map(function (n) {
        return [n, true];
      }));
      var rows = all.filter(function (x) {
        return !f || x[0].toLowerCase().includes(f);
      }).sort(function (a, b) {
        return favs.includes(b[0]) - favs.includes(a[0]) || a[1] - b[1];
      });
      list.innerHTML = rows.length ? rows.map(function (x) {
        return "<div class=\"li ".concat(chosen === x[0] ? 'on' : '', "\" data-t=\"").concat(esc(x[0]), "\" data-a=\"").concat(x[1] ? 1 : 0, "\"><span class=\"nm\">").concat(esc(x[0]), "</span><span class=\"sub\">").concat(x[1] ? 'áudio' : 'vídeo', "</span><span class=\"ic ").concat(favs.includes(x[0]) ? 'on' : '', "\" data-fav=\"").concat(esc(x[0]), "\">").concat(icon('star'), "</span></div>");
      }).join('') : '<div class="empty">Nenhuma transição encontrada.</div>';
    };
    var load = function load(btn) {
      if (btn) btn.classList.add('busy');
      Animate.loadTransitions(!!btn).then(draw).catch(function (e) {
        list.innerHTML = "<div class=\"empty\">".concat(esc(e.message), "</div>");
      }).then(function () {
        return btn && btn.classList.remove('busy');
      });
    };
    load();
    filter.addEventListener('input', draw);
    $('[data-nf]', el).addEventListener('change', function (e) {
      return Store.set('nativeFrames', clamp(parseInt(e.target.value, 10) || 15, 1, 300));
    });
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-load]')) return load(e.target.closest('[data-load]'));
      var fav = e.target.closest('[data-fav]');
      if (fav) {
        var n = fav.getAttribute('data-fav'),
          arr = Store.data.transFavs,
          i = arr.indexOf(n);
        if (i >= 0) arr.splice(i, 1);else arr.push(n);
        Store.save();
        draw();
        return;
      }
      var row = e.target.closest('[data-t]');
      if (row) {
        chosen = row.getAttribute('data-t');
        isAudio = row.getAttribute('data-a') === '1';
        apply.disabled = false;
        apply.textContent = "Aplicar \u201C".concat(chosen, "\u201D");
        draw();
        return;
      }
      if (e.target.closest('[data-apply]') && chosen) {
        UI.run(apply, 'Transição', 'nativeTransition', {
          name: chosen,
          audio: isAudio,
          frames: Store.s.nativeFrames,
          where: Store.s.nativeWhere
        }, function (d) {
          return "".concat(d.added, " transi\xE7\xE3o(\xF5es) adicionada(s)").concat(d.failed ? " \xB7 ".concat(d.failed, " falha(s)") : '');
        }).catch(function () {});
      }
    });
  }
});
var CAP_IN = [['pop', 'Pop'], ['bounce', 'Bounce'], ['rise', 'Rise'], ['fade', 'Fade'], ['drop', 'Drop'], ['zoom_in', 'Zoom In'], ['zoom_out', 'Zoom Out'], ['slide_u', 'Slide ↑'], ['slide_l', 'Slide ←'], ['swing', 'Swing'], ['spin', 'Spin']];
App.registerTool({
  id: 'captions',
  module: 'animate',
  icon: 'caption',
  title: 'Legendas animadas',
  desc: 'Textos e legendas entrando palavra por palavra',
  needs: 'clips',
  steps: ['Selecione os textos', 'Escolha entrada e saída', 'Toque em Animar'],
  keywords: 'legenda texto caption palavra subtitle animar texto gráfico essential graphics',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Entrada</label>".concat(UI.select('capPreset', CAP_IN, s.capPreset, 'grow'), "<input class=\"input num\" type=\"number\" min=\"1\" max=\"60\" data-cin value=\"").concat(s.capIn, "\" title=\"frames\"></div>\n      <div class=\"row\"><label class=\"l\">Sa\xEDda</label>").concat(UI.select('capOut', [['none', 'Nenhuma']].concat(CAP_IN), s.capOut, 'grow'), "<input class=\"input num\" type=\"number\" min=\"1\" max=\"60\" data-cout value=\"").concat(s.capOutFrames, "\" title=\"frames\"></div>\n      <div class=\"row\"><label class=\"l\">Alcance</label>").concat(UI.seg('capTrack', [['false', 'Só os selecionados'], ['true', 'Trilha inteira']], String(s.capTrack)), "</div>\n      <div class=\"tiles\"><div class=\"tile wide\" style=\"max-width:none\" data-capprev><div class=\"pv pv-").concat(s.capPreset, "\"><b></b></div><span>pr\xE9via da entrada</span></div></div>\n      <button class=\"btn primary block\" data-cap>").concat(icon('wand'), "Animar legendas</button>");
    UI.bindSettings(el, function (k, v) {
      if (k === 'capPreset') $('[data-capprev] .pv', el).className = 'pv pv-' + v;
      if (k === 'capTrack') Store.set('capTrack', v === 'true' || v === true);
    });
    $('[data-cin]', el).addEventListener('change', function (e) {
      return Store.set('capIn', clamp(parseInt(e.target.value, 10) || 6, 1, 60));
    });
    $('[data-cout]', el).addEventListener('change', function (e) {
      return Store.set('capOutFrames', clamp(parseInt(e.target.value, 10) || 4, 1, 60));
    });
    $('[data-cap]', el).addEventListener('click', function (e) {
      var s2 = Store.s;
      UI.run(e.currentTarget, 'Legendas', 'captions', {
        preset: s2.capPreset,
        outPreset: s2.capOut,
        inFrames: s2.capIn,
        outFrames: s2.capOutFrames,
        wholeTrack: s2.capTrack === true || s2.capTrack === 'true',
        intensity: 1
      }, function (d) {
        return "".concat(d.clips, " legenda(s) animada(s)");
      }).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'effects',
  module: 'animate',
  icon: 'fx',
  title: 'Efeitos & Stacks',
  desc: 'Busque qualquer efeito e salve combinações',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Busque um efeito', 'Toque para aplicar'],
  keywords: 'efeito effect preset stack combinação lumetri blur desfoque favorito lote batch',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"row\">".concat(UI.seg('_fxKind', [['video', 'Vídeo'], ['audio', 'Áudio']], 'video'), "<button class=\"btn sm\" data-load>").concat(icon('refresh'), "</button></div>\n      <div class=\"row\"><input class=\"input grow\" data-filter placeholder=\"Buscar efeito\u2026\"></div>\n      <div class=\"chips\"><span class=\"chip on\" data-chipf=\"all\">Todos</span><span class=\"chip\" data-chipf=\"fav\">\u2605 Favoritos</span></div>\n      <div class=\"list tall\" data-flist><div class=\"empty\">Carregando efeitos\u2026</div></div>\n      <div class=\"section-label\">Montando stack</div>\n      <div class=\"chips\" data-builder></div>\n      <div class=\"btns\"><button class=\"btn sm\" data-applybuild>").concat(icon('check'), "Aplicar stack</button><button class=\"btn sm\" data-savebuild>").concat(icon('plus'), "Salvar stack</button><button class=\"btn sm ghost\" data-clearbuild>").concat(icon('x'), "</button></div>\n      <div class=\"section-label\">Stacks salvos</div>\n      <div class=\"list\" data-stacks></div>");
    var kind = 'video',
      onlyFav = false,
      build = [];
    var list = $('[data-flist]', el),
      filter = $('[data-filter]', el);
    var draw = function draw() {
      if (!Animate.effects) return;
      var f = filter.value.trim().toLowerCase(),
        favs = Store.data.effectFavs;
      var names = (Animate.effects[kind] || []).filter(function (n) {
        return !f || n.toLowerCase().includes(f);
      });
      if (onlyFav) names = names.filter(function (n) {
        return favs.includes(kind + ':' + n);
      });
      names.sort(function (a, b) {
        return favs.includes(kind + ':' + b) - favs.includes(kind + ':' + a) || a.localeCompare(b);
      });
      list.innerHTML = names.length ? names.slice(0, 400).map(function (n) {
        return "<div class=\"li\" data-fx=\"".concat(esc(n), "\"><span class=\"nm\">").concat(esc(n), "</span><span class=\"ic\" data-add=\"").concat(esc(n), "\" title=\"Adicionar ao stack\">").concat(icon('plus'), "</span><span class=\"ic ").concat(favs.includes(kind + ':' + n) ? 'on' : '', "\" data-fav=\"").concat(esc(n), "\">").concat(icon('star'), "</span></div>");
      }).join('') : "<div class=\"empty\">".concat(Animate.effects[kind] && Animate.effects[kind].length ? 'Nenhum efeito encontrado.' : 'Lista vazia — conecte ao Premiere e recarregue.', "</div>");
    };
    var drawBuild = function drawBuild() {
      $('[data-builder]', el).innerHTML = build.length ? build.map(function (n, i) {
        return "<span class=\"chip\" data-rm=\"".concat(i, "\">").concat(esc(n), " \u2715</span>");
      }).join('') : '<span class="hint" style="margin:3px">Vazio — use + na lista</span>';
    };
    var drawStacks = function drawStacks() {
      var st = Store.data.stacks;
      $('[data-stacks]', el).innerHTML = st.length ? st.map(function (x, i) {
        return "<div class=\"li\" data-stack=\"".concat(i, "\"><span class=\"nm\"><b>").concat(esc(x.name), "</b> <span class=\"sub\">").concat(x.audio ? 'áudio · ' : '').concat(x.effects.map(esc).join(' + '), "</span></span><span class=\"ic\" data-stackapply=\"").concat(i, "\" title=\"Aplicar\">").concat(icon('play'), "</span><span class=\"ic\" data-stackdel=\"").concat(i, "\" title=\"Excluir\">").concat(icon('trash'), "</span></div>");
      }).join('') : '<div class="empty">Monte um stack com <b>+</b> e salve para reaplicar com 1 clique.</div>';
    };
    var load = function load(btn) {
      if (btn) btn.classList.add('busy');
      Animate.loadEffects(!!btn).then(draw).catch(function (e) {
        list.innerHTML = "<div class=\"empty\">".concat(esc(e.message), "</div>");
      }).then(function () {
        return btn && btn.classList.remove('busy');
      });
    };
    load();
    drawBuild();
    drawStacks();
    filter.addEventListener('input', draw);
    UI.bindSettings(el, function (k, v) {
      if (k === '_fxKind') {
        kind = v;
        build = [];
        drawBuild();
        draw();
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(s) {
        return e.target.closest(s);
      };
      if (g('[data-load]')) return load(g('[data-load]'));
      var chip = g('[data-chipf]');
      if (chip) {
        onlyFav = chip.getAttribute('data-chipf') === 'fav';
        $$('[data-chipf]', el).forEach(function (c) {
          return c.classList.toggle('on', c === chip);
        });
        draw();
        return;
      }
      if (g('[data-fav]')) {
        var k = kind + ':' + g('[data-fav]').getAttribute('data-fav'),
          a = Store.data.effectFavs,
          i = a.indexOf(k);
        if (i >= 0) a.splice(i, 1);else a.push(k);
        Store.save();
        draw();
        return;
      }
      if (g('[data-add]')) {
        build.push(g('[data-add]').getAttribute('data-add'));
        drawBuild();
        return;
      }
      if (g('[data-rm]')) {
        build.splice(parseInt(g('[data-rm]').getAttribute('data-rm'), 10), 1);
        drawBuild();
        return;
      }
      if (g('[data-clearbuild]')) {
        build = [];
        drawBuild();
        return;
      }
      if (g('[data-applybuild]')) {
        if (!build.length) return UI.toast('Adicione efeitos ao stack com +', 'info');
        return UI.run(g('[data-applybuild]'), 'Stack', 'applyEffects', {
          names: build,
          audio: kind === 'audio'
        }, fxMsg).catch(function () {});
      }
      if (g('[data-savebuild]')) {
        if (!build.length) return UI.toast('Adicione efeitos ao stack com +', 'info');
        return UI.prompt('Nome do stack', 'Meu stack').then(function (name) {
          if (!name) return;
          Store.data.stacks.push({
            id: uid(),
            name: name,
            effects: build.slice(),
            audio: kind === 'audio'
          });
          Store.save();
          build = [];
          drawBuild();
          drawStacks();
          UI.toast('Stack salvo', 'ok');
        });
      }
      if (g('[data-stackapply]')) {
        var st = Store.data.stacks[parseInt(g('[data-stackapply]').getAttribute('data-stackapply'), 10)];
        return UI.run(g('[data-stackapply]'), 'Stack ' + st.name, 'applyEffects', {
          names: st.effects,
          audio: !!st.audio
        }, fxMsg).catch(function () {});
      }
      if (g('[data-stackdel]')) {
        var _i2 = parseInt(g('[data-stackdel]').getAttribute('data-stackdel'), 10);
        return UI.confirm('Excluir stack', "Excluir \u201C".concat(Store.data.stacks[_i2].name, "\u201D?"), 'Excluir').then(function (ok) {
          if (ok) {
            Store.data.stacks.splice(_i2, 1);
            Store.save();
            drawStacks();
          }
        });
      }
      var fx = g('[data-fx]');
      if (fx) UI.run(fx, 'Efeito', 'applyEffects', {
        names: [fx.getAttribute('data-fx')],
        audio: kind === 'audio'
      }, fxMsg).catch(function () {});
    });
  }
});
function fxMsg(d) {
  return "".concat(d.applied, " efeito(s) aplicado(s) em ").concat(d.clips, " clipe(s)").concat(d.missing && d.missing.length ? " \xB7 n\xE3o encontrado: ".concat(d.missing.join(', ')) : '');
}
var TB_N = 120;
var tbNoise = function tbNoise(i) {
  var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
};
var tbSmooth = function tbSmooth(x) {
  var i = Math.floor(x),
    f = x - i,
    e = f * f * (3 - 2 * f);
  return tbNoise(i) + (tbNoise(i + 1) - tbNoise(i)) * e;
};
var bump = function bump(u, c, w) {
  return Math.exp(-Math.pow((u - c) / w, 2));
};
var TAU = Math.PI * 2;
var TB_LOOKS = [{
  id: 'respiro',
  name: 'Respiro',
  period: 3,
  f: function f(u) {
    return 0.5 - 0.5 * Math.cos(TAU * u);
  }
}, {
  id: 'pulsacao',
  name: 'Pulsação',
  period: 1.2,
  f: function f(u) {
    return Math.min(1, bump(u, 0.12, 0.06) + 0.7 * bump(u, 0.34, 0.07));
  }
}, {
  id: 'mare',
  name: 'Maré',
  period: 4.5,
  f: function f(u) {
    return u < 0.7 ? Math.sin(u / 0.7 * Math.PI / 2) : Math.cos((u - 0.7) / 0.3 * Math.PI / 2);
  }
}, {
  id: 'impacto',
  name: 'Impacto',
  period: 1.5,
  f: function f(u) {
    return Math.exp(-u * 7);
  }
}, {
  id: 'tremor',
  name: 'Tremor',
  period: 1,
  f: function f(u) {
    return tbSmooth(u * 9 + 3);
  }
}, {
  id: 'sonho',
  name: 'Sonho',
  period: 6,
  f: function f(u) {
    return 0.55 + 0.3 * Math.sin(TAU * u) + 0.15 * Math.sin(TAU * 3 * u + 1);
  }
}, {
  id: 'flash',
  name: 'Flash',
  period: 1,
  f: function f(u) {
    return u < 0.14 ? 1 : 0.12 + 0.1 * Math.exp(-(u - 0.14) * 8);
  }
}, {
  id: 'trovao',
  name: 'Trovão',
  period: 3.2,
  f: function f(u) {
    return Math.min(1, 0.15 + 0.85 * Math.exp(-u * 5) + 0.55 * bump(u, 0.45, 0.04) + 0.35 * bump(u, 0.62, 0.05));
  }
}, {
  id: 'onda',
  name: 'Onda',
  period: 2,
  f: function f(u) {
    return 0.5 + 0.35 * Math.sin(TAU * u) + 0.15 * Math.sin(TAU * 4 * u);
  }
}, {
  id: 'fantasma',
  name: 'Fantasma',
  period: 2,
  f: function f() {
    return 0.85;
  }
}, {
  id: 'aparicao',
  name: 'Aparição',
  loop: false,
  f: function f(u) {
    return Math.sin(Math.PI * u);
  }
}, {
  id: 'deriva',
  name: 'Deriva',
  loop: false,
  f: function f(u) {
    return u * u * (3 - 2 * u);
  }
}];
var TB_LEVELS = {
  sutil: {
    streak: 1.5,
    echoes: 4,
    glow: 3
  },
  media: {
    streak: 2.5,
    echoes: 6,
    glow: 6
  },
  forte: {
    streak: 4,
    echoes: 9,
    glow: 12
  }
};
var TimeBlur = {
  look: function look(id) {
    return TB_LOOKS.find(function (l) {
      return l.id === id;
    }) || TB_LOOKS[0];
  },
  samples: function samples(l) {
    var out = [];
    for (var i = 0; i <= TB_N; i++) out.push(Math.max(0, Math.min(1, l.f(i / TB_N))));
    return out;
  },
  thumb: function thumb(l, on) {
    var pts = [],
      reps = l.loop === false ? 1 : 2;
    for (var i = 0; i <= 64; i++) {
      var x = i / 64,
        u = x === 1 ? 1 : x * reps % 1;
      var y = Math.max(0, Math.min(1, l.f(u)));
      pts.push("".concat((4 + x * 56).toFixed(1), ",").concat((44 - y * 36).toFixed(1)));
    }
    return "<svg viewBox=\"0 0 64 52\" class=\"cthumb\"><path d=\"M4 44H60\" class=\"cgrid\"/><path d=\"M".concat(pts.join('L'), "\" class=\"cline").concat(on ? ' on' : '', "\"/></svg>");
  },
  args: function args() {
    var s = Store.s,
      l = this.look(s.tbLook),
      lv = TB_LEVELS[s.tbLevel] || TB_LEVELS.media;
    return {
      samples: this.samples(l),
      period: l.period || 2,
      loop: l.loop !== false,
      streak: lv.streak * (s.tbStreak || 1),
      echoes: lv.echoes,
      pulse: s.tbPulse,
      mix: s.tbMix,
      light: s.tbLight !== false,
      glow: s.tbGlow !== false ? lv.glow : 0,
      shimmer: l.id === 'fantasma' ? 0.2 : 0.1
    };
  }
};
App.registerTool({
  id: 'timeblur',
  module: 'after',
  icon: 'blur',
  title: 'Rastro de luz',
  desc: 'Rastros de luz que pulsam, como filme antigo',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha um look', 'Toque em Aplicar'],
  keywords: 'time blur echo eco rastro luz ghost fantasma pulso streak trail glow brilho filme sonho shift',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"ctiles\" data-looks></div>\n      <div class=\"row\"><label class=\"l\">Intensidade</label>".concat(UI.seg('tbLevel', [['sutil', 'Sutil'], ['media', 'Média'], ['forte', 'Forte']], s.tbLevel), "</div>\n      <details class=\"adv\"><summary>Ajustes</summary><div>\n        <div class=\"row\"><label class=\"l\">Rastro</label>").concat(UI.range('tbStreak', 0.5, 2.5, 0.1, s.tbStreak, '×'), "</div>\n        <div class=\"row\"><label class=\"l\">Pulso</label>").concat(UI.range('tbPulse', 0, 1, 0.05, s.tbPulse, ''), "</div>\n        <div class=\"row\"><label class=\"l\">Mistura</label>").concat(UI.range('tbMix', 0, 1, 0.05, s.tbMix, ''), "</div>\n        <div class=\"row\">").concat(UI.toggle('tbLight', 'Somar como luz', s.tbLight !== false)).concat(UI.toggle('tbGlow', 'Desfoque', s.tbGlow !== false), "</div>\n      </div></details>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('blur'), "Aplicar</button><button class=\"btn sm\" data-off>").concat(icon('x'), "Desligar</button></div>");
    var draw = function draw() {
      var st = Store.s,
        fav = st.tbFav || [];
      var list = TB_LOOKS.slice().sort(function (a, b) {
        return (fav.indexOf(b.id) >= 0) - (fav.indexOf(a.id) >= 0);
      });
      $('[data-looks]', el).innerHTML = list.map(function (l) {
        var on = l.id === st.tbLook,
          f = fav.indexOf(l.id) >= 0;
        return "<div class=\"ctile ".concat(on ? 'on' : '', "\" data-look=\"").concat(l.id, "\">").concat(TimeBlur.thumb(l, on), "<span>").concat(esc(l.name), "</span><em data-fav=\"").concat(l.id, "\" class=\"").concat(f ? 'fav' : '', "\" title=\"Favorito\">").concat(f ? '★' : '☆', "</em></div>");
      }).join('');
    };
    draw();
    UI.bindSettings(el);
    var apply = function apply(btn) {
      return UI.run(btn, 'Rastro de luz', 'timeBlur', TimeBlur.args(), function (d) {
        return "".concat(TimeBlur.look(Store.s.tbLook).name, " em ").concat(d.clips, " clipe(s) \xB7 renderize a pr\xE9via (Enter)");
      });
    };
    el.addEventListener('click', function (e) {
      var fv = e.target.closest('[data-fav]');
      if (fv) {
        e.stopPropagation();
        var id = fv.getAttribute('data-fav'),
          fav = (Store.s.tbFav || []).slice(),
          i = fav.indexOf(id);
        if (i >= 0) fav.splice(i, 1);else fav.push(id);
        Store.set('tbFav', fav);
        draw();
        return;
      }
      var t = e.target.closest('[data-look]');
      if (t) {
        Store.set('tbLook', t.getAttribute('data-look'));
        draw();
        return;
      }
      var ap = e.target.closest('[data-apply]');
      if (ap) return apply(ap);
      var off = e.target.closest('[data-off]');
      if (off) UI.run(off, 'Rastro de luz', 'timeBlur', {
        remove: true
      }, function (d) {
        return "Rastro desligado em ".concat(d.clips, " clipe(s)");
      });
    });
  }
});
App.registerTool({
  id: 'beatfx',
  module: 'after',
  icon: 'zap',
  title: 'Efeito na batida',
  desc: 'Punch ou tremor em cada marcador da música',
  needs: 'seq',
  steps: ['Marque as batidas com M', 'Escolha o efeito', 'Toque em Aplicar'],
  keywords: 'batida beat marcador música ritmo punch zoom shake tremor pulso aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Efeito</label>".concat(UI.seg('beatPreset', [['punch', 'Punch'], ['shake', 'Tremor'], ['pulse', 'Pulso']], s.beatPreset), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('beatFrames', 2, 20, 1, s.beatFrames, ' fr'), "</div>\n      <details class=\"adv\"><summary>Ajustes</summary><div>\n        <div class=\"row\"><label class=\"l\">For\xE7a</label>").concat(UI.range('beatIntensity', 0.3, 2, 0.1, s.beatIntensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('beatSfx', 'Som de impacto em cada batida', s.beatSfx), "</div>\n      </div></details>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('zap'), "Aplicar nas batidas</button></div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-apply]');
      if (!b) return;
      var st = Store.s;
      UI.run(b, 'Batida', 'beatFx', {
        preset: st.beatPreset,
        frames: st.beatFrames,
        intensity: st.beatIntensity
      }, function (d) {
        return "".concat(d.done, " batida(s)").concat(d.skipped ? " \xB7 ".concat(d.skipped, " sem clipe") : '');
      }).then(function (d) {
        if (!st.beatSfx || !d || !d.times || !d.times.length) return;
        var hit = SFX.byCat('impact');
        if (!hit) {
          UI.toast('Nenhum som de impacto nas suas pastas.', 'info');
          return;
        }
        FE.call('placeSfx', {
          path: hit,
          mode: 'times',
          times: d.times,
          offsetFrames: 0,
          track: st.sfxTrack
        }).catch(function () {});
      }).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'flashcut',
  module: 'after',
  icon: 'wand',
  title: 'Flash no corte',
  desc: 'Flash branco rápido entre os clipes',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha a duração', 'Toque em Aplicar'],
  keywords: 'flash branco corte transição dip white aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>".concat(UI.seg('flashFrames', [[2, '2 fr'], [4, '4 fr'], [6, '6 fr'], [10, '10 fr']], s.flashFrames), "</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('wand'), "Aplicar</button></div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-apply]');
      if (!b) return;
      Animate.loadTransitions().then(function (d) {
        var v = d && d.video || [];
        var name = v.find(function (n) {
          return /dip to white|branco/i.test(n);
        }) || v.find(function (n) {
          return /white/i.test(n);
        });
        if (!name) {
          UI.toast('Transição "Dip to White" não encontrada.', 'err');
          return;
        }
        UI.run(b, 'Flash', 'nativeTransition', {
          name: name,
          frames: Store.s.flashFrames,
          where: 'start'
        }, function (r) {
          return "".concat(r.added, " flash(es) aplicado(s)");
        }).catch(function () {});
      }).catch(function (err) {
        return UI.toast(err.message, 'err');
      });
    });
  }
});
App.registerTool({
  id: 'speedfx',
  module: 'after',
  icon: 'motion',
  title: 'Câmera lenta',
  desc: 'Velocidade dos clipes em um toque',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Toque na velocidade'],
  keywords: 'câmera lenta slow motion velocidade speed 50% 25% rápido 60fps aftermovie same day',
  render: function render(el) {
    var opts = [[25, '25%'], [40, '40%'], [50, '50%'], [100, 'Normal'], [200, '200%']];
    el.innerHTML = "\n      <div class=\"tiles\">".concat(opts.map(function (o) {
      return "<div class=\"tile\" data-speed=\"".concat(o[0], "\"><div class=\"spd\">").concat(o[1], "</div><span>").concat(o[0] < 100 ? 'Lenta' : o[0] > 100 ? 'Rápida' : 'Original', "</span></div>");
    }).join(''), "</div>\n      <div class=\"row\">").concat(UI.toggle('_ripple', 'Empurrar o resto da timeline', false), "</div>");
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-speed]');
      if (!t) return;
      var v = parseInt(t.getAttribute('data-speed'), 10);
      UI.run(t, 'Velocidade', 'batch', {
        op: 'speed',
        value: v,
        ripple: $('[data-toggle="_ripple"]', el).checked
      }, function (d) {
        return "".concat(v, "% em ").concat(d.done, " clipe(s)");
      }).catch(function () {});
    });
  }
});
var CURVE_TYPES = [['custom', 'Personalizada'], ['back', 'Back'], ['bounce', 'Bounce'], ['cubic', 'Cubic'], ['elastic', 'Elastic'], ['expo', 'Expo']];
var CURVE_MODES = [['in', 'Entrada'], ['out', 'Saída'], ['inout', 'Ambos']];
var CURVE_PARAMS = {
  back: [['amount', 'Recuo', 0, 4, 0.05, 1.7]],
  bounce: [['bounces', 'Quiques', 1, 6, 1, 3], ['bounciness', 'Altura', 0.1, 0.8, 0.02, 0.4]],
  cubic: [['power', 'Força', 1.5, 6, 0.1, 3]],
  elastic: [['swing', 'Swing', 0.5, 3, 0.02, 1.5], ['osc', 'Oscilações', 1, 12, 0.5, 3], ['damp', 'Amortecimento', 1, 12, 0.1, 6]],
  expo: [['power', 'Força', 3, 16, 0.5, 10]]
};
var Ease = {
  mode: function mode(f, m, x) {
    if (m === 'out') return 1 - f(1 - x);
    if (m === 'inout') return x < 0.5 ? f(2 * x) / 2 : 1 - f(2 - 2 * x) / 2;
    return f(x);
  },
  back: function back(c, x) {
    var s = c.amount === undefined ? 1.7 : c.amount;
    return Ease.mode(function (t) {
      return (s + 1) * t * t * t - s * t * t;
    }, c.mode || 'out', x);
  },
  cubic: function cubic(c, x) {
    var p = c.power || 3;
    return Ease.mode(function (t) {
      return Math.pow(t, p);
    }, c.mode || 'inout', x);
  },
  expo: function expo(c, x) {
    var k = c.power || 10,
      d = Math.pow(2, -k);
    return Ease.mode(function (t) {
      return t <= 0 ? 0 : (Math.pow(2, k * (t - 1)) - d) / (1 - d);
    }, c.mode || 'out', x);
  },
  bounce: function bounce(c, x) {
    var n = Math.round(c.bounces || 3),
      r = c.bounciness || 0.4;
    var segs = [1];
    for (var k = 1; k <= n; k++) segs.push(2 * Math.pow(r, k / 2));
    var tot = segs.reduce(function (a, b) {
      return a + b;
    }, 0);
    var out = function out(t) {
      var T = t * tot;
      if (T <= 1) return T * T;
      T -= 1;
      for (var _k = 1; _k <= n; _k++) {
        var d = segs[_k];
        if (T <= d) {
          var u = (T - d / 2) / (d / 2);
          return 1 - Math.pow(r, _k) * (1 - u * u);
        }
        T -= d;
      }
      return 1;
    };
    return Ease.mode(function (t) {
      return 1 - out(1 - t);
    }, c.mode || 'out', x);
  },
  elastic: function elastic(c, x) {
    var A = c.swing === undefined ? 1.5 : c.swing,
      osc = c.osc || 3,
      dmp = c.damp || 6;
    var w = Math.PI * (2 * osc - 1);
    var g = function g(t) {
      return Math.exp(-dmp * t) * (Math.cos(w * t) - (A - 1) * Math.sin(w * t) * 0.6);
    };
    var g1 = g(1);
    var out = function out(t) {
      return 1 - (g(t) - g1 * t);
    };
    return Ease.mode(function (t) {
      return 1 - out(1 - t);
    }, c.mode || 'out', x);
  },
  custom: function custom(c, x) {
    var p = c.p || [0.42, 0, 0.58, 1];
    var pts = (c.pts || []).slice().sort(function (a, b) {
      return a[0] - b[0];
    });
    if (!pts.length) return Curves.bezier(p, x);
    var A = [[0, 0]].concat(pts, [[1, 1]]);
    var m = A.map(function (pt, i) {
      if (i === 0) return p[0] > 0.001 ? p[1] / p[0] : p[1] > 0 ? 8 : 0;
      if (i === A.length - 1) return p[2] < 0.999 ? (1 - p[3]) / (1 - p[2]) : p[3] < 1 ? 8 : 0;
      return (A[i + 1][1] - A[i - 1][1]) / Math.max(1e-4, A[i + 1][0] - A[i - 1][0]);
    });
    var i = 0;
    while (i < A.length - 2 && x > A[i + 1][0]) i++;
    var x0 = A[i][0],
      x1 = A[i + 1][0],
      y0 = A[i][1],
      y1 = A[i + 1][1],
      dx = Math.max(1e-4, x1 - x0);
    var t = clamp((x - x0) / dx, 0, 1),
      t2 = t * t,
      t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * dx * m[i] + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * dx * m[i + 1];
  }
};
var CP_ = function CP_(name, c) {
  return Object.assign({
    id: 'p_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_'),
    name: name
  }, c);
};
var CB = function CB(name, p) {
  return CP_(name, {
    type: 'custom',
    p: p,
    pts: []
  });
};
var CURVE_PRESETS = [CB('Linear', [0, 0, 1, 1]), CB('Suave', [0.37, 0, 0.63, 1]), CB('Ease In', [0.42, 0, 1, 1]), CB('Ease Out', [0, 0, 0.58, 1]), CB('Ease In-Out', [0.42, 0, 0.58, 1]), CB('Sine In', [0.12, 0, 0.39, 0]), CB('Sine Out', [0.61, 1, 0.88, 1]), CB('Sine In-Out', [0.37, 0, 0.63, 1]), CP_('Quad In', {
  type: 'cubic',
  mode: 'in',
  power: 2
}), CP_('Quad Out', {
  type: 'cubic',
  mode: 'out',
  power: 2
}), CP_('Quad In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 2
}), CP_('Cubic In', {
  type: 'cubic',
  mode: 'in',
  power: 3
}), CP_('Cubic Out', {
  type: 'cubic',
  mode: 'out',
  power: 3
}), CP_('Cubic In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 3
}), CP_('Quart In', {
  type: 'cubic',
  mode: 'in',
  power: 4
}), CP_('Quart Out', {
  type: 'cubic',
  mode: 'out',
  power: 4
}), CP_('Quart In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 4
}), CP_('Quint In', {
  type: 'cubic',
  mode: 'in',
  power: 5
}), CP_('Quint Out', {
  type: 'cubic',
  mode: 'out',
  power: 5
}), CP_('Quint In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 5
}), CP_('Expo In', {
  type: 'expo',
  mode: 'in',
  power: 10
}), CP_('Expo Out', {
  type: 'expo',
  mode: 'out',
  power: 10
}), CP_('Expo In-Out', {
  type: 'expo',
  mode: 'inout',
  power: 10
}), CB('Circ In', [0.55, 0, 1, 0.45]), CB('Circ Out', [0, 0.55, 0.45, 1]), CB('Circ In-Out', [0.85, 0, 0.15, 1]), CP_('Back In', {
  type: 'back',
  mode: 'in',
  amount: 1.7
}), CP_('Back Out', {
  type: 'back',
  mode: 'out',
  amount: 1.7
}), CP_('Back In-Out', {
  type: 'back',
  mode: 'inout',
  amount: 1.7
}), CP_('Back Out Forte', {
  type: 'back',
  mode: 'out',
  amount: 3
}), CP_('Elastic Out', {
  type: 'elastic',
  mode: 'out',
  swing: 1.5,
  osc: 3,
  damp: 6
}), CP_('Elastic In', {
  type: 'elastic',
  mode: 'in',
  swing: 1.5,
  osc: 3,
  damp: 6
}), CP_('Elastic In-Out', {
  type: 'elastic',
  mode: 'inout',
  swing: 1.3,
  osc: 2.5,
  damp: 6
}), CP_('Mola Leve', {
  type: 'elastic',
  mode: 'out',
  swing: 1,
  osc: 2,
  damp: 7
}), CP_('Mola Forte', {
  type: 'elastic',
  mode: 'out',
  swing: 2.4,
  osc: 4,
  damp: 4.5
}), CP_('Tremida', {
  type: 'elastic',
  mode: 'out',
  swing: 1.2,
  osc: 8,
  damp: 5
}), CP_('Bounce Out', {
  type: 'bounce',
  mode: 'out',
  bounces: 3,
  bounciness: 0.4
}), CP_('Bounce In', {
  type: 'bounce',
  mode: 'in',
  bounces: 3,
  bounciness: 0.4
}), CP_('Bounce In-Out', {
  type: 'bounce',
  mode: 'inout',
  bounces: 3,
  bounciness: 0.4
}), CP_('Quique Leve', {
  type: 'bounce',
  mode: 'out',
  bounces: 2,
  bounciness: 0.25
}), CB('Snap', [0.9, 0, 0.1, 1]), CB('Snap Out', [0.16, 1, 0.3, 1]), CB('Arrancada', [0.7, 0, 0.84, 0]), CB('Freio', [0.05, 0.7, 0.1, 1]), CB('Zoom Leve', [0.25, 0.1, 0.25, 1]), CB('Pop', [0.34, 1.56, 0.64, 1]), CB('Antecipação', [0.68, -0.6, 0.32, 1.6]), CB('Recua e Vai', [0.36, 0, 0.66, -0.56]), CP_('Ease + Elastic', {
  type: 'elastic',
  mode: 'out',
  swing: 1.1,
  osc: 1.5,
  damp: 5
}), CB('Whip', [0.8, 0, 0.05, 1]), CB('Flutuar', [0.45, 0.05, 0.55, 0.95]), CB('Degrau Suave', [1, 0, 0, 1])];
var Curves = {
  N: 120,
  bezier: function bezier(p, x) {
    var x1 = p[0],
      y1 = p[1],
      x2 = p[2],
      y2 = p[3];
    var bx = function bx(t) {
      return 3 * (1 - t) * (1 - t) * t * x1 + 3 * (1 - t) * t * t * x2 + t * t * t;
    };
    var by = function by(t) {
      return 3 * (1 - t) * (1 - t) * t * y1 + 3 * (1 - t) * t * t * y2 + t * t * t;
    };
    var lo = 0,
      hi = 1,
      t = x;
    for (var i = 0; i < 40; i++) {
      t = (lo + hi) / 2;
      if (bx(t) < x) lo = t;else hi = t;
    }
    return by(t);
  },
  norm: function norm(c) {
    if (!c) return CURVE_PRESETS[1];
    if (c.type) return c;
    if (c.fn === 'bounce') return {
      id: c.id,
      name: c.name,
      type: 'bounce',
      mode: 'out',
      bounces: 3,
      bounciness: 0.4
    };
    if (c.fn === 'elastic') return {
      id: c.id,
      name: c.name,
      type: 'elastic',
      mode: 'out',
      swing: 1.5,
      osc: 3,
      damp: 6
    };
    return {
      id: c.id,
      name: c.name,
      type: 'custom',
      p: (c.p || [0.37, 0, 0.63, 1]).slice(),
      pts: []
    };
  },
  value: function value(c, x) {
    c = this.norm(c);
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    var f = Ease[c.type] || Ease.custom;
    var y = f(c, x);
    return isFinite(y) ? y : x;
  },
  samples: function samples(c) {
    var out = [];
    for (var i = 0; i <= this.N; i++) out.push(Math.round(this.value(c, i / this.N) * 10000) / 10000);
    return out;
  },
  current: function current() {
    return this.norm(Store.s.curve || CURVE_PRESETS[1]);
  },
  range: function range(c) {
    var lo = 0,
      hi = 1;
    for (var i = 0; i <= 80; i++) {
      var y = this.value(c, i / 80);
      if (y < lo) lo = y;
      if (y > hi) hi = y;
    }
    var m = (hi - lo) * 0.1 + 0.04;
    return [lo - m, hi + m];
  },
  path: function path(c, w, h, pad) {
    var r = this.range(c),
      lo = r[0],
      hi = r[1],
      pts = [];
    for (var i = 0; i <= 60; i++) {
      var x = i / 60,
        y = this.value(c, x);
      pts.push("".concat((pad + x * (w - 2 * pad)).toFixed(1), ",").concat((pad + (hi - y) / (hi - lo) * (h - 2 * pad)).toFixed(1)));
    }
    return 'M' + pts.join('L');
  },
  thumb: function thumb(c, on) {
    var r = this.range(c),
      Y = function Y(v) {
        return (6 + (r[1] - v) / (r[1] - r[0]) * 40).toFixed(1);
      };
    return "<svg viewBox=\"0 0 64 52\" class=\"cthumb\"><path d=\"M6 ".concat(Y(0), "H58M6 ").concat(Y(1), "H58\" class=\"cgrid\"/><path d=\"").concat(this.path(c, 64, 52, 6), "\" class=\"cline").concat(on ? ' on' : '', "\"/></svg>");
  },
  clone: function clone(c) {
    return JSON.parse(JSON.stringify(this.norm(c)));
  },
  ofType: function ofType(type, prev) {
    if (type === 'custom') {
      var p = prev && prev.type === 'custom' ? prev.p : [0.42, 0, 0.58, 1];
      return {
        id: 'custom',
        name: 'Personalizada',
        type: 'custom',
        p: p.slice(),
        pts: prev && prev.pts ? prev.pts.slice() : []
      };
    }
    var c = {
      id: type,
      name: (CURVE_TYPES.find(function (t) {
        return t[0] === type;
      }) || [0, type])[1],
      type: type,
      mode: prev && prev.mode ? prev.mode : type === 'cubic' ? 'inout' : 'out'
    };
    (CURVE_PARAMS[type] || []).forEach(function (d) {
      c[d[0]] = d[5];
    });
    return c;
  }
};
App.registerTool({
  id: 'curves',
  module: 'animate',
  icon: 'curve',
  title: 'Curvas de animação',
  desc: 'Suavize os keyframes com gráfico ou presets',
  needs: 'clips',
  steps: ['Selecione clipes com keyframes', 'Escolha a curva', 'Toque em Aplicar'],
  keywords: 'curva easing ease velocidade bezier flow keyo keyframe suavizar overshoot bounce elastic back expo cubic graph gráfico interpolação',
  render: function render(el) {
    var s = Store.s;
    var cur = Curves.clone(Curves.current());
    var tab = s.curveTab || 'graph';
    el.innerHTML = "\n      <div class=\"ctabs\"><button data-ctab=\"graph\">Gr\xE1fico</button><button data-ctab=\"presets\">Presets</button></div>\n      <div data-pane=\"graph\">\n        <select class=\"select ctype\" data-ctype>".concat(CURVE_TYPES.map(function (t) {
      return "<option value=\"".concat(t[0], "\">").concat(t[1], "</option>");
    }).join(''), "</select>\n        <div class=\"curve-box\"><canvas data-cv></canvas></div>\n        <div class=\"chint\" data-chint>Duplo clique adiciona ponto \xB7 clique no ponto apaga</div>\n        <div data-params></div>\n        <div class=\"row cfav-head\"><div class=\"section-label\">Favoritos</div><button class=\"btn sm\" data-save>").concat(icon('plus'), "Salvar preset</button></div>\n        <div class=\"ctiles\" data-mine></div>\n      </div>\n      <div data-pane=\"presets\"><div class=\"ctiles cgrid-all\" data-presets></div></div>\n      <details class=\"adv\"><summary>Onde aplicar</summary><div>\n        <div class=\"row\">").concat(UI.seg('curveSegment', [['all', 'Todos os keyframes'], ['playhead', 'Trecho na agulha']], s.curveSegment || 'all'), "</div>\n        <div class=\"row\">").concat(UI.seg('curveScope', [['motion', 'Movimento'], ['all', 'Todos os efeitos']], s.curveScope || 'motion'), "</div>\n      </div></details>\n      <div class=\"cbar\"><button class=\"btn danger\" data-undo title=\"Volta aos keyframes originais\">").concat(icon('trash'), "Remover</button><button class=\"btn primary grow\" data-apply>").concat(icon('check'), "Aplicar</button></div>");
    var cv = $('[data-cv]', el),
      box = $('.curve-box', el);
    var LO = -0.1,
      HI = 1.1,
      W = 0,
      H = 0;
    var PX = 16,
      PY = 14,
      dpr = window.devicePixelRatio || 1;
    var drag = null,
      moved = false;
    var fit = function fit() {
      var r = Curves.range(cur);
      LO = Math.min(-0.08, r[0]);
      HI = Math.max(1.08, r[1]);
      if (cur.type === 'custom') {
        LO = Math.min(LO, cur.p[1] - 0.06, cur.p[3] - 0.06);
        HI = Math.max(HI, cur.p[1] + 0.06, cur.p[3] + 0.06);
      }
    };
    var toPx = function toPx(x, y) {
      return [PX + x * (W - 2 * PX), PY + (HI - y) / (HI - LO) * (H - 2 * PY)];
    };
    var fromPx = function fromPx(px, py) {
      return [clamp((px - PX) / (W - 2 * PX), 0, 1), HI - (py - PY) / (H - 2 * PY) * (HI - LO)];
    };
    var colors = function colors() {
      var st = getComputedStyle(box);
      return {
        line: st.color,
        grid: st.borderTopColor,
        bg: st.backgroundColor
      };
    };
    var draw = function draw(keepRange) {
      if (!keepRange) fit();
      W = box.clientWidth;
      H = Math.round(W * 0.6);
      cv.width = W * dpr;
      cv.height = H * dpr;
      cv.style.width = W + 'px';
      cv.style.height = H + 'px';
      var g = cv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      var col = colors();
      g.clearRect(0, 0, W, H);
      g.strokeStyle = col.grid;
      g.lineWidth = 1;
      g.globalAlpha = 0.7;
      for (var i = 0; i <= 10; i++) {
        var x = PX + i / 10 * (W - 2 * PX);
        g.beginPath();
        g.moveTo(x, PY);
        g.lineTo(x, H - PY);
        g.stroke();
      }
      for (var _i3 = 0; _i3 <= 6; _i3++) {
        var y = PY + _i3 / 6 * (H - 2 * PY);
        g.beginPath();
        g.moveTo(PX, y);
        g.lineTo(W - PX, y);
        g.stroke();
      }
      g.globalAlpha = 1;
      var _toPx = toPx(0, 0),
        ax = _toPx[0],
        ay = _toPx[1],
        _toPx2 = toPx(1, 1),
        bx = _toPx2[0],
        by = _toPx2[1];
      g.setLineDash([4, 4]);
      g.globalAlpha = 0.5;
      g.strokeStyle = col.line;
      g.beginPath();
      g.moveTo(ax, by);
      g.lineTo(bx, by);
      g.stroke();
      g.setLineDash([]);
      g.globalAlpha = 1;
      var line = [];
      for (var _i4 = 0; _i4 <= 200; _i4++) {
        var _x2 = _i4 / 200;
        line.push(toPx(_x2, Curves.value(cur, _x2)));
      }
      var grad = g.createLinearGradient(0, PY, 0, H - PY);
      grad.addColorStop(0, col.line);
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.beginPath();
      g.moveTo(ax, ay);
      line.forEach(function (p) {
        return g.lineTo(p[0], p[1]);
      });
      g.lineTo(bx, ay);
      g.closePath();
      g.globalAlpha = 0.22;
      g.fillStyle = grad;
      g.fill();
      g.globalAlpha = 1;
      g.strokeStyle = col.line;
      g.lineWidth = 3;
      g.lineJoin = 'round';
      g.shadowColor = col.line;
      g.shadowBlur = 10;
      g.beginPath();
      line.forEach(function (p, i) {
        return i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]);
      });
      g.stroke();
      g.shadowBlur = 0;
      var dot = function dot(p, r, filled) {
        g.beginPath();
        g.arc(p[0], p[1], r, 0, 7);
        if (filled) {
          g.fillStyle = col.line;
          g.fill();
        } else {
          g.fillStyle = col.bg;
          g.fill();
          g.lineWidth = 2.5;
          g.strokeStyle = col.line;
          g.stroke();
        }
      };
      if (cur.type === 'custom') {
        var h1 = toPx(cur.p[0], cur.p[1]),
          h2 = toPx(cur.p[2], cur.p[3]);
        g.setLineDash([3, 3]);
        g.lineWidth = 1.5;
        g.globalAlpha = 0.8;
        g.strokeStyle = col.line;
        g.beginPath();
        g.moveTo(ax, ay);
        g.lineTo(h1[0], h1[1]);
        g.moveTo(bx, by);
        g.lineTo(h2[0], h2[1]);
        g.stroke();
        g.setLineDash([]);
        g.globalAlpha = 1;
        dot(h1, 6, false);
        dot(h2, 6, false);
        (cur.pts || []).forEach(function (pt) {
          return dot(toPx(pt[0], pt[1]), 6, true);
        });
      }
      dot([ax, ay], 5, true);
      dot([bx, by], 5, true);
    };
    var renderParams = function renderParams() {
      $('[data-ctype]', el).value = cur.type;
      $('[data-chint]', el).style.display = cur.type === 'custom' ? '' : 'none';
      var defs = CURVE_PARAMS[cur.type] || [];
      $('[data-params]', el).innerHTML = cur.type === 'custom' ? '' : "\n        <div class=\"row\">".concat(UI.seg('_cmode', CURVE_MODES, cur.mode || 'out'), "</div>\n        <div class=\"cparams\">").concat(defs.map(function (d) {
        return "<label class=\"cparam\"><span>".concat(d[1], "</span><b data-pv=\"").concat(d[0], "\">").concat(cur[d[0]], "</b><input type=\"range\" data-cp=\"").concat(d[0], "\" min=\"").concat(d[2], "\" max=\"").concat(d[3], "\" step=\"").concat(d[4], "\" value=\"").concat(cur[d[0]], "\"></label>");
      }).join(''), "</div>");
    };
    var persist = function persist() {
      Store.set('curve', cur);
      drawMine();
      drawPresets();
    };
    var setCur = function setCur(c) {
      cur = Curves.clone(c);
      renderParams();
      draw();
      persist();
    };
    var drawPresets = function drawPresets() {
      var favIds = (Store.data.curvePresets || []).map(function (c) {
        return c.from;
      });
      $('[data-presets]', el).innerHTML = CURVE_PRESETS.map(function (c) {
        return "<div class=\"ctile ".concat(cur.id === c.id ? 'on' : '', "\" data-preset=\"").concat(c.id, "\" title=\"").concat(esc(c.name), "\">").concat(Curves.thumb(c, cur.id === c.id), "<span>").concat(esc(c.name), "</span><em data-favp=\"").concat(c.id, "\" class=\"").concat(favIds.indexOf(c.id) >= 0 ? 'fav' : '', "\">").concat(favIds.indexOf(c.id) >= 0 ? '★' : '☆', "</em></div>");
      }).join('');
    };
    var drawMine = function drawMine() {
      var mine = Store.data.curvePresets || [];
      $('[data-mine]', el).innerHTML = mine.length ? mine.map(function (c, i) {
        return "<div class=\"ctile ".concat(cur.id === c.id ? 'on' : '', "\" data-mine=\"").concat(i, "\" title=\"").concat(esc(c.name), "\">").concat(Curves.thumb(c, cur.id === c.id), "<span>").concat(esc(c.name), "</span><em data-delmine=\"").concat(i, "\" title=\"Excluir\">\xD7</em></div>");
      }).join('') : '<div class="muted chint">Salve suas curvas favoritas aqui.</div>';
    };
    var showTab = function showTab(t) {
      tab = t;
      Store.set('curveTab', t);
      $$('[data-ctab]', el).forEach(function (b) {
        return b.classList.toggle('on', b.getAttribute('data-ctab') === t);
      });
      $$('[data-pane]', el).forEach(function (p) {
        p.style.display = p.getAttribute('data-pane') === t ? '' : 'none';
      });
      if (t === 'graph') setTimeout(function () {
        return draw();
      }, 10);
    };
    var pos = function pos(e) {
      var r = cv.getBoundingClientRect();
      return [e.clientX - r.left, e.clientY - r.top];
    };
    var hit = function hit(mx, my) {
      var cands = [];
      var h1 = toPx(cur.p[0], cur.p[1]),
        h2 = toPx(cur.p[2], cur.p[3]);
      cands.push({
        k: 'h',
        i: 0,
        d: Math.hypot(h1[0] - mx, h1[1] - my)
      }, {
        k: 'h',
        i: 1,
        d: Math.hypot(h2[0] - mx, h2[1] - my)
      });
      (cur.pts || []).forEach(function (pt, i) {
        var q = toPx(pt[0], pt[1]);
        cands.push({
          k: 'p',
          i: i,
          d: Math.hypot(q[0] - mx, q[1] - my)
        });
      });
      cands.sort(function (a, b) {
        return a.d - b.d;
      });
      return cands[0] && cands[0].d < 16 ? cands[0] : null;
    };
    cv.addEventListener('mousedown', function (e) {
      if (cur.type !== 'custom') return;
      var _pos = pos(e),
        mx = _pos[0],
        my = _pos[1];
      drag = hit(mx, my);
      moved = false;
      if (drag) e.preventDefault();
    });
    var move = function move(e) {
      if (!drag) return;
      var _pos2 = pos(e),
        mx = _pos2[0],
        my = _pos2[1],
        xy = fromPx(mx, my),
        x = Math.round(xy[0] * 100) / 100,
        y = Math.round(xy[1] * 100) / 100;
      moved = true;
      if (drag.k === 'h') {
        cur.p[drag.i * 2] = x;
        cur.p[drag.i * 2 + 1] = y;
      } else cur.pts[drag.i] = [clamp(x, 0.02, 0.98), y];
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw(true);
    };
    var up = function up() {
      if (!drag) return;
      if (!moved && drag.k === 'p') cur.pts.splice(drag.i, 1);
      drag = null;
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw();
      persist();
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
    cv.addEventListener('dblclick', function (e) {
      if (cur.type !== 'custom') {
        setCur(Curves.ofType('custom', cur));
        return;
      }
      var _pos3 = pos(e),
        mx = _pos3[0],
        my = _pos3[1],
        xy = fromPx(mx, my);
      if (hit(mx, my)) return;
      cur.pts = (cur.pts || []).concat([[clamp(Math.round(xy[0] * 100) / 100, 0.02, 0.98), Math.round(xy[1] * 100) / 100]]).sort(function (a, b) {
        return a[0] - b[0];
      });
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw();
      persist();
    });
    window.addEventListener('resize', function () {
      if (document.body.contains(el) && !drag && tab === 'graph') draw();
    });
    $('[data-ctype]', el).addEventListener('change', function (e) {
      return setCur(Curves.ofType(e.target.value, cur));
    });
    el.addEventListener('input', function (e) {
      var k = e.target.getAttribute('data-cp');
      if (!k) return;
      cur[k] = parseFloat(e.target.value);
      var o = $("[data-pv=\"".concat(k, "\"]"), el);
      if (o) o.textContent = cur[k];
      cur.id = cur.type;
      cur.name = (CURVE_TYPES.find(function (t) {
        return t[0] === cur.type;
      }) || [0, ''])[1];
      draw();
    });
    el.addEventListener('change', function (e) {
      if (e.target.getAttribute('data-cp')) persist();
    });
    UI.bindSettings(el, function (key, v) {
      if (key === '_cmode') {
        cur.mode = v;
        draw();
        persist();
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      if (g('[data-ctab]')) return showTab(g('[data-ctab]').getAttribute('data-ctab'));
      if (g('[data-favp]')) {
        e.stopPropagation();
        var id = g('[data-favp]').getAttribute('data-favp'),
          list = (Store.data.curvePresets || []).slice();
        var i = list.findIndex(function (c) {
          return c.from === id;
        });
        if (i >= 0) list.splice(i, 1);else {
          var c = Curves.clone(CURVE_PRESETS.find(function (x) {
            return x.id === id;
          }));
          c.from = id;
          c.id = 'u_' + uid();
          list.push(c);
        }
        Store.data.curvePresets = list;
        Store.save();
        drawPresets();
        drawMine();
        return;
      }
      if (g('[data-delmine]')) {
        e.stopPropagation();
        Store.data.curvePresets.splice(parseInt(g('[data-delmine]').getAttribute('data-delmine'), 10), 1);
        Store.save();
        drawMine();
        drawPresets();
        return;
      }
      if (g('[data-preset]')) {
        setCur(CURVE_PRESETS.find(function (x) {
          return x.id === g('[data-preset]').getAttribute('data-preset');
        }));
        return;
      }
      if (g('[data-mine]')) {
        setCur(Store.data.curvePresets[parseInt(g('[data-mine]').getAttribute('data-mine'), 10)]);
        return;
      }
      if (g('[data-save]')) {
        return UI.prompt('Nome do preset', "Preset ".concat((Store.data.curvePresets || []).length + 1)).then(function (name) {
          if (!name) return;
          var c = Curves.clone(cur);
          c.id = 'u_' + uid();
          c.name = name;
          delete c.from;
          Store.data.curvePresets = (Store.data.curvePresets || []).concat([c]);
          Store.save();
          cur = Curves.clone(c);
          persist();
          UI.toast('Preset salvo nos favoritos', 'ok');
        });
      }
      var st = Store.s;
      var args = {
        scope: st.curveScope || 'motion',
        segment: st.curveSegment || 'all',
        step: 1
      };
      if (g('[data-apply]')) {
        UI.run(g('[data-apply]'), 'Curva', 'applyCurve', Object.assign(args, {
          samples: Curves.samples(cur)
        }), function (d) {
          return "\u201C".concat(cur.name || 'Curva', "\u201D em ").concat(d.segments, " trecho(s) \xB7 ").concat(d.params, " propriedade(s)");
        }).catch(function () {});
      }
      if (g('[data-undo]')) {
        UI.run(g('[data-undo]'), 'Curva', 'applyCurve', Object.assign(args, {
          remove: true
        }), function (d) {
          return "Keyframes originais de volta em ".concat(d.segments, " trecho(s)");
        }).catch(function () {});
      }
    });
    renderParams();
    drawMine();
    drawPresets();
    showTab(tab);
  }
});
(function () {
  var i = App.tools.findIndex(function (t) {
      return t.id === 'curves';
    }),
    j = App.tools.findIndex(function (t) {
      return t.id === 'motion';
    });
  if (i > j + 1) App.tools.splice(j + 1, 0, App.tools.splice(i, 1)[0]);
})();
var Workflow = {
  seqSize: function seqSize() {
    return FE.call('info').then(function (i) {
      if (!i || !i.seq) throw new Error('Abra uma sequência na timeline primeiro.');
      return i.seq;
    });
  },
  placeGuide: function placeGuide(btn, platform, opts) {
    if (btn) btn.classList.add('busy');
    opts = opts || {
      zones: true,
      crop: false
    };
    var name = platform === 'generic' ? 'Grade' : GUIDE_SPECS[platform].name;
    return this.seqSize().then(function (s) {
      var path = Gen.guide(s.w, s.h, platform, opts);
      return FE.call('overlay', {
        kind: 'file',
        path: path,
        mode: 'full',
        label: 'FE_Guide_' + platform
      });
    }).then(function (d) {
      UI.toast("Guia do ".concat(name, " adicionada no topo. A sequ\xEAncia n\xE3o foi alterada."), 'ok');
      App.log(true, "Guia ".concat(name));
      return d;
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Guia: ' + e.message);
    }).then(function () {
      return btn && btn.classList.remove('busy');
    });
  }
};
var STACK_LENGTHS = [1, 2, 3, 4, 5, 8, 10, 15, 25, 50];
var Stack = {
  template: function template() {
    return FE.inCEP ? FE.sysPath('extension').replace(/\\/g, '/') + '/assets/template/FE_AdjustmentLayer.prproj' : '';
  },
  frames: function frames() {
    return Store.s.stackFrames || 3;
  },
  effectLabel: function effectLabel() {
    var v = Store.s.stackEffect || '';
    if (!v) return 'Nenhum';
    if (v.indexOf('stack:') === 0) {
      var st = Store.data.stacks.find(function (x) {
        return x.id === v.slice(6);
      });
      return st ? st.name : 'Nenhum';
    }
    return v.slice(3);
  },
  effectNames: function effectNames() {
    var v = Store.s.stackEffect || '';
    if (v.indexOf('stack:') === 0) {
      var st = Store.data.stacks.find(function (x) {
        return x.id === v.slice(6);
      });
      return st ? st.effects : [];
    }
    if (v.indexOf('fx:') === 0) return [v.slice(3)];
    return [];
  },
  apply: function apply(kind, cuts, btn) {
    var _this16 = this;
    var s = Store.s;
    var base = {
      mode: cuts ? 'cuts' : 'auto',
      frames: this.frames()
    };
    var msg = function msg(d) {
      var what = kind === 'adjustment' ? 'Camada de ajuste' : 'Matte';
      var where = d.mode === 'playhead' ? "no playhead (".concat(_this16.frames(), " fr)") : d.mode === 'cuts' ? "em ".concat(d.placed, " corte(s)") : "em ".concat(d.placed, " take(s)");
      return "".concat(what, " ").concat(where).concat(d.effects && d.effects.applied ? " \xB7 ".concat(d.effects.applied, " efeito(s)") : '');
    };
    if (kind === 'adjustment') {
      return UI.run(btn, 'Stack', 'overlay', Object.assign(base, {
        kind: 'adjustment',
        nodeId: s.adjNodeId,
        template: this.template(),
        effects: this.effectNames()
      }), msg).catch(function () {});
    }
    if (btn) btn.classList.add('busy');
    return Workflow.seqSize().then(function (sz) {
      var path = Gen.matte(sz.w, sz.h, s.matteColor, s.matteAlpha);
      if (btn) btn.classList.remove('busy');
      return UI.run(btn, 'Stack', 'overlay', Object.assign(base, {
        kind: 'file',
        path: path
      }), msg);
    }).catch(function (er) {
      if (btn) btn.classList.remove('busy');
      if (er && !er._shown) UI.toast(er.message, 'err');
    });
  }
};
NEEDS.stack = function (sq) {
  return sq && sq.selected ? ["".concat(sq.selected, " take").concat(sq.selected > 1 ? 's' : '', " selecionado").concat(sq.selected > 1 ? 's' : ''), 'ok'] : ["Nada selecionado \u2014 vai na agulha (".concat(Stack.frames(), " fr)"), 'ok'];
};
App.registerTool({
  id: 'stack',
  module: 'workflow',
  icon: 'layers',
  title: 'Stack',
  desc: 'Camada de ajuste ou matte nos takes ou na agulha',
  keywords: 'stack adjustment layer camada de ajuste color matte cor sólida flash letterbox overlay corte agulha playhead frames',
  render: function render(el) {
    var s = Store.s;
    var swatches = ['#000000', '#ffffff', '#2340C8', '#C4F82A', '#f87171', '#fbbf24', '#34d399', '#a78bfa'];
    var tip = '<b>Clique:</b> nos takes selecionados ou na agulha<br><b>Shift:</b> um em cada corte';
    el.innerHTML = "\n      <div class=\"stack-btns\">\n        <div class=\"stack-btn\" data-stack=\"adjustment\" data-tip>".concat(icon('adjust'), "<span>Camada de ajuste</span><div class=\"tipbox\">").concat(tip, "</div></div>\n        <div class=\"stack-btn\" data-stack=\"matte\" data-tip><i class=\"matte-sw\" data-mattesw></i><span>Matte</span><div class=\"tipbox\">").concat(tip, "</div></div>\n      </div>\n      <div class=\"stack-sum\"><span data-sum></span><button class=\"btn sm\" data-cfg>").concat(icon('settings'), "Configurar</button></div>\n      <div class=\"stack-cfg\" data-cfgbox style=\"display:none\">\n        <div class=\"section-label\" style=\"margin-top:4px\">Dura\xE7\xE3o na agulha</div>\n        <div class=\"chips\" data-lens></div>\n        <div class=\"row\"><input class=\"input num\" type=\"number\" min=\"1\" max=\"600\" data-lencustom value=\"").concat(s.stackFrames || 3, "\"><span class=\"muted\">frames</span></div>\n        <div class=\"section-label\">Efeito na camada</div>\n        <div class=\"row\"><select class=\"select grow\" data-stackfx></select></div>\n        <div class=\"hint\" data-fxhint></div>\n        <div class=\"section-label\">Cor do matte</div>\n        <div class=\"row\"><div class=\"swatches\">").concat(swatches.map(function (c) {
      return "<div class=\"sw ".concat(c.toLowerCase() === (s.matteColor || '').toLowerCase() ? 'on' : '', "\" data-sw=\"").concat(c, "\" style=\"background:").concat(c, "\"></div>");
    }).join(''), "</div><input type=\"color\" data-color value=\"").concat(s.matteColor, "\"></div>\n        <div class=\"row\"><label class=\"l\">Opacidade</label>").concat(UI.range('matteAlpha', 5, 100, 5, s.matteAlpha, '%'), "</div>\n      </div>\n      <details class=\"adv\"><summary>Letterbox</summary><div>\n        <div class=\"btns\">").concat([['2.39', '2.39:1'], ['2', '2:1'], ['1.85', '1.85:1'], ['1.333', '4:3']].map(function (r) {
      return "<button class=\"btn sm\" data-lb=\"".concat(r[0], "\">").concat(r[1], "</button>");
    }).join(''), "</div>\n      </div></details>");
    var sum = function sum() {
      var c = Store.s.matteColor;
      $('[data-sum]', el).innerHTML = "<b>".concat(Stack.frames(), " fr</b> \xB7 efeito: <b>").concat(esc(Stack.effectLabel()), "</b> \xB7 matte <i class=\"dot-sw\" style=\"background:").concat(c, ";opacity:").concat((Store.s.matteAlpha || 100) / 100, "\"></i>");
      $('[data-mattesw]', el).style.background = c;
      $('[data-mattesw]', el).style.opacity = Math.max(0.25, (Store.s.matteAlpha || 100) / 100);
      el.classList.toggle('no-tips', Store.s.stackTips === false);
      $$('[data-lens] .chip', el).forEach(function (ch) {
        return ch.classList.toggle('on', parseInt(ch.getAttribute('data-len'), 10) === Stack.frames());
      });
      App.updateCtx();
    };
    $('[data-lens]', el).innerHTML = STACK_LENGTHS.map(function (n) {
      return "<span class=\"chip\" data-len=\"".concat(n, "\">").concat(n, "</span>");
    }).join('');
    var fillFx = function fillFx() {
      var sel = $('[data-stackfx]', el);
      var stacks = Store.data.stacks.filter(function (x) {
        return !x.audio;
      });
      var favs = Store.data.effectFavs.filter(function (k) {
        return k.indexOf('video:') === 0;
      }).map(function (k) {
        return k.slice(6);
      });
      sel.innerHTML = '<option value="">Nenhum (só a camada)</option>' + (stacks.length ? "<optgroup label=\"Meus stacks\">".concat(stacks.map(function (x) {
        return "<option value=\"stack:".concat(x.id, "\">").concat(esc(x.name), "</option>");
      }).join(''), "</optgroup>") : '') + (favs.length ? "<optgroup label=\"Efeitos favoritos\">".concat(favs.map(function (n) {
        return "<option value=\"fx:".concat(esc(n), "\">").concat(esc(n), "</option>");
      }).join(''), "</optgroup>") : '');
      sel.value = Store.s.stackEffect || '';
      $('[data-fxhint]', el).innerHTML = stacks.length || favs.length ? '' : 'Favorite efeitos em Animar > Efeitos para aparecerem aqui.';
    };
    var status = function status() {
      FE.call('findAdjustment', {
        nodeId: Store.s.adjNodeId
      }).then(function (r) {
        var tag = $('[data-adjstatus]', el);
        if (!tag) return;
        if (r) {
          tag.className = 'tag ok';
          tag.textContent = '✓ ' + r.name;
          Store.set('adjNodeId', r.nodeId);
        } else {
          tag.className = 'tag warn';
          tag.textContent = 'Crie uma vez: Project > New Item > Adjustment Layer';
        }
      }).catch(function () {});
    };
    fillFx();
    sum();
    UI.bindSettings(el, function () {
      return sum();
    });
    $('[data-lencustom]', el).addEventListener('change', function (e) {
      Store.set('stackFrames', clamp(parseInt(e.target.value, 10) || 3, 1, 600));
      sum();
    });
    $('[data-stackfx]', el).addEventListener('change', function (e) {
      Store.set('stackEffect', e.target.value);
      sum();
    });
    $('[data-color]', el).addEventListener('input', function (e) {
      Store.set('matteColor', e.target.value);
      $$('[data-sw]', el).forEach(function (x) {
        return x.classList.remove('on');
      });
      sum();
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      var b = g('[data-stack]');
      if (b) return Stack.apply(b.getAttribute('data-stack'), e.shiftKey, b);
      if (g('[data-cfg]')) {
        var bx = $('[data-cfgbox]', el);
        bx.style.display = bx.style.display === 'none' ? '' : 'none';
        return;
      }
      var ln = g('[data-len]');
      if (ln) {
        Store.set('stackFrames', parseInt(ln.getAttribute('data-len'), 10));
        $('[data-lencustom]', el).value = Stack.frames();
        sum();
        return;
      }
      var sw = g('[data-sw]');
      if (sw) {
        Store.set('matteColor', sw.getAttribute('data-sw'));
        $('[data-color]', el).value = Store.s.matteColor;
        $$('[data-sw]', el).forEach(function (x) {
          return x.classList.toggle('on', x === sw);
        });
        sum();
        return;
      }
      if (g('[data-adjsel]')) {
        FE.call('adjustmentFromSelection').then(function (r) {
          Store.set('adjNodeId', r.nodeId);
          UI.toast('Camada de ajuste definida: ' + r.name, 'ok');
          status();
        }).catch(function (er) {
          return UI.toast(er.message, 'err');
        });
        return;
      }
      var lb = g('[data-lb]');
      if (lb) {
        lb.classList.add('busy');
        Workflow.seqSize().then(function (sz) {
          var path = Gen.letterbox(sz.w, sz.h, parseFloat(lb.getAttribute('data-lb')));
          lb.classList.remove('busy');
          return UI.run(lb, 'Letterbox', 'overlay', {
            kind: 'file',
            path: path,
            mode: 'auto',
            frames: Stack.frames()
          }, function (d) {
            return "Letterbox em ".concat(d.placed, " lugar(es)");
          });
        }).catch(function (er) {
          lb.classList.remove('busy');
          if (er && !er._shown) UI.toast(er.message, 'err');
        });
      }
    });
  }
});
var SETUP_TEMPLATES = [{
  id: 'youtube',
  name: 'YouTube / Conteúdo',
  text: '01 Sequências\n02 Brutos\n  Câmera A\n  Câmera B\n  Tela\n03 Áudio\n  Voz\n  Trilhas\n  SFX\n04 Gráficos\n  Thumbs\n  Lower Thirds\n05 B-Roll\n06 Exports'
}, {
  id: 'comercial',
  name: 'Comercial / Publicidade',
  text: '00 Entregas\n01 Sequências\n  Master\n  Cortes 30s\n  Cortes 15s\n  Versões Sociais\n02 Vídeo\n  Diárias\n  Selecionados\n03 Áudio\n  Locução\n  Trilha\n  SFX\n04 Gráficos\n  Logos\n  Cartelas\n  MOGRTs\n05 Referências\n06 Color & Finalização'
}, {
  id: 'doc',
  name: 'Documentário',
  text: '01 Sequências\n  Strings\n  Cortes\n02 Entrevistas\n03 B-Roll\n04 Arquivo\n05 Áudio\n  Ambiente\n  Trilha\n  SFX\n06 Gráficos\n07 Legendas'
}, {
  id: 'social',
  name: 'Social Media',
  text: '01 Sequências\n  9x16\n  1x1\n  4x5\n  16x9\n02 Brutos\n03 Áudio\n  Músicas\n  SFX\n04 Gráficos\n  Legendas\n  Stickers\n05 Exports'
}, {
  id: 'evento',
  name: 'Casamento / Evento',
  text: '01 Sequências\n  Teaser\n  Filme\n02 Câmeras\n  Cam 1\n  Cam 2\n  Drone\n03 Áudio\n  Lapela\n  Ambiente\n  Músicas\n04 Gráficos\n05 Exports'
}];
function parseTree(text) {
  var root = {
      children: []
    },
    stack = [{
      depth: -1,
      node: root
    }];
  text.split(/\r?\n/).forEach(function (line) {
    if (!line.trim()) return;
    var depth = line.match(/^[\t ]*/)[0].replace(/\t/g, '  ').length / 2 | 0;
    var node = {
      name: line.trim().replace(/^[-*•]\s*/, ''),
      children: []
    };
    while (stack.length > 1 && stack[stack.length - 1].depth >= depth) stack.pop();
    stack[stack.length - 1].node.children.push(node);
    stack.push({
      depth: depth,
      node: node
    });
  });
  return root.children;
}
App.registerTool({
  id: 'setup',
  module: 'workflow',
  icon: 'bins',
  title: 'Iniciar projeto',
  desc: 'Cria a estrutura de bins a partir de um modelo',
  needs: 'project',
  steps: ['Escolha um modelo', 'Edite se quiser', 'Toque em Criar'],
  keywords: 'pastas bins estrutura template projeto setup organizar criar',
  render: function render(el) {
    var all = function all() {
      return SETUP_TEMPLATES.concat(Store.s.customTemplates || []);
    };
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Template</label><select class=\"select grow\" data-tpl></select></div>\n      <textarea class=\"input\" rows=\"10\" data-tree style=\"width:100%\"></textarea>\n      <div class=\"btns\"><button class=\"btn primary\" data-create>".concat(icon('folder'), "Criar estrutura</button><button class=\"btn\" data-save>").concat(icon('plus'), "Salvar template</button><button class=\"btn ghost danger\" data-del title=\"Excluir template personalizado\">").concat(icon('trash'), "</button></div>");
    var sel = $('[data-tpl]', el),
      ta = $('[data-tree]', el);
    var fill = function fill(id) {
      sel.innerHTML = all().map(function (t) {
        return "<option value=\"".concat(t.id, "\">").concat(esc(t.name)).concat(t.custom ? ' ★' : '', "</option>");
      }).join('');
      if (id) sel.value = id;
      var t = all().find(function (x) {
        return x.id === sel.value;
      }) || all()[0];
      ta.value = t.text;
      $('[data-del]', el).style.display = t.custom ? '' : 'none';
    };
    fill();
    sel.addEventListener('change', function () {
      return fill(sel.value);
    });
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-create]')) {
        var tree = parseTree(ta.value);
        if (!tree.length) return UI.toast('Template vazio', 'err');
        UI.run(e.target.closest('[data-create]'), 'Project Setup', 'projectSetup', {
          tree: tree
        }, function (d) {
          return "".concat(d.created, " bin(s) criado(s)").concat(d.skipped ? " \xB7 ".concat(d.skipped, " j\xE1 existia(m)") : '');
        }).catch(function () {});
      }
      if (e.target.closest('[data-save]')) {
        UI.prompt('Nome do template', 'Meu template').then(function (name) {
          if (!name) return;
          var t = {
            id: 'c_' + uid(),
            name: name,
            text: ta.value,
            custom: true
          };
          Store.s.customTemplates = (Store.s.customTemplates || []).concat([t]);
          Store.save();
          fill(t.id);
          UI.toast('Template salvo', 'ok');
        });
      }
      if (e.target.closest('[data-del]')) {
        Store.s.customTemplates = (Store.s.customTemplates || []).filter(function (t) {
          return t.id !== sel.value;
        });
        Store.save();
        fill();
      }
    });
  }
});
var ORG_CATS = [['seq', 'Sequências'], ['video', 'Vídeos'], ['audio', 'Áudios'], ['image', 'Imagens'], ['graphic', 'Gráficos / Sintéticos'], ['other', 'Outros']];
App.registerTool({
  id: 'organizer',
  module: 'workflow',
  icon: 'organize',
  title: 'Organizar projeto',
  desc: 'Coloca cada mídia no bin certo, com prévia',
  needs: 'project',
  steps: ['Confira os bins', 'Veja a prévia', 'Toque em Organizar'],
  keywords: 'organizar bins mídia tipo project painel limpar ordenar pastas automático',
  render: function render(el) {
    var b = Store.s.orgBins;
    el.innerHTML = "\n      <table class=\"tbl\"><tr><th>Tipo</th><th>Mover para o bin</th></tr>\n        ".concat(ORG_CATS.map(function (c) {
      return "<tr><td>".concat(c[1], "</td><td><input class=\"input\" style=\"width:100%\" data-bin=\"").concat(c[0], "\" value=\"").concat(esc(b[c[0]] || ''), "\" placeholder=\"(n\xE3o mover)\"></td></tr>");
    }).join(''), "\n      </table>\n      <div class=\"row\" style=\"margin-top:8px\">").concat(UI.toggle('orgNested', 'Incluir subpastas', Store.s.orgNested), "</div>\n      <div data-preview></div>\n      <div class=\"btns\"><button class=\"btn\" data-prev>").concat(icon('search'), "Pr\xE9via</button><button class=\"btn primary\" data-apply>").concat(icon('check'), "Organizar</button></div>");
    UI.bindSettings(el);
    el.addEventListener('change', function (e) {
      var k = e.target.getAttribute('data-bin');
      if (k) {
        Store.s.orgBins[k] = e.target.value.trim();
        Store.save();
      }
    });
    var run = function run(apply, btn) {
      return UI.run(btn, 'Organizer', 'organize', {
        bins: Store.s.orgBins,
        nested: Store.s.orgNested,
        apply: apply
      }, function (d) {
        return apply ? "".concat(Object.values(d.plan).reduce(function (a, x) {
          return a + x.count;
        }, 0), " item(ns) organizado(s)") : null;
      }).then(function (d) {
        var rows = Object.keys(d.plan).map(function (k) {
          return d.plan[k];
        });
        $('[data-preview]', el).innerHTML = "<div class=\"banner info\" style=\"margin-top:8px\">".concat(rows.length ? rows.map(function (r) {
          return "<div><b>".concat(r.count, "</b> \u2192 ").concat(esc(r.bin), " <span class=\"muted\">(").concat(r.samples.map(esc).join(', ')).concat(r.count > r.samples.length ? '…' : '', ")</span></div>");
        }).join('') : 'Tudo já está organizado.', "</div>");
      }).catch(function () {});
    };
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-prev]')) run(false, e.target.closest('[data-prev]'));
      if (e.target.closest('[data-apply]')) run(true, e.target.closest('[data-apply]'));
    });
  }
});
App.registerTool({
  id: 'sort',
  module: 'workflow',
  icon: 'sort',
  title: 'Ordenar takes',
  desc: 'Reordena os clipes por nome, duração ou sorteio',
  needs: 'clips',
  steps: ['Selecione clipes de 1 trilha', 'Escolha a ordem', 'Pronto'],
  keywords: 'ordenar takes nome sequência reorganizar clipes ordem shuffle aleatório duração',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-sort=\"name\">A \u2192 Z</button><button class=\"btn\" data-sort=\"nameDesc\">Z \u2192 A</button><button class=\"btn\" data-sort=\"reverse\">Inverter</button></div>\n      <div class=\"btns\"><button class=\"btn\" data-sort=\"duration\">Curto \u2192 Longo</button><button class=\"btn\" data-sort=\"durationDesc\">Longo \u2192 Curto</button><button class=\"btn\" data-sort=\"shuffle\">Aleat\xF3rio</button></div>";
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-sort]');
      if (b) UI.run(b, 'Sort Clips', 'sortClips', {
        mode: b.getAttribute('data-sort')
      }, function (d) {
        return "".concat(d.sorted, " clipes reordenados");
      }).catch(function () {});
    });
  }
});
var LABELS = [[0, 'Violeta'], [1, 'Íris'], [2, 'Caribe'], [3, 'Lavanda'], [4, 'Cerúleo'], [5, 'Floresta'], [6, 'Rosa'], [7, 'Manga'], [8, 'Púrpura'], [9, 'Azul'], [10, 'Verde-azulado'], [11, 'Magenta'], [12, 'Bronze'], [13, 'Verde'], [14, 'Marrom'], [15, 'Amarelo']];
App.registerTool({
  id: 'batch',
  module: 'workflow',
  icon: 'batch',
  title: 'Ações em lote',
  desc: 'Desativar, velocidade, remover efeitos e mais',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha a ação', 'Pronto'],
  keywords: 'lote batch desativar ativar efeitos remover velocidade speed escala frame size reverso link unlink cor label disable',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"section-label\" style=\"margin-top:0\">Clipes</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-op=\"disable\">Desativar</button><button class=\"btn\" data-op=\"enable\">Ativar</button><button class=\"btn\" data-op=\"toggle\">Inverter</button></div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-op=\"unlink\">Desvincular A/V</button><button class=\"btn\" data-op=\"link\">Vincular A/V</button></div>\n      <div class=\"section-label\">Efeitos e imagem</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn danger\" data-op=\"removeEffects\">Remover efeitos</button><button class=\"btn\" data-op=\"scaleToFrame\">Ajustar ao quadro</button></div>\n      <div class=\"row\"><label class=\"l\">Velocidade</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"10000\" value=\"100\" data-speed><span class=\"muted\">%</span>".concat(UI.toggle('_ripple', 'Ripple', true), "<button class=\"btn sm right\" data-op=\"speed\">Aplicar</button></div>\n      <div class=\"row\"><button class=\"btn sm\" data-op=\"reverse\">Reproduzir ao contr\xE1rio</button></div>\n      <div class=\"section-label\">Cor do r\xF3tulo (m\xEDdia)</div>\n      <div class=\"row\">").concat(UI.select('_label', LABELS, 7, 'grow'), "<button class=\"btn sm\" data-op=\"label\">Aplicar</button></div>");
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-op]');
      if (!b) return;
      var op = b.getAttribute('data-op');
      var args = {
        op: op
      };
      if (op === 'speed') {
        args.value = parseFloat($('[data-speed]', el).value) || 100;
        args.ripple = $('[data-toggle="_ripple"]', el).checked;
      }
      if (op === 'label') args.value = parseInt($('[data-select="_label"]', el).value, 10);
      var go = function go() {
        return UI.run(b, 'Batch', 'batch', args, function (d) {
          return "".concat(d.done, " clipe(s) atualizado(s)").concat(d.failed ? " \xB7 ".concat(d.failed, " falha(s)") : '');
        }).catch(function () {});
      };
      if (op === 'removeEffects') UI.confirm('Remover efeitos', 'Remove todos os efeitos aplicados aos clipes selecionados (Ctrl+Z desfaz).', 'Remover').then(function (ok) {
        return ok && go();
      });else go();
    });
  }
});
App.registerTool({
  id: 'cleaner',
  module: 'workflow',
  icon: 'clean',
  title: 'Limpar timeline',
  desc: 'Fecha buracos, tira flash frames e trilhas vazias',
  needs: 'seq',
  steps: ['Abra a sequência', 'Escolha a limpeza', 'Pronto'],
  keywords: 'limpar timeline gaps espaços vazios flash frame clipes curtos desativados trilhas vazias cleaner',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"col\"><label>Espa\xE7os vazios (em todas as trilhas, mantendo sincronia)</label>\n        <div class=\"row\" style=\"margin:0\">".concat(UI.toggle('_fromStart', 'Incluir início da sequência', true), "<button class=\"btn sm right\" data-c=\"gaps\">").concat(icon('clean'), "Fechar espa\xE7os</button></div></div>\n      <div class=\"col\"><label>Flash frames / sobras de corte</label>\n        <div class=\"row\" style=\"margin:0\"><span class=\"muted\">Clipes com menos de</span><input class=\"input num\" type=\"number\" min=\"1\" max=\"30\" value=\"3\" data-short><span class=\"muted\">frames</span><button class=\"btn sm right\" data-c=\"short\">Remover</button></div></div>\n      <div class=\"btns\" style=\"margin-top:4px\"><button class=\"btn\" data-c=\"disabled\">Remover desativados</button><button class=\"btn\" data-c=\"tracks\">Remover trilhas vazias</button></div>");
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-c]');
      if (!b) return;
      var c = b.getAttribute('data-c');
      if (c === 'gaps') UI.run(b, 'Cleaner', 'closeGaps', {
        minFrames: 1,
        fromStart: $('[data-toggle="_fromStart"]', el).checked
      }, function (d) {
        return d.gaps ? "".concat(d.gaps, " espa\xE7o(s) removido(s) \xB7 ").concat(d.seconds, "s") : 'Nenhum espaço vazio encontrado';
      }).catch(function () {});
      if (c === 'short') {
        var fr = parseInt($('[data-short]', el).value, 10) || 3;
        UI.confirm('Remover clipes curtos', "Remove todos os clipes com menos de ".concat(fr, " frame(s) na sequ\xEAncia ativa."), 'Remover').then(function (ok) {
          return ok && UI.run(b, 'Cleaner', 'removeShort', {
            frames: fr
          }, function (d) {
            return "".concat(d.removed, " clipe(s) removido(s)");
          }).catch(function () {});
        });
      }
      if (c === 'disabled') UI.confirm('Remover desativados', 'Remove da timeline todos os clipes desativados.', 'Remover').then(function (ok) {
        return ok && UI.run(b, 'Cleaner', 'removeDisabled', {}, function (d) {
          return "".concat(d.removed, " clipe(s) removido(s)");
        }).catch(function () {});
      });
      if (c === 'tracks') UI.run(b, 'Cleaner', 'removeEmptyTracks', {}, 'Trilhas vazias removidas').catch(function () {});
    });
  }
});
var SOCIAL_FORMATS = [['9:16', 1080, 1920, 'Reels · TikTok · Shorts'], ['1:1', 1080, 1080, 'Feed quadrado'], ['4:5', 1080, 1350, 'Feed vertical'], ['16:9', 1920, 1080, 'YouTube'], ['4:3', 1440, 1080, 'Clássico']];
App.registerTool({
  id: 'social',
  module: 'workflow',
  icon: 'social',
  title: 'Guias de redes sociais',
  desc: 'Veja os botões do Reels, Shorts e TikTok por cima do vídeo',
  needs: 'seq',
  steps: ['Escolha o app', 'Confira a prévia', 'Adicione por cima'],
  keywords: 'guia faca safe zone reels tiktok shorts instagram youtube botões legenda cortando interface enquadramento vertical 9:16',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"row\">".concat(UI.seg('_gPlat', [['reels', 'Reels'], ['shorts', 'Shorts'], ['tiktok', 'TikTok'], ['generic', 'Só grade']], 'reels'), "</div>\n      <div class=\"guide-prev\"><canvas data-prev width=\"270\" height=\"480\"></canvas></div>\n      <div class=\"row\">").concat(UI.toggle('_gZones', 'Áreas de risco', true)).concat(UI.toggle('_gCrop', 'Corte lateral', false), "</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-guide>").concat(icon('social'), "Adicionar guia</button></div>\n      <div class=\"guide-state\" data-gstate></div>");
    var plat = 'reels';
    var draw = function draw() {
      var cv = $('[data-prev]', el),
        g = cv.getContext('2d');
      var grd = g.createLinearGradient(0, 0, 270, 480);
      grd.addColorStop(0, '#5a6b8c');
      grd.addColorStop(1, '#2b3346');
      g.fillStyle = grd;
      g.fillRect(0, 0, 270, 480);
      g.fillStyle = 'rgba(255,255,255,0.10)';
      g.font = '600 15px "DM Sans", sans-serif';
      g.textAlign = 'center';
      g.fillText('seu vídeo', 135, 245);
      var c = Gen.guideCanvas(270, 480, plat, {
        zones: $('[data-toggle="_gZones"]', el).checked,
        crop: $('[data-toggle="_gCrop"]', el).checked
      });
      g.drawImage(c, 0, 0);
    };
    UI.bindSettings(el, function (k, v) {
      if (k === '_gPlat') plat = v;
      draw();
    });
    setTimeout(draw, 30);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(draw);
    var gstate = function gstate(st) {
      var box = $('[data-gstate]', el);
      if (!box) return;
      if (!st || !st.count) {
        box.innerHTML = '';
        return;
      }
      box.innerHTML = "<div class=\"guide-switch ".concat(st.visible ? 'on' : '', "\" data-gtoggle>\n          <div class=\"gs-t\"><b>").concat(st.visible ? 'Guia visível' : 'Guia escondida', "</b></div>\n          <label class=\"toggle\" style=\"margin:0;pointer-events:none\"><input type=\"checkbox\" ").concat(st.visible ? 'checked' : '', "><i></i></label></div>\n        <div class=\"btns\" style=\"margin-top:2px\"><button class=\"btn sm\" data-rmguide>").concat(icon('trash'), "Remover guias</button></div>");
    };
    var refresh = function refresh() {
      return FE.call('guidesState').then(gstate).catch(function () {
        return gstate(null);
      });
    };
    refresh();
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-guide]')) Workflow.placeGuide(e.target.closest('[data-guide]'), plat, {
        zones: $('[data-toggle="_gZones"]', el).checked,
        crop: $('[data-toggle="_gCrop"]', el).checked
      }).then(refresh);
      if (e.target.closest('[data-gtoggle]')) FE.call('toggleGuides', {}).then(function (st) {
        gstate(st);
        UI.toast(st.visible ? 'Guia visível' : 'Guia escondida', 'info');
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
      if (e.target.closest('[data-rmguide]')) UI.run(e.target.closest('[data-rmguide]'), 'Guias', 'removeGuides', {}, function (d) {
        return d.removed ? "".concat(d.removed, " guia(s) removida(s)") : 'Nenhuma guia na sequência';
      }).then(refresh).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'formats',
  module: 'workflow',
  icon: 'batch',
  title: 'Cópia em outro formato',
  desc: 'Cria uma CÓPIA da sequência em 9:16, 1:1, 4:5… (a original fica igual)',
  needs: 'seq',
  steps: ['Abra a sequência', 'Escolha o formato', 'Uma cópia é criada'],
  keywords: 'formato vertical 9:16 1:1 4:5 auto reframe duplicar sequência redimensionar',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"tiles\">".concat(SOCIAL_FORMATS.map(function (f) {
      return "<div class=\"tile\" data-fmt=\"".concat(f[0], "\"><b style=\"font-size:14px\">").concat(f[0], "</b><span>").concat(f[3], "</span></div>");
    }).join(''), "</div>\n      <div class=\"row\">").concat(UI.toggle('_reframe', 'Auto Reframe', true), "</div>");
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-fmt]');
      if (!t) return;
      var f = SOCIAL_FORMATS.find(function (x) {
        return x[0] === t.getAttribute('data-fmt');
      });
      var _f$0$split$map = f[0].split(':').map(Number),
        num = _f$0$split$map[0],
        den = _f$0$split$map[1];
      UI.run(t, 'Formato', 'socialSequence', {
        w: f[1],
        h: f[2],
        num: num,
        den: den,
        label: f[0].replace(':', 'x'),
        autoReframe: $('[data-toggle="_reframe"]', el).checked
      }, function (d) {
        return "C\xF3pia \u201C".concat(d.name, "\u201D criada").concat(d.method === 'autoReframe' ? ' com Auto Reframe' : '');
      }).catch(function () {});
    });
  }
});
var NodeX = {
  req: function req(m) {
    try {
      if (window.cep_node && window.cep_node.require) return window.cep_node.require(m);
      if (typeof window.require === 'function') return window.require(m);
    } catch (e) {}
    return null;
  },
  get ok() {
    return !!this.req('child_process');
  },
  run: function run(cmd, args, timeout) {
    var cp = this.req('child_process');
    if (!cp) return Promise.reject(new Error('Node indisponível'));
    return new Promise(function (resolve, reject) {
      cp.execFile(cmd, args, {
        windowsHide: true,
        timeout: timeout || 20000,
        maxBuffer: 4 * 1024 * 1024
      }, function (err, stdout, stderr) {
        if (err) reject(new Error(String(stderr || err.message).trim().slice(0, 300)));else resolve(String(stdout || '').trim());
      });
    });
  }
};
var Clip = {
  stamp: function stamp() {
    var d = new Date();
    return "".concat(d.getFullYear()).concat(pad2(d.getMonth() + 1)).concat(pad2(d.getDate()), "_").concat(pad2(d.getHours())).concat(pad2(d.getMinutes())).concat(pad2(d.getSeconds()));
  },
  projectDir: function projectDir() {
    var pp = App.info && App.info.projectPath;
    return pp && /[\\/]/.test(pp) ? pp.replace(/\\/g, '/').replace(/\/[^/]*$/, '') : '';
  },
  pasteDir: function pasteDir() {
    var d = this.projectDir();
    return d ? d + '/colagens' : (Store.dataDir || '') + '/colagens';
  },
  fresh: function fresh() {
    return FE.call('info').then(function (i) {
      App.info = i;
      return i;
    }).catch(function () {
      return App.info;
    });
  },
  psq: function psq(s) {
    return "'" + String(s).replace(/'/g, "''") + "'";
  },
  isMac: function isMac() {
    return navigator.platform.indexOf('Mac') >= 0;
  },
  readSystem: function readSystem() {
    var _this17 = this;
    var out = this.pasteDir() + "/colagem_".concat(this.stamp(), ".png");
    FS.mkdirp(this.pasteDir());
    if (this.isMac()) {
      var script = ['try', 'set fl to (the clipboard as «class furl»)', 'return "FILE:" & POSIX path of fl', 'end try', 'try', "set f to open for access (POSIX file ".concat(JSON.stringify(out), ") with write permission"), 'write (the clipboard as «class PNGf») to f', 'close access f', "return \"IMG:".concat(out, "\""), 'on error', 'try', 'return "TXT:" & (the clipboard as text)', 'on error', 'return "NONE"', 'end try', 'end try'];
      var args = [];
      script.forEach(function (l) {
        args.push('-e', l);
      });
      return NodeX.run('osascript', args).then(function (r) {
        return _this17.parse(r);
      });
    }
    var ps = ['Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing;', "$out = ".concat(this.psq(out), ";"), '$d = [Windows.Forms.Clipboard]::GetDataObject();', 'if ($d -eq $null) { "NONE"; exit }', 'if ($d.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) { $d.GetData([Windows.Forms.DataFormats]::FileDrop) | ForEach-Object { "FILE:" + $_ }; exit }', 'if ($d.GetDataPresent("PNG")) { $ms = $d.GetData("PNG"); if ($ms -is [IO.MemoryStream]) { [IO.File]::WriteAllBytes($out, $ms.ToArray()); "IMG:" + $out; exit } }', 'if ([Windows.Forms.Clipboard]::ContainsImage()) { $i = [Windows.Forms.Clipboard]::GetImage(); $i.Save($out, [Drawing.Imaging.ImageFormat]::Png); "IMG:" + $out; exit }', 'if ([Windows.Forms.Clipboard]::ContainsText()) { "TXT:" + [Windows.Forms.Clipboard]::GetText(); exit }', '"NONE"'].join(' ');
    return NodeX.run('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps]).then(function (r) {
      return _this17.parse(r);
    });
  },
  parse: function parse(r) {
    var lines = String(r).split(/\r?\n/).map(function (l) {
      return l.trim();
    }).filter(Boolean);
    var files = lines.filter(function (l) {
      return l.indexOf('FILE:') === 0;
    }).map(function (l) {
      return l.slice(5);
    });
    if (files.length) return {
      type: 'files',
      paths: files
    };
    var img = lines.find(function (l) {
      return l.indexOf('IMG:') === 0;
    });
    if (img) return {
      type: 'image',
      paths: [img.slice(4)]
    };
    var txt = lines.find(function (l) {
      return l.indexOf('TXT:') === 0;
    });
    if (txt) {
      var t = txt.slice(4).trim();
      if (/^https?:\/\/\S+$/i.test(t)) return {
        type: 'url',
        url: t
      };
      if (/^[a-z]:[\\/]|^\//i.test(t) && FS.exists(t)) return {
        type: 'files',
        paths: [t]
      };
    }
    return {
      type: 'none'
    };
  },
  download: function download(url) {
    var _this18 = this;
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', url, true);
      x.responseType = 'arraybuffer';
      x.timeout = 30000;
      x.onload = function () {
        if (x.status < 200 || x.status >= 300) return reject(new Error('Não consegui baixar a imagem do link.'));
        var type = (x.getResponseHeader('Content-Type') || '').toLowerCase();
        if (type.indexOf('image/') !== 0) return reject(new Error('O link copiado não é de uma imagem.'));
        var ext = (type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '').slice(0, 4) || 'png';
        var bytes = new Uint8Array(x.response);
        var bin = '';
        for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        var p = _this18.pasteDir() + "/colagem_".concat(_this18.stamp(), ".").concat(ext === 'svgxml' ? 'svg' : ext);
        if (!FS.write(p, btoa(bin), true)) return reject(new Error('Não consegui salvar a imagem.'));
        resolve(p);
      };
      x.onerror = function () {
        return reject(new Error('Sem conexão para baixar a imagem.'));
      };
      x.ontimeout = function () {
        return reject(new Error('O download demorou demais.'));
      };
      x.send();
    });
  },
  saveBlob: function saveBlob(blob) {
    var _this19 = this;
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        var b64 = String(r.result).split(',')[1];
        var ext = (blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
        var p = _this19.pasteDir() + "/colagem_".concat(_this19.stamp(), ".").concat(ext);
        FS.write(p, b64, true) ? resolve(p) : reject(new Error('Não consegui salvar a imagem colada.'));
      };
      r.onerror = function () {
        return reject(new Error('Não consegui ler a imagem colada.'));
      };
      r.readAsDataURL(blob);
    });
  },
  place: function place(paths, btn, cuts) {
    if (!paths || !paths.length) return Promise.resolve();
    var s = Store.s;
    var imgRx = /\.(png|jpe?g|gif|bmp|tiff?|webp|psd|svg|heic)$/i;
    var frames = Math.round((s.clipSeconds || 3) * (App.info && App.info.seq && App.info.seq.fps || 30));
    var at = null,
      placed = 0;
    var _next = function next(i) {
      if (i >= paths.length) return Promise.resolve();
      var isImg = imgRx.test(paths[i]);
      var args = {
        kind: 'file',
        path: paths[i],
        mode: paths.length > 1 ? 'playhead' : cuts ? 'cuts' : 'auto',
        frames: frames,
        fit: isImg && s.clipFit !== false,
        natural: !isImg
      };
      if (at !== null) args.atSec = at;
      return FE.call('overlay', args).then(function (d) {
        placed += d.placed;
        if (d.lastEnd !== null && d.lastEnd !== undefined) at = d.lastEnd;
        return _next(i + 1);
      });
    };
    if (btn) btn.classList.add('busy');
    return _next(0).then(function () {
      var msg = paths.length > 1 ? "".concat(paths.length, " arquivos colados em sequ\xEAncia") : "Colado ".concat(placed > 1 ? "em ".concat(placed, " takes") : 'na timeline');
      UI.toast(msg, 'ok');
      App.log(true, 'Colar: ' + msg);
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Colar: ' + e.message);
    }).then(function () {
      if (btn) btn.classList.remove('busy');
    });
  },
  paste: function paste(btn, cuts) {
    var _this20 = this;
    if (!FE.inCEP) {
      UI.toast('Disponível dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    if (!NodeX.ok) {
      UI.toast('Use Ctrl+V aqui no painel para colar (reinicie o Premiere para liberar o botão).', 'info');
      return Promise.resolve();
    }
    if (btn) btn.classList.add('busy');
    return this.fresh().then(function () {
      return _this20.readSystem();
    }).then(function (r) {
      if (btn) btn.classList.remove('busy');
      if (r.type === 'none') throw new Error('A área de transferência não tem imagem nem arquivos.');
      if (r.type === 'url') return _this20.download(r.url).then(function (p) {
        return _this20.place([p], btn, cuts);
      });
      return _this20.place(r.paths, btn, cuts);
    }).catch(function (e) {
      if (btn) btn.classList.remove('busy');
      UI.toast(e.message, 'err');
    });
  },
  onPaste: function onPaste(e) {
    var _this21 = this;
    if (/INPUT|TEXTAREA/.test((document.activeElement || {}).tagName || '')) return;
    if (!FE.inCEP) return;
    var items = e.clipboardData ? Array.from(e.clipboardData.items || []) : [];
    var img = items.find(function (it) {
      return it.kind === 'file' && /^image\//.test(it.type);
    });
    if (img) {
      e.preventDefault();
      var f = img.getAsFile();
      this.fresh().then(function () {
        return _this21.saveBlob(f);
      }).then(function (p) {
        return _this21.place([p]);
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
      return;
    }
    if (NodeX.ok) {
      e.preventDefault();
      this.paste(null);
      return;
    }
    var txt = e.clipboardData ? e.clipboardData.getData('text') : '';
    if (/^https?:\/\/\S+$/i.test((txt || '').trim())) {
      e.preventDefault();
      this.fresh().then(function () {
        return _this21.download(txt.trim());
      }).then(function (p) {
        return _this21.place([p]);
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
    }
  },
  copyFrame: function copyFrame(btn, alsoSave) {
    var _this22 = this;
    if (!FE.inCEP) {
      UI.toast('Disponível dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    var dir = (Store.dataDir || '') + '/frames';
    FS.mkdirp(dir);
    var tmp = "".concat(dir, "/frame_").concat(this.stamp(), ".png");
    if (btn) btn.classList.add('busy');
    return FE.call('exportFrame', {
      path: tmp
    }).then(function () {
      return _this22.waitFile([tmp, tmp + '.png']);
    }).then(function (p) {
      var saves = [];
      if (alsoSave) {
        var target = (_this22.projectDir() || Store.dataDir) + '/frames';
        var name = "".concat((App.info && App.info.seq ? App.info.seq.name : 'frame').replace(/[\\/:*?"<>|]/g, '_'), "_").concat(_this22.stamp(), ".png");
        var r = window.cep.fs.readFile(p, window.cep.encoding.Base64);
        if (r.err === 0 && FS.write(target + '/' + name, r.data, true)) saves.push(target + '/' + name);
      }
      return _this22.toClipboard(p).then(function () {
        UI.toast(saves.length ? 'Frame copiado e salvo em /frames' : 'Frame copiado!', 'ok');
        App.log(true, 'Frame copiado para a área de transferência');
      });
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Copiar frame: ' + e.message);
    }).then(function () {
      if (btn) btn.classList.remove('busy');
    });
  },
  waitFile: function waitFile(cands) {
    var t0 = Date.now();
    return new Promise(function (resolve, reject) {
      var _tick = function tick() {
        var hit = cands.find(function (p) {
          return FS.exists(p);
        });
        if (hit) {
          setTimeout(function () {
            return resolve(hit);
          }, 250);
          return;
        }
        if (Date.now() - t0 > 8000) return reject(new Error('O Premiere não gerou o frame (tente de novo com a timeline focada).'));
        setTimeout(_tick, 150);
      };
      _tick();
    });
  },
  toClipboard: function toClipboard(path) {
    if (NodeX.ok) {
      if (this.isMac()) return NodeX.run('osascript', ['-e', "set the clipboard to (read (POSIX file ".concat(JSON.stringify(path), ") as \xABclass PNGf\xBB)")]);
      var ps = ['Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing;', "$img = [Drawing.Image]::FromFile(".concat(this.psq(path), ");"), '$d = New-Object Windows.Forms.DataObject; $d.SetImage($img);', '$ms = New-Object IO.MemoryStream; $img.Save($ms, [Drawing.Imaging.ImageFormat]::Png); $d.SetData("PNG", $ms);', '[Windows.Forms.Clipboard]::SetDataObject($d, $true); "OK"'].join(' ');
      return NodeX.run('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps]);
    }
    if (navigator.clipboard && window.ClipboardItem) {
      var r = window.cep.fs.readFile(path, window.cep.encoding.Base64);
      if (r.err !== 0) return Promise.reject(new Error('Frame não encontrado.'));
      var bin = atob(r.data),
        arr = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return navigator.clipboard.write([new window.ClipboardItem({
        'image/png': new Blob([arr], {
          type: 'image/png'
        })
      })]);
    }
    return Promise.reject(new Error('Reinicie o Premiere para liberar a cópia para a área de transferência.'));
  }
};
document.addEventListener('paste', function (e) {
  return Clip.onPaste(e);
});
NEEDS.clip = function (sq) {
  return sq && sq.selected ? ["".concat(sq.selected, " take").concat(sq.selected > 1 ? 's' : '', " selecionado").concat(sq.selected > 1 ? 's' : ''), 'ok'] : sq ? ['Nada selecionado — vai na agulha', 'ok'] : ['Abra uma sequência', 'warn'];
};
App.registerTool({
  id: 'clipboard',
  module: 'workflow',
  icon: 'paste',
  title: 'Copiar & Colar',
  desc: 'Cole imagens na timeline e copie o frame da agulha',
  keywords: 'colar copiar clipboard área de transferência imagem print screenshot navegador frame exportar png ctrl+v',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"stack-btns\">\n        <div class=\"stack-btn\" data-cb=\"paste\">".concat(icon('paste'), "<span>Colar imagem</span><div class=\"tipbox\"><b>Clique:</b> nos takes selecionados ou na agulha<br><b>Shift:</b> um em cada corte<br><b>Ctrl+V</b> no painel tamb\xE9m cola</div></div>\n        <div class=\"stack-btn\" data-cb=\"copy\">").concat(icon('camera'), "<span>Copiar frame</span><div class=\"tipbox\"><b>Clique:</b> copia o frame da agulha<br><b>Shift:</b> tamb\xE9m salva o PNG</div></div>\n      </div>\n      <div class=\"stack-sum\"><span data-sum></span><button class=\"btn sm\" data-cfg>").concat(icon('settings'), "Configurar</button></div>\n      <div class=\"stack-cfg\" data-cfgbox style=\"display:none\">\n        <div class=\"section-label\" style=\"margin-top:4px\">Dura\xE7\xE3o na agulha</div>\n        <div class=\"chips\">").concat([1, 2, 3, 5, 10].map(function (n) {
      return "<span class=\"chip\" data-sec=\"".concat(n, "\">").concat(n, "s</span>");
    }).join(''), "</div>\n        <div class=\"row\">").concat(UI.toggle('clipFit', 'Ajustar ao quadro', s.clipFit !== false), "</div>\n      </div>\n      ").concat(FE.inCEP && !NodeX.ok ? '<div class="hint">Reinicie o Premiere uma vez para liberar os botões.</div>' : '');
    var sum = function sum() {
      var d = Clip.projectDir();
      $('[data-sum]', el).innerHTML = "<b>".concat(Store.s.clipSeconds || 3, "s</b> \xB7 salva em <b>").concat(d ? esc(d.split('/').pop()) + '/colagens' : 'colagens', "</b>");
      $$('[data-sec]', el).forEach(function (c) {
        return c.classList.toggle('on', parseFloat(c.getAttribute('data-sec')) === (Store.s.clipSeconds || 3));
      });
    };
    sum();
    UI.bindSettings(el, sum);
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      var b = g('[data-cb]');
      if (b) return b.getAttribute('data-cb') === 'paste' ? Clip.paste(b, e.shiftKey) : Clip.copyFrame(b, e.shiftKey);
      if (g('[data-cfg]')) {
        var bx = $('[data-cfgbox]', el);
        bx.style.display = bx.style.display === 'none' ? '' : 'none';
        return;
      }
      var sc = g('[data-sec]');
      if (sc) {
        Store.set('clipSeconds', parseFloat(sc.getAttribute('data-sec')));
        sum();
      }
    });
  }
});
var SFX_CATS = [['whoosh', 'Whoosh', /whoosh|swoosh|swish|woosh|whizz|swipe|swoop|pass[\s_-]?by|fly[\s_-]?by/i], ['impact', 'Impacts', /impact|hit|boom|punch|thud|slam|bang|kick|braam|bass|drop|sub\b/i], ['riser', 'Risers', /riser|rise|build|uplift|tension|power[\s_-]?up|reverse/i], ['transition', 'Transições', /transition|sweep|transform|zap|warp|speed|hyperlapse/i], ['ui', 'Cliques & UI', /pop|click|button|select|\bui\b|bubble|tick|blip|notification|ding|beep|enter|typing|keyboard|type|count|number|acent|accent/i], ['glitch', 'Glitch', /glitch|digital|error|static|flicker|distort|data|sci[\s_-]?fi/i], ['camera', 'Câmera', /camera|shutter|flash|snap|photo/i], ['ambience', 'Ambiente', /ambien|atmos|room|wind|rain|city|crowd|forest|seaside|rural|public places|transport|nature|waterfall|jungle|office|airport/i], ['drone', 'Drones', /drone/i], ['foley', 'Foley', /foley|footstep|kitchen|movement|cloth|door|gym|stone|water|fire|mechanic|car\b|cars\b|vehicle|horror|magic|monster|battle/i]];
var SFX_DEFAULT_FOLDERS = ['F:/FIRST VIDEO/SFX', 'E:/Clickup Project File/Clickup Project File/Copied_Brain clcik up AI', 'E:/IGOR ESCOUTO/sfx'];
var SFX_EXTS = /\.(wav|mp3|aif|aiff|m4a|aac|ogg|flac)$/i;
var SFX_SKIP_DIR = /^(__MACOSX|\.|Media Cache|Adobe Premiere Pro |.*\.PRV$|.*PREVIEWS?$|Peak Files)/i;
var SFX_SKIP_FILE = /\.(mp4|mov|mxf|png|jpe?g|gif|pdf|txt|html?|csv|xlsx?|docx?|zip|rar|7z|prproj|prin|pek|cfa|ds_store|json|xml|psd|ai|aep|mogrt|exe|dmg|ini|lnk)$/i;
var SFX = {
  items: null,
  scanning: false,
  playing: null,
  lastPlayed: null,
  audio: null,
  cat: 'all',
  q: '',
  onScan: null,
  cachePath: function cachePath() {
    return Store.dataDir ? Store.dataDir + '/sfx-index.json' : '';
  },
  seedFolders: function seedFolders() {
    if (Store.data.sfxSeeded || !FS.ok) return;
    var have = Store.s.sfxFolders || [];
    SFX_DEFAULT_FOLDERS.forEach(function (f) {
      if (FS.isDir(f) && have.indexOf(f) < 0) have.push(f);
    });
    Store.s.sfxFolders = have;
    Store.data.sfxSeeded = true;
    Store.save();
  },
  cleanName: function cleanName(raw, cat) {
    var n = String(raw).replace(SFX_EXTS, '').replace(/[^\s_(]*@[\w.]+/g, ' ').replace(/[_]+/g, ' ').replace(/\s{2,}/g, ' ').replace(/^[\s\-–·.]+|[\s\-–·.]+$/g, '').trim();
    n = n.replace(/^pack\s*[-–]\s*/i, '').replace(/^(\d+)\s+(\D.*)$/, '$2 $1');
    var label = (SFX_CATS.find(function (c) {
      return c[0] === cat;
    }) || [0, 'Som'])[1].replace(/s$/, '');
    if (!n) n = label;else if (/^[\d\s()]+$/.test(n)) n = label + ' ' + n.replace(/[()]/g, '').trim();
    return n;
  },
  categorize: function categorize(path) {
    var parts = path.replace(/\\/g, '/').split('/');
    var file = parts[parts.length - 1].replace(SFX_EXTS, '');
    for (var i = 0; i < SFX_CATS.length; i++) if (SFX_CATS[i][2].test(file)) return SFX_CATS[i][0];
    var dirs = parts.slice(-5, -1).reverse();
    for (var d = 0; d < dirs.length; d++) for (var _i5 = 0; _i5 < SFX_CATS.length; _i5++) if (SFX_CATS[_i5][2].test(dirs[d])) return SFX_CATS[_i5][0];
    return 'other';
  },
  load: function load() {
    if (this.items) return;
    this.seedFolders();
    var raw = this.cachePath() ? FS.read(this.cachePath()) : null;
    var cache = null;
    try {
      cache = raw ? JSON.parse(raw) : null;
    } catch (e) {
      cache = null;
    }
    var key = 'v2|' + (Store.s.sfxFolders || []).join('|');
    if (cache && cache.key === key && cache.items) {
      var gone = (Store.s.sfxFolders || []).filter(function (f) {
        return !FS.isDir(f);
      }).map(function (f) {
        return f.replace(/\\/g, '/').toLowerCase();
      });
      this.items = gone.length ? cache.items.filter(function (x) {
        return !gone.some(function (g) {
          return x.path.replace(/\\/g, '/').toLowerCase().indexOf(g) === 0;
        });
      }) : cache.items;
      if (Date.now() - cache.t > 6 * 3600000) this.scan();
    } else {
      this.items = [];
      this.scan();
    }
  },
  scan: function scan() {
    var _this23 = this;
    if (this.scanning) return;
    this.scanning = true;
    var folders = (Store.s.sfxFolders || []).slice();
    var out = [];
    var clean = function clean(n) {
      return n.replace(/-\d{8}T\d{6}Z(-\d+)*(-\d+)?$/i, '').replace(/\.(zip|rar)$/i, '').replace(/(^|\s)@[\w.]+/g, '$1').replace(/^[\s\-–]+|[\s\-–]+$/g, '').trim() || n;
    };
    var rootLabel = function rootLabel(f) {
      var parts = f.replace(/\\/g, '/').replace(/\/$/, '').split('/');
      var n = parts.pop();
      if (/^(sfx|sounds?|sons|audios?|efeitos)$/i.test(n) && parts.length > 1) n = parts.pop();
      return clean(n);
    };
    var queue = folders.filter(function (f) {
      return FS.isDir(f);
    }).map(function (f) {
      return {
        dir: f,
        depth: 0,
        label: rootLabel(f)
      };
    });
    var seen = {};
    var _step2 = function step() {
      var budget = 160;
      var _loop = function _loop() {
        var job = queue.shift();
        FS.list(job.dir).forEach(function (n) {
          budget--;
          var p = job.dir.replace(/[\\/]$/, '') + '/' + n;
          if (SFX_EXTS.test(n)) {
            if (n.indexOf('._') === 0) return;
            var k = p.toLowerCase();
            if (seen[k]) return;
            seen[k] = true;
            var cat = _this23.categorize(p);
            out.push({
              path: p,
              name: _this23.cleanName(n, cat),
              cat: cat,
              src: job.label
            });
          } else if (!SFX_SKIP_FILE.test(n) && !SFX_SKIP_DIR.test(n) && job.depth < 10 && FS.isDir(p)) {
            queue.push({
              dir: p,
              depth: job.depth + 1,
              label: job.depth === 0 ? clean(n) : job.label
            });
          }
        });
      };
      while (queue.length && budget > 0) {
        _loop();
      }
      if (_this23.onScan) _this23.onScan(out.length, false);
      if (queue.length && out.length < 30000) {
        setTimeout(_step2, 0);
        return;
      }
      _this23.items = out;
      _this23.scanning = false;
      if (_this23.cachePath()) FS.write(_this23.cachePath(), JSON.stringify({
        t: Date.now(),
        key: 'v2|' + folders.join('|'),
        items: out
      }));
      if (_this23.onScan) _this23.onScan(out.length, true);
    };
    setTimeout(_step2, 0);
  },
  byCat: function byCat(cat) {
    this.load();
    var favs = Store.data.sfxFavs || [];
    var list = (this.items || []).filter(function (x) {
      return x.cat === cat;
    });
    var pick = list.find(function (x) {
      return favs.includes(x.path);
    }) || list[0];
    return pick ? pick.path : null;
  },
  whoosh: function whoosh() {
    var s = Store.s;
    if (s.sfxWhoosh && (!FS.ok || FS.exists(s.sfxWhoosh))) return s.sfxWhoosh;
    this.load();
    var favs = Store.data.sfxFavs;
    var list = (this.items || []).filter(function (x) {
      return x.cat === 'whoosh';
    });
    var pick = list.find(function (x) {
      return favs.includes(x.path);
    }) || list[0];
    return pick ? pick.path : null;
  },
  play: function play(path) {
    var _this24 = this;
    if (!this.audio) this.audio = new Audio();
    var a = this.audio;
    if (this.playing === path && !a.paused) {
      a.pause();
      this.playing = null;
      this.markPlaying();
      return;
    }
    a.src = FE.inCEP ? FS.fileURL(path) : path;
    a.volume = Store.s.sfxVolume;
    a.onerror = function () {
      if (_this24.playing !== path) return;
      _this24.playing = null;
      _this24.markPlaying();
      var ext = (path.match(/\.(\w+)$/) || [0, ''])[1].toUpperCase();
      UI.toast(FS.exists(path) ? "Pr\xE9via indispon\xEDvel para ".concat(ext || 'este arquivo', " \u2014 inserir na timeline funciona normal.") : 'Arquivo não encontrado. A pasta foi movida ou o HD está desconectado?', 'info');
    };
    var pr = a.play();
    if (pr && pr.catch) pr.catch(function () {});
    this.playing = path;
    this.lastPlayed = path;
    a.onended = function () {
      _this24.playing = null;
      _this24.markPlaying();
    };
    this.markPlaying();
    if (this.onPlay) this.onPlay(path);
  },
  markPlaying: function markPlaying() {
    var _this25 = this;
    $$('[data-play]').forEach(function (b) {
      var on = b.getAttribute('data-play') === _this25.playing;
      b.classList.toggle('playing', on);
      b.innerHTML = icon(on ? 'stop' : 'play');
    });
  },
  insert: function insert(path, btn) {
    var s = Store.s;
    return UI.run(btn, 'Som', 'placeSfx', {
      path: path,
      mode: s.sfxMode,
      track: s.sfxTrack,
      offsetFrames: s.sfxOffset,
      gainDb: s.sfxGain
    }, function (d) {
      return "".concat(d.item, " inserido").concat(d.placed > 1 ? " ".concat(d.placed, "\xD7") : '');
    }).catch(function () {});
  }
};
App.registerTool({
  id: 'sfx',
  module: 'sfx',
  icon: 'sfx',
  title: 'Biblioteca de sons',
  full: true,
  desc: 'Seus efeitos sonoros com prévia, favoritos e inserção em 1 clique',
  keywords: 'som sound design whoosh impacto riser transição sfx efeito sonoro biblioteca áudio inserir',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"hero\"><h1>Seus sons<span class=\"hand\">em um clique</span></h1><p><span class=\"tag\" data-count></span></p></div>\n      ".concat(App.connBanner(), "\n      <div class=\"row\"><input class=\"input grow\" data-q placeholder=\"Buscar som\u2026\" value=\"").concat(esc(SFX.q), "\"><button class=\"btn sm\" data-addfolder title=\"Adicionar a pasta da sua biblioteca de sons\">").concat(icon('plus'), "Pasta</button></div>\n      <div class=\"chips\" data-cats></div>\n      <div class=\"list tall\" data-list></div>\n      <div class=\"panel\"><div class=\"panel-t\">Onde colocar<span class=\"hand\">\u2913</span></div>\n        <div class=\"row\"><label class=\"l\">Inserir no</label>").concat(UI.seg('sfxMode', [['playhead', 'Playhead'], ['selection', 'Clipes'], ['markers', 'Marcadores']], s.sfxMode), "</div>\n        <div class=\"row\"><label class=\"l\">Trilha A</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"99\" data-track value=\"").concat(s.sfxTrack, "\"><label class=\"l\" style=\"min-width:0\">Offset</label><input class=\"input num\" type=\"number\" min=\"-120\" max=\"120\" data-off value=\"").concat(s.sfxOffset, "\"><span class=\"muted\">fr</span></div>\n        <div class=\"row\"><label class=\"l\">Ganho</label>").concat(UI.range('sfxGain', -24, 12, 1, s.sfxGain, ' dB'), "</div>\n        <div class=\"row\"><label class=\"l\">Whoosh padr\xE3o</label><span class=\"grow\" data-whoosh style=\"font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\"></span><button class=\"btn sm\" data-setwhoosh title=\"Usa o \xFAltimo som que voc\xEA ouviu\">Usar o \xFAltimo ouvido</button></div>\n      </div>\n      <div data-folders></div>");
    var listEl = $('[data-list]', el);
    var drawFolders = function drawFolders() {
      var f = Store.s.sfxFolders || [];
      $('[data-folders]', el).innerHTML = f.length ? "<div class=\"section-label\">Suas pastas</div><div class=\"list\">".concat(f.map(function (p, i) {
        return "<div class=\"li\"><span class=\"ic\">".concat(icon('folder'), "</span><span class=\"nm\" title=\"").concat(esc(p), "\">").concat(esc(p), "</span><span class=\"ic\" data-rmfolder=\"").concat(i, "\" title=\"Remover\">").concat(icon('x'), "</span></div>");
      }).join(''), "</div><button class=\"btn sm\" data-rescan>").concat(icon('refresh'), "Procurar sons novos</button>") : '';
    };
    var drawWhoosh = function drawWhoosh() {
      var w = SFX.whoosh();
      $('[data-whoosh]', el).textContent = w ? w.replace(/\\/g, '/').split('/').pop().replace(SFX_EXTS, '') : 'nenhum ainda';
    };
    var draw = function draw() {
      SFX.load();
      var favs = Store.data.sfxFavs,
        q = SFX.q.toLowerCase();
      var counts = {
        all: SFX.items.length,
        fav: SFX.items.filter(function (x) {
          return favs.includes(x.path);
        }).length
      };
      SFX.items.forEach(function (x) {
        counts[x.cat] = (counts[x.cat] || 0) + 1;
      });
      var cats = [['all', 'Todos'], ['fav', '★ Favoritos']].concat(SFX_CATS.map(function (c) {
        return [c[0], c[1]];
      })).concat([['other', 'Outros']]).filter(function (c) {
        return c[0] === 'all' || c[0] === 'fav' || counts[c[0]];
      });
      $('[data-cats]', el).innerHTML = cats.map(function (c) {
        return "<span class=\"chip ".concat(SFX.cat === c[0] ? 'on' : '', "\" data-cat=\"").concat(c[0], "\">").concat(c[1], "<em>").concat(counts[c[0]] || 0, "</em></span>");
      }).join('');
      var rows = SFX.items.filter(function (x) {
        return (SFX.cat === 'all' || (SFX.cat === 'fav' ? favs.includes(x.path) : x.cat === SFX.cat)) && (!q || (x.name + ' ' + x.src).toLowerCase().includes(q));
      });
      rows.sort(function (a, b) {
        return favs.includes(b.path) - favs.includes(a.path) || a.name.localeCompare(b.name);
      });
      $('[data-count]', el).textContent = SFX.scanning ? "procurando\u2026 ".concat(SFX.items.length || '') : "".concat(SFX.items.length, " sons");
      listEl.innerHTML = rows.length ? rows.slice(0, 500).map(function (x) {
        return "<div class=\"li\" data-row=\"".concat(esc(x.path), "\">\n          <span class=\"ic play ").concat(SFX.playing === x.path ? 'playing' : '', "\" data-play=\"").concat(esc(x.path), "\">").concat(icon(SFX.playing === x.path ? 'stop' : 'play'), "</span>\n          <span class=\"nm\" title=\"").concat(esc(x.src), "\">").concat(esc(x.name), "</span>\n          <span class=\"ic ").concat(favs.includes(x.path) ? 'on' : '', "\" data-fav=\"").concat(esc(x.path), "\">").concat(icon('star'), "</span>\n          <span class=\"ic\" data-ins=\"").concat(esc(x.path), "\" title=\"Inserir\">").concat(icon('insert'), "</span></div>");
      }).join('') : "<div class=\"empty\">".concat(art('waves')).concat(SFX.scanning ? 'Procurando seus sons…' : (Store.s.sfxFolders || []).length ? 'Nenhum som encontrado.' : 'Escolha a pasta onde ficam seus efeitos sonoros.<br><button class="btn primary" data-addfolder style="margin-top:10px">' + icon('folder') + 'Escolher pasta de sons</button>', "</div>");
      drawWhoosh();
    };
    SFX.onScan = function (n, done) {
      if (!el.isConnected && !document.body.contains(el)) return;
      if (done) draw();else $('[data-count]', el).textContent = "procurando\u2026 ".concat(n);
    };
    draw();
    drawFolders();
    UI.bindSettings(el, function (k, v) {
      if (k === 'sfxVolume' && SFX.audio) SFX.audio.volume = v;
    });
    $('[data-q]', el).addEventListener('input', function (e) {
      SFX.q = e.target.value;
      draw();
    });
    $('[data-track]', el).addEventListener('change', function (e) {
      return Store.set('sfxTrack', clamp(parseInt(e.target.value, 10) || 1, 1, 99));
    });
    $('[data-off]', el).addEventListener('change', function (e) {
      return Store.set('sfxOffset', clamp(parseInt(e.target.value, 10) || 0, -120, 120));
    });
    el.addEventListener('dblclick', function (e) {
      var r = e.target.closest('[data-row]');
      if (r && !e.target.closest('.ic')) SFX.insert(r.getAttribute('data-row'), r);
    });
    el.addEventListener('click', function (e) {
      var g = function g(s2) {
        return e.target.closest(s2);
      };
      if (g('[data-cat]')) {
        SFX.cat = g('[data-cat]').getAttribute('data-cat');
        draw();
        return;
      }
      if (g('[data-play]')) {
        SFX.play(g('[data-play]').getAttribute('data-play'));
        return;
      }
      if (g('[data-fav]')) {
        var p = g('[data-fav]').getAttribute('data-fav'),
          a = Store.data.sfxFavs,
          i = a.indexOf(p);
        if (i >= 0) a.splice(i, 1);else a.push(p);
        Store.save();
        draw();
        return;
      }
      if (g('[data-ins]')) {
        SFX.insert(g('[data-ins]').getAttribute('data-ins'), g('[data-ins]'));
        return;
      }
      if (g('[data-row]') && !g('.ic')) {
        SFX.play(g('[data-row]').getAttribute('data-row'));
        return;
      }
      if (g('[data-addfolder]')) {
        var d = FS.pickFolder('Escolha a pasta da sua biblioteca de SFX');
        if (d) {
          Store.s.sfxFolders = (Store.s.sfxFolders || []).concat([d]);
          Store.save();
          SFX.items = [];
          SFX.scan();
          draw();
          drawFolders();
          UI.toast('Pasta adicionada — procurando sons…', 'ok');
        } else if (!FS.ok) UI.toast('Disponível apenas dentro do Premiere', 'info');
        return;
      }
      if (g('[data-rescan]')) {
        SFX.scan();
        draw();
        UI.toast('Procurando sons novos…', 'info');
        return;
      }
      if (g('[data-setwhoosh]')) {
        if (!SFX.lastPlayed) return UI.toast('Ouça um som (▶) primeiro e depois toque aqui.', 'info');
        Store.set('sfxWhoosh', SFX.lastPlayed);
        drawWhoosh();
        UI.toast('Whoosh padrão definido', 'ok');
        return;
      }
      if (g('[data-rmfolder]')) {
        Store.s.sfxFolders.splice(parseInt(g('[data-rmfolder]').getAttribute('data-rmfolder'), 10), 1);
        Store.save();
        SFX.items = [];
        SFX.scan();
        draw();
        drawFolders();
      }
    });
  }
});
var Timer = {
  state: 'stopped',
  fingerprint: '',
  lastActivity: Date.now(),
  manualPause: false,
  get T() {
    return Store.data.time;
  },
  keyFor: function keyFor(info) {
    return info && info.project ? info.projectPath || info.project : '';
  },
  nameFor: function nameFor(key) {
    var p = this.T.projects[key];
    return p && p.name ? p.name : String(key).replace(/\\/g, '/').split('/').pop().replace(/\.prproj$/i, '');
  },
  project: function project(key) {
    if (!this.T.projects[key]) this.T.projects[key] = {
      name: this.nameFor(key),
      estimateH: 0,
      rate: 0
    };
    return this.T.projects[key];
  },
  init: function init() {
    var _this26 = this;
    var r = this.T.running;
    if (r && Date.now() - r.last > 120000) this.close(r.last);else if (r) this.state = 'running';
    setInterval(function () {
      return _this26.tick();
    }, 1000);
    document.addEventListener('mousedown', function () {
      return _this26.activity();
    }, true);
    document.addEventListener('keydown', function () {
      return _this26.activity();
    }, true);
    App.onInfo(function (info) {
      return _this26.onInfo(info);
    });
  },
  activity: function activity() {
    this.lastActivity = Date.now();
  },
  onInfo: function onInfo(info) {
    var key = this.keyFor(info);
    var s = info && info.seq;
    var fp = s ? [key, s.name, s.clips, s.duration, s.playhead, s.selected, s.vTracks, s.aTracks].join('|') : key;
    if (fp !== this.fingerprint) {
      this.fingerprint = fp;
      this.activity();
    }
    var r = this.T.running;
    if (!Store.s.autoTimer) return;
    if (!key) {
      if (r) this.close(Date.now());
      return;
    }
    if (r && r.key !== key) this.close(Date.now());
    if (!this.T.running && !this.manualPause && this.state !== 'idle') this.start(key);
  },
  start: function start(key) {
    if (!key) {
      var k = this.keyFor(App.info);
      if (!k) {
        UI.toast('Abra um projeto no Premiere para cronometrar.', 'info');
        return;
      }
      key = k;
    }
    if (this.T.running) return;
    this.project(key);
    this.T.running = {
      key: key,
      start: Date.now(),
      last: Date.now()
    };
    this.state = 'running';
    this.manualPause = false;
    this.activity();
    Store.save();
  },
  close: function close(endTs) {
    var r = this.T.running;
    if (!r) return;
    var end = Math.max(r.start, endTs || Date.now());
    var sec = Math.round((end - r.start) / 1000);
    if (sec >= 10) this.T.sessions.push({
      id: uid(),
      key: r.key,
      start: r.start,
      end: end,
      sec: sec
    });
    this.T.running = null;
    this.state = 'stopped';
    Store.save();
  },
  pause: function pause() {
    this.manualPause = true;
    this.close(Date.now());
    this.state = 'paused';
  },
  toggle: function toggle() {
    if (this.T.running) this.pause();else {
      this.manualPause = false;
      this.start();
    }
  },
  persist: function persist() {
    if (this.T.running) {
      this.T.running.last = Date.now();
      Store.saveNow();
    }
  },
  tick: function tick() {
    var r = this.T.running;
    var idleMs = (Store.s.idleMinutes || 0) * 60000;
    if (r) {
      r.last = Date.now();
      if (idleMs && Date.now() - this.lastActivity > idleMs) {
        this.close(this.lastActivity);
        this.state = 'idle';
      }
      if (Date.now() % 15000 < 1000) Store.save();
    } else if (this.state === 'idle' && Date.now() - this.lastActivity < 2000 && Store.s.autoTimer) {
      this.state = 'stopped';
      this.start(this.keyFor(App.info));
    }
    this.renderChip();
    if (App.current === 'time') TimeView.live();
  },
  currentSec: function currentSec() {
    var r = this.T.running;
    return r ? (Date.now() - r.start) / 1000 : 0;
  },
  totalFor: function totalFor(key, sinceTs) {
    var t = 0;
    this.T.sessions.forEach(function (s) {
      if ((!key || s.key === key) && (!sinceTs || s.start >= sinceTs)) t += s.sec;
    });
    var r = this.T.running;
    if (r && (!key || r.key === key)) t += this.currentSec();
    return t;
  },
  todayFor: function todayFor(key) {
    var d = new Date();
    d.setHours(0, 0, 0, 0);
    return this.totalFor(key, d.getTime());
  },
  rateFor: function rateFor(key) {
    var p = this.T.projects[key];
    return p && p.rate ? p.rate : Store.s.hourlyRate;
  },
  renderChip: function renderChip() {
    var chip = $('#timerChip');
    if (!chip) return;
    var key = this.T.running ? this.T.running.key : this.keyFor(App.info);
    chip.className = 'timer-chip ' + (this.T.running ? 'run' : this.state === 'idle' ? 'idle' : '');
    $('span', chip).textContent = fmtDur(key ? this.totalFor(key) : 0);
    chip.title = this.T.running ? 'Cronometrando · clique para detalhes' : this.state === 'idle' ? 'Pausado por inatividade' : 'Cronômetro parado';
  }
};
var TimeView = {
  filter: '',
  render: function render(el) {
    var _this27 = this;
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"hero\"><h1>Seu tempo<span class=\"hand\">vale ouro</span></h1></div>\n      <div class=\"timecard\"><div class=\"clock\">\n        <div class=\"big\" data-big>00:00:00</div>\n        <div class=\"whoc\" data-who></div>\n        <span class=\"state\" data-state></span>\n      </div><button class=\"btn\" data-toggle-timer></button></div>\n      <div class=\"stats\" style=\"margin:0 -3px 8px\">\n        <div class=\"stat\"><b data-today>\u2013</b><span>hoje</span></div>\n        <div class=\"stat\"><b data-total>\u2013</b><span>no projeto</span></div>\n        <div class=\"stat\"><b data-cost>\u2013</b><span>custo</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Quanto cobrar<span class=\"hand\">$$</span></div>\n        <div class=\"row\"><label class=\"l\">Valor/hora</label><input class=\"input num\" style=\"width:84px\" type=\"number\" min=\"0\" step=\"5\" data-rate><span class=\"muted\" data-rate-hint></span></div>\n        <div class=\"row\"><label class=\"l\">Estimativa</label><input class=\"input num\" style=\"width:84px\" type=\"number\" min=\"0\" step=\"0.5\" data-est><span class=\"muted\">horas</span></div>\n        <div data-budget></div>\n        <div class=\"row\" style=\"margin-top:4px\"><label class=\"l\">Margem</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"500\" data-margin value=\"".concat(s.margin, "\"><span class=\"muted\">%</span></div>\n        <div data-quote></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">\xDAltimos 7 dias</div><div class=\"chart\" data-chart></div></div>\n      <div class=\"panel\"><div class=\"panel-t\">Projetos<span class=\"muted\" style=\"margin-left:auto;font-weight:400;font-size:11px\">toque para filtrar</span></div><table class=\"tbl\" data-projects></table></div>\n      <div class=\"section-label\">Sess\xF5es</div>\n      <div class=\"list\" data-sessions></div>\n      <div class=\"btns\"><button class=\"btn\" data-csv>").concat(icon('download'), "Exportar planilha</button><button class=\"btn\" data-addmanual>").concat(icon('plus'), "Lan\xE7ar horas</button></div>\n      <div class=\"panel\" style=\"margin-top:10px\"><div class=\"panel-t\">Cron\xF4metro</div>\n        <div class=\"row\">").concat(UI.toggle('autoTimer', 'Automático', s.autoTimer), "</div>\n        <div class=\"row\"><label class=\"l\">Pausar ap\xF3s</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"120\" data-idle value=\"").concat(s.idleMinutes, "\"><span class=\"muted\">min parado</span></div>\n      </div>");
    UI.bindSettings(el);
    $('[data-idle]', el).addEventListener('change', function (e) {
      return Store.set('idleMinutes', clamp(parseInt(e.target.value, 10) || 0, 0, 120));
    });
    $('[data-margin]', el).addEventListener('input', function (e) {
      Store.set('margin', parseFloat(e.target.value) || 0);
      _this27.live();
    });
    $('[data-rate]', el).addEventListener('change', function (e) {
      var key = _this27.key();
      var v = parseFloat(e.target.value) || 0;
      if (key) {
        _this27.projectCfg(key).rate = v;
        Store.save();
      } else Store.set('hourlyRate', v);
      _this27.live(true);
    });
    $('[data-est]', el).addEventListener('change', function (e) {
      var key = _this27.key();
      if (key) {
        _this27.projectCfg(key).estimateH = parseFloat(e.target.value) || 0;
        Store.save();
        _this27.live(true);
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      if (g('[data-toggle-timer]')) {
        Timer.toggle();
        _this27.live(true);
      }
      if (g('[data-csv]')) _this27.exportCSV();
      if (g('[data-addmanual]')) _this27.manual();
      if (g('[data-delsession]')) {
        var id = g('[data-delsession]').getAttribute('data-delsession');
        UI.confirm('Excluir sessão', 'Remover esta sessão do histórico?', 'Excluir').then(function (ok) {
          if (ok) {
            Store.data.time.sessions = Store.data.time.sessions.filter(function (x) {
              return x.id !== id;
            });
            Store.save();
            _this27.live(true);
          }
        });
      }
      if (g('[data-proj]')) {
        var k = g('[data-proj]').getAttribute('data-proj');
        _this27.filter = _this27.filter === k ? '' : k;
        _this27.live(true);
      }
    });
    this.live(true);
  },
  key: function key() {
    return Timer.T.running ? Timer.T.running.key : Timer.keyFor(App.info);
  },
  projectCfg: function projectCfg(key) {
    return Timer.project(key);
  },
  live: function live(full) {
    var _this28 = this;
    var el = $('#view');
    if (!$('[data-big]', el)) return;
    var s = Store.s,
      key = this.key(),
      cur = s.currency;
    var total = key ? Timer.totalFor(key) : 0;
    var rate = key ? Timer.rateFor(key) : s.hourlyRate;
    $('[data-big]', el).textContent = fmtDur(Timer.T.running ? Timer.currentSec() : 0);
    $('[data-who]', el).textContent = key ? Timer.nameFor(key) : 'Nenhum projeto aberto';
    var st = $('[data-state]', el);
    var states = {
      running: ['Gravando', 'ok'],
      idle: ['Pausado por inatividade', 'warn'],
      paused: ['Pausado', ''],
      stopped: ['Parado', '']
    };
    var cs = Timer.T.running ? states.running : states[Timer.state] || states.stopped;
    st.textContent = cs[0];
    $('[data-toggle-timer]', el).innerHTML = Timer.T.running ? "".concat(icon('pause'), "Pausar") : "".concat(icon('play'), "Come\xE7ar a contar");
    $('[data-today]', el).textContent = fmtDur(key ? Timer.todayFor(key) : 0, false);
    $('[data-total]', el).textContent = fmtDur(total, false);
    $('[data-cost]', el).textContent = fmtMoney(total / 3600 * rate, cur);
    var p = key ? Timer.T.projects[key] : null;
    var est = p ? p.estimateH || 0 : 0;
    if (est) {
      var pct = total / 3600 / est * 100;
      $('[data-budget]', el).innerHTML = "<div class=\"bar ".concat(pct > 100 ? 'over' : '', "\"><i style=\"width:").concat(clamp(pct, 0, 100), "%\"></i></div><div class=\"hint ").concat(pct > 100 ? 'warn' : '', "\">").concat((total / 3600).toFixed(1), "h de ").concat(est, "h estimadas (").concat(Math.round(pct), "%)").concat(pct > 100 ? ' · acima da estimativa' : '', "</div>");
    } else $('[data-budget]', el).innerHTML = '';
    var hours = Math.max(est, total / 3600);
    var price = hours * rate * (1 + (s.margin || 0) / 100);
    $('[data-quote]', el).innerHTML = "<div class=\"quote\"><span>pre\xE7o sugerido</span><b>".concat(fmtMoney(price, cur), "</b><span>").concat(hours.toFixed(1), "h \xD7 ").concat(fmtMoney(rate, cur)).concat(s.margin ? " + ".concat(s.margin, "% de margem") : '', " ").concat(est && est > total / 3600 ? '· pela estimativa' : '· pelo tempo real', "</span></div>");
    if (!full) return;
    var ri = $('[data-rate]', el),
      ei = $('[data-est]', el);
    if (document.activeElement !== ri) ri.value = rate;
    if (document.activeElement !== ei) ei.value = est || '';
    $('[data-rate-hint]', el).textContent = key && p && p.rate ? 'deste projeto' : 'padrão';
    var days = [];
    for (var i = 6; i >= 0; i--) {
      var d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      days.push(d);
    }
    var totals = days.map(function (d) {
      var a = d.getTime(),
        b = a + 86400000;
      var t = 0;
      Timer.T.sessions.forEach(function (x) {
        if (x.start >= a && x.start < b) t += x.sec;
      });
      if (Timer.T.running && Timer.T.running.start >= a && Timer.T.running.start < b) t += Timer.currentSec();
      return t;
    });
    var max = Math.max.apply(null, totals.concat([3600]));
    var wd = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
    $('[data-chart]', el).innerHTML = days.map(function (d, i) {
      return "<div class=\"c\"><em>".concat(totals[i] ? (totals[i] / 3600).toFixed(1) + 'h' : '', "</em><i class=\"").concat(i === 6 ? 'today' : '', "\" style=\"height:").concat(Math.round(totals[i] / max * 60), "px\"></i><span>").concat(wd[d.getDay()], "</span></div>");
    }).join('');
    var keys = {};
    Timer.T.sessions.forEach(function (x) {
      keys[x.key] = (keys[x.key] || 0) + x.sec;
    });
    if (Timer.T.running) keys[Timer.T.running.key] = (keys[Timer.T.running.key] || 0) + Timer.currentSec();
    var rows = Object.keys(keys).sort(function (a, b) {
      return keys[b] - keys[a];
    });
    $('[data-projects]', el).innerHTML = rows.length ? "<tr><th>Projeto</th><th class=\"r\">Horas</th><th class=\"r\">Custo</th></tr>" + rows.map(function (k) {
      return "<tr data-proj=\"".concat(esc(k), "\" style=\"cursor:pointer;").concat(_this28.filter === k ? 'font-weight:700' : '', "\"><td>").concat(esc(Timer.nameFor(k)), "</td><td class=\"r\">").concat((keys[k] / 3600).toFixed(2), "</td><td class=\"r\">").concat(fmtMoney(keys[k] / 3600 * Timer.rateFor(k), cur), "</td></tr>");
    }).join('') : '<tr><td class="muted" style="padding:6px">Nenhuma sessão ainda — o cronômetro começa ao abrir um projeto.</td></tr>';
    var ss = Timer.T.sessions.filter(function (x) {
      return !_this28.filter || x.key === _this28.filter;
    }).slice(-40).reverse();
    $('[data-sessions]', el).innerHTML = ss.length ? ss.map(function (x) {
      var d = new Date(x.start);
      return "<div class=\"li\"><span class=\"nm\">".concat(esc(Timer.nameFor(x.key))).concat(x.manual ? ' <span class="tag">manual</span>' : '', "</span><span class=\"sub\">").concat(pad2(d.getDate()), "/").concat(pad2(d.getMonth() + 1), " ").concat(pad2(d.getHours()), ":").concat(pad2(d.getMinutes()), " \xB7 ").concat(fmtDur(x.sec, false), "</span><span class=\"ic\" data-delsession=\"").concat(x.id, "\">").concat(icon('trash'), "</span></div>");
    }).join('') : "<div class=\"empty\">".concat(art('clock'), "Sem sess\xF5es por enquanto.</div>");
  },
  manual: function manual() {
    var _this29 = this;
    var key = this.key();
    if (!key) return UI.toast('Abra um projeto para lançar tempo.', 'info');
    UI.prompt('Lançar quantas horas neste projeto? (ex: 1,5)', '1').then(function (v) {
      var h = parseFloat(String(v || '').replace(',', '.'));
      if (!h || h <= 0) return;
      var end = Date.now();
      Timer.T.sessions.push({
        id: uid(),
        key: key,
        start: end - h * 3600000,
        end: end,
        sec: Math.round(h * 3600),
        manual: true
      });
      Store.save();
      _this29.live(true);
      UI.toast("".concat(h, "h lan\xE7adas"), 'ok');
    });
  },
  exportCSV: function exportCSV() {
    var cur = Store.s.currency;
    var lines = [['Projeto', 'Início', 'Fim', 'Duração (h)', "Valor/hora (".concat(cur, ")"), "Custo (".concat(cur, ")"), 'Tipo'].join(';')];
    Timer.T.sessions.forEach(function (x) {
      var r = Timer.rateFor(x.key),
        h = x.sec / 3600;
      lines.push([Timer.nameFor(x.key), new Date(x.start).toLocaleString('pt-BR'), new Date(x.end).toLocaleString('pt-BR'), h.toFixed(3).replace('.', ','), String(r).replace('.', ','), (h * r).toFixed(2).replace('.', ','), x.manual ? 'manual' : 'automático'].map(function (c) {
        return "\"".concat(String(c).replace(/"/g, '""'), "\"");
      }).join(';'));
    });
    var csv = '﻿' + lines.join('\r\n');
    var name = "FastEdit-relatorio-".concat(dayKey(Date.now()), ".csv");
    var path = FS.saveDialog('Salvar relatório', name, ['csv']);
    if (path) {
      FS.write(/\.csv$/i.test(path) ? path : path + '.csv', csv);
      UI.toast('Relatório salvo', 'ok');
    } else if (!FS.ok) {
      var a = document.createElement('a');
      a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
      a.download = name;
      a.click();
    }
  }
};
App.registerTool({
  id: 'time',
  module: 'time',
  icon: 'time',
  title: 'Cronômetro',
  full: true,
  desc: 'Cronômetro automático por projeto, custo por hora e relatórios',
  keywords: 'tempo cronômetro timer horas custo preço orçamento relatório produtividade sessões',
  render: function render(el) {
    TimeView.render(el);
  }
});
var Settings = {
  render: function render(outer) {
    var _this30 = this;
    var s = Store.s;
    outer.innerHTML = '';
    var view = document.createElement('div');
    outer.appendChild(view);
    view.innerHTML = "\n      <div class=\"page-head\"><div class=\"back\" data-a=\"back\">".concat(icon('back'), "</div><h2>Ajustes<small>Salvos no seu computador</small></h2></div>\n      <div class=\"panel\"><div class=\"panel-t\">Apar\xEAncia</div>\n        <div class=\"row\">").concat(UI.seg('theme', [['cream', 'Creme'], ['cobalt', 'Cobalto'], ['neon', 'Neon']], s.theme || 'cream'), "</div>\n        <button class=\"btn sm\" data-a=\"tour\">Ver o tour</button>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Anima\xE7\xE3o (padr\xF5es)</div>\n        <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('frames', 2, 60, 1, s.frames, ' fr'), "</div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('intensity', 0.2, 2, 0.1, s.intensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('ease', 'Movimento suave', s.ease)).concat(UI.toggle('replace', 'Substituir animação anterior', s.replace), "</div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Tempo & pre\xE7o</div>\n        <div class=\"row\"><label class=\"l\">Valor/hora</label><input class=\"input num\" style=\"width:80px\" type=\"number\" min=\"0\" step=\"5\" data-k=\"hourlyRate\" value=\"").concat(s.hourlyRate, "\"><label class=\"l\" style=\"min-width:0\">Moeda</label>").concat(UI.select('currency', [['R$', 'R$'], ['US$', 'US$'], ['€', '€'], ['£', '£']], s.currency), "</div>\n        <div class=\"row\">").concat(UI.toggle('autoTimer', 'Cronômetro automático', s.autoTimer), "</div>\n        <div class=\"row\"><label class=\"l\">Inatividade</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"120\" data-k=\"idleMinutes\" value=\"").concat(s.idleMinutes, "\"><span class=\"muted\">min</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Sons</div>\n        <div class=\"row\"><label class=\"l\">Trilha padr\xE3o</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"99\" data-k=\"sfxTrack\" value=\"").concat(s.sfxTrack, "\"><label class=\"l\" style=\"min-width:0\">Offset</label><input class=\"input num\" type=\"number\" min=\"-120\" max=\"120\" data-k=\"sfxOffset\" value=\"").concat(s.sfxOffset, "\"><span class=\"muted\">fr</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Atualiza\xE7\xF5es</div><div data-upd></div></div>\n      <div class=\"section-label\">Seus dados</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-a=\"export\">").concat(icon('download'), "Backup</button><button class=\"btn\" data-a=\"import\">").concat(icon('upload'), "Restaurar</button></div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-a=\"cache\">").concat(icon('trash'), "Limpar imagens geradas</button><button class=\"btn danger\" data-a=\"reset\">").concat(icon('refresh'), "Restaurar padr\xF5es</button></div>\n      <div class=\"section-label\">Sobre</div>\n      <div class=\"panel sel-text\"><div>\n        <b>Fast Edit ").concat(APP_VERSION, "</b> \xB7 Creative Workflow Suite<br><span class=\"hand\" data-credit style=\"font-size:18px;cursor:pointer;text-decoration:underline\">feito por @odalluz</span><br>\n        <span class=\"muted\">Premiere: ").concat(esc(App.info ? App.info.version : '—'), " \xB7 Host: ").concat(FE.hostReady ? 'carregado' : 'não carregado', " \xB7 CEP ").concat(esc(FE.inCEP && window.__adobe_cep__.getCurrentApiVersion ? JSON.stringify(window.__adobe_cep__.getCurrentApiVersion()).replace(/[{}"]/g, '').replace(/major:|minor:|micro:/g, '').split(',').join('.') : '—'), "</span><br>\n        <span class=\"muted mono\" style=\"font-size:10.5px\">").concat(esc(Store.dataDir || 'localStorage'), "</span>\n        <div class=\"btns\" style=\"margin-top:10px\"><button class=\"btn sm\" data-a=\"reconnect\">").concat(icon('refresh'), "Reconectar</button><button class=\"btn sm\" data-a=\"reload\">Recarregar painel</button></div>\n      </div></div>");
    UI.bindSettings(view, function (k, v) {
      if (k === 'theme') Theme.apply(v);
    });
    this.renderUpdate();
    view.addEventListener('change', function (e) {
      if (e.target.hasAttribute('data-updurl')) {
        Store.set('updateUrl', e.target.value.trim());
        Updater.available = null;
        _this30.renderUpdate();
        return;
      }
      var k = e.target.getAttribute('data-k');
      if (k) Store.set(k, parseFloat(e.target.value) || 0);
    });
    view.addEventListener('click', function (e) {
      if (e.target.closest('[data-credit]')) return FE.openURL(CREDIT_URL);
      if (e.target.closest('[data-checkupd]')) return Updater.check(true);
      if (e.target.closest('[data-doupd]')) return Updater.install(e.target.closest('[data-doupd]'));
      var b = e.target.closest('[data-a]');
      if (!b) return;
      var a = b.getAttribute('data-a');
      if (a === 'back') {
        App.go('home');
        return;
      }
      if (a === 'tour') {
        Onboarding.show();
        return;
      }
      if (a === 'reconnect') {
        FE.hostReady = false;
        App.poll(true);
      }
      if (a === 'reload') {
        Timer.persist();
        Store.saveNow();
        FE.reload();
      }
      if (a === 'export') {
        var p = FS.saveDialog('Salvar backup do Fast Edit', "FastEdit-backup-".concat(dayKey(Date.now()), ".json"), ['json']);
        if (p) {
          FS.write(p, JSON.stringify(Store.data, null, 2));
          UI.toast('Backup salvo', 'ok');
        }
      }
      if (a === 'import') {
        var _p = FS.pickFile('Escolha um backup do Fast Edit', ['json']);
        if (!_p) return;
        try {
          var d = JSON.parse(FS.read(_p));
          Store.data = Store.merge(JSON.parse(JSON.stringify(DEFAULTS)), d);
          Store.saveNow();
          UI.toast('Backup restaurado', 'ok');
          _this30.render(outer);
        } catch (er) {
          UI.toast('Arquivo inválido', 'err');
        }
      }
      if (a === 'cache') {
        var dir = Gen.dir();
        var files = FS.list(dir);
        files.forEach(function (f) {
          return FS.remove(dir + '/' + f);
        });
        UI.toast("".concat(files.length, " imagem(ns) removida(s). Itens j\xE1 importados no projeto continuam l\xE1."), 'info');
      }
      if (a === 'reset') {
        UI.confirm('Restaurar padrões', 'Volta todas as preferências ao padrão. Sessões de tempo, stacks e favoritos são mantidos.', 'Restaurar').then(function (ok) {
          if (!ok) return;
          Store.data.settings = JSON.parse(JSON.stringify(DEFAULTS.settings));
          Store.saveNow();
          _this30.render(outer);
          UI.toast('Padrões restaurados', 'ok');
        });
      }
    });
  }
};
Settings.renderUpdate = function () {
  var el = $('[data-upd]');
  if (!el) return;
  var u = Updater.available;
  el.innerHTML = "<div class=\"row\" style=\"margin:0\"><span>Vers\xE3o <b>".concat(APP_VERSION, "</b></span>\n    ").concat(u ? "<button class=\"btn primary sm right\" data-doupd>".concat(icon('download'), "Atualizar para ").concat(esc(u.version), "</button>") : "<button class=\"btn sm right\" data-checkupd>".concat(icon('refresh')).concat(Updater.checking ? 'Procurando…' : 'Procurar atualização', "</button>"), "</div>");
};
(function boot() {
  var start = function start() {
    try {
      App.init();
    } catch (e) {
      document.body.innerHTML = "<div style=\"padding:16px;color:#f87171;font:12px Segoe UI\">Erro ao iniciar o Fast Edit: ".concat(esc(e.message), "</div>");
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);else start();
})();
var UPDATE_REPO = 'thauanfelippepro-ux/fast-edit';
var CREDIT_URL = 'https://instagram.com/odalluz';
var Updater = {
  available: null,
  checking: false,
  installing: false,
  lastError: '',
  base: function base() {
    var custom = (Store.s.updateUrl || '').trim();
    return custom ? custom.replace(/\/?$/, '/') : "https://raw.githubusercontent.com/".concat(UPDATE_REPO, "/main/updates/");
  },
  cmp: function cmp(a, b) {
    var pa = String(a).split('.').map(function (n) {
        return parseInt(n, 10) || 0;
      }),
      pb = String(b).split('.').map(function (n) {
        return parseInt(n, 10) || 0;
      });
    for (var i = 0; i < 3; i++) {
      if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    }
    return 0;
  },
  get: function get(url, onProgress) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', url + (url.indexOf('?') < 0 ? '?t=' : '&t=') + Date.now(), true);
      x.timeout = 30000;
      x.onload = function () {
        return x.status >= 200 && x.status < 300 ? resolve(x.responseText) : reject(new Error(x.status === 404 ? 'Nenhuma versão publicada ainda.' : "Servidor respondeu ".concat(x.status, ".")));
      };
      x.onerror = function () {
        return reject(new Error('Sem conexão com a internet.'));
      };
      x.ontimeout = function () {
        return reject(new Error('A conexão demorou demais.'));
      };
      if (onProgress) x.onprogress = function (e) {
        if (e.lengthComputable) onProgress(e.loaded / e.total);
      };
      x.send();
    });
  },
  check: function check(manual) {
    var _this31 = this;
    if (this.checking || this.installing) return Promise.resolve(this.available);
    this.checking = true;
    Store.data.lastUpdateCheck = Date.now();
    Store.save();
    return this.get(this.base() + 'latest.json').then(function (txt) {
      var r = JSON.parse(txt);
      if (!r.version) throw new Error('Arquivo de versão inválido.');
      _this31.lastError = '';
      if (_this31.cmp(r.version, APP_VERSION) > 0) {
        _this31.available = r;
        if (manual || Store.data.notifiedVersion !== r.version) UI.toast("Nova vers\xE3o ".concat(r.version, " dispon\xEDvel!"), 'info');
        Store.data.notifiedVersion = r.version;
        Store.save();
      } else {
        _this31.available = null;
        if (manual) UI.toast("Voc\xEA j\xE1 est\xE1 na vers\xE3o mais nova (".concat(APP_VERSION, ")."), 'ok');
      }
      return _this31.available;
    }).catch(function (e) {
      _this31.lastError = e.message;
      if (manual) UI.toast('Não consegui verificar: ' + e.message, 'err');
      return null;
    }).then(function (r) {
      _this31.checking = false;
      _this31.refreshUI();
      return r;
    });
  },
  install: function install(btn) {
    var _this32 = this;
    var info = this.available;
    if (!info || this.installing) return Promise.resolve();
    if (!FE.inCEP || !FS.ok) {
      UI.toast('A atualização só funciona dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    this.installing = true;
    var label = btn ? btn.innerHTML : '';
    var setBtn = function setBtn(t) {
      if (btn) btn.innerHTML = t;
    };
    if (btn) btn.classList.add('busy');
    setBtn('Baixando… 0%');
    var extDir = FE.sysPath('extension').replace(/\\/g, '/').replace(/\/$/, '');
    var backupDir = Store.dataDir + '/backup/' + APP_VERSION;
    return this.get(this.base() + (info.package || 'fastedit-update.json'), function (p) {
      return setBtn("Baixando\u2026 ".concat(Math.round(p * 100), "%"));
    }).then(function (txt) {
      setBtn('Instalando…');
      var pkg = JSON.parse(txt);
      if (pkg.version !== info.version || !pkg.files || !pkg.files.length) throw new Error('Pacote de atualização inválido.');
      pkg.files.forEach(function (f) {
        if (!/^[\w\-. /]+$/.test(f.path) || f.path.indexOf('..') >= 0 || f.path[0] === '/') throw new Error('Pacote contém caminho inválido: ' + f.path);
      });
      var backed = [];
      pkg.files.forEach(function (f) {
        var target = extDir + '/' + f.path;
        if (FS.exists(target)) {
          var r = window.cep.fs.readFile(target, window.cep.encoding.Base64);
          if (r.err === 0) {
            FS.write(backupDir + '/' + f.path, r.data, true);
            backed.push(f.path);
          }
        }
      });
      var written = [];
      try {
        pkg.files.forEach(function (f) {
          if (!FS.write(extDir + '/' + f.path, f.b64, true)) throw new Error('Sem permissão para gravar ' + f.path);
          written.push(f.path);
        });
      } catch (e) {
        backed.forEach(function (p) {
          var r = window.cep.fs.readFile(backupDir + '/' + p, window.cep.encoding.Base64);
          if (r.err === 0) FS.write(extDir + '/' + p, r.data, true);
        });
        throw e;
      }
      Store.data.justUpdated = {
        from: APP_VERSION,
        to: pkg.version,
        notes: info.notes || '',
        restart: !!pkg.restartPremiere,
        t: Date.now()
      };
      Store.saveNow();
      setBtn('Recarregando…');
      var hostFile = extDir + '/host/fastedit.jsx';
      return FE.evalScript("try{$.evalFile(".concat(JSON.stringify(hostFile), ");\"ok\"}catch(e){\"ERR:\"+e.message}")).then(function () {
        setTimeout(function () {
          Timer.persist();
          FE.reload();
        }, 400);
      });
    }).catch(function (e) {
      _this32.installing = false;
      if (btn) {
        btn.classList.remove('busy');
        btn.innerHTML = label;
      }
      UI.toast('Atualização falhou: ' + e.message, 'err');
      App.log(false, 'Atualização: ' + e.message);
    });
  },
  init: function init() {
    var _this33 = this;
    var j = Store.data.justUpdated;
    if (j && j.to === APP_VERSION) {
      Store.data.justUpdated = null;
      Store.save();
      setTimeout(function () {
        UI.toast("Fast Edit atualizado para ".concat(APP_VERSION, "!"), 'ok');
        App.log(true, "Atualizado de ".concat(j.from, " para ").concat(j.to));
        if (j.restart) UI.confirm('Quase lá', 'Esta versão mudou a configuração do painel. Feche e abra o Premiere quando puder para concluir.', 'Entendi');
      }, 1800);
    }
    if (Store.s.autoUpdate !== false) {
      setTimeout(function () {
        return _this33.check(false);
      }, 4000);
      setInterval(function () {
        return _this33.check(false);
      }, 6 * 3600000);
    }
  },
  refreshUI: function refreshUI() {
    var g = $('#gear');
    if (g) g.classList.toggle('badge', !!this.available);
    if (App.current === 'home' && !App.page) Home.renderUpdate();
    if (App.current === 'settings') Settings.renderUpdate();
  }
};
