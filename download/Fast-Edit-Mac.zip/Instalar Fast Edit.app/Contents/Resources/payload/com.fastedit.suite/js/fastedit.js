/* Fast Edit 2.27.7 — feito por @odalluz */
function _regenerator() { var r, e, o = "function" == typeof Symbol ? Symbol : {}, n = o.iterator || "@@iterator", a = o.toStringTag || "@@toStringTag"; function i(o, n, a, i) { var u = n && n.prototype instanceof Generator ? n : Generator, f = Object.create(u.prototype); return _regeneratorDefine2(f, "_invoke", function (t, o, n) { var a, i, u, f = 0, p = n || [], y = !1, G = { p: 0, n: 0, v: r, a: l, f: l.bind(r, 4), d: function d(t, e) { return a = t, i = 0, u = r, G.n = e, c; } }; function l(t, o) { for (i = t, u = o, e = 0; !y && f && !n && e < p.length; e++) { var n, a = p[e], l = G.p, F = a[2]; t > 3 ? (n = F === o) && (u = a[(i = a[4]) ? 5 : (i = 3, 3)], a[4] = a[5] = r) : a[0] <= l && ((n = t < 2 && l < a[1]) ? (i = 0, G.v = o, G.n = a[1]) : l < F && (n = t < 3 || a[0] > o || o > F) && (a[4] = t, a[5] = o, G.n = F, i = 0)); } if (n || t > 1) return c; throw y = !0, o; } return function (n, p, F) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && l(p, F), i = p, u = F; (e = i < 2 ? r : u) || !y;) { a || (i ? (i > 1 && (G.n = i < 3 ? -1 : u), l(i, u)) : G.v = u); try { if (f = 2, a) { if (i || (n = "next"), e = a[n]) { if (!(e = e.call(a, u))) throw TypeError("iterator result is not an object"); if (!e.done) return e; u = e.value, i < 2 && (i = 0); } else 1 === i && (e = a.return) && e.call(a), i < 2 && (u = TypeError("The iterator does not provide a '" + n + "' method"), i = 1); a = r; } else if ((e = (y = G.n < 0) ? u : t.call(o, G)) !== c) break; } catch (t) { a = r, i = 1, u = t; } finally { f = 1; } } return { value: e, done: y }; }; }(o, a, i), !0), f; } var c = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} e = Object.getPrototypeOf; var u = [][n] ? e(e([][n]())) : (_regeneratorDefine2(e = {}, n, function () { return this; }), e), f = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(u); function p(r) { return Object.setPrototypeOf ? Object.setPrototypeOf(r, GeneratorFunctionPrototype) : (r.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(r, a, "GeneratorFunction")), r.prototype = Object.create(f), r; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(f, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, a, "GeneratorFunction"), _regeneratorDefine2(f), _regeneratorDefine2(f, a, "Generator"), _regeneratorDefine2(f, n, function () { return this; }), _regeneratorDefine2(f, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: p }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _callSpread(a, e, l) { return a.apply(e, l); }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
if (!Object.assign) {
  Object.assign = function (t) {
    for (var i = 1; i < arguments.length; i++) {
      var s = arguments[i];
      if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) t[k] = s[k];
    }
    return t;
  };
}
if (!Object.values) Object.values = function (o) {
  return Object.keys(o).map(function (k) {
    return o[k];
  });
};
if (!Array.prototype.find) Array.prototype.find = function (f) {
  for (var i = 0; i < this.length; i++) if (f(this[i], i)) return this[i];
};
if (!Array.prototype.findIndex) Array.prototype.findIndex = function (f) {
  for (var i = 0; i < this.length; i++) if (f(this[i], i)) return i;
  return -1;
};
if (!Array.prototype.includes) Array.prototype.includes = function (v) {
  return this.indexOf(v) >= 0;
};
if (!String.prototype.includes) String.prototype.includes = function (v) {
  return this.indexOf(v) >= 0;
};
if (!String.prototype.startsWith) String.prototype.startsWith = function (v) {
  return this.indexOf(v) === 0;
};
if (!Array.from) Array.from = function (a) {
  return Array.prototype.slice.call(a);
};
if (window.NodeList && !NodeList.prototype.forEach) NodeList.prototype.forEach = Array.prototype.forEach;
if (window.Element && !Element.prototype.matches) Element.prototype.matches = Element.prototype.webkitMatchesSelector;
if (window.Element && !Element.prototype.closest) {
  Element.prototype.closest = function (s) {
    var el = this;
    while (el && el.nodeType === 1) {
      if (el.matches(s)) return el;
      el = el.parentElement;
    }
    return null;
  };
}
var APP_VERSION = '2.27.7';
var $ = function $(s, r) {
  return (r || document).querySelector(s);
};
var $$ = function $$(s, r) {
  return Array.from((r || document).querySelectorAll(s));
};
var esc = function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[c];
  });
};
var clamp = function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
};
var pad2 = function pad2(n) {
  return (n < 10 ? '0' : '') + n;
};
function fmtDur(sec, withSec) {
  sec = Math.max(0, Math.floor(sec || 0));
  var h = Math.floor(sec / 3600),
    m = Math.floor(sec % 3600 / 60),
    s = sec % 60;
  return withSec === false ? "".concat(h, "h ").concat(pad2(m), "m") : "".concat(pad2(h), ":").concat(pad2(m), ":").concat(pad2(s));
}
function fmtMoney(v, cur) {
  var n = (Math.round((v || 0) * 100) / 100).toFixed(2).replace('.', ',');
  return "".concat(cur || 'R$', " ").concat(n.replace(/\B(?=(\d{3})+(?!\d))/g, '.'));
}
function debounce(fn, ms) {
  var t;
  return function () {
    var a = arguments;
    clearTimeout(t);
    t = setTimeout(function () {
      return fn.apply(null, a);
    }, ms);
  };
}
function dayKey(ts) {
  var d = new Date(ts);
  return "".concat(d.getFullYear(), "-").concat(pad2(d.getMonth() + 1), "-").concat(pad2(d.getDate()));
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
var FE = {
  inCEP: !!window.__adobe_cep__,
  hostReady: false,
  hostVersion: '',
  sysPath: function sysPath(type) {
    if (!this.inCEP) return '';
    var p = window.__adobe_cep__.getSystemPath(type) || '';
    p = decodeURIComponent(p.replace(/^file:\/\//, ''));
    if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return p;
  },
  get isWin() {
    return navigator.platform.indexOf('Win') >= 0;
  },
  evalScript: function evalScript(script) {
    var _this = this;
    return new Promise(function (resolve) {
      if (!_this.inCEP) {
        resolve('EvalScript error.');
        return;
      }
      window.__adobe_cep__.evalScript(script, function (r) {
        return resolve(r);
      });
    });
  },
  ensureHost: function ensureHost() {
    var _this2 = this;
    if (!this.inCEP) {
      this.hostReady = true;
      return Promise.resolve(true);
    }
    return this.evalScript('typeof $._FE === "object" ? $._FE.version : "no"').then(function (r) {
      if (r && r !== 'no' && r.indexOf('rror') < 0 && r === APP_VERSION) {
        _this2.hostReady = true;
        _this2.hostVersion = r;
        return true;
      }
      var file = (_this2.sysPath('extension') + '/host/fastedit.jsx').replace(/\\/g, '/');
      return _this2.evalScript("try{$.evalFile(".concat(JSON.stringify(file), ");\"ok\"}catch(e){\"ERR:\"+e.message+\" @\"+e.line}")).then(function (r2) {
        if (r2 === 'ok' || r2 && r2.indexOf('ready') >= 0) {
          _this2.hostReady = true;
          return true;
        }
        _this2.hostReady = false;
        _this2.lastHostError = r2;
        return false;
      });
    });
  },
  call: function call(name, args) {
    var _this3 = this;
    if (!this.inCEP) return MOCK.call(name, args || {});
    var payload = JSON.stringify(JSON.stringify(args || {}));
    return this.ensureHost().then(function (ok) {
      if (!ok) throw new Error('Não foi possível carregar o script do Fast Edit no Premiere. ' + (_this3.lastHostError || ''));
      return _this3.evalScript("$._FE.run(".concat(JSON.stringify(name), ", ").concat(payload, ")"));
    }).then(function (raw) {
      var r;
      try {
        r = JSON.parse(raw);
      } catch (e) {
        throw new Error('Resposta inválida do Premiere: ' + String(raw).slice(0, 120));
      }
      if (!r.ok) throw new Error(r.error || 'Erro desconhecido');
      return r.data;
    });
  },
  openURL: function openURL(url) {
    if (this.inCEP) window.__adobe_cep__.invokeSync('openURLInDefaultBrowser', url);else window.open(url);
  },
  reload: function reload() {
    location.reload();
  }
};
var FS = {
  ok: !!(window.cep && window.cep.fs),
  read: function read(path) {
    if (!this.ok) return null;
    var r = window.cep.fs.readFile(path);
    return r.err === 0 ? r.data : null;
  },
  write: function write(path, data, base64) {
    if (!this.ok) return false;
    this.mkdirp(path.replace(/[\\/][^\\/]*$/, ''));
    var r = base64 ? window.cep.fs.writeFile(path, data, window.cep.encoding.Base64) : window.cep.fs.writeFile(path, data);
    return r.err === 0;
  },
  exists: function exists(path) {
    if (!this.ok) return false;
    return window.cep.fs.stat(path).err === 0;
  },
  mkdirp: function mkdirp(dir) {
    if (!this.ok || !dir || this.exists(dir)) return;
    this.mkdirp(dir.replace(/[\\/][^\\/]*$/, ''));
    window.cep.fs.makedir(dir);
  },
  list: function list(dir) {
    if (!this.ok) return [];
    var r = window.cep.fs.readdir(dir);
    return r.err === 0 ? r.data : [];
  },
  isDir: function isDir(path) {
    if (!this.ok) return false;
    var r = window.cep.fs.stat(path);
    return r.err === 0 && r.data.isDirectory();
  },
  remove: function remove(path) {
    if (this.ok) window.cep.fs.deleteFile(path);
  },
  pickFolder: function pickFolder(title) {
    if (!this.ok) return null;
    var r = window.cep.fs.showOpenDialog(false, true, title || 'Escolher pasta', '');
    return r.err === 0 && r.data && r.data.length ? r.data[0] : null;
  },
  pickFile: function pickFile(title, types) {
    if (!this.ok) return null;
    var r = window.cep.fs.showOpenDialog(false, false, title || 'Escolher arquivo', '', types || []);
    return r.err === 0 && r.data && r.data.length ? r.data[0] : null;
  },
  saveDialog: function saveDialog(title, name, types) {
    if (!this.ok) return null;
    var r;
    if (window.cep.fs.showSaveDialogEx) r = window.cep.fs.showSaveDialogEx(title, '', types || [], name);
    return r && r.err === 0 && r.data ? r.data : null;
  },
  fileURL: function fileURL(p) {
    p = String(p).replace(/\\/g, '/');
    var parts = p.split('/').map(function (seg, i) {
      return i === 0 && /^[A-Za-z]:$/.test(seg) ? seg : encodeURIComponent(seg);
    });
    return 'file://' + (p[0] === '/' ? '' : '/') + parts.join('/');
  }
};
var DEFAULTS = {
  settings: {
    frames: 12,
    intensity: 1,
    ease: true,
    replace: true,
    where: 'in',
    transFrames: 8,
    transIntensity: 1,
    transWhoosh: false,
    nativeFrames: 15,
    nativeWhere: 'both',
    capPreset: 'pop',
    capOut: 'none',
    capIn: 6,
    capOutFrames: 4,
    capTrack: false,
    hourlyRate: 80,
    currency: 'R$',
    margin: 0,
    autoTimer: true,
    idleMinutes: 5,
    sfxFolders: [],
    sfxWhoosh: '',
    sfxTrack: 3,
    sfxOffset: 0,
    sfxMode: 'playhead',
    sfxGain: 0,
    sfxVolume: 0.8,
    adjNodeId: '',
    overlayMode: 'selection',
    overlayType: 'adjustment',
    overlaySeconds: 5,
    matteColor: '#000000',
    matteAlpha: 100,
    orgBins: {
      seq: '01 Sequências',
      video: '02 Vídeo',
      audio: '03 Áudio',
      image: '04 Imagens',
      graphic: '05 Gráficos',
      other: '06 Outros'
    },
    orgNested: false,
    customTemplates: [],
    theme: 'neon',
    autoUpdate: true,
    updateUrl: '',
    shelfMode: 'carousel',
    stackFrames: 3,
    stackEffect: '',
    stackTips: true,
    clipSeconds: 3,
    clipFit: true,
    clipDir: '',
    frameSave: false,
    frameDir: '',
    tbLook: 'respiro',
    tbLevel: 'media',
    tbStreak: 1,
    tbPulse: 0.8,
    tbMix: 0.5,
    tbLight: true,
    tbGlow: true,
    tbFav: [],
    beatPreset: 'punch',
    beatFrames: 6,
    beatIntensity: 1,
    beatSfx: false,
    flashFrames: 4,
    gridCols: 5,
    gridRows: 5,
    gridPattern: 'random',
    gridFrames: 18,
    gridLines: true,
    gridThick: 3,
    gridLineColor: '#141414',
    gridFlash: true,
    gridFlashColor: '#8cdc28',
    gridFlashI: 100,
    gridFlashF: 6,
    mcFrames: 4,
    mcRhythm: 'const',
    mcAlign: 'center',
    mcLoops: 1,
    mcZoom: 25,
    prStyle: 'h',
    prFrames: 16,
    prIntensity: 1,
    prFlash: true,
    rampPreset: 'whip',
    rampMax: 300,
    rampMin: 30,
    rampStep: 2,
    rampPts: null,
    rampHard: false,
    zmScope: 'sel',
    zmPattern: 'all',
    zmEvery: 3,
    zmOffset: false,
    zmZooms: [10, 30, 50],
    zmOrder: 'cycle',
    zmMotion: 'in',
    zmDurMode: 'take',
    zmFrames: 12,
    zmOutEnd: false,
    zmEase: 'smooth',
    zmDrift: 'none',
    zmDriftAmt: 4,
    zmBlur: false,
    zmColor: true,
    zmLabelIn: -1,
    zmLabelOut: -1,
    glLook: 'cone',
    glX: 0.5,
    glY: 0.42,
    glSize: 0.75,
    glFstop: 8,
    glTiltX: 0,
    glTiltY: 0,
    glStr: 1,
    glChroma: 0.35,
    glSoft: 0,
    glLight: 0.15,
    glAnim: 'none'
  },
  onboarded: false,
  favorites: ['motion', 'transitions', 'stack', 'sfx'],
  effectFavs: [],
  transFavs: [],
  stacks: [],
  sfxFavs: [],
  usage: {},
  history: [],
  time: {
    running: null,
    sessions: [],
    projects: {}
  }
};
var Store = {
  data: null,
  path: '',
  init: function init() {
    var base = FE.sysPath('userData');
    this.path = base ? base.replace(/\\/g, '/') + '/FastEdit/fastedit-data.json' : '';
    var raw = this.path ? FS.read(this.path) : null;
    if (!raw) {
      try {
        raw = localStorage.getItem('fastedit-data');
      } catch (e) {
        raw = null;
      }
    }
    var d = {};
    try {
      d = raw ? JSON.parse(raw) : {};
    } catch (e) {
      d = {};
    }
    this.data = this.merge(JSON.parse(JSON.stringify(DEFAULTS)), d);
    if (!this.data.neonDefault) {
      this.data.neonDefault = true;
      this.data.settings.theme = 'neon';
    }
    if (!this.data.zoomAnimDefault) {
      this.data.zoomAnimDefault = true;
      if (this.data.settings.zmMotion === 'static') this.data.settings.zmMotion = 'in';
    }
  },
  merge: function merge(def, d) {
    var _this4 = this;
    Object.keys(d || {}).forEach(function (k) {
      if (def[k] && _typeof(def[k]) === 'object' && !Array.isArray(def[k]) && d[k] && _typeof(d[k]) === 'object' && !Array.isArray(d[k])) {
        def[k] = _this4.merge(def[k], d[k]);
      } else def[k] = d[k];
    });
    return def;
  },
  get dataDir() {
    return this.path ? this.path.replace(/\/[^/]*$/, '') : '';
  },
  save: null,
  saveNow: function saveNow() {
    var raw = JSON.stringify(this.data);
    if (this.path) FS.write(this.path, raw);
    try {
      localStorage.setItem('fastedit-data', raw);
    } catch (e) {}
  },
  get s() {
    return this.data.settings;
  },
  set: function set(key, val) {
    this.data.settings[key] = val;
    this.save();
  }
};
Store.save = debounce(function () {
  return Store.saveNow();
}, 400);
var ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
  animate: '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
  workflow: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  sfx: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  time: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
  chev: '<path d="m9 6 6 6-6 6"/>',
  play: '<path d="M7 4v16l13-8z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  insert: '<path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  folder: '<path d="M3 6a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.8-3.5L3 10"/><path d="M3 4v6h6"/><path d="M4 13a8 8 0 0 0 14.8 3.5L21 14"/><path d="M21 20v-6h-6"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
  motion: '<path d="M4 17c4 0 4-10 8-10s4 10 8 10"/><circle cx="4" cy="17" r="1.5"/><circle cx="20" cy="17" r="1.5"/>',
  transition: '<rect x="3" y="6" width="8" height="12" rx="1.5"/><rect x="13" y="6" width="8" height="12" rx="1.5"/><path d="m9 12 6 0M13 10l2 2-2 2"/>',
  caption: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 14h4M13 14h4M7 10h10"/>',
  fx: '<path d="M5 20 19 6"/><path d="m15 4 1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/><path d="m6 5 .7 1.3L8 7l-1.3.7L6 9l-.7-1.3L4 7l1.3-.7z"/>',
  bins: '<path d="M3 7a1 1 0 0 1 1-1h5l2 2h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M8 13h8"/>',
  organize: '<path d="M4 6h16M4 12h10M4 18h6"/><path d="m17 15 3 3-3 3"/>',
  sort: '<path d="M7 4v16M3 16l4 4 4-4"/><path d="M14 6h7M14 11h5M14 16h3"/>',
  batch: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  clean: '<path d="M3 21h18"/><path d="m14 4 6 6-8 8H6v-6z"/>',
  social: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  upload: '<path d="M12 20V8M7 13l5-5 5 5M4 4h16"/>',
  wand: '<path d="m4 20 11-11"/><path d="m14 4 1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',
  money: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  prism: '<path d="M12 3 3 20h18z"/><path d="M12 3v17M7.5 11.5 21 20"/>',
  glass: '<circle cx="9" cy="10" r="6"/><path d="M14 4h6v16h-6"/><path d="M6.5 8.5a3 3 0 0 1 3-1.5"/>',
  zoom: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/><path d="M11 8v6M8 11h6"/>',
  ramp: '<path d="M3 18c4 0 5-12 9-12s5 12 9 12"/><path d="M3 21h18"/>',
  match: '<rect x="2" y="5" width="13" height="10" rx="2"/><rect x="9" y="9" width="13" height="10" rx="2"/><circle cx="12" cy="12" r="1.6"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  paste: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="M9 11h6M9 15h4"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  adjust: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/>',
  blur: '<path d="M4 12h3M4 8h5M4 16h5" opacity=".5"/><circle cx="15" cy="12" r="5"/><path d="M10 12h0"/>',
  flag: '<path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/>',
  crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
  power: '<path d="M12 3v9"/><path d="M6.3 7.5a8 8 0 1 0 11.4 0"/>',
  curve: '<path d="M4 19C11 19 12 5 20 5"/><circle cx="4" cy="19" r="1.6"/><circle cx="20" cy="5" r="1.6"/><path d="M4 19h5M20 5h-5" stroke-dasharray="1.5 2"/>'
};
var icon = function icon(n, cls) {
  return "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"i ".concat(cls || '', "\">").concat(ICONS[n] || '', "</svg>");
};
var UI = {
  toast: function toast(msg, type) {
    var box = $('#toasts');
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'ok');
    el.innerHTML = icon(type === 'err' ? 'x' : type === 'info' ? 'info' : 'check') + '<span>' + esc(msg) + '</span>';
    box.appendChild(el);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () {
        return el.remove();
      }, 300);
    }, type === 'err' ? 6500 : 3200);
  },
  confirm: function confirm(title, text, okLabel) {
    return new Promise(function (resolve) {
      var bg = document.createElement('div');
      bg.className = 'modal-bg';
      bg.innerHTML = "<div class=\"modal\"><h4>".concat(esc(title), "</h4><p>").concat(esc(text), "</p><div class=\"btns\"><button class=\"btn ghost\" data-r=\"0\">Cancelar</button><button class=\"btn primary\" data-r=\"1\">").concat(esc(okLabel || 'Confirmar'), "</button></div></div>");
      document.body.appendChild(bg);
      bg.addEventListener('click', function (e) {
        var b = e.target.closest('[data-r]');
        if (!b && e.target !== bg) return;
        bg.remove();
        resolve(b ? b.getAttribute('data-r') === '1' : false);
      });
    });
  },
  prompt: function prompt(title, value, okLabel) {
    return new Promise(function (resolve) {
      var bg = document.createElement('div');
      bg.className = 'modal-bg';
      bg.innerHTML = "<div class=\"modal\"><h4>".concat(esc(title), "</h4><input class=\"input\" style=\"width:100%;margin:6px 0 14px\" value=\"").concat(esc(value || ''), "\"><div class=\"btns\"><button class=\"btn ghost\" data-r=\"0\">Cancelar</button><button class=\"btn primary\" data-r=\"1\">").concat(esc(okLabel || 'OK'), "</button></div></div>");
      document.body.appendChild(bg);
      var inp = $('input', bg);
      inp.focus();
      inp.select();
      var done = function done(ok) {
        var v = inp.value.trim();
        bg.remove();
        resolve(ok && v ? v : null);
      };
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') done(true);
        if (e.key === 'Escape') done(false);
      });
      bg.addEventListener('click', function (e) {
        var b = e.target.closest('[data-r]');
        if (b) done(b.getAttribute('data-r') === '1');else if (e.target === bg) done(false);
      });
    });
  },
  run: function run(btn, label, name, args, okMsg) {
    if (btn) btn.classList.add('busy');
    return FE.call(name, args).then(function (data) {
      var msg = typeof okMsg === 'function' ? okMsg(data) : okMsg || 'Feito';
      if (msg) UI.toast(msg, 'ok');
      App.log(true, "".concat(label, ": ").concat(msg || 'ok'));
      return data;
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, "".concat(label, ": ").concat(e.message));
      e._shown = true;
      throw e;
    }).then(function (d) {
      if (btn) btn.classList.remove('busy');
      return d;
    }, function (e) {
      if (btn) btn.classList.remove('busy');
      return Promise.reject(e);
    });
  },
  seg: function seg(name, options, value) {
    return "<div class=\"seg\" data-seg=\"".concat(name, "\">").concat(options.map(function (o) {
      return "<button data-v=\"".concat(esc(o[0]), "\" class=\"").concat(String(o[0]) === String(value) ? 'on' : '', "\">").concat(esc(o[1]), "</button>");
    }).join(''), "</div>");
  },
  range: function range(name, min, max, step, value, suffix) {
    return "<div class=\"range\"><input type=\"range\" data-range=\"".concat(name, "\" min=\"").concat(min, "\" max=\"").concat(max, "\" step=\"").concat(step, "\" value=\"").concat(value, "\"><output data-out=\"").concat(name, "\">").concat(value).concat(suffix || '', "</output></div>");
  },
  toggle: function toggle(name, label, checked) {
    return "<label class=\"toggle\"><input type=\"checkbox\" data-toggle=\"".concat(name, "\"").concat(checked ? ' checked' : '', "><i></i>").concat(esc(label), "</label>");
  },
  select: function select(name, options, value, cls) {
    return "<select class=\"select ".concat(cls || '', "\" data-select=\"").concat(name, "\">").concat(options.map(function (o) {
      return "<option value=\"".concat(esc(o[0]), "\"").concat(String(o[0]) === String(value) ? ' selected' : '', ">").concat(esc(o[1]), "</option>");
    }).join(''), "</select>");
  },
  bindSettings: function bindSettings(root, onChange) {
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-seg] button');
      if (!b) return;
      var seg = b.parentNode;
      $$('button', seg).forEach(function (x) {
        return x.classList.toggle('on', x === b);
      });
      var key = seg.getAttribute('data-seg');
      var v = b.getAttribute('data-v');
      if (/^-?\d+(\.\d+)?$/.test(v)) v = parseFloat(v);
      if (key.indexOf('_') !== 0) Store.set(key, v);
      if (onChange) onChange(key, v);
    });
    root.addEventListener('input', function (e) {
      var r = e.target.getAttribute('data-range');
      if (r) {
        var v = parseFloat(e.target.value);
        var out = $("[data-out=\"".concat(r, "\"]"), root);
        if (out) out.textContent = out.textContent.replace(/^[\d.,-]+/, String(v));
        if (r.indexOf('_') !== 0) Store.set(r, v);
        if (onChange) onChange(r, v);
      }
    });
    root.addEventListener('change', function (e) {
      var t = e.target.getAttribute('data-toggle');
      if (t) {
        if (t.indexOf('_') !== 0) Store.set(t, e.target.checked);
        if (onChange) onChange(t, e.target.checked);
      }
      var s = e.target.getAttribute('data-select');
      if (s) {
        var v = e.target.value;
        if (/^-?\d+(\.\d+)?$/.test(v)) v = parseFloat(v);
        if (s.indexOf('_') !== 0) Store.set(s, v);
        if (onChange) onChange(s, v);
      }
    });
  }
};
var Sized = {
  dims: function dims() {
    var s = App.info && App.info.seq;
    return s && s.w && s.h ? [s.w, s.h] : null;
  },
  tag: function tag() {
    var d = this.dims();
    return d ? " (".concat(d[0], "x").concat(d[1], ")") : '';
  },
  uuid: function uuid() {
    var h = function h() {
      return Math.floor(Math.random() * 65536).toString(16).padStart(4, '0');
    };
    return "".concat(h()).concat(h(), "-").concat(h(), "-4").concat(h().slice(1), "-").concat((8 + Math.floor(Math.random() * 4)).toString(16)).concat(h().slice(1), "-").concat(h()).concat(h()).concat(h());
  },
  make: function make(src, names) {
    var _this5 = this;
    var d = this.dims(),
      fs = NodeX.req('fs'),
      zlib = NodeX.req('zlib');
    if (!src || !d || !fs || !zlib) return {
      tpl: src,
      tag: ''
    };
    try {
      var raw = fs.readFileSync(src);
      var xml = (raw[0] === 0x1f && raw[1] === 0x8b ? zlib.gunzipSync(raw) : raw).toString('utf8');
      var m = xml.match(/<FrameRect>0,0,(\d+),(\d+)<\/FrameRect>/);
      if (!m || +m[1] === d[0] && +m[2] === d[1]) return {
        tpl: src,
        tag: ''
      };
      var tag = " (".concat(d[0], "x").concat(d[1], ")"),
        base = src.replace(/\\/g, '/').split('/').pop();
      var out = "".concat(Gen.dir(), "/sized/").concat(d[0], "x").concat(d[1], "/").concat(base);
      if (!FS.exists(out)) {
        xml = xml.replace(/<FrameRect>0,0,\d+,\d+<\/FrameRect>/g, "<FrameRect>0,0,".concat(d[0], ",").concat(d[1], "</FrameRect>"));
        (names || []).forEach(function (nm) {
          var e = nm.replace(/&/g, '&amp;').replace(/</g, '&lt;');
          xml = xml.split("<Name>".concat(e, "</Name>")).join("<Name>".concat(e).concat(tag, "</Name>")).split("<ClipName>".concat(e, "</ClipName>")).join("<ClipName>".concat(e).concat(tag, "</ClipName>"));
        });
        var keep = {};
        (xml.match(/ClassID="[^"]+"/g) || []).forEach(function (x) {
          keep[x.slice(9, -1)] = 1;
        });
        var map = {};
        xml = xml.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g, function (u) {
          return keep[u] ? u : map[u] || (map[u] = _this5.uuid());
        });
        var fp = String(1e9 + Math.floor(Math.random() * 8e9));
        xml = xml.replace(/<FilePath>\d+<\/FilePath>/g, "<FilePath>".concat(fp, "</FilePath>")).replace(/<ActualMediaFilePath>\d+<\/ActualMediaFilePath>/g, "<ActualMediaFilePath>".concat(fp, "</ActualMediaFilePath>"));
        FS.mkdirp(out.replace(/\/[^/]*$/, ''));
        var B = (NodeX.req('buffer') || {}).Buffer || window.Buffer;
        fs.writeFileSync(out, zlib.gzipSync(B.from(xml, 'utf8')));
      }
      return {
        tpl: out,
        tag: tag
      };
    } catch (e) {
      console.warn('Sized', e);
      return {
        tpl: src,
        tag: ''
      };
    }
  }
};
var Gen = {
  dir: function dir() {
    return (Store.dataDir || '') + '/generated';
  },
  savePNG: function savePNG(canvas, name) {
    var path = this.dir() + '/' + name;
    if (FS.exists(path)) return path;
    var b64 = canvas.toDataURL('image/png').split(',')[1];
    if (!FS.write(path, b64, true)) throw new Error('Não foi possível salvar a imagem gerada.');
    return path;
  },
  canvas: function canvas(w, h) {
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  },
  matte: function matte(w, h, color, alpha) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    g.globalAlpha = alpha / 100;
    g.fillStyle = color;
    g.fillRect(0, 0, w, h);
    return this.savePNG(c, "FE_Matte_".concat(color.replace('#', ''), "_").concat(alpha, "_").concat(w, "x").concat(h, ".png"));
  },
  letterbox: function letterbox(w, h, ratio) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    g.fillStyle = '#000';
    var frame = w / h;
    if (ratio > frame) {
      var ih = Math.round(w / ratio),
        bar = Math.round((h - ih) / 2);
      g.fillRect(0, 0, w, bar);
      g.fillRect(0, h - bar, w, bar);
    } else {
      var iw = Math.round(h * ratio),
        _bar = Math.round((w - iw) / 2);
      g.fillRect(0, 0, _bar, h);
      g.fillRect(w - _bar, 0, _bar, h);
    }
    return this.savePNG(c, "FE_Letterbox_".concat(String(ratio).replace('.', '_'), "_").concat(w, "x").concat(h, ".png"));
  },
  guideCanvas: function guideCanvas(w, h, platform, opts) {
    var c = this.canvas(w, h),
      g = c.getContext('2d');
    if (platform === 'generic') this.grid(g, w, h);else GuideArt.draw(g, w, h, platform, opts || {});
    return c;
  },
  guide: function guide(w, h, platform, opts) {
    opts = opts || {};
    var c = this.guideCanvas(w, h, platform, opts);
    return this.savePNG(c, "FE_Guide_".concat(platform, "_").concat(opts.zones ? 'z' : '').concat(opts.crop ? 'c' : '', "_v5_").concat(w, "x").concat(h, ".png"));
  },
  grid: function grid(g, w, h) {
    var lw = Math.max(2, Math.round(Math.min(w, h) / 360));
    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = lw;
    for (var i = 1; i < 3; i++) {
      g.beginPath();
      g.moveTo(w * i / 3, 0);
      g.lineTo(w * i / 3, h);
      g.stroke();
      g.beginPath();
      g.moveTo(0, h * i / 3);
      g.lineTo(w, h * i / 3);
      g.stroke();
    }
    g.strokeStyle = 'rgba(35,64,200,0.9)';
    g.setLineDash([lw * 4, lw * 3]);
    g.strokeRect(w * 0.05, h * 0.05, w * 0.9, h * 0.9);
    g.setLineDash([]);
    g.beginPath();
    g.moveTo(w / 2 - 20 * lw, h / 2);
    g.lineTo(w / 2 + 20 * lw, h / 2);
    g.moveTo(w / 2, h / 2 - 20 * lw);
    g.lineTo(w / 2, h / 2 + 20 * lw);
    g.stroke();
  }
};
var MOCK = {
  call: function call(name, a) {
    var d = {
      info: {
        version: '25.6',
        project: 'Projeto Demo.prproj',
        projectPath: 'C:/Projetos/Projeto Demo.prproj',
        seq: {
          name: 'Sequência 01',
          w: 1920,
          h: 1080,
          fps: 29.97,
          duration: 184.5,
          playhead: 42.1,
          vTracks: 4,
          aTracks: 4,
          clips: 57,
          selected: 3
        }
      },
      listEffects: {
        video: ['Lumetri Color', 'Gaussian Blur', 'Transform', 'Crop', 'Warp Stabilizer', 'Ultra Key', 'Sharpen', 'Noise', 'Mirror', 'Directional Blur', 'Basic 3D', 'Drop Shadow'],
        audio: ['DeNoise', 'Parametric Equalizer', 'Hard Limiter', 'Reverb']
      },
      _x: 0,
      listTransitions: {
        video: ['Cross Dissolve', 'Dip to Black', 'Dip to White', 'Film Dissolve', 'Push', 'Slide', 'Iris Round', 'Morph Cut'],
        audio: ['Constant Power', 'Constant Gain']
      },
      findAdjustment: null,
      organize: {
        plan: {
          video: {
            bin: '02 Vídeo',
            count: 34,
            samples: ['A001_C003.mov', 'DJI_0042.mp4']
          },
          audio: {
            bin: '03 Áudio',
            count: 8,
            samples: ['trilha.wav']
          },
          image: {
            bin: '04 Imagens',
            count: 5,
            samples: ['logo.png']
          }
        },
        total: 47,
        applied: !!a.apply
      },
      markerTimes: [2, 5.5, 9]
    }[name];
    return new Promise(function (res, rej) {
      return setTimeout(function () {
        if (name === 'motion' || name === 'captions') res({
          clips: 3,
          keys: 12
        });else if (name === 'guidesState' || name === 'toggleGuides') res({
          count: 1,
          visible: name === 'toggleGuides' ? !!a.visible : true
        });else if (name === 'gridTransition') res({
          cuts: 1,
          clipped: 0
        });else if (name === 'matchRead') res({
          takes: null,
          w: 1920,
          h: 1080,
          fps: 25,
          at: 0,
          markers: []
        });else if (name === 'matchCut') res({
          placed: 10,
          track: 2,
          tooShort: 0
        });else if (name === 'beatFx') res({
          markers: 8,
          done: 8,
          skipped: 0,
          times: [1, 2, 3]
        });else if (name === 'timeBlur') res({
          clips: 3,
          keys: 270
        });else if (name === 'applyCurve') res({
          clips: 3,
          params: 4,
          segments: 6,
          keys: 84
        });else if (d !== undefined) res(d);else res({
          placed: 1,
          done: 3,
          clips: 3,
          added: 2,
          applied: 2,
          missing: [],
          removed: 0,
          gaps: 2,
          seconds: 3.4,
          sorted: 4,
          created: 6,
          skipped: 0,
          cuts: [1, 2],
          name: 'Seq 9:16',
          method: 'clone'
        });
      }, 250);
    });
  }
};
var ART = {
  mascot: "\n  <g class=\"ink\">\n    <!-- pernas -->\n    <path d=\"M86 150 C84 162 80 172 74 182\"/>\n    <path d=\"M74 182 C70 184 62 185 58 183\"/>\n    <path d=\"M116 150 C120 160 126 170 134 178\"/>\n    <path d=\"M134 178 C138 181 146 181 150 178\"/>\n    <!-- corpo (claquete) -->\n    <path d=\"M58 82 C57 104 58 128 60 150 C86 152 116 152 142 150 C144 128 145 104 143 82 C114 80 86 80 58 82 Z\" class=\"fill\"/>\n    <!-- tampa aberta -->\n    <path d=\"M58 80 L66 52 C92 50 118 52 146 56 L143 80\" class=\"fill\"/>\n    <path d=\"M66 66 L76 51 M84 66 L94 51 M102 66 L112 52 M120 67 L130 53 M137 68 L145 57\" stroke-width=\"6\"/>\n    <path d=\"M62 66 C88 64 116 66 145 69\" />\n    <!-- \xF3culos -->\n    <path d=\"M72 100 C72 94 92 94 93 100 C94 110 74 112 72 100 Z\" class=\"solid\"/>\n    <path d=\"M106 100 C106 94 127 94 128 100 C128 111 107 112 106 100 Z\" class=\"solid\"/>\n    <path d=\"M93 99 C97 97 102 97 106 99\"/>\n    <path d=\"M72 99 L64 96 M128 99 L136 95\"/>\n    <!-- sorriso -->\n    <path d=\"M88 124 C96 132 108 132 116 123\"/>\n    <!-- bra\xE7o esquerdo acenando -->\n    <path d=\"M58 112 C46 108 38 98 34 86\"/>\n    <path d=\"M34 86 C30 82 31 76 35 74 M34 86 C29 85 26 81 28 77\"/>\n    <!-- bra\xE7o direito com caf\xE9 -->\n    <path d=\"M143 114 C154 112 162 104 164 94\"/>\n    <path d=\"M154 70 L176 70 L172 98 L158 98 Z\" class=\"fill\"/>\n    <path d=\"M152 70 C152 64 178 64 178 70\"/>\n    <path d=\"M160 64 C162 60 168 60 170 64\"/>\n    <path d=\"M157 82 L174 82\"/>\n    <path d=\"M164 56 C161 52 167 49 164 44 M171 56 C168 52 174 49 171 44\"/>\n  </g>",
  timeline: "\n  <g class=\"ink\">\n    <rect x=\"20\" y=\"40\" width=\"160\" height=\"96\" rx=\"10\" class=\"fill\"/>\n    <path d=\"M20 62 L180 62\"/>\n    <rect x=\"34\" y=\"74\" width=\"46\" height=\"18\" rx=\"4\" class=\"solid\"/>\n    <rect x=\"84\" y=\"74\" width=\"38\" height=\"18\" rx=\"4\"/>\n    <rect x=\"126\" y=\"74\" width=\"40\" height=\"18\" rx=\"4\" class=\"solid\"/>\n    <rect x=\"50\" y=\"100\" width=\"62\" height=\"14\" rx=\"4\"/>\n    <rect x=\"116\" y=\"100\" width=\"34\" height=\"14\" rx=\"4\"/>\n    <path d=\"M102 50 L102 128\"/>\n    <path d=\"M96 46 L108 46 L102 54 Z\" class=\"solid\"/>\n    <!-- cursor -->\n    <path d=\"M140 118 L140 150 L148 142 L156 158 L162 155 L154 140 L166 140 Z\" class=\"fill\"/>\n  </g>",
  magic: "\n  <g class=\"ink\">\n    <path d=\"M40 160 L130 70\"/>\n    <path d=\"M124 64 L136 76\" stroke-width=\"7\"/>\n    <path d=\"M140 30 L146 46 L162 52 L146 58 L140 74 L134 58 L118 52 L134 46 Z\" class=\"fill\"/>\n    <path d=\"M70 46 L73 54 L81 57 L73 60 L70 68 L67 60 L59 57 L67 54 Z\" class=\"solid\"/>\n    <path d=\"M160 104 L163 110 L169 113 L163 116 L160 122 L157 116 L151 113 L157 110 Z\" class=\"solid\"/>\n  </g>",
  clock: "\n  <g class=\"ink\">\n    <circle cx=\"100\" cy=\"104\" r=\"56\" class=\"fill\"/>\n    <path d=\"M100 66 L100 104 L126 120\"/>\n    <path d=\"M86 40 L114 40 M100 40 L100 48\"/>\n    <path d=\"M150 60 L160 50\"/>\n    <path d=\"M100 56 L100 62 M148 104 L142 104 M100 152 L100 146 M52 104 L58 104\"/>\n    <path d=\"M40 168 C70 160 130 160 160 168\"/>\n  </g>",
  waves: "\n  <g class=\"ink\">\n    <path d=\"M30 100 C40 70 50 70 60 100 C70 130 80 130 90 100 C100 70 110 70 120 100 C130 130 140 130 150 100 C160 70 170 70 176 90\"/>\n    <path d=\"M70 160 L70 60 L140 46 L140 146\"/>\n    <ellipse cx=\"58\" cy=\"160\" rx=\"14\" ry=\"10\" class=\"solid\"/>\n    <ellipse cx=\"128\" cy=\"146\" rx=\"14\" ry=\"10\" class=\"solid\"/>\n  </g>"
};
var SKETCH_FILTER = "<svg width=\"0\" height=\"0\" style=\"position:absolute\"><defs>\n  <filter id=\"sketch\" x=\"-5%\" y=\"-5%\" width=\"110%\" height=\"110%\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.035\" numOctaves=\"2\" seed=\"3\"/><feDisplacementMap in=\"SourceGraphic\" scale=\"2.2\"/></filter>\n</defs></svg>";
function art(name, cls) {
  return "<svg viewBox=\"0 0 200 200\" class=\"art ".concat(cls || '', "\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\">").concat(ART[name], "</svg>");
}
var GUIDE_SPECS = {
  reels: {
    name: 'Instagram Reels',
    vh: 1460,
    vw: 821,
    off: 40,
    items: [['status'], ['plus', 48, 125, 36], ['text', 183, 138, 'Reels', 38, 700, 1], ['text', 318, 138, 'Amigos', 38, 700, 0.55], ['heart', 686, 833, 44], ['label', 686, 892, 'Curtidas'], ['comment', 686, 955, 42], ['label', 686, 1013, '69'], ['repost', 686, 1083, 42], ['label', 686, 1146, '85'], ['send', 686, 1210, 40], ['menu', 686, 1285, 36], ['thumb', 687, 1366, 50], ['avatar', 66, 1256, 32, true], ['text', 118, 1265, 'seuperfil', 25, 700, 1], ['pill', 297, 1236, 100, 40, 'Seguir', false], ['text', 28, 1336, 'Legenda do seu vídeo aparece aqui…', 23, 400, 1], ['text', 124, 1391, 'Seguido por amigo e outras 9 pessoas', 19, 400, 0.85], ['faces', 28, 1383], ['bar', 28, 1430, 684]],
    zones: [[630, 780, 110, 640], [0, 1215, 640, 230], [0, 0, 740, 170]]
  },
  shorts: {
    name: 'YouTube Shorts',
    vh: 1455,
    vw: 818,
    off: 39,
    items: [['status'], ['sparkle', 438, 122, 36], ['comment', 521, 122, 36], ['search', 604, 122, 36], ['dots', 687, 122, 34], ['heart', 684, 862, 44], ['label', 684, 909, '13 mil'], ['comment', 684, 965, 40], ['label', 684, 1013, '418'], ['bookmark', 684, 1070, 40], ['label', 684, 1116, 'Salvar'], ['share', 684, 1173, 40], ['label', 684, 1220, 'Compartilhar'], ['remix', 684, 1277, 40], ['label', 684, 1324, 'Remix'], ['thumb', 684, 1392, 52], ['avatar', 55, 1354, 27, false], ['text', 97, 1363, '@seucanal', 23, 700, 1], ['pill', 282, 1328, 168, 52, 'Inscrever-se', true], ['text', 28, 1420, 'Título do seu Short #hashtag', 23, 400, 1], ['bar', 0, 1450, 740]],
    zones: [[630, 820, 110, 620], [0, 1310, 630, 145], [380, 80, 360, 90]]
  },
  tiktok: {
    name: 'TikTok',
    vh: 1455,
    vw: 818,
    off: 39,
    items: [['status'], ['live', 48, 140, 40], ['text', 320, 152, 'Seguindo', 25, 600, 0.6], ['text', 455, 152, 'Loja', 25, 600, 0.6], ['text', 524, 152, 'Para você', 25, 700, 1], ['underline', 563, 172, 40], ['search', 690, 140, 38], ['avatar', 685, 810, 36, false], ['follow', 685, 850], ['heart', 685, 933, 46, true], ['label', 685, 983, '12,3 mil'], ['bubble', 685, 1045, 44], ['label', 685, 1095, '1.234'], ['bookmark', 685, 1160, 40, true], ['label', 685, 1209, '980'], ['share', 685, 1273, 42, true], ['label', 685, 1322, 'Compartilhar'], ['disc', 685, 1397, 32], ['text', 22, 1309, 'Seu Perfil', 27, 700, 1], ['text', 22, 1352, 'Legenda do vídeo aparece aqui e pode', 23, 400, 1], ['text', 22, 1387, 'ocupar até duas linhas… mais', 23, 400, 1], ['text', 22, 1434, '♫ som original - seuperfil', 21, 400, 1]],
    zones: [[630, 760, 110, 680], [0, 1270, 630, 185], [0, 90, 740, 100]]
  }
};
var GuideArt = {
  icon: function icon(g, kind, cx, cy, px, filled) {
    var s = px / 24;
    g.save();
    g.translate(cx - 12 * s, cy - 12 * s);
    g.scale(s, s);
    g.lineWidth = 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    g.strokeStyle = '#fff';
    g.fillStyle = '#fff';
    var P = function P(d, fill) {
      var p = new Path2D(d);
      if (fill) g.fill(p);
      g.stroke(p);
    };
    switch (kind) {
      case 'heart':
        P('M12 20.5s-8-4.9-8-11A4.5 4.5 0 0 1 12 6.6 4.5 4.5 0 0 1 20 9.5c0 6.1-8 11-8 11z', filled);
        break;
      case 'comment':
        P('M20 11.5a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.5z');
        break;
      case 'bubble':
        P('M12 4c4.9 0 8.5 3.1 8.5 7s-3.6 7-8.5 7c-.9 0-1.8-.1-2.6-.3L5 20l.9-3.7C4.4 15 3.5 13.1 3.5 11c0-3.9 3.6-7 8.5-7z', true);
        g.fillStyle = 'rgba(0,0,0,.55)';
        [8.5, 12, 15.5].forEach(function (x) {
          g.beginPath();
          g.arc(x, 11, 1.2, 0, 7);
          g.fill();
        });
        break;
      case 'repost':
        P('M7 7h11l-3-3M18 7v4M17 17H6l3 3M6 17v-4');
        break;
      case 'send':
        P('M21 3 3 10l7 3 3 7z');
        P('M10 13l11-10');
        break;
      case 'menu':
        P('M5 9h14M5 15h9');
        break;
      case 'plus':
        P('M12 4v16M4 12h16');
        break;
      case 'search':
        P('M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM16 16l5 5');
        break;
      case 'dots':
        [6, 12, 18].forEach(function (x) {
          g.beginPath();
          g.arc(x, 12, 1.6, 0, 7);
          g.fill();
        });
        break;
      case 'sparkle':
        P('M12 3c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7z', true);
        break;
      case 'bookmark':
        P('M6 3h12v18l-6-4.5L6 21z', filled);
        break;
      case 'share':
        if (filled) P('M13 5l8 7-8 7v-4c-5 0-8 1.5-10 5 .7-5.5 3.5-9.5 10-10.5z', true);else P('M14 5l7 7-7 7v-4c-5 0-8 1.5-10 4.5.8-5 3.8-8.8 10-9.5z');
        break;
      case 'remix':
        P('M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4M12 9v6M9 12h6');
        break;
      case 'live':
        P('M4 8h16v11H4zM9 4l3 3 3-3');
        g.font = '700 6.5px sans-serif';
        g.textAlign = 'center';
        g.fillText('LIVE', 12, 16);
        break;
      case 'home':
        P('M4 10.5 12 4l8 6.5V20h-5v-5h-6v5H4z');
        break;
      case 'reel':
        P('M5 5h14v14H5z');
        P('M10 9l5 3-5 3z', true);
        break;
      default:
        break;
    }
    g.restore();
  },
  draw: function draw(g, W, H, platform, opts) {
    var _this6 = this;
    var spec = GUIDE_SPECS[platform];
    var fw = W,
      fh = H;
    if (Math.abs(W / H - 9 / 16) > 0.01) {
      if (W / H > 9 / 16) fw = Math.round(H * 9 / 16);else fh = Math.round(W * 16 / 9);
    }
    var fx = Math.round((W - fw) / 2),
      fy = Math.round((H - fh) / 2);
    if (fx > 0 || fy > 0) {
      g.fillStyle = 'rgba(0,0,0,0.72)';
      if (fx > 0) {
        g.fillRect(0, 0, fx, H);
        g.fillRect(fx + fw, 0, W - fx - fw, H);
      }
      if (fy > 0) {
        g.fillRect(0, 0, W, fy);
        g.fillRect(0, fy + fh, W, H - fy - fh);
      }
    }
    var S = fh / spec.vh;
    var X = function X(x) {
      return fx + (x + spec.off) / spec.vw * fw;
    };
    var Y = function Y(y) {
      return fy + y / spec.vh * fh;
    };
    var font = function font(px, wt) {
      return "".concat(wt || 400, " ").concat(Math.round(px * S), "px \"DM Sans\", \"Segoe UI\", Arial, sans-serif");
    };
    if (opts.zones) {
      spec.zones.forEach(function (z) {
        g.fillStyle = 'rgba(255,59,48,0.20)';
        g.fillRect(X(z[0]), Y(z[1]), z[2] / spec.vw * fw, z[3] / spec.vh * fh);
        g.strokeStyle = 'rgba(255,59,48,0.75)';
        g.lineWidth = Math.max(2, 2 * S);
        g.setLineDash([8 * S, 6 * S]);
        g.strokeRect(X(z[0]), Y(z[1]), z[2] / spec.vw * fw, z[3] / spec.vh * fh);
        g.setLineDash([]);
      });
    }
    if (opts.crop) {
      g.strokeStyle = 'rgba(255,255,255,0.55)';
      g.lineWidth = Math.max(2, 2 * S);
      g.setLineDash([14 * S, 10 * S]);
      [X(0), X(740)].forEach(function (x) {
        g.beginPath();
        g.moveTo(x, fy);
        g.lineTo(x, fy + fh);
        g.stroke();
      });
      g.setLineDash([]);
    }
    g.save();
    g.shadowColor = 'rgba(0,0,0,0.45)';
    g.shadowBlur = 6 * S;
    g.shadowOffsetY = 1 * S;
    spec.items.forEach(function (it) {
      var k = it[0];
      if (k === 'status') {
        g.fillStyle = '#fff';
        g.font = font(30, 600);
        g.textAlign = 'left';
        g.fillText('9:41', X(80), Y(56));
        var bx = X(628),
          by = Y(34);
        g.strokeStyle = '#fff';
        g.lineWidth = 2 * S;
        g.strokeRect(bx, by, 50 * S, 22 * S);
        g.fillRect(bx + 3 * S, by + 3 * S, 36 * S, 16 * S);
        for (var i = 0; i < 4; i++) g.fillRect(X(560) + i * 9 * S, Y(56) - (6 + i * 4) * S, 6 * S, (6 + i * 4) * S);
      } else if (k === 'text') {
        g.globalAlpha = it[6];
        g.fillStyle = '#fff';
        g.font = font(it[4], it[5]);
        g.textAlign = 'left';
        g.fillText(it[3], X(it[1]), Y(it[2]));
        g.globalAlpha = 1;
      } else if (k === 'label') {
        g.fillStyle = '#fff';
        g.font = font(20, 600);
        g.textAlign = 'center';
        g.fillText(it[3], X(it[1]), Y(it[2]));
      } else if (k === 'avatar') {
        var r = it[3] * S,
          cx = X(it[1]),
          cy = Y(it[2]);
        if (it[4]) {
          var gr = g.createLinearGradient(cx - r, cy + r, cx + r, cy - r);
          gr.addColorStop(0, '#f9ce34');
          gr.addColorStop(0.5, '#ee2a7b');
          gr.addColorStop(1, '#6228d7');
          g.strokeStyle = gr;
          g.lineWidth = 4 * S;
          g.beginPath();
          g.arc(cx, cy, r + 4 * S, 0, 7);
          g.stroke();
        }
        g.fillStyle = '#9aa3b5';
        g.beginPath();
        g.arc(cx, cy, r, 0, 7);
        g.fill();
        g.strokeStyle = '#fff';
        g.lineWidth = 2.5 * S;
        g.stroke();
        g.fillStyle = '#d7dbe4';
        g.beginPath();
        g.arc(cx, cy - r * 0.18, r * 0.36, 0, 7);
        g.fill();
        g.beginPath();
        g.arc(cx, cy + r * 0.75, r * 0.62, Math.PI, 0);
        g.fill();
      } else if (k === 'follow') {
        g.fillStyle = '#fe2c55';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), 14 * S, 0, 7);
        g.fill();
        g.shadowBlur = 0;
        _this6.icon(g, 'plus', X(it[1]), Y(it[2]), 18 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'pill') {
        var x = X(it[1]),
          y = Y(it[2]),
          w = it[3] * S,
          h = it[4] * S;
        g.beginPath();
        g.moveTo(x + h / 2, y);
        g.arcTo(x + w, y, x + w, y + h, h / 2);
        g.arcTo(x + w, y + h, x, y + h, h / 2);
        g.arcTo(x, y + h, x, y, h / 2);
        g.arcTo(x, y, x + w, y, h / 2);
        g.closePath();
        if (it[6]) {
          g.fillStyle = '#fff';
          g.fill();
        } else {
          g.strokeStyle = 'rgba(255,255,255,.8)';
          g.lineWidth = 2 * S;
          g.stroke();
        }
        g.shadowBlur = 0;
        g.fillStyle = it[6] ? '#0f0f0f' : '#fff';
        g.font = font(22, 600);
        g.textAlign = 'center';
        g.fillText(it[5], x + w / 2, y + h / 2 + 8 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'thumb') {
        var s2 = it[3] * S;
        g.fillStyle = '#5b6474';
        g.strokeStyle = '#fff';
        g.lineWidth = 3 * S;
        g.fillRect(X(it[1]) - s2 / 2, Y(it[2]) - s2 / 2, s2, s2);
        g.strokeRect(X(it[1]) - s2 / 2, Y(it[2]) - s2 / 2, s2, s2);
      } else if (k === 'disc') {
        var _r = it[3] * S;
        g.fillStyle = '#222';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), _r, 0, 7);
        g.fill();
        g.fillStyle = '#7d8696';
        g.beginPath();
        g.arc(X(it[1]), Y(it[2]), _r * 0.55, 0, 7);
        g.fill();
      } else if (k === 'faces') {
        for (var _i = 0; _i < 3; _i++) {
          g.fillStyle = ['#7d8696', '#5b6474', '#a3abb9'][_i];
          g.beginPath();
          g.arc(X(it[1] + 14 + _i * 26), Y(it[2]), 14 * S, 0, 7);
          g.fill();
          g.strokeStyle = '#fff';
          g.lineWidth = 2 * S;
          g.stroke();
        }
      } else if (k === 'bar') {
        g.shadowBlur = 0;
        g.fillStyle = 'rgba(255,255,255,0.35)';
        g.fillRect(X(it[1]), Y(it[2]), it[3] / spec.vw * fw, 3 * S);
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]), Y(it[2]), 40 * S, 3 * S);
        g.shadowBlur = 6 * S;
      } else if (k === 'underline') {
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]) - it[3] * S / 2, Y(it[2]), it[3] * S, 4 * S);
      } else if (k === 'nav') {
        var _x = X(it[1]),
          _y = Y(it[2]),
          _w = it[3] * S,
          _h = it[4] * S;
        g.shadowBlur = 0;
        g.fillStyle = 'rgba(40,40,40,0.55)';
        g.beginPath();
        g.moveTo(_x + _h / 2, _y);
        g.arcTo(_x + _w, _y, _x + _w, _y + _h, _h / 2);
        g.arcTo(_x + _w, _y + _h, _x, _y + _h, _h / 2);
        g.arcTo(_x, _y + _h, _x, _y, _h / 2);
        g.arcTo(_x, _y, _x + _w, _y, _h / 2);
        g.fill();
        g.fillStyle = 'rgba(255,255,255,0.18)';
        var ax = X(it[5][it[6]]);
        g.beginPath();
        g.arc(ax, _y + _h / 2, _h * 0.42, 0, 7);
        g.fill();
        it[5].forEach(function (cx, i) {
          var icn = it[7][i];
          if (icn === 'me') {
            g.fillStyle = '#9aa3b5';
            g.beginPath();
            g.arc(X(cx), _y + _h / 2, 20 * S, 0, 7);
            g.fill();
          } else _this6.icon(g, icn, X(cx), _y + _h / 2, 40 * S, icn === 'reel');
        });
        g.shadowBlur = 6 * S;
      } else if (k === 'homebar') {
        g.fillStyle = '#fff';
        g.fillRect(X(it[1]), Y(it[2]), it[3] / spec.vw * fw, 6 * S);
      } else {
        _this6.icon(g, k, X(it[1]), Y(it[2]), it[3] * S, it[4]);
      }
    });
    g.restore();
    g.strokeStyle = 'rgba(35,64,200,0.9)';
    g.lineWidth = Math.max(2, 3 * S);
    g.strokeRect(fx + 1, fy + 1, fw - 2, fh - 2);
  }
};
var MODULES = [{
  id: 'home',
  title: 'Início',
  icon: 'home'
}, {
  id: 'animate',
  title: 'Animar',
  icon: 'animate',
  h1: 'Dê vida aos',
  hand: 'seus clipes',
  p: ''
}, {
  id: 'workflow',
  title: 'Editar',
  icon: 'workflow',
  h1: 'Edição sem',
  hand: 'trabalho chato',
  p: ''
}, {
  id: 'after',
  title: 'Aftermovie',
  icon: 'blur',
  h1: 'Aftermovie e',
  hand: 'same day',
  p: ''
}, {
  id: 'sfx',
  title: 'Sons',
  icon: 'sfx'
}, {
  id: 'time',
  title: 'Tempo',
  icon: 'time'
}];
var NEEDS = {
  clips: function clips(s) {
    return s && s.selected ? ["".concat(s.selected, " clipe").concat(s.selected > 1 ? 's' : '', " selecionado").concat(s.selected > 1 ? 's' : ''), 'ok'] : ['Selecione clipes na timeline do Premiere', 'warn'];
  },
  seq: function seq(s) {
    return s ? ["Sequ\xEAncia: ".concat(s.name), 'ok'] : ['Abra uma sequência na timeline', 'warn'];
  },
  project: function project(s, i) {
    return i && i.project ? ["Projeto: ".concat(i.project.replace(/\.prproj$/i, '')), 'ok'] : ['Abra um projeto no Premiere', 'warn'];
  }
};
var App = {
  tools: [],
  current: 'home',
  page: null,
  info: null,
  connected: null,
  listeners: [],
  registerTool: function registerTool(t) {
    this.tools.push(t);
  },
  tool: function tool(id) {
    return this.tools.find(function (t) {
      return t.id === id;
    });
  },
  onInfo: function onInfo(fn) {
    this.listeners.push(fn);
  },
  log: function log(ok, msg) {
    var h = Store.data.history;
    h.unshift({
      t: Date.now(),
      ok: ok,
      msg: msg
    });
    if (h.length > 40) h.length = 40;
    Store.save();
    if (this.current === 'home' && !this.page) Home.renderLog();
  },
  init: function init() {
    var _this7 = this;
    Store.init();
    Theme.apply(Store.s.theme);
    this.renderShell();
    Splash.show();
    this.go('home');
    this.poll();
    setInterval(function () {
      return _this7.poll();
    }, 2000);
    Timer.init();
    Updater.init();
    document.addEventListener('keydown', function (e) {
      if (e.key === 'k' && (e.ctrlKey || e.metaKey) || e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
        e.preventDefault();
        $('#q').focus();
      }
      if (e.key === 'Escape' && _this7.page && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) _this7.go(_this7.tool(_this7.page).module);
    });
    window.addEventListener('beforeunload', function () {
      Timer.persist();
      Store.saveNow();
    });
  },
  renderShell: function renderShell() {
    var _this8 = this;
    $('#app').innerHTML = "\n      ".concat(SKETCH_FILTER, "\n      <div class=\"header\">\n        <div class=\"avatar\" title=\"Fast Edit\">").concat(art('mascot'), "</div>\n        <div class=\"who\" id=\"who\"><b>Fast Edit</b><span><i class=\"dot\"></i>conectando\u2026</span></div>\n        <div class=\"hbtn timer\" id=\"timerChip\" title=\"Cron\xF4metro\"><i></i><span>0:00</span></div>\n        <div class=\"hbtn\" id=\"gear\" title=\"Ajustes\">").concat(icon('settings'), "</div>\n      </div>\n      <div class=\"searchwrap\">\n        <div class=\"search\">").concat(icon('search'), "<input id=\"q\" placeholder=\"O que voc\xEA quer fazer?\" autocomplete=\"off\"><kbd>Ctrl K</kbd></div>\n        <div class=\"results\" id=\"results\"></div>\n      </div>\n      <div class=\"view\" id=\"view\"></div>\n      <div class=\"tabbar\">").concat(MODULES.map(function (m) {
      return "<div class=\"tab\" data-go=\"".concat(m.id, "\" title=\"").concat(m.title, "\">").concat(icon(m.icon), "<span>").concat(m.title, "</span></div>");
    }).join(''), "</div>\n      <div class=\"toasts\" id=\"toasts\"></div>");
    $('.tabbar').addEventListener('click', function (e) {
      var n = e.target.closest('[data-go]');
      if (n) _this8.go(n.getAttribute('data-go'));
    });
    $('#who').addEventListener('click', function () {
      FE.hostReady = false;
      _this8.poll(true);
    });
    $('#timerChip').addEventListener('click', function () {
      return _this8.go('time');
    });
    $('#gear').addEventListener('click', function () {
      return _this8.go('settings');
    });
    this.bindSearch();
  },
  go: function go(id) {
    var _this9 = this;
    if (typeof QTip !== "undefined") QTip.hide();
    this.current = id;
    this.page = null;
    $$('.tab').forEach(function (n) {
      return n.classList.toggle('active', n.getAttribute('data-go') === id);
    });
    var view = this.freshView();
    if (id === 'home') return Home.render(view);
    if (id === 'settings') return Settings.render(view);
    var m = MODULES.find(function (x) {
      return x.id === id;
    });
    var tools = this.tools.filter(function (t) {
      return t.module === id;
    });
    if (tools.length === 1 && tools[0].full) {
      tools[0].render(view);
      return;
    }
    view.innerHTML = "<div class=\"hero\"><h1>".concat(m.h1, "<span class=\"hand\">").concat(m.hand, "</span></h1>").concat(m.p ? "<p>".concat(m.p, "</p>") : '', "</div>").concat(this.connBanner()) + (id === 'after' ? "<div class=\"qa-grid tgrid\">".concat(tools.map(function (t) {
      return "<div class=\"qa\" data-open=\"".concat(t.id, "\" data-qtip=\"").concat(esc(t.desc), "\">").concat(icon(t.icon), "<span>").concat(esc(t.title), "</span></div>");
    }).join(''), "</div>") : tools.map(function (t) {
      return _this9.rowHTML(t);
    }).join(''));
    view.addEventListener('click', function (e) {
      var star = e.target.closest('[data-star]');
      if (star) {
        e.stopPropagation();
        _this9.toggleFav(star.getAttribute('data-star'));
        star.classList.toggle('on');
        return;
      }
      var r = e.target.closest('[data-open]');
      if (r) _this9.openTool(r.getAttribute('data-open'));
    });
  },
  freshView: function freshView() {
    var old = $('#view');
    var v = old.cloneNode(false);
    old.parentNode.replaceChild(v, old);
    v.scrollTop = 0;
    return v;
  },
  rowHTML: function rowHTML(t) {
    var fav = Store.data.favorites.includes(t.id);
    return "<div class=\"tool-row\" data-open=\"".concat(t.id, "\">\n      <div class=\"ticon\">").concat(icon(t.icon), "</div>\n      <div class=\"tt\"><b>").concat(esc(t.title), "</b><span>").concat(esc(t.desc), "</span></div>\n      <div class=\"star ").concat(fav ? 'on' : '', "\" data-star=\"").concat(t.id, "\" title=\"Fixar no In\xEDcio\">").concat(icon('star'), "</div>\n      <div class=\"go\">").concat(icon('chev'), "</div></div>");
  },
  openTool: function openTool(id) {
    var _this0 = this;
    if (typeof QTip !== "undefined") QTip.hide();
    var t = this.tool(id);
    if (!t) return;
    if (t.full) {
      this.go(t.module);
      return;
    }
    this.current = t.module;
    this.page = id;
    $$('.tab').forEach(function (n) {
      return n.classList.toggle('active', n.getAttribute('data-go') === t.module);
    });
    var view = this.freshView();
    var fav = Store.data.favorites.includes(t.id);
    view.innerHTML = "\n      <div class=\"page-head\"><div class=\"back\" data-back title=\"Voltar (Esc)\">".concat(icon('back'), "</div>\n        <h2>").concat(esc(t.title), "<small>").concat(esc(t.desc), "</small></h2>\n        <div class=\"star ").concat(fav ? 'on' : '', "\" data-star=\"").concat(t.id, "\" title=\"Fixar no In\xEDcio\">").concat(icon('star'), "</div></div>\n      ").concat(t.needs ? '<div class="ctx" id="ctx"></div>' : '', "\n      <div class=\"panel\" id=\"toolBody\"></div>");
    $('[data-back]', view).addEventListener('click', function () {
      return _this0.go(t.module);
    });
    $('[data-star]', view).addEventListener('click', function (e) {
      _this0.toggleFav(t.id);
      e.currentTarget.classList.toggle('on');
    });
    this.updateCtx();
    t.render($('#toolBody', view));
  },
  updateCtx: function updateCtx() {
    var el = $('#ctx');
    if (!el || !this.page) return;
    var t = this.tool(this.page);
    if (this.connected === false) {
      el.className = 'ctx warn';
      el.innerHTML = icon('info') + 'Premiere desconectado — toque no nome do projeto lá em cima';
      return;
    }
    var r = NEEDS[t.needs](this.info && this.info.seq, this.info);
    el.className = 'ctx ' + r[1];
    el.innerHTML = icon(r[1] === 'ok' ? 'check' : 'info') + esc(r[0]);
  },
  toggleFav: function toggleFav(id) {
    var f = Store.data.favorites,
      i = f.indexOf(id);
    if (i >= 0) f.splice(i, 1);else f.push(id);
    Store.save();
  },
  connBanner: function connBanner() {
    if (this.connected !== false) return '';
    return "<div class=\"banner\"><b>N\xE3o estou falando com o Premiere.</b>Abra um projeto e toque no nome l\xE1 em cima para reconectar.".concat(FE.lastHostError ? "<br><span class=\"mono\" style=\"font-size:10.5px\">".concat(esc(FE.lastHostError), "</span>") : '', "</div>");
  },
  bindSearch: function bindSearch() {
    var _this1 = this;
    var q = $('#q'),
      box = $('#results');
    var sel = 0,
      items = [];
    var norm = function norm(s) {
      s = String(s).toLowerCase();
      return s.normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g, '') : s;
    };
    var draw = function draw() {
      var term = norm(q.value.trim());
      if (!term) {
        box.classList.remove('show');
        return;
      }
      items = _this1.tools.filter(function (x) {
        return norm("".concat(x.title, " ").concat(x.desc, " ").concat(x.keywords || '')).includes(term);
      });
      sel = 0;
      box.innerHTML = items.length ? items.map(function (x, i) {
        return "<div class=\"result ".concat(i === 0 ? 'sel' : '', "\" data-id=\"").concat(x.id, "\"><div class=\"ri\">").concat(icon(x.icon), "</div><div><b>").concat(esc(x.title), "</b><span>").concat(esc(x.desc), "</span></div></div>");
      }).join('') : '<div class="empty">Nada por aqui. Tente “zoom”, “legenda”, “whoosh”…</div>';
      box.classList.add('show');
    };
    var pick = function pick(id) {
      q.value = '';
      box.classList.remove('show');
      q.blur();
      _this1.openTool(id);
    };
    q.addEventListener('input', draw);
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        sel = clamp(sel + (e.key === 'ArrowDown' ? 1 : -1), 0, items.length - 1);
        $$('.result', box).forEach(function (r, i) {
          return r.classList.toggle('sel', i === sel);
        });
      } else if (e.key === 'Enter' && items[sel]) pick(items[sel].id);else if (e.key === 'Escape') {
        q.value = '';
        box.classList.remove('show');
        q.blur();
      }
    });
    box.addEventListener('mousedown', function (e) {
      var r = e.target.closest('[data-id]');
      if (r) {
        e.preventDefault();
        pick(r.getAttribute('data-id'));
      }
    });
    q.addEventListener('blur', function () {
      return setTimeout(function () {
        return box.classList.remove('show');
      }, 150);
    });
  },
  poll: function poll(manual) {
    var _this10 = this;
    if (this.polling) return;
    this.polling = true;
    FE.call('info').then(function (info) {
      var was = _this10.connected;
      _this10.connected = true;
      _this10.info = info;
      if (was === false && !_this10.page) _this10.go(_this10.current);
      if (manual) UI.toast('Conectado ao Premiere ' + (info.version || ''), 'info');
    }).catch(function (e) {
      var was = _this10.connected;
      _this10.connected = false;
      _this10.info = null;
      if (manual) UI.toast('Sem conexão: ' + e.message, 'err');
      if (was !== false && !_this10.page) _this10.go(_this10.current);
    }).then(function () {
      _this10.polling = false;
      Splash.ready();
      _this10.renderWho();
      _this10.updateCtx();
      _this10.listeners.forEach(function (fn) {
        try {
          fn(_this10.info);
        } catch (e) {}
      });
    });
  },
  renderWho: function renderWho() {
    var w = $('#who'),
      i = this.info;
    if (!this.connected) {
      w.innerHTML = "<b>Fast Edit</b><span><i class=\"dot off\"></i>Premiere desconectado \xB7 toque para tentar</span>";
      return;
    }
    if (!i.project) {
      w.innerHTML = "<b>Fast Edit</b><span><i class=\"dot on\"></i>Premiere ".concat(esc(String(i.version).split('.').slice(0, 2).join('.')), " \xB7 nenhum projeto</span>");
      return;
    }
    var s = i.seq;
    w.innerHTML = "<b>".concat(esc(i.project.replace(/\.prproj$/i, '')), "</b><span><i class=\"dot on\"></i>").concat(s ? "".concat(esc(s.name), " \xB7 ").concat(s.w, "\xD7").concat(s.h, " \xB7 ").concat(s.fps, "fps") : 'nenhuma sequência aberta', "</span>");
  }
};
var QUICK = [{
  k: 'adj',
  name: 'Camada de ajuste',
  icon: 'adjust',
  tip: 'Cria uma camada de ajuste nos takes selecionados ou na agulha (Shift: uma em cada corte).'
}, {
  k: 'matte',
  name: 'Matte',
  icon: 'layers',
  tip: 'Coloca uma cor sólida por cima, na cor e opacidade escolhidas no Stack.'
}, {
  k: 'paste',
  name: 'Colar imagem',
  icon: 'paste',
  tip: 'Cola na timeline a imagem que está na área de transferência (print, foto copiada).'
}, {
  k: 'ramp',
  name: 'Speed ramp',
  icon: 'ramp',
  tip: 'Acelera e desacelera o take com a rampa escolhida, sem keyframes.'
}, {
  k: 'blur',
  name: 'Rastro de luz',
  icon: 'blur',
  tip: 'Aplica o rastro nos pontos de luz dos takes selecionados, no estilo escolhido.'
}, {
  k: 'prism',
  name: 'Prisma',
  icon: 'prism',
  tip: 'Transição prisma no corte entre dois takes (ou onde está a agulha).'
}, {
  k: 'grid',
  name: 'Grid no corte',
  icon: 'batch',
  tip: 'A imagem troca em quadrículas no corte entre os takes selecionados.'
}, {
  k: 'match',
  name: 'Match cut',
  icon: 'match',
  tip: 'Abre o Match cut: vários takes trocando rápido com o assunto no mesmo lugar.'
}, {
  k: 'fx',
  name: 'Efeitos prontos',
  icon: 'fx',
  tip: 'Abre a biblioteca de transições, movimentos e looks prontos.'
}, {
  k: 'guide',
  name: 'Guia de redes',
  icon: 'social',
  tip: 'Mostra ou esconde a guia do Reels/TikTok/Shorts. Se não tiver guia, abre a ferramenta.'
}, {
  k: 'formats',
  name: 'Outro formato',
  icon: 'crop',
  tip: 'Abre a cópia da sequência em outro formato (9:16, 1:1, 4:5…).'
}, {
  k: 'setup',
  name: 'Iniciar projeto',
  icon: 'bins',
  tip: 'Cria as pastas do projeto no padrão que você escolher.'
}];
var Home = {
  render: function render(view) {
    var _this11 = this;
    view.innerHTML = "\n      ".concat(App.connBanner(), "\n      <div id=\"homeUpdate\"></div>\n      <div id=\"homeStats\"></div>\n      <div class=\"qa-head\"><span class=\"qa-title\">A\xE7\xF5es r\xE1pidas</span><div class=\"qa-tabs\"><button data-qtab=\"actions\">A\xE7\xF5es</button><button data-qtab=\"fx\">Efeitos</button></div></div>\n      <div class=\"qa-grid\" id=\"homeQA\"></div>\n      <div class=\"section\"><h3>Favoritos</h3></div>\n      <div id=\"homeFavs\"></div>\n      <div class=\"madeby hand\">feito com \u2615 por <b data-credit>@odalluz</b></div>");
    this.renderStats(App.info);
    this.renderQA(view);
    this.renderFavs();
    this.renderLog();
    this.renderUpdate();
    Updater.maybeCheck();
    view.addEventListener('click', function (e) {
      if (e.target.closest('[data-credit]')) return FE.openURL(CREDIT_URL);
      var up = e.target.closest('[data-update]');
      if (up) return Updater.install(up);
      var qt = e.target.closest('[data-qtab]');
      if (qt) {
        Store.set('qaTab', qt.getAttribute('data-qtab'));
        _this11.renderQA(view);
        return;
      }
      var q = e.target.closest('[data-qa]');
      if (q) return _this11.quick(q.getAttribute('data-qa'), q, e);
      var qf = e.target.closest('[data-qfx]');
      if (qf) {
        var fx = FX_LIB.find(function (f) {
          return f.i === qf.getAttribute('data-qfx');
        });
        if (fx) FX.apply(fx, qf).catch(function () {});
        return;
      }
      var star = e.target.closest('[data-star]');
      if (star) {
        e.stopPropagation();
        App.toggleFav(star.getAttribute('data-star'));
        _this11.renderFavs();
        return;
      }
      var r = e.target.closest('[data-open]');
      if (r) App.openTool(r.getAttribute('data-open'));
    });
  },
  bindShelf: function bindShelf(view) {
    var _this12 = this;
    var shelf = $('#homeQA', view),
      dots = $('#shelfDots', view),
      modeBtn = $('[data-shelfmode]', view);
    var apply = function apply() {
      var grid = Store.s.shelfMode === 'grid';
      shelf.classList.toggle('grid', grid);
      view.querySelector('.shelf-ctl').classList.toggle('grid', grid);
      modeBtn.textContent = grid ? 'carrossel' : 'ver todos';
      upd();
    };
    var upd = function upd() {
      if (Store.s.shelfMode === 'grid') {
        dots.innerHTML = '';
        return;
      }
      var max = shelf.scrollWidth - shelf.clientWidth;
      var n = Math.max(1, Math.ceil(shelf.scrollWidth / Math.max(1, shelf.clientWidth)));
      var at = max > 0 ? Math.round(shelf.scrollLeft / max * (n - 1)) : 0;
      dots.innerHTML = n > 1 ? Array.from({
        length: n
      }, function (_, i) {
        return "<i class=\"".concat(i === at ? 'on' : '', "\"></i>");
      }).join('') : '';
    };
    var go = function go(dir) {
      var to = shelf.scrollLeft + dir * Math.max(140, shelf.clientWidth * 0.8);
      var from = shelf.scrollLeft,
        t0 = Date.now();
      var _step = function step() {
        var k = Math.min(1, (Date.now() - t0) / 260);
        shelf.scrollLeft = from + (to - from) * (1 - Math.pow(1 - k, 3));
        if (k < 1) requestAnimationFrame(_step);else upd();
      };
      requestAnimationFrame(_step);
    };
    var down = false,
      sx = 0,
      sl = 0;
    shelf.addEventListener('mousedown', function (e) {
      if (Store.s.shelfMode === 'grid') return;
      down = true;
      _this12.dragged = false;
      sx = e.clientX;
      sl = shelf.scrollLeft;
      shelf.classList.add('dragging');
      e.preventDefault();
    });
    document.addEventListener('mousemove', function (e) {
      if (!down) return;
      var dx = e.clientX - sx;
      if (Math.abs(dx) > 5) _this12.dragged = true;
      shelf.scrollLeft = sl - dx;
    });
    document.addEventListener('mouseup', function () {
      if (!down) return;
      down = false;
      shelf.classList.remove('dragging');
      upd();
      setTimeout(function () {
        _this12.dragged = false;
      }, 0);
    });
    shelf.addEventListener('wheel', function (e) {
      if (Store.s.shelfMode === 'grid') return;
      var d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      var max = shelf.scrollWidth - shelf.clientWidth;
      if (d > 0 && shelf.scrollLeft < max - 1 || d < 0 && shelf.scrollLeft > 0) {
        shelf.scrollLeft += d;
        e.preventDefault();
        upd();
      }
    });
    shelf.addEventListener('scroll', upd);
    view.querySelectorAll('[data-shelf]').forEach(function (b) {
      return b.addEventListener('click', function () {
        return go(parseInt(b.getAttribute('data-shelf'), 10));
      });
    });
    modeBtn.addEventListener('click', function () {
      Store.set('shelfMode', Store.s.shelfMode === 'grid' ? 'carousel' : 'grid');
      apply();
    });
    window.addEventListener('resize', upd);
    setTimeout(apply, 0);
  },
  renderQA: function renderQA(view) {
    var tab = Store.s.qaTab || 'actions',
      el = $('#homeQA', view);
    $$('[data-qtab]', view).forEach(function (b) {
      return b.classList.toggle('on', b.getAttribute('data-qtab') === tab);
    });
    if (tab === 'fx') {
      var favs = (Store.data.fxFavs || []).map(function (id) {
        return FX_LIB.find(function (f) {
          return f.i === id;
        });
      }).filter(Boolean);
      el.innerHTML = favs.length ? favs.map(function (f) {
        return "<div class=\"qa qfx\" data-qfx=\"".concat(esc(f.i), "\" data-qtip=\"Aplica ").concat(esc(f.n), " numa camada de ajuste\"><i style=\"background-image:url('assets/prev/fx_").concat(f.f, ".webp')\"></i><span>").concat(esc(f.n), "</span></div>");
      }).join('') : "<div class=\"qa-empty\">Toque na \u2606 de um efeito em <b data-goafter>After \u203A Efeitos</b> para ele aparecer aqui.</div>";
      var go = $('[data-goafter]', el);
      if (go) go.onclick = function () {
        return App.openTool('fxlib');
      };
      return;
    }
    el.innerHTML = QUICK.map(function (q) {
      return "<div class=\"qa\" data-qa=\"".concat(q.k, "\" data-qtip=\"").concat(esc(q.tip), "\">").concat(icon(q.icon), "<span>").concat(esc(q.name), "</span></div>");
    }).join('');
  },
  renderUpdate: function renderUpdate() {
    var el = $('#homeUpdate');
    if (!el) return;
    var u = Updater.available;
    if (!u) {
      el.innerHTML = '';
      return;
    }
    el.innerHTML = "<div class=\"update-card\">\n      <div class=\"uhead\">".concat(icon('download'), "<div class=\"ut\"><b>Atualiza\xE7\xE3o ").concat(esc(u.version), " dispon\xEDvel</b><span>Voc\xEA est\xE1 na ").concat(esc(APP_VERSION), "</span></div></div>\n      <button class=\"btn primary\" data-update>").concat(icon('download'), "Atualizar agora</button></div>");
  },
  renderStats: function renderStats(info) {
    var el = $('#homeStats');
    if (!el) return;
    var s = info && info.seq;
    var today = info && info.project ? Timer.todayFor(Timer.keyFor(info)) : 0;
    var h = Math.floor(today / 3600),
      m = Math.floor(today % 3600 / 60);
    el.innerHTML = "<div class=\"stats\">\n      <div class=\"stat\"><b>".concat(s ? s.selected : '–', "</b><span>selecionados</span></div>\n      <div class=\"stat\"><b>").concat(s ? s.clips : '–', "</b><span>clipes</span></div>\n      <div class=\"stat\"><b>").concat(s ? fmtDur(s.duration).replace(/^00:/, '') : '–', "</b><span>dura\xE7\xE3o</span></div>\n      <div class=\"stat\"><b>").concat(h, "h").concat(pad2(m), "</b><span>hoje</span></div></div>");
  },
  renderFavs: function renderFavs() {
    var el = $('#homeFavs');
    var favs = Store.data.favorites.map(function (id) {
      return App.tool(id);
    }).filter(Boolean);
    el.innerHTML = favs.length ? favs.map(function (t) {
      return App.rowHTML(t);
    }).join('') : '<div class="hint">Toque na ☆ de uma ferramenta para fixar aqui.</div>';
  },
  renderLog: function renderLog() {
    var el = $('#homeLog');
    if (!el) return;
    var h = Store.data.history.slice(0, 6);
    el.innerHTML = h.length ? h.map(function (x) {
      return "<div class=\"li\" style=\"cursor:default\"><span class=\"ic\" style=\"color:".concat(x.ok ? 'var(--ok)' : 'var(--bad)', "\">").concat(icon(x.ok ? 'check' : 'x'), "</span><span class=\"nm\">").concat(esc(x.msg), "</span><span class=\"sub\">").concat(new Date(x.t).toTimeString().slice(0, 5), "</span></div>");
    }).join('') : "<div class=\"empty\">".concat(art('magic'), "Nada por aqui ainda.</div>");
  },
  quick: function quick(k, btn, ev) {
    var s = Store.s,
      shift = !!(ev && ev.shiftKey);
    var run = function run(label, fn, args, msg) {
      return UI.run(btn, label, fn, args, msg).catch(function () {});
    };
    if (k === 'match') return App.openTool('matchcut');
    if (k === 'fx') return App.openTool('fxlib');
    if (k === 'formats') return App.openTool('formats');
    if (k === 'prism') return Prism.run(btn);
    if (k === 'ramp') return Ramp.run(btn);
    if (k === 'adj') return Stack.apply('adjustment', shift, btn);
    if (k === 'matte') return Stack.apply('matte', shift, btn);
    if (k === 'paste') return Clip.paste(btn);
    if (k === 'blur') return run('Rastro de luz', 'timeBlur', TimeBlur.args(), function (d) {
      return "".concat(TimeBlur.look(s.tbLook).name, " em ").concat(d.clips, " clipe(s)");
    });
    if (k === 'grid') {
      var lines = null;
      if (s.gridLines && FS.ok) {
        try {
          lines = Grid.linesPNG(s.gridCols, s.gridRows, s.gridThick, s.gridLineColor);
        } catch (er) {
          lines = null;
        }
      }
      return run('Grid', 'gridTransition', {
        cols: s.gridCols,
        rows: s.gridRows,
        frames: s.gridFrames,
        pattern: s.gridPattern,
        seed: Math.floor(Math.random() * 1e6),
        linesPng: lines,
        flash: !!s.gridFlash,
        flashColor: hexRgb(s.gridFlashColor),
        flashIntensity: s.gridFlashI,
        flashFrames: s.gridFlashF
      }, function (d) {
        return "Grid em ".concat(d.cuts, " corte(s)").concat(d.noTint ? ' · não achei o efeito Tingir (Tint): o destaque ficou de fora' : '').concat(d.noHandle ? ' · sem sobra nos takes: o grid entra no fim do take anterior' : '');
      });
    }
    if (k === 'guide') {
      return FE.call('guidesState').then(function (st) {
        if (!st.count) {
          App.openTool('social');
          return;
        }
        return FE.call('toggleGuides', {}).then(function (r) {
          return UI.toast(r.visible ? 'Guia visível' : 'Guia escondida', 'info');
        });
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
    }
    if (k === 'setup') return App.openTool('setup');
  }
};
App.onInfo(function (info) {
  if (App.current === 'home' && !App.page) Home.renderStats(info);
});
var Theme = {
  apply: function apply(t) {
    var link = $('link[rel=stylesheet]');
    if (!link) return;
    var want = t === 'cobalt' ? 'css/fastedit-cobalt.css' : t === 'neon' ? 'css/fastedit-neon.css' : 'css/fastedit.css';
    if (link.getAttribute('href') !== want) link.setAttribute('href', want);
  }
};
var Splash = {
  el: null,
  pct: 0,
  t0: 0,
  done: false,
  show: function show() {
    var _this13 = this;
    this.t0 = Date.now();
    var el = document.createElement('div');
    el.className = 'splash walk';
    el.innerHTML = "".concat(art('mascot'), "<h1>Fast Edit</h1><div class=\"tagline\">edite r\xE1pido, fique pelo caf\xE9</div><div class=\"pct\">0%</div><div class=\"credit\">feito por @odalluz \xB7 v").concat(APP_VERSION, "</div>");
    document.body.appendChild(el);
    this.el = el;
    this.timer = setInterval(function () {
      var target = _this13.done ? 100 : 86;
      _this13.pct = Math.min(target, _this13.pct + (_this13.done ? 9 : 3 + Math.random() * 4));
      $('.pct', el).textContent = Math.round(_this13.pct) + '%';
      if (_this13.pct >= 100 && Date.now() - _this13.t0 > 900) _this13.hide();
    }, 60);
  },
  ready: function ready() {
    this.done = true;
  },
  hide: function hide() {
    clearInterval(this.timer);
    if (!this.el) return;
    var el = this.el;
    this.el = null;
    el.classList.add('hide');
    setTimeout(function () {
      el.remove();
      if (!Store.data.onboarded) Onboarding.show();else if (!Store.data.toured) Tour.start();
    }, 380);
  }
};
var Onboarding = {
  themes: function themes() {
    var cur = Store.s.theme || 'neon';
    var opt = function opt(id, name, bg, fg, acc) {
      return "<div class=\"theme-opt ".concat(cur === id ? 'on' : '', "\" data-theme=\"").concat(id, "\">\n      <div class=\"theme-sw\" style=\"background:").concat(bg, "\"><i style=\"background:").concat(acc, "\"></i><b style=\"background:").concat(fg, "\"></b><b style=\"background:").concat(fg, ";width:60%\"></b><u style=\"background:").concat(acc, "\"></u></div><span>").concat(name, "</span></div>");
    };
    return "<div class=\"theme-pick\">".concat(opt('neon', 'Neon', '#0B0B0B', '#232323', '#C4F82A')).concat(opt('cream', 'Creme', '#F3EEE4', 'rgba(35,64,200,.25)', '#2340C8')).concat(opt('cobalt', 'Cobalto', '#2340C8', 'rgba(245,240,230,.3)', '#F5F0E6'), "</div>");
  },
  slides: [{
    art: 'timeline',
    t: 'Selecione na timeline',
    p: 'O Fast Edit sempre age nos clipes que você selecionou no Premiere. O topo de cada ferramenta mostra quantos estão selecionados.'
  }, {
    art: 'magic',
    t: 'Escolha e pronto',
    p: 'Abra uma ferramenta, ajuste se quiser e aplique. Errou? Ctrl+Z no Premiere desfaz.'
  }, {
    art: 'clock',
    t: 'Seu tempo conta',
    p: 'O cronômetro registra sozinho as horas de cada projeto e calcula quanto cobrar.'
  }, {
    theme: true,
    t: 'Escolha seu visual',
    p: 'Dá para trocar quando quiser em Ajustes (engrenagem).'
  }],
  show: function show() {
    var _this14 = this;
    var i = 0;
    var el = document.createElement('div');
    el.className = 'onb';
    document.body.appendChild(el);
    var close = function close() {
      Store.data.onboarded = true;
      Store.save();
      el.remove();
      if (!Store.data.toured) setTimeout(function () {
        return Tour.start();
      }, 250);
    };
    var draw = function draw() {
      var s = _this14.slides[i];
      el.innerHTML = "<div class=\"oart\">".concat(s.theme ? Onboarding.themes() : art(s.art), "</div>\n        <div class=\"dots\">").concat(_this14.slides.map(function (x, j) {
        return "<i class=\"".concat(j === i ? 'on' : '', "\"></i>");
      }).join(''), "</div>\n        <h2>").concat(s.t, "</h2><p>").concat(s.p, "</p>\n        <div class=\"onav\"><a data-skip>Pular</a><button class=\"btn primary\" data-next>").concat(i === _this14.slides.length - 1 ? 'Começar' : 'Próximo', "</button></div>");
    };
    el.addEventListener('click', function (e) {
      var th = e.target.closest('[data-theme]');
      if (th) {
        Store.set('theme', th.getAttribute('data-theme'));
        Theme.apply(Store.s.theme);
        draw();
        return;
      }
      if (e.target.closest('[data-skip]')) close();
      if (e.target.closest('[data-next]')) {
        if (i < _this14.slides.length - 1) {
          i++;
          draw();
        } else close();
      }
    });
    draw();
  }
};
var QTip = {
  el: null,
  timer: 0,
  show: function show(target) {
    if (!this.el) {
      this.el = document.createElement('div');
      this.el.className = 'qtip';
      document.body.appendChild(this.el);
    }
    this.el.textContent = target.getAttribute('data-qtip');
    this.el.classList.add('show');
    var r = target.getBoundingClientRect(),
      w = this.el.offsetWidth,
      h = this.el.offsetHeight,
      vw = window.innerWidth;
    var x = r.left + r.width / 2 - w / 2,
      y = r.top - h - 8,
      below = false;
    if (y < 6) {
      y = r.bottom + 8;
      below = true;
    }
    x = Math.max(6, Math.min(vw - w - 6, x));
    this.el.style.left = x + 'px';
    this.el.style.top = y + 'px';
    this.el.classList.toggle('below', below);
    this.el.style.setProperty('--ax', r.left + r.width / 2 - x + 'px');
  },
  hide: function hide() {
    clearTimeout(this.timer);
    if (this.el) this.el.classList.remove('show');
  }
};
document.addEventListener('mouseover', function (e) {
  var t = e.target.closest && e.target.closest('[data-qtip]');
  if (!t) return;
  clearTimeout(QTip.timer);
  QTip.timer = setTimeout(function () {
    if (document.body.contains(t)) QTip.show(t);
  }, 350);
});
document.addEventListener('mouseout', function (e) {
  var t = e.target.closest && e.target.closest('[data-qtip]');
  if (t && !(e.relatedTarget && t.contains(e.relatedTarget))) QTip.hide();
});
document.addEventListener('mousedown', function () {
  return QTip.hide();
});
var Tour = {
  steps: [{
    t: 'Bem-vindo ao Fast Edit',
    p: 'Ele é um painel do Premiere Pro (não é do After Effects). Em 1 minuto eu te mostro onde fica cada coisa. Use Próximo ou as setas do teclado.',
    go: 'home'
  }, {
    sel: '#who',
    t: 'Sua sequência',
    p: 'Aqui aparece o projeto e a sequência abertos no Premiere. A bolinha verde mostra que o painel está conectado.',
    go: 'home'
  }, {
    sel: '.search',
    t: 'Busca',
    p: 'Digite o que você quer fazer, como "zoom", "speed" ou "flash", e o painel leva direto para a ferramenta. Atalho: Ctrl K.',
    go: 'home'
  }, {
    sel: '#homeQA',
    t: 'Ações rápidas',
    p: 'Os atalhos das ferramentas mais usadas. Passe o mouse em cima de cada uma para ver o que ela faz.',
    go: 'home'
  }, {
    sel: '.tabbar',
    t: 'As abas',
    p: 'Cada aba junta um tipo de ferramenta. Vamos passar por elas.',
    go: 'home'
  }, {
    sel: '#view',
    tab: 'animate',
    t: 'Animar',
    p: 'Entradas, saídas e ênfases nos clipes, com keyframes de verdade, sem você mexer em keyframe.',
    go: 'animate'
  }, {
    sel: '#view',
    tab: 'workflow',
    t: 'Editar',
    p: 'O trabalho repetitivo da edição: camada de ajuste, matte, colar imagem, outro formato e mais.',
    go: 'workflow'
  }, {
    sel: '#view .tgrid',
    tab: 'after',
    t: 'Aftermovie',
    p: 'As ferramentas para vídeo de evento (aftermovie e same day): speed ramp, match cut, zoom nos takes, prisma, efeitos prontos…',
    go: 'after'
  }, {
    sel: '#ctx',
    t: 'Sempre selecione antes',
    p: 'Toda ferramenta age nos clipes selecionados na timeline. Esta faixa mostra quantos estão selecionados agora.',
    tool: 'ramp'
  }, {
    sel: '[data-rbig]',
    t: 'Speed ramp',
    p: 'Escolha uma rampa pronta ou arraste os pontos do gráfico para desenhar a sua. A bolinha anda na velocidade que o take vai ter.',
    tool: 'ramp'
  }, {
    sel: '[data-apply]',
    t: 'Aplicar',
    p: 'Depois de ajustar, é só aplicar. Errou? Ctrl+Z no Premiere desfaz.',
    tool: 'ramp'
  }, {
    sel: '[data-zprev]',
    t: 'Prévia antes de aplicar',
    p: 'As ferramentas mostram como vai ficar. Aqui, no Zoom nos takes, cada quadradinho é um take com o zoom que ele vai receber.',
    tool: 'zoomtakes'
  }, {
    sel: '#view',
    tab: 'sfx',
    t: 'Sons',
    p: 'Sua biblioteca de efeitos sonoros com a forma de onda. Clique para ouvir e mande para a timeline.',
    go: 'sfx'
  }, {
    sel: '#view',
    tab: 'time',
    t: 'Tempo',
    p: 'O cronômetro conta sozinho as horas de cada projeto e ajuda a calcular quanto cobrar.',
    go: 'time'
  }, {
    sel: '#gear',
    t: 'Ajustes',
    p: 'Temas, atualizações, backup e este tutorial de novo, quando quiser.',
    go: 'home'
  }, {
    t: 'Pronto!',
    p: 'Quando sair uma versão nova, aparece um aviso na tela inicial: é só clicar em Atualizar agora. Bom trabalho!',
    go: 'home',
    last: true
  }],
  start: function start(done) {
    var _this15 = this;
    this.stop();
    this.i = 0;
    this.done = done;
    var root = document.createElement('div');
    root.className = 'tour';
    root.innerHTML = '<div class="tour-hole"></div><div class="tour-card" role="dialog" aria-live="polite"></div>';
    document.body.appendChild(root);
    this.root = root;
    root.addEventListener('click', function (e) {
      if (e.target.closest('[data-tnext]')) return _this15.next();
      if (e.target.closest('[data-tprev]')) return _this15.prev();
      if (e.target.closest('[data-tskip]')) return _this15.finish();
    });
    this.onKey = function (e) {
      if (e.key === 'ArrowRight' || e.key === 'Enter') {
        e.preventDefault();
        _this15.next();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        _this15.prev();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        _this15.finish();
      }
    };
    document.addEventListener('keydown', this.onKey, true);
    this.onResize = function () {
      return _this15.place();
    };
    window.addEventListener('resize', this.onResize);
    this.show();
  },
  next: function next() {
    if (this.i < this.steps.length - 1) {
      this.i++;
      this.show();
    } else this.finish();
  },
  prev: function prev() {
    if (this.i > 0) {
      this.i--;
      this.show();
    }
  },
  show: function show() {
    var _this16 = this;
    var s = this.steps[this.i];
    if (s.tool) {
      if (App.page !== s.tool) App.openTool(s.tool);
    } else if (s.go && (App.current !== s.go || App.page)) App.go(s.go);
    var card = $('.tour-card', this.root),
      n = this.steps.length;
    card.innerHTML = "<div class=\"tour-step\">".concat(this.i + 1, " de ").concat(n, "</div><h3>").concat(esc(s.t), "</h3><p>").concat(esc(s.p), "</p>\n      <div class=\"tour-bar\"><i style=\"width:").concat((this.i + 1) / n * 100, "%\"></i></div>\n      <div class=\"tour-nav\">").concat(s.last ? '' : '<button class="tour-skip" data-tskip>Pular tutorial</button>', "<span></span>\n        ").concat(this.i ? '<button class="btn" data-tprev>Voltar</button>' : '', "<button class=\"btn primary\" data-tnext>").concat(s.last ? 'Começar a usar' : 'Próximo', "</button></div>");
    setTimeout(function () {
      return _this16.place();
    }, 60);
    setTimeout(function () {
      return _this16.place();
    }, 320);
  },
  place: function place() {
    if (!this.root) return;
    var s = this.steps[this.i],
      hole = $('.tour-hole', this.root),
      card = $('.tour-card', this.root);
    var el = s.sel ? document.querySelector(s.sel) : null;
    if (el && el.scrollIntoView) {
      try {
        el.scrollIntoView({
          block: 'nearest'
        });
      } catch (e) {}
    }
    var r = el ? el.getBoundingClientRect() : null;
    var W = window.innerWidth,
      H = window.innerHeight,
      pad = 6;
    if (!r || !r.width) {
      hole.style.cssText = "left:".concat(W / 2, "px;top:").concat(H / 2, "px;width:0;height:0");
      card.style.cssText = "left:".concat(Math.max(12, (W - Math.min(340, W - 24)) / 2), "px;top:").concat(Math.max(12, H / 2 - 110), "px");
      return;
    }
    var top = Math.max(4, r.top - pad),
      left = Math.max(4, r.left - pad);
    var w = Math.min(W - left - 4, r.width + pad * 2),
      h = Math.min(H - top - 4, r.height + pad * 2);
    hole.style.cssText = "left:".concat(left, "px;top:").concat(top, "px;width:").concat(w, "px;height:").concat(h, "px");
    var cw = Math.min(340, W - 24),
      ch = card.offsetHeight || 190;
    var ct = top + h + 12;
    if (ct + ch > H - 8) ct = top - ch - 12;
    if (ct < 8) ct = h > H * 0.5 ? H - ch - 14 : Math.max(8, Math.min(H - ch - 8, top + 12));
    var cl = Math.max(12, Math.min(W - cw - 12, left + w / 2 - cw / 2));
    card.style.cssText = "left:".concat(cl, "px;top:").concat(ct, "px");
  },
  finish: function finish() {
    Store.data.toured = true;
    Store.data.onboarded = true;
    Store.save();
    this.stop();
    App.go('home');
    if (this.done) this.done();
  },
  stop: function stop() {
    if (this.root) this.root.remove();
    this.root = null;
    if (this.onKey) document.removeEventListener('keydown', this.onKey, true);
    if (this.onResize) window.removeEventListener('resize', this.onResize);
  }
};
var MOTION_PRESETS = [['fade', 'Fade'], ['zoom_in', 'Zoom In'], ['zoom_out', 'Zoom Out'], ['pop', 'Pop'], ['bounce', 'Bounce'], ['slide_l', 'Slide ←'], ['slide_r', 'Slide →'], ['slide_u', 'Slide ↑'], ['slide_d', 'Slide ↓'], ['rise', 'Rise'], ['drop', 'Drop'], ['spin', 'Spin'], ['swing', 'Swing']];
var FE_SINGLE_UI = {
  punch: 1,
  pulse: 1,
  shake: 1,
  kenburns: 1
};
var SINGLE_PRESETS = [['punch', 'Punch Zoom'], ['pulse', 'Pulse'], ['shake', 'Shake'], ['kenburns', 'Ken Burns']];
var KTRANS = [['push_l', 'Push ←'], ['push_r', 'Push →'], ['push_u', 'Push ↑'], ['push_d', 'Push ↓'], ['zoom', 'Zoom In'], ['zoom_out', 'Zoom Out'], ['spin', 'Spin'], ['flash_zoom', 'Flash Zoom']];
var APV = {
  easeOut: function easeOut(u) {
    return 1 - Math.pow(1 - u, 3);
  },
  backOut: function backOut(u) {
    var c = 1.9;
    return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2);
  },
  elastic: function elastic(u) {
    return u <= 0 ? 0 : u >= 1 ? 1 : Math.pow(2, -10 * u) * Math.sin((u * 10 - 0.75) * (2 * Math.PI) / 3) + 1;
  },
  state: function state(p, u, t) {
    var e = this.easeOut(u),
      st = {
        x: 0,
        y: 0,
        s: 1,
        r: 0,
        o: 1
      };
    switch (p) {
      case 'fade':
        st.o = e;
        break;
      case 'zoom_in':
        st.s = 0.3 + 0.7 * e;
        st.o = Math.min(1, u * 3);
        break;
      case 'zoom_out':
        st.s = 2.4 - 1.4 * e;
        st.o = Math.min(1, u * 3);
        break;
      case 'pop':
        st.s = Math.max(0, this.backOut(u));
        break;
      case 'bounce':
        st.s = Math.max(0, this.elastic(u));
        break;
      case 'slide_l':
        st.x = -70 * (1 - e);
        st.o = Math.min(1, u * 4);
        break;
      case 'slide_r':
        st.x = 70 * (1 - e);
        st.o = Math.min(1, u * 4);
        break;
      case 'slide_u':
        st.y = -34 * (1 - e);
        st.o = Math.min(1, u * 4);
        break;
      case 'slide_d':
        st.y = 34 * (1 - e);
        st.o = Math.min(1, u * 4);
        break;
      case 'rise':
        st.y = 14 * (1 - e);
        st.o = e;
        break;
      case 'drop':
        st.y = -22 * (1 - this.backOut(u));
        st.o = Math.min(1, u * 3);
        break;
      case 'spin':
        st.r = -180 * (1 - e);
        st.s = e;
        break;
      case 'swing':
        st.r = -35 * (1 - this.elastic(u));
        st.o = Math.min(1, u * 4);
        break;
      case 'punch':
        {
          var k = t % 1.6 / 1.6;
          st.s = 1 + 0.35 * Math.max(0, 1 - Math.abs(k - 0.3) / 0.08) * (k > 0.22 ? 1 : 0) + (k > 0.3 && k < 0.6 ? 0.35 * Math.pow(1 - (k - 0.3) / 0.3, 3) : 0);
          break;
        }
      case 'pulse':
        st.s = 1 + 0.12 * (0.5 - 0.5 * Math.cos(t % 1.2 / 1.2 * Math.PI * 2));
        break;
      case 'shake':
        st.x = Math.sin(t * 61) * 3;
        st.y = Math.cos(t * 47) * 2;
        break;
      case 'kenburns':
        {
          var _k = t % 4 / 4;
          st.s = 1 + 0.25 * _k;
          st.x = 6 * _k;
          break;
        }
      default:
        st.o = e;
    }
    return st;
  },
  card: function card(preset) {
    return "<div class=\"apv\" data-apv=\"".concat(preset, "\"><div class=\"apv-t apv-clip\"><svg viewBox=\"0 0 64 36\" preserveAspectRatio=\"xMidYMid slice\"><defs><linearGradient id=\"apvSky\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#3d5bd9\"/><stop offset=\"1\" stop-color=\"#f0a46b\"/></linearGradient></defs><rect width=\"64\" height=\"36\" fill=\"url(#apvSky)\"/><circle cx=\"44\" cy=\"15\" r=\"6\" fill=\"#ffe2a8\"/><path d=\"M0 36 L0 26 L14 16 L24 24 L36 13 L52 26 L64 20 L64 36 Z\" fill=\"#1c2340\"/><path d=\"M0 36 L0 31 L20 27 L40 31 L64 28 L64 36 Z\" fill=\"#11162b\"/></svg></div></div>");
  },
  loop: function loop() {
    var _this17 = this;
    if (this.running) return;
    this.running = true;
    var t0 = Date.now();
    var _tick = function tick() {
      var cards = document.querySelectorAll('.apv');
      if (!cards.length) {
        _this17.running = false;
        return;
      }
      var t = (Date.now() - t0) / 1000;
      cards.forEach(function (c) {
        var p = c.getAttribute('data-apv'),
          words = c.hasAttribute('data-words');
        var single = FE_SINGLE_UI[p];
        var cyc = 2.4,
          k = t % cyc / cyc;
        var fadeOut = single ? 1 : k > 0.88 ? Math.max(0, 1 - (k - 0.88) / 0.08) : 1;
        var apply = function apply(node, st) {
          node.style.transform = "translate(".concat(st.x.toFixed(1), "px,").concat(st.y.toFixed(1), "px) scale(").concat(st.s.toFixed(3), ") rotate(").concat(st.r.toFixed(1), "deg)");
          node.style.opacity = (st.o * fadeOut).toFixed(3);
        };
        if (words) {
          var ws = c.querySelectorAll('i');
          ws.forEach(function (w, i) {
            var u = clamp((k - 0.05 - i * 0.07) / 0.22, 0, 1);
            apply(w, APV.state(p, u, t));
          });
        } else {
          var u = clamp((k - 0.05) / 0.35, 0, 1);
          apply(c.firstChild, APV.state(p, u, t));
        }
      });
      requestAnimationFrame(_tick);
    };
    requestAnimationFrame(_tick);
  }
};
var Animate = {
  effects: null,
  transitions: null,
  loadEffects: function loadEffects(force) {
    var _this18 = this;
    if (this.effects && !force) return Promise.resolve(this.effects);
    return FE.call('listEffects').then(function (d) {
      _this18.effects = d;
      return d;
    });
  },
  loadTransitions: function loadTransitions(force) {
    var _this19 = this;
    if (this.transitions && !force) return Promise.resolve(this.transitions);
    return FE.call('listTransitions').then(function (d) {
      _this19.transitions = d;
      return d;
    });
  }
};
App.registerTool({
  id: 'motion',
  module: 'animate',
  icon: 'motion',
  title: 'Animações',
  desc: 'Entradas, saídas e ênfases com keyframes de verdade',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha entrada ou saída', 'Toque em um estilo'],
  keywords: 'animação keyframe zoom pop slide fade escala posição rotação entrada saída shake punch ken burns',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Aplicar em</label>".concat(UI.seg('where', [['in', 'Entrada'], ['out', 'Saída'], ['both', 'Ambos']], s.where), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('frames', 2, 60, 1, s.frames, ' fr'), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('intensity', 0.2, 2, 0.1, s.intensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('ease', 'Movimento suave', s.ease)).concat(UI.toggle('replace', 'Substituir animação anterior', s.replace), "</div>\n        <div class=\"row\"><label class=\"l\">Curva</label>").concat(UI.seg('motionCurve', [['std', 'Padrão'], ['editor', 'Minha curva']], s.motionCurve || 'std'), "</div>\n      </div></details>\n      <div class=\"apvs\">").concat(MOTION_PRESETS.map(function (p) {
      return "<div class=\"apvc\" data-preset=\"".concat(p[0], "\">").concat(APV.card(p[0]), "<span>").concat(p[1], "</span></div>");
    }).join(''), "</div>\n      <div class=\"section-label\">\xCAnfase</div>\n      <div class=\"row\" style=\"display:none\">").concat(UI.toggle('_atPlayhead', 'Na agulha', true), "</div>\n      <div class=\"apvs\">").concat(SINGLE_PRESETS.map(function (p) {
      return "<div class=\"apvc\" data-preset=\"".concat(p[0], "\">").concat(APV.card(p[0]), "<span>").concat(p[1], "</span></div>");
    }).join(''), "</div>\n      <div class=\"btns\"><button class=\"btn sm\" data-reset>").concat(icon('refresh'), "Limpar anima\xE7\xE3o</button></div>");
    UI.bindSettings(el);
    APV.loop();
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-gocurve]')) return App.openTool('curves');
      var t = e.target.closest('[data-preset]');
      if (t) {
        var s2 = Store.s;
        var preset = t.getAttribute('data-preset');
        var label = (MOTION_PRESETS.concat(SINGLE_PRESETS).find(function (p) {
          return p[0] === preset;
        }) || [0, preset])[1];
        UI.run(t, 'Motion', 'motion', {
          preset: preset,
          where: s2.where,
          frames: s2.frames,
          ease: s2.ease,
          replace: s2.replace,
          intensity: s2.intensity,
          atPlayhead: $('[data-toggle="_atPlayhead"]', el).checked,
          samples: s2.motionCurve === 'editor' && !FE_SINGLE_UI[preset] ? Curves.samples(Curves.current()) : null
        }, function (d) {
          return "".concat(label, " em ").concat(d.clips, " clipe(s) \xB7 ").concat(d.keys, " keyframes");
        });
      }
      if (e.target.closest('[data-reset]')) UI.run(e.target.closest('[data-reset]'), 'Motion', 'resetMotion', {}, function (d) {
        return "Anima\xE7\xE3o removida de ".concat(d.clips, " clipe(s)");
      });
    });
  }
});
App.registerTool({
  id: 'transitions',
  module: 'animate',
  icon: 'transition',
  title: 'Transições de movimento',
  desc: 'Push, zoom e spin no corte entre dois clipes',
  needs: 'clips',
  steps: ['Selecione 2+ clipes colados', 'Ajuste a duração', 'Toque em uma transição'],
  keywords: 'transição push slide whip zoom spin corte vertical horizontal movimento',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>".concat(UI.range('transFrames', 2, 30, 1, s.transFrames, ' fr'), "</div>\n      <div class=\"row\">").concat(UI.toggle('transWhoosh', 'Whoosh no corte', s.transWhoosh), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('transIntensity', 0.3, 1.5, 0.1, s.transIntensity, '×'), "</div>\n        <div class=\"row\"><label class=\"l\">Curva</label>").concat(UI.seg('transCurve', [['std', 'Padrão'], ['editor', 'Minha curva']], s.transCurve || 'std'), "</div>\n      </div></details>\n      <div class=\"tiles\">").concat(KTRANS.map(function (p) {
      return "<div class=\"tile\" data-kt=\"".concat(p[0], "\"><div class=\"pvt pvt-").concat(p[0], "\"><i></i><u></u></div><span>").concat(p[1], "</span></div>");
    }).join(''), "</div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var kt = e.target.closest('[data-kt]');
      if (!kt) return;
      var s2 = Store.s,
        type = kt.getAttribute('data-kt');
      UI.run(kt, 'Transição', 'ktransition', {
        type: type,
        frames: s2.transFrames,
        intensity: s2.transIntensity,
        samples: s2.transCurve === 'editor' ? Curves.samples(Curves.current()) : null
      }, function (d) {
        return "".concat((KTRANS.find(function (k) {
          return k[0] === type;
        }) || [])[1], " em ").concat(d.cuts.length, " corte(s)");
      }).then(function (d) {
        var wh = s2.transWhoosh ? SFX.whoosh() : null;
        if (s2.transWhoosh && !wh) UI.toast('Nenhum whoosh encontrado nas suas pastas de sons.', 'info');
        if (wh && d && d.cuts && d.cuts.length) {
          FE.call('placeSfx', {
            path: wh,
            mode: 'times',
            times: d.cuts,
            offsetFrames: -s2.transFrames,
            track: s2.sfxTrack
          }).then(function (r) {
            return UI.toast("".concat(r.placed, " whoosh(es) adicionados"), 'info');
          }).catch(function (er) {
            return UI.toast(er.message, 'err');
          });
        }
      }).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'native',
  module: 'animate',
  icon: 'zap',
  title: 'Transições do Premiere',
  desc: 'Qualquer transição instalada, em vários clipes de uma vez',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha a transição', 'Toque em Aplicar'],
  keywords: 'transição nativa cross dissolve dip to black lote premiere',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><input class=\"input grow\" data-filter placeholder=\"Buscar transi\xE7\xE3o\u2026\"><button class=\"btn sm\" data-load title=\"Recarregar\">".concat(icon('refresh'), "</button></div>\n      <div class=\"list\" data-tlist><div class=\"empty\">Carregando transi\xE7\xF5es\u2026</div></div>\n      <div class=\"row\"><label class=\"l\">Onde</label>").concat(UI.seg('nativeWhere', [['start', 'Início'], ['end', 'Fim'], ['both', 'Os dois']], s.nativeWhere), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"300\" data-nf value=\"").concat(s.nativeFrames, "\"><span class=\"muted\">frames</span></div>\n      <button class=\"btn primary block\" data-apply disabled>Escolha uma transi\xE7\xE3o na lista</button>");
    UI.bindSettings(el);
    var chosen = null,
      isAudio = false;
    var list = $('[data-tlist]', el),
      filter = $('[data-filter]', el),
      apply = $('[data-apply]', el);
    var draw = function draw() {
      if (!Animate.transitions) return;
      var f = filter.value.trim().toLowerCase(),
        favs = Store.data.transFavs;
      var all = Animate.transitions.video.map(function (n) {
        return [n, false];
      }).concat(Animate.transitions.audio.map(function (n) {
        return [n, true];
      }));
      var rows = all.filter(function (x) {
        return !f || x[0].toLowerCase().includes(f);
      }).sort(function (a, b) {
        return favs.includes(b[0]) - favs.includes(a[0]) || a[1] - b[1];
      });
      list.innerHTML = rows.length ? rows.map(function (x) {
        return "<div class=\"li ".concat(chosen === x[0] ? 'on' : '', "\" data-t=\"").concat(esc(x[0]), "\" data-a=\"").concat(x[1] ? 1 : 0, "\"><span class=\"nm\">").concat(esc(x[0]), "</span><span class=\"sub\">").concat(x[1] ? 'áudio' : 'vídeo', "</span><span class=\"ic ").concat(favs.includes(x[0]) ? 'on' : '', "\" data-fav=\"").concat(esc(x[0]), "\">").concat(icon('star'), "</span></div>");
      }).join('') : '<div class="empty">Nenhuma transição encontrada.</div>';
    };
    var load = function load(btn) {
      if (btn) btn.classList.add('busy');
      Animate.loadTransitions(!!btn).then(draw).catch(function (e) {
        list.innerHTML = "<div class=\"empty\">".concat(esc(e.message), "</div>");
      }).then(function () {
        return btn && btn.classList.remove('busy');
      });
    };
    load();
    filter.addEventListener('input', draw);
    $('[data-nf]', el).addEventListener('change', function (e) {
      return Store.set('nativeFrames', clamp(parseInt(e.target.value, 10) || 15, 1, 300));
    });
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-load]')) return load(e.target.closest('[data-load]'));
      var fav = e.target.closest('[data-fav]');
      if (fav) {
        var n = fav.getAttribute('data-fav'),
          arr = Store.data.transFavs,
          i = arr.indexOf(n);
        if (i >= 0) arr.splice(i, 1);else arr.push(n);
        Store.save();
        draw();
        return;
      }
      var row = e.target.closest('[data-t]');
      if (row) {
        chosen = row.getAttribute('data-t');
        isAudio = row.getAttribute('data-a') === '1';
        apply.disabled = false;
        apply.textContent = "Aplicar \u201C".concat(chosen, "\u201D");
        draw();
        return;
      }
      if (e.target.closest('[data-apply]') && chosen) {
        UI.run(apply, 'Transição', 'nativeTransition', {
          name: chosen,
          audio: isAudio,
          frames: Store.s.nativeFrames,
          where: Store.s.nativeWhere
        }, function (d) {
          return "".concat(d.added, " transi\xE7\xE3o(\xF5es) adicionada(s)").concat(d.failed ? " \xB7 ".concat(d.failed, " falha(s)") : '');
        }).catch(function () {});
      }
    });
  }
});
App.registerTool({
  id: 'effects',
  module: 'animate',
  icon: 'fx',
  title: 'Efeitos & Stacks',
  desc: 'Busque qualquer efeito e salve combinações',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Busque um efeito', 'Toque para aplicar'],
  keywords: 'efeito effect preset stack combinação lumetri blur desfoque favorito lote batch',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"row\">".concat(UI.seg('_fxKind', [['video', 'Vídeo'], ['audio', 'Áudio']], 'video'), "<button class=\"btn sm\" data-load>").concat(icon('refresh'), "</button></div>\n      <div class=\"row\"><input class=\"input grow\" data-filter placeholder=\"Buscar efeito\u2026\"></div>\n      <div class=\"chips\"><span class=\"chip on\" data-chipf=\"all\">Todos</span><span class=\"chip\" data-chipf=\"fav\">\u2605 Favoritos</span></div>\n      <div class=\"list tall\" data-flist><div class=\"empty\">Carregando efeitos\u2026</div></div>\n      <div class=\"section-label\">Montando stack</div>\n      <div class=\"chips\" data-builder></div>\n      <div class=\"btns\"><button class=\"btn sm\" data-applybuild>").concat(icon('check'), "Aplicar stack</button><button class=\"btn sm\" data-savebuild>").concat(icon('plus'), "Salvar stack</button><button class=\"btn sm ghost\" data-clearbuild>").concat(icon('x'), "</button></div>\n      <div class=\"section-label\">Stacks salvos</div>\n      <div class=\"list\" data-stacks></div>");
    var kind = 'video',
      onlyFav = false,
      build = [];
    var list = $('[data-flist]', el),
      filter = $('[data-filter]', el);
    var draw = function draw() {
      if (!Animate.effects) return;
      var f = filter.value.trim().toLowerCase(),
        favs = Store.data.effectFavs;
      var names = (Animate.effects[kind] || []).filter(function (n) {
        return !f || n.toLowerCase().includes(f);
      });
      if (onlyFav) names = names.filter(function (n) {
        return favs.includes(kind + ':' + n);
      });
      names.sort(function (a, b) {
        return favs.includes(kind + ':' + b) - favs.includes(kind + ':' + a) || a.localeCompare(b);
      });
      list.innerHTML = names.length ? names.slice(0, 400).map(function (n) {
        return "<div class=\"li\" data-fx=\"".concat(esc(n), "\"><span class=\"nm\">").concat(esc(n), "</span><span class=\"ic\" data-add=\"").concat(esc(n), "\" title=\"Adicionar ao stack\">").concat(icon('plus'), "</span><span class=\"ic ").concat(favs.includes(kind + ':' + n) ? 'on' : '', "\" data-fav=\"").concat(esc(n), "\">").concat(icon('star'), "</span></div>");
      }).join('') : "<div class=\"empty\">".concat(Animate.effects[kind] && Animate.effects[kind].length ? 'Nenhum efeito encontrado.' : 'Lista vazia — conecte ao Premiere e recarregue.', "</div>");
    };
    var drawBuild = function drawBuild() {
      $('[data-builder]', el).innerHTML = build.length ? build.map(function (n, i) {
        return "<span class=\"chip\" data-rm=\"".concat(i, "\">").concat(esc(n), " \u2715</span>");
      }).join('') : '<span class="hint" style="margin:3px">Vazio — use + na lista</span>';
    };
    var drawStacks = function drawStacks() {
      var st = Store.data.stacks;
      $('[data-stacks]', el).innerHTML = st.length ? st.map(function (x, i) {
        return "<div class=\"li\" data-stack=\"".concat(i, "\"><span class=\"nm\"><b>").concat(esc(x.name), "</b> <span class=\"sub\">").concat(x.audio ? 'áudio · ' : '').concat(x.effects.map(esc).join(' + '), "</span></span><span class=\"ic\" data-stackapply=\"").concat(i, "\" title=\"Aplicar\">").concat(icon('play'), "</span><span class=\"ic\" data-stackdel=\"").concat(i, "\" title=\"Excluir\">").concat(icon('trash'), "</span></div>");
      }).join('') : '<div class="empty">Monte um stack com <b>+</b> e salve para reaplicar com 1 clique.</div>';
    };
    var load = function load(btn) {
      if (btn) btn.classList.add('busy');
      Animate.loadEffects(!!btn).then(draw).catch(function (e) {
        list.innerHTML = "<div class=\"empty\">".concat(esc(e.message), "</div>");
      }).then(function () {
        return btn && btn.classList.remove('busy');
      });
    };
    load();
    drawBuild();
    drawStacks();
    filter.addEventListener('input', draw);
    UI.bindSettings(el, function (k, v) {
      if (k === '_fxKind') {
        kind = v;
        build = [];
        drawBuild();
        draw();
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(s) {
        return e.target.closest(s);
      };
      if (g('[data-load]')) return load(g('[data-load]'));
      var chip = g('[data-chipf]');
      if (chip) {
        onlyFav = chip.getAttribute('data-chipf') === 'fav';
        $$('[data-chipf]', el).forEach(function (c) {
          return c.classList.toggle('on', c === chip);
        });
        draw();
        return;
      }
      if (g('[data-fav]')) {
        var k = kind + ':' + g('[data-fav]').getAttribute('data-fav'),
          a = Store.data.effectFavs,
          i = a.indexOf(k);
        if (i >= 0) a.splice(i, 1);else a.push(k);
        Store.save();
        draw();
        return;
      }
      if (g('[data-add]')) {
        build.push(g('[data-add]').getAttribute('data-add'));
        drawBuild();
        return;
      }
      if (g('[data-rm]')) {
        build.splice(parseInt(g('[data-rm]').getAttribute('data-rm'), 10), 1);
        drawBuild();
        return;
      }
      if (g('[data-clearbuild]')) {
        build = [];
        drawBuild();
        return;
      }
      if (g('[data-applybuild]')) {
        if (!build.length) return UI.toast('Adicione efeitos ao stack com +', 'info');
        return UI.run(g('[data-applybuild]'), 'Stack', 'applyEffects', {
          names: build,
          audio: kind === 'audio'
        }, fxMsg).catch(function () {});
      }
      if (g('[data-savebuild]')) {
        if (!build.length) return UI.toast('Adicione efeitos ao stack com +', 'info');
        return UI.prompt('Nome do stack', 'Meu stack').then(function (name) {
          if (!name) return;
          Store.data.stacks.push({
            id: uid(),
            name: name,
            effects: build.slice(),
            audio: kind === 'audio'
          });
          Store.save();
          build = [];
          drawBuild();
          drawStacks();
          UI.toast('Stack salvo', 'ok');
        });
      }
      if (g('[data-stackapply]')) {
        var st = Store.data.stacks[parseInt(g('[data-stackapply]').getAttribute('data-stackapply'), 10)];
        return UI.run(g('[data-stackapply]'), 'Stack ' + st.name, 'applyEffects', {
          names: st.effects,
          audio: !!st.audio
        }, fxMsg).catch(function () {});
      }
      if (g('[data-stackdel]')) {
        var _i2 = parseInt(g('[data-stackdel]').getAttribute('data-stackdel'), 10);
        return UI.confirm('Excluir stack', "Excluir \u201C".concat(Store.data.stacks[_i2].name, "\u201D?"), 'Excluir').then(function (ok) {
          if (ok) {
            Store.data.stacks.splice(_i2, 1);
            Store.save();
            drawStacks();
          }
        });
      }
      var fx = g('[data-fx]');
      if (fx) UI.run(fx, 'Efeito', 'applyEffects', {
        names: [fx.getAttribute('data-fx')],
        audio: kind === 'audio'
      }, fxMsg).catch(function () {});
    });
  }
});
function fxMsg(d) {
  return "".concat(d.applied, " efeito(s) aplicado(s) em ").concat(d.clips, " clipe(s)").concat(d.missing && d.missing.length ? " \xB7 n\xE3o encontrado: ".concat(d.missing.join(', ')) : '');
}
var TB_N = 120;
var tbNoise = function tbNoise(i) {
  var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
};
var tbSmooth = function tbSmooth(x) {
  var i = Math.floor(x),
    f = x - i,
    e = f * f * (3 - 2 * f);
  return tbNoise(i) + (tbNoise(i + 1) - tbNoise(i)) * e;
};
var bump = function bump(u, c, w) {
  return Math.exp(-Math.pow((u - c) / w, 2));
};
var TAU = Math.PI * 2;
var TB_LOOKS = [{
  id: 'respiro',
  name: 'Respiro',
  period: 3,
  f: function f(u) {
    return 0.5 - 0.5 * Math.cos(TAU * u);
  }
}, {
  id: 'pulsacao',
  name: 'Pulsação',
  period: 1.2,
  f: function f(u) {
    return Math.min(1, bump(u, 0.12, 0.06) + 0.7 * bump(u, 0.34, 0.07));
  }
}, {
  id: 'mare',
  name: 'Maré',
  period: 4.5,
  f: function f(u) {
    return u < 0.7 ? Math.sin(u / 0.7 * Math.PI / 2) : Math.cos((u - 0.7) / 0.3 * Math.PI / 2);
  }
}, {
  id: 'impacto',
  name: 'Impacto',
  period: 1.5,
  f: function f(u) {
    return Math.exp(-u * 7);
  }
}, {
  id: 'tremor',
  name: 'Tremor',
  period: 1,
  f: function f(u) {
    return tbSmooth(u * 9 + 3);
  }
}, {
  id: 'sonho',
  name: 'Sonho',
  period: 6,
  f: function f(u) {
    return 0.55 + 0.3 * Math.sin(TAU * u) + 0.15 * Math.sin(TAU * 3 * u + 1);
  }
}, {
  id: 'flash',
  name: 'Flash',
  period: 1,
  f: function f(u) {
    return u < 0.14 ? 1 : 0.12 + 0.1 * Math.exp(-(u - 0.14) * 8);
  }
}, {
  id: 'trovao',
  name: 'Trovão',
  period: 3.2,
  f: function f(u) {
    return Math.min(1, 0.15 + 0.85 * Math.exp(-u * 5) + 0.55 * bump(u, 0.45, 0.04) + 0.35 * bump(u, 0.62, 0.05));
  }
}, {
  id: 'onda',
  name: 'Onda',
  period: 2,
  f: function f(u) {
    return 0.5 + 0.35 * Math.sin(TAU * u) + 0.15 * Math.sin(TAU * 4 * u);
  }
}, {
  id: 'fantasma',
  name: 'Fantasma',
  period: 2,
  f: function f() {
    return 0.85;
  }
}, {
  id: 'aparicao',
  name: 'Aparição',
  loop: false,
  f: function f(u) {
    return Math.sin(Math.PI * u);
  }
}, {
  id: 'deriva',
  name: 'Deriva',
  loop: false,
  f: function f(u) {
    return u * u * (3 - 2 * u);
  }
}];
var TB_LEVELS = {
  sutil: {
    streak: 1.5,
    echoes: 4,
    glow: 2
  },
  media: {
    streak: 2,
    echoes: 6,
    glow: 4
  },
  forte: {
    streak: 3,
    echoes: 9,
    glow: 8
  }
};
var TimeBlur = {
  look: function look(id) {
    return TB_LOOKS.find(function (l) {
      return l.id === id;
    }) || TB_LOOKS[0];
  },
  samples: function samples(l) {
    var out = [];
    for (var i = 0; i <= TB_N; i++) out.push(Math.max(0, Math.min(1, l.f(i / TB_N))));
    return out;
  },
  thumb: function thumb(l, on) {
    var pts = [],
      reps = l.loop === false ? 1 : 2;
    for (var i = 0; i <= 64; i++) {
      var x = i / 64,
        u = x === 1 ? 1 : x * reps % 1;
      var y = Math.max(0, Math.min(1, l.f(u)));
      pts.push("".concat((4 + x * 56).toFixed(1), ",").concat((44 - y * 36).toFixed(1)));
    }
    return "<svg viewBox=\"0 0 64 52\" class=\"cthumb\"><path d=\"M4 44H60\" class=\"cgrid\"/><path d=\"M".concat(pts.join('L'), "\" class=\"cline").concat(on ? ' on' : '', "\"/></svg>");
  },
  args: function args() {
    var s = Store.s,
      l = this.look(s.tbLook),
      lv = TB_LEVELS[s.tbLevel] || TB_LEVELS.media;
    return {
      samples: this.samples(l),
      period: l.period || 2,
      loop: l.loop !== false,
      streak: lv.streak * (s.tbStreak || 1),
      echoes: s.tbFast !== false ? Math.min(3, lv.echoes) : lv.echoes,
      pulse: s.tbPulse,
      step: s.tbFast !== false ? 2 : 1,
      mix: s.tbMix,
      light: s.tbLight !== false,
      glow: s.tbGlow !== false && s.tbFast === false ? lv.glow : 0,
      shimmer: l.id === 'fantasma' ? 0.2 : 0.1
    };
  }
};
App.registerTool({
  id: 'timeblur',
  module: 'after',
  icon: 'blur',
  title: 'Rastro de luz',
  desc: 'Rastro borrado de movimento nas partes claras',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha um look', 'Toque em Aplicar'],
  keywords: 'time blur echo eco rastro luz ghost fantasma pulso streak trail glow brilho filme sonho shift',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"ctiles\" data-looks></div>\n      <div class=\"row\"><label class=\"l\">Intensidade</label>".concat(UI.seg('tbLevel', [['sutil', 'Sutil'], ['media', 'Média'], ['forte', 'Forte']], s.tbLevel), "</div>\n      <div class=\"row\">").concat(UI.toggle('tbFast', 'Modo leve (reproduz sem travar)', s.tbFast !== false), "</div>\n      <details class=\"adv\"><summary>Ajustes</summary><div>\n        <div class=\"row\"><label class=\"l\">Rastro</label>").concat(UI.range('tbStreak', 0.5, 2.5, 0.1, s.tbStreak, '×'), "</div>\n        <div class=\"row\"><label class=\"l\">Pulso</label>").concat(UI.range('tbPulse', 0, 1, 0.05, s.tbPulse, ''), "</div>\n        <div class=\"row\"><label class=\"l\">Mistura</label>").concat(UI.range('tbMix', 0, 1, 0.05, s.tbMix, ''), "</div>\n        <div class=\"row\">").concat(UI.toggle('tbLight', 'Só nos destaques', s.tbLight !== false)).concat(UI.toggle('tbGlow', 'Rastro borrado', s.tbGlow !== false), "</div>\n      </div></details>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('blur'), "Aplicar</button><button class=\"btn sm\" data-off>").concat(icon('x'), "Desligar</button></div>");
    var draw = function draw() {
      var st = Store.s,
        fav = st.tbFav || [];
      var list = TB_LOOKS.slice().sort(function (a, b) {
        return (fav.indexOf(b.id) >= 0) - (fav.indexOf(a.id) >= 0);
      });
      $('[data-looks]', el).innerHTML = list.map(function (l) {
        var on = l.id === st.tbLook,
          f = fav.indexOf(l.id) >= 0;
        return "<div class=\"ctile lkpv ".concat(on ? 'on' : '', "\" data-look=\"").concat(l.id, "\"><div class=\"pvbox\"><img src=\"assets/prev/tb_").concat(l.id, ".webp\" alt=\"\" loading=\"lazy\" onerror=\"this.style.display='none'\">").concat(TimeBlur.thumb(l, on), "</div><span>").concat(esc(l.name), "</span><em data-fav=\"").concat(l.id, "\" class=\"").concat(f ? 'fav' : '', "\" title=\"Favorito\">").concat(f ? '★' : '☆', "</em></div>");
      }).join('');
    };
    draw();
    UI.bindSettings(el);
    var apply = function apply(btn) {
      return UI.run(btn, 'Rastro de luz', 'timeBlur', TimeBlur.args(), function (d) {
        return "".concat(TimeBlur.look(Store.s.tbLook).name, " em ").concat(d.clips, " clipe(s) \xB7 renderize a pr\xE9via (Enter)");
      });
    };
    el.addEventListener('click', function (e) {
      var fv = e.target.closest('[data-fav]');
      if (fv) {
        e.stopPropagation();
        var id = fv.getAttribute('data-fav'),
          fav = (Store.s.tbFav || []).slice(),
          i = fav.indexOf(id);
        if (i >= 0) fav.splice(i, 1);else fav.push(id);
        Store.set('tbFav', fav);
        draw();
        return;
      }
      var t = e.target.closest('[data-look]');
      if (t) {
        Store.set('tbLook', t.getAttribute('data-look'));
        draw();
        return;
      }
      var ap = e.target.closest('[data-apply]');
      if (ap) return apply(ap);
      var off = e.target.closest('[data-off]');
      if (off) UI.run(off, 'Rastro de luz', 'timeBlur', {
        remove: true
      }, function (d) {
        return "Rastro removido de ".concat(d.clips, " clipe(s)");
      });
    });
  }
});
App.registerTool({
  id: 'beatfx',
  module: 'after',
  icon: 'zap',
  title: 'Efeito na batida',
  desc: 'Punch ou tremor em cada marcador da música',
  needs: 'seq',
  steps: ['Marque as batidas com M', 'Escolha o efeito', 'Toque em Aplicar'],
  keywords: 'batida beat marcador música ritmo punch zoom shake tremor pulso aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Efeito</label>".concat(UI.seg('beatPreset', [['punch', 'Punch'], ['shake', 'Tremor'], ['pulse', 'Pulso']], s.beatPreset), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('beatFrames', 2, 20, 1, s.beatFrames, ' fr'), "</div>\n      <details class=\"adv\"><summary>Ajustes</summary><div>\n        <div class=\"row\"><label class=\"l\">For\xE7a</label>").concat(UI.range('beatIntensity', 0.3, 2, 0.1, s.beatIntensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('beatSfx', 'Som de impacto em cada batida', s.beatSfx), "</div>\n      </div></details>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('zap'), "Aplicar nas batidas</button></div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-apply]');
      if (!b) return;
      var st = Store.s;
      UI.run(b, 'Batida', 'beatFx', {
        preset: st.beatPreset,
        frames: st.beatFrames,
        intensity: st.beatIntensity
      }, function (d) {
        return "".concat(d.done, " batida(s)").concat(d.skipped ? " \xB7 ".concat(d.skipped, " sem clipe") : '');
      }).then(function (d) {
        if (!st.beatSfx || !d || !d.times || !d.times.length) return;
        var hit = SFX.byCat('impact');
        if (!hit) {
          UI.toast('Nenhum som de impacto nas suas pastas.', 'info');
          return;
        }
        FE.call('placeSfx', {
          path: hit,
          mode: 'times',
          times: d.times,
          offsetFrames: 0,
          track: st.sfxTrack
        }).catch(function () {});
      }).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'speedfx',
  module: 'after',
  icon: 'motion',
  title: 'Câmera lenta',
  desc: 'Velocidade dos clipes em um toque',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Toque na velocidade'],
  keywords: 'câmera lenta slow motion velocidade speed 50% 25% rápido 60fps aftermovie same day',
  render: function render(el) {
    var opts = [[25, '25%'], [40, '40%'], [50, '50%'], [100, 'Normal'], [200, '200%']];
    el.innerHTML = "\n      <div class=\"tiles\">".concat(opts.map(function (o) {
      return "<div class=\"tile\" data-speed=\"".concat(o[0], "\"><div class=\"spd\">").concat(o[1], "</div><span>").concat(o[0] < 100 ? 'Lenta' : o[0] > 100 ? 'Rápida' : 'Original', "</span></div>");
    }).join(''), "</div>\n      <div class=\"row\">").concat(UI.toggle('_ripple', 'Empurrar o resto da timeline', false), "</div>");
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-speed]');
      if (!t) return;
      var v = parseInt(t.getAttribute('data-speed'), 10);
      UI.run(t, 'Velocidade', 'batch', {
        op: 'speed',
        value: v,
        ripple: $('[data-toggle="_ripple"]', el).checked
      }, function (d) {
        return "".concat(v, "% em ").concat(d.done, " clipe(s)");
      }).catch(function () {});
    });
  }
});
var FX_LIB = [{
  "n": "Cam Zoom Vai",
  "i": "Cam Zoom Vai",
  "f": "cam-zoom-vai",
  "s": 2.6276,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Cam Zoom Vai e volta",
  "i": "Cam Zoom Vai e volta",
  "f": "cam-zoom-vai-e-volta",
  "s": 4.0457,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Cam Zoom Volta",
  "i": "Cam Zoom Volta",
  "f": "cam-zoom-volta",
  "s": 2.6276,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Degrade",
  "i": "Degrade",
  "f": "degrade",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Halation",
  "i": "Halation",
  "f": "halation",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Zoom",
  "i": "Zoom",
  "f": "zoom",
  "s": 3.003,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Black Blink Flash",
  "i": "Black Blink Flash",
  "f": "black-blink-flash",
  "s": 0.4167,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Destruction 05",
  "i": "Destruction 05",
  "f": "destruction-05",
  "s": 2.9696,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 06",
  "i": "Destruction 06",
  "f": "destruction-06",
  "s": 2.9696,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 07",
  "i": "Destruction 07",
  "f": "destruction-07",
  "s": 2.9696,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 08",
  "i": "Destruction 08",
  "f": "destruction-08",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 09",
  "i": "Destruction 09",
  "f": "destruction-09",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 10",
  "i": "Destruction 10",
  "f": "destruction-10",
  "s": 5.005,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 11",
  "i": "Destruction 11",
  "f": "destruction-11",
  "s": 3.8705,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 12",
  "i": "Destruction 12",
  "f": "destruction-12",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 13",
  "i": "Destruction 13",
  "f": "destruction-13",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 14",
  "i": "Destruction 14",
  "f": "destruction-14",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 15",
  "i": "Destruction 15",
  "f": "destruction-15",
  "s": 2.369,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 16",
  "i": "Destruction 16",
  "f": "destruction-16",
  "s": 3.8705,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 17",
  "i": "Destruction 17",
  "f": "destruction-17",
  "s": 3.8705,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 18",
  "i": "Destruction 18",
  "f": "destruction-18",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 19",
  "i": "Destruction 19",
  "f": "destruction-19",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Destruction 20",
  "i": "Destruction 20",
  "f": "destruction-20",
  "s": 1.2346,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Double Flash",
  "i": "Double Flash",
  "f": "double-flash",
  "s": 0.25,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Extractor Cut Out",
  "i": "Extractor Cut Out",
  "f": "extractor-cut-out",
  "s": 0.2917,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Flashy Blur",
  "i": "Flashy Blur",
  "f": "flashy-blur",
  "s": 0.25,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Ghost Slide",
  "i": "Ghost Slide",
  "f": "ghost-slide",
  "s": 0.3333,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Hard Ghost",
  "i": "Hard Ghost",
  "f": "hard-ghost",
  "s": 1.4167,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Heavy Offset Blur",
  "i": "Heavy Offset Blur",
  "f": "heavy-offset-blur",
  "s": 0.75,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Legacy Camera Shutter",
  "i": "Legacy Camera Shutter",
  "f": "legacy-camera-shutter",
  "s": 0.4167,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Legacy Extractor Directional",
  "i": "Legacy Extractor Directional",
  "f": "legacy-extractor-directional",
  "s": 0.25,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Legacy Extractor Directional 2",
  "i": "Legacy Extractor Directional 2",
  "f": "legacy-extractor-directional-2",
  "s": 0.25,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Legacy Flicker Invert",
  "i": "Legacy Flicker Invert",
  "f": "legacy-flicker-invert",
  "s": 0.4167,
  "c": "trans",
  "k": true,
  "o": [[0.0, 0.0], [0.041666666666666664, 100.0], [0.08333333333333333, 0.0], [0.125, 100.0], [0.16666666666666666, 0.0], [0.20833333333333334, 100.0], [0.25, 0.0], [0.2916666666666667, 100.0], [0.3333333333333333, 0.0]]
}, {
  "n": "Mask",
  "i": "Mask",
  "f": "mask",
  "s": 0.5417,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Mask Swipe Up & Flash",
  "i": "Mask Swipe Up & Flash",
  "f": "mask-swipe-up-flash",
  "s": 0.8523,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Mask Swipe Up",
  "i": "Mask Swipe Up",
  "f": "mask-swipe-up",
  "s": 0.6667,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Night Vision",
  "i": "Night Vision",
  "f": "night-vision",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Opium",
  "i": "Opium",
  "f": "opium",
  "s": 0.75,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Pixel Stretch 01",
  "i": "Pixel Stretch 01",
  "f": "pixel-stretch-01",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Pixel Stretch 02",
  "i": "Pixel Stretch 02",
  "f": "pixel-stretch-02",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Pixel Stretch 00",
  "i": "Pixel Stretch 00",
  "f": "pixel-stretch-00",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Pixel Stretch Horizontal 04",
  "i": "Pixel Stretch Horizontal 04",
  "f": "pixel-stretch-horizontal-04",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Red Flash",
  "i": "Red Flash",
  "f": "red-flash",
  "s": 0.4167,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Radial Blur 25",
  "i": "Radial Blur 25",
  "f": "radial-blur-25",
  "s": 5.0,
  "c": "move",
  "k": false,
  "o": []
}, {
  "n": "Radial Blur",
  "i": "Radial Blur",
  "f": "radial-blur",
  "s": 5.9,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Rapid Flash Extractor",
  "i": "Rapid Flash Extractor",
  "f": "rapid-flash-extractor",
  "s": 0.6256,
  "c": "trans",
  "k": true,
  "o": []
}, {
  "n": "Vhs Stylize",
  "i": "Vhs Stylize",
  "f": "vhs-stylize",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Vhs Stylize Damaged",
  "i": "Vhs Stylize Damaged",
  "f": "vhs-stylize-damaged",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Shaking Blur",
  "i": "Shaking Blur",
  "f": "shaking-blur",
  "s": 3.0417,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Split Screen",
  "i": "Split Screen",
  "f": "split-screen",
  "s": 1.7083,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Split Screen 2",
  "i": "Split Screen 2",
  "f": "split-screen-2",
  "s": 1.2917,
  "c": "move",
  "k": true,
  "o": []
}, {
  "n": "Print Step",
  "i": "Print Step",
  "f": "print-step",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Slow Shutter",
  "i": "Slow Shutter",
  "f": "slow-shutter",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Unique Fish Eye Lens",
  "i": "Unique Fish Eye Lens",
  "f": "unique-fish-eye-lens",
  "s": 5.0,
  "c": "look",
  "k": false,
  "o": []
}, {
  "n": "Whip Smear",
  "i": "Whip Smear",
  "f": "whip-smear",
  "s": 0.8333,
  "c": "move",
  "k": true,
  "o": []
}];
var CURVE_TYPES = [['custom', 'Personalizada'], ['back', 'Back'], ['bounce', 'Bounce'], ['cubic', 'Cubic'], ['elastic', 'Elastic'], ['expo', 'Expo']];
var CURVE_MODES = [['in', 'Entrada'], ['out', 'Saída'], ['inout', 'Ambos']];
var CURVE_PARAMS = {
  back: [['amount', 'Recuo', 0, 4, 0.05, 1.7]],
  bounce: [['bounces', 'Quiques', 1, 6, 1, 3], ['bounciness', 'Altura', 0.1, 0.8, 0.02, 0.4]],
  cubic: [['power', 'Força', 1.5, 6, 0.1, 3]],
  elastic: [['swing', 'Swing', 0.5, 3, 0.02, 1.5], ['osc', 'Oscilações', 1, 12, 0.5, 3], ['damp', 'Amortecimento', 1, 12, 0.1, 6]],
  expo: [['power', 'Força', 3, 16, 0.5, 10]]
};
var Ease = {
  mode: function mode(f, m, x) {
    if (m === 'out') return 1 - f(1 - x);
    if (m === 'inout') return x < 0.5 ? f(2 * x) / 2 : 1 - f(2 - 2 * x) / 2;
    return f(x);
  },
  back: function back(c, x) {
    var s = c.amount === undefined ? 1.7 : c.amount;
    return Ease.mode(function (t) {
      return (s + 1) * t * t * t - s * t * t;
    }, c.mode || 'out', x);
  },
  cubic: function cubic(c, x) {
    var p = c.power || 3;
    return Ease.mode(function (t) {
      return Math.pow(t, p);
    }, c.mode || 'inout', x);
  },
  expo: function expo(c, x) {
    var k = c.power || 10,
      d = Math.pow(2, -k);
    return Ease.mode(function (t) {
      return t <= 0 ? 0 : (Math.pow(2, k * (t - 1)) - d) / (1 - d);
    }, c.mode || 'out', x);
  },
  bounce: function bounce(c, x) {
    var n = Math.round(c.bounces || 3),
      r = c.bounciness || 0.4;
    var segs = [1];
    for (var k = 1; k <= n; k++) segs.push(2 * Math.pow(r, k / 2));
    var tot = segs.reduce(function (a, b) {
      return a + b;
    }, 0);
    var out = function out(t) {
      var T = t * tot;
      if (T <= 1) return T * T;
      T -= 1;
      for (var _k2 = 1; _k2 <= n; _k2++) {
        var d = segs[_k2];
        if (T <= d) {
          var u = (T - d / 2) / (d / 2);
          return 1 - Math.pow(r, _k2) * (1 - u * u);
        }
        T -= d;
      }
      return 1;
    };
    return Ease.mode(function (t) {
      return 1 - out(1 - t);
    }, c.mode || 'out', x);
  },
  elastic: function elastic(c, x) {
    var A = c.swing === undefined ? 1.5 : c.swing,
      osc = c.osc || 3,
      dmp = c.damp || 6;
    var w = Math.PI * (2 * osc - 1);
    var g = function g(t) {
      return Math.exp(-dmp * t) * (Math.cos(w * t) - (A - 1) * Math.sin(w * t) * 0.6);
    };
    var g1 = g(1);
    var out = function out(t) {
      return 1 - (g(t) - g1 * t);
    };
    return Ease.mode(function (t) {
      return 1 - out(1 - t);
    }, c.mode || 'out', x);
  },
  custom: function custom(c, x) {
    var p = c.p || [0.42, 0, 0.58, 1];
    var pts = (c.pts || []).slice().sort(function (a, b) {
      return a[0] - b[0];
    });
    if (!pts.length) return Curves.bezier(p, x);
    var A = [[0, 0]].concat(pts, [[1, 1]]);
    var m = A.map(function (pt, i) {
      if (i === 0) return p[0] > 0.001 ? p[1] / p[0] : p[1] > 0 ? 8 : 0;
      if (i === A.length - 1) return p[2] < 0.999 ? (1 - p[3]) / (1 - p[2]) : p[3] < 1 ? 8 : 0;
      return (A[i + 1][1] - A[i - 1][1]) / Math.max(1e-4, A[i + 1][0] - A[i - 1][0]);
    });
    var i = 0;
    while (i < A.length - 2 && x > A[i + 1][0]) i++;
    var x0 = A[i][0],
      x1 = A[i + 1][0],
      y0 = A[i][1],
      y1 = A[i + 1][1],
      dx = Math.max(1e-4, x1 - x0);
    var t = clamp((x - x0) / dx, 0, 1),
      t2 = t * t,
      t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * dx * m[i] + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * dx * m[i + 1];
  }
};
var CP_ = function CP_(name, c) {
  return Object.assign({
    id: 'p_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_'),
    name: name
  }, c);
};
var CB = function CB(name, p) {
  return CP_(name, {
    type: 'custom',
    p: p,
    pts: []
  });
};
var CURVE_PRESETS = [CB('Linear', [0, 0, 1, 1]), CB('Suave', [0.37, 0, 0.63, 1]), CB('Ease In', [0.42, 0, 1, 1]), CB('Ease Out', [0, 0, 0.58, 1]), CB('Ease In-Out', [0.42, 0, 0.58, 1]), CB('Sine In', [0.12, 0, 0.39, 0]), CB('Sine Out', [0.61, 1, 0.88, 1]), CB('Sine In-Out', [0.37, 0, 0.63, 1]), CP_('Quad In', {
  type: 'cubic',
  mode: 'in',
  power: 2
}), CP_('Quad Out', {
  type: 'cubic',
  mode: 'out',
  power: 2
}), CP_('Quad In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 2
}), CP_('Cubic In', {
  type: 'cubic',
  mode: 'in',
  power: 3
}), CP_('Cubic Out', {
  type: 'cubic',
  mode: 'out',
  power: 3
}), CP_('Cubic In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 3
}), CP_('Quart In', {
  type: 'cubic',
  mode: 'in',
  power: 4
}), CP_('Quart Out', {
  type: 'cubic',
  mode: 'out',
  power: 4
}), CP_('Quart In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 4
}), CP_('Quint In', {
  type: 'cubic',
  mode: 'in',
  power: 5
}), CP_('Quint Out', {
  type: 'cubic',
  mode: 'out',
  power: 5
}), CP_('Quint In-Out', {
  type: 'cubic',
  mode: 'inout',
  power: 5
}), CP_('Expo In', {
  type: 'expo',
  mode: 'in',
  power: 10
}), CP_('Expo Out', {
  type: 'expo',
  mode: 'out',
  power: 10
}), CP_('Expo In-Out', {
  type: 'expo',
  mode: 'inout',
  power: 10
}), CB('Circ In', [0.55, 0, 1, 0.45]), CB('Circ Out', [0, 0.55, 0.45, 1]), CB('Circ In-Out', [0.85, 0, 0.15, 1]), CP_('Back In', {
  type: 'back',
  mode: 'in',
  amount: 1.7
}), CP_('Back Out', {
  type: 'back',
  mode: 'out',
  amount: 1.7
}), CP_('Back In-Out', {
  type: 'back',
  mode: 'inout',
  amount: 1.7
}), CP_('Back Out Forte', {
  type: 'back',
  mode: 'out',
  amount: 3
}), CP_('Elastic Out', {
  type: 'elastic',
  mode: 'out',
  swing: 1.5,
  osc: 3,
  damp: 6
}), CP_('Elastic In', {
  type: 'elastic',
  mode: 'in',
  swing: 1.5,
  osc: 3,
  damp: 6
}), CP_('Elastic In-Out', {
  type: 'elastic',
  mode: 'inout',
  swing: 1.3,
  osc: 2.5,
  damp: 6
}), CP_('Mola Leve', {
  type: 'elastic',
  mode: 'out',
  swing: 1,
  osc: 2,
  damp: 7
}), CP_('Mola Forte', {
  type: 'elastic',
  mode: 'out',
  swing: 2.4,
  osc: 4,
  damp: 4.5
}), CP_('Tremida', {
  type: 'elastic',
  mode: 'out',
  swing: 1.2,
  osc: 8,
  damp: 5
}), CP_('Bounce Out', {
  type: 'bounce',
  mode: 'out',
  bounces: 3,
  bounciness: 0.4
}), CP_('Bounce In', {
  type: 'bounce',
  mode: 'in',
  bounces: 3,
  bounciness: 0.4
}), CP_('Bounce In-Out', {
  type: 'bounce',
  mode: 'inout',
  bounces: 3,
  bounciness: 0.4
}), CP_('Quique Leve', {
  type: 'bounce',
  mode: 'out',
  bounces: 2,
  bounciness: 0.25
}), CB('Snap', [0.9, 0, 0.1, 1]), CB('Snap Out', [0.16, 1, 0.3, 1]), CB('Arrancada', [0.7, 0, 0.84, 0]), CB('Freio', [0.05, 0.7, 0.1, 1]), CB('Zoom Leve', [0.25, 0.1, 0.25, 1]), CB('Pop', [0.34, 1.56, 0.64, 1]), CB('Antecipação', [0.68, -0.6, 0.32, 1.6]), CB('Recua e Vai', [0.36, 0, 0.66, -0.56]), CP_('Ease + Elastic', {
  type: 'elastic',
  mode: 'out',
  swing: 1.1,
  osc: 1.5,
  damp: 5
}), CB('Whip', [0.8, 0, 0.05, 1]), CB('Flutuar', [0.45, 0.05, 0.55, 0.95]), CB('Degrau Suave', [1, 0, 0, 1])];
var Curves = {
  N: 120,
  bezier: function bezier(p, x) {
    var x1 = p[0],
      y1 = p[1],
      x2 = p[2],
      y2 = p[3];
    var bx = function bx(t) {
      return 3 * (1 - t) * (1 - t) * t * x1 + 3 * (1 - t) * t * t * x2 + t * t * t;
    };
    var by = function by(t) {
      return 3 * (1 - t) * (1 - t) * t * y1 + 3 * (1 - t) * t * t * y2 + t * t * t;
    };
    var lo = 0,
      hi = 1,
      t = x;
    for (var i = 0; i < 40; i++) {
      t = (lo + hi) / 2;
      if (bx(t) < x) lo = t;else hi = t;
    }
    return by(t);
  },
  norm: function norm(c) {
    if (!c) return CURVE_PRESETS[1];
    if (c.type) return c;
    if (c.fn === 'bounce') return {
      id: c.id,
      name: c.name,
      type: 'bounce',
      mode: 'out',
      bounces: 3,
      bounciness: 0.4
    };
    if (c.fn === 'elastic') return {
      id: c.id,
      name: c.name,
      type: 'elastic',
      mode: 'out',
      swing: 1.5,
      osc: 3,
      damp: 6
    };
    return {
      id: c.id,
      name: c.name,
      type: 'custom',
      p: (c.p || [0.37, 0, 0.63, 1]).slice(),
      pts: []
    };
  },
  value: function value(c, x) {
    c = this.norm(c);
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    var f = Ease[c.type] || Ease.custom;
    var y = f(c, x);
    return isFinite(y) ? y : x;
  },
  samples: function samples(c) {
    var out = [];
    for (var i = 0; i <= this.N; i++) out.push(Math.round(this.value(c, i / this.N) * 10000) / 10000);
    return out;
  },
  current: function current() {
    return this.norm(Store.s.curve || CURVE_PRESETS[1]);
  },
  range: function range(c) {
    var lo = 0,
      hi = 1;
    for (var i = 0; i <= 80; i++) {
      var y = this.value(c, i / 80);
      if (y < lo) lo = y;
      if (y > hi) hi = y;
    }
    var m = (hi - lo) * 0.1 + 0.04;
    return [lo - m, hi + m];
  },
  path: function path(c, w, h, pad) {
    var r = this.range(c),
      lo = r[0],
      hi = r[1],
      pts = [];
    for (var i = 0; i <= 60; i++) {
      var x = i / 60,
        y = this.value(c, x);
      pts.push("".concat((pad + x * (w - 2 * pad)).toFixed(1), ",").concat((pad + (hi - y) / (hi - lo) * (h - 2 * pad)).toFixed(1)));
    }
    return 'M' + pts.join('L');
  },
  thumb: function thumb(c, on) {
    var r = this.range(c),
      Y = function Y(v) {
        return (6 + (r[1] - v) / (r[1] - r[0]) * 40).toFixed(1);
      };
    return "<svg viewBox=\"0 0 64 52\" class=\"cthumb\"><path d=\"M6 ".concat(Y(0), "H58M6 ").concat(Y(1), "H58\" class=\"cgrid\"/><path d=\"").concat(this.path(c, 64, 52, 6), "\" class=\"cline").concat(on ? ' on' : '', "\"/></svg>");
  },
  clone: function clone(c) {
    return JSON.parse(JSON.stringify(this.norm(c)));
  },
  ofType: function ofType(type, prev) {
    if (type === 'custom') {
      var p = prev && prev.type === 'custom' ? prev.p : [0.42, 0, 0.58, 1];
      return {
        id: 'custom',
        name: 'Personalizada',
        type: 'custom',
        p: p.slice(),
        pts: prev && prev.pts ? prev.pts.slice() : []
      };
    }
    var c = {
      id: type,
      name: (CURVE_TYPES.find(function (t) {
        return t[0] === type;
      }) || [0, type])[1],
      type: type,
      mode: prev && prev.mode ? prev.mode : type === 'cubic' ? 'inout' : 'out'
    };
    (CURVE_PARAMS[type] || []).forEach(function (d) {
      c[d[0]] = d[5];
    });
    return c;
  }
};
App.registerTool({
  id: 'curves',
  module: 'animate',
  icon: 'curve',
  title: 'Curvas de animação',
  desc: 'Suavize os keyframes com gráfico ou presets',
  needs: 'clips',
  steps: ['Selecione clipes com keyframes', 'Escolha a curva', 'Toque em Aplicar'],
  keywords: 'curva easing ease velocidade bezier flow keyo keyframe suavizar overshoot bounce elastic back expo cubic graph gráfico interpolação',
  render: function render(el) {
    var s = Store.s;
    var cur = Curves.clone(Curves.current());
    var tab = s.curveTab || 'graph';
    el.innerHTML = "\n      <div class=\"ctabs\"><button data-ctab=\"graph\">Gr\xE1fico</button><button data-ctab=\"presets\">Presets</button></div>\n      <div data-pane=\"graph\">\n        <select class=\"select ctype\" data-ctype>".concat(CURVE_TYPES.map(function (t) {
      return "<option value=\"".concat(t[0], "\">").concat(t[1], "</option>");
    }).join(''), "</select>\n        <div class=\"curve-box\"><canvas data-cv></canvas></div>\n        <div class=\"chint\" data-chint>Duplo clique adiciona ponto \xB7 clique no ponto apaga</div>\n        <div data-params></div>\n        <div class=\"row cfav-head\"><div class=\"section-label\">Favoritos</div><button class=\"btn sm\" data-save>").concat(icon('plus'), "Salvar preset</button></div>\n        <div class=\"ctiles\" data-mine></div>\n      </div>\n      <div data-pane=\"presets\"><div class=\"ctiles cgrid-all\" data-presets></div></div>\n      <details class=\"adv\"><summary>Onde aplicar</summary><div>\n        <div class=\"row\">").concat(UI.seg('curveSegment', [['all', 'Todos os keyframes'], ['playhead', 'Trecho na agulha']], s.curveSegment || 'all'), "</div>\n        <div class=\"row\">").concat(UI.seg('curveScope', [['motion', 'Movimento'], ['all', 'Todos os efeitos']], s.curveScope || 'motion'), "</div>\n      </div></details>\n      <div class=\"cbar\"><button class=\"btn danger\" data-undo title=\"Volta aos keyframes originais\">").concat(icon('trash'), "Remover</button><button class=\"btn primary grow\" data-apply>").concat(icon('check'), "Aplicar</button></div>");
    var cv = $('[data-cv]', el),
      box = $('.curve-box', el);
    var LO = -0.1,
      HI = 1.1,
      W = 0,
      H = 0;
    var PX = 16,
      PY = 14,
      dpr = window.devicePixelRatio || 1;
    var drag = null,
      moved = false;
    var fit = function fit() {
      var r = Curves.range(cur);
      LO = Math.min(-0.08, r[0]);
      HI = Math.max(1.08, r[1]);
      if (cur.type === 'custom') {
        LO = Math.min(LO, cur.p[1] - 0.06, cur.p[3] - 0.06);
        HI = Math.max(HI, cur.p[1] + 0.06, cur.p[3] + 0.06);
      }
    };
    var toPx = function toPx(x, y) {
      return [PX + x * (W - 2 * PX), PY + (HI - y) / (HI - LO) * (H - 2 * PY)];
    };
    var fromPx = function fromPx(px, py) {
      return [clamp((px - PX) / (W - 2 * PX), 0, 1), HI - (py - PY) / (H - 2 * PY) * (HI - LO)];
    };
    var colors = function colors() {
      var st = getComputedStyle(box);
      return {
        line: st.color,
        grid: st.borderTopColor,
        bg: st.backgroundColor
      };
    };
    var draw = function draw(keepRange) {
      if (!keepRange) fit();
      W = box.clientWidth;
      H = Math.round(W * 0.6);
      cv.width = W * dpr;
      cv.height = H * dpr;
      cv.style.width = W + 'px';
      cv.style.height = H + 'px';
      var g = cv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      var col = colors();
      g.clearRect(0, 0, W, H);
      g.strokeStyle = col.grid;
      g.lineWidth = 1;
      g.globalAlpha = 0.7;
      for (var i = 0; i <= 10; i++) {
        var x = PX + i / 10 * (W - 2 * PX);
        g.beginPath();
        g.moveTo(x, PY);
        g.lineTo(x, H - PY);
        g.stroke();
      }
      for (var _i3 = 0; _i3 <= 6; _i3++) {
        var y = PY + _i3 / 6 * (H - 2 * PY);
        g.beginPath();
        g.moveTo(PX, y);
        g.lineTo(W - PX, y);
        g.stroke();
      }
      g.globalAlpha = 1;
      var _toPx = toPx(0, 0),
        ax = _toPx[0],
        ay = _toPx[1],
        _toPx2 = toPx(1, 1),
        bx = _toPx2[0],
        by = _toPx2[1];
      g.setLineDash([4, 4]);
      g.globalAlpha = 0.5;
      g.strokeStyle = col.line;
      g.beginPath();
      g.moveTo(ax, by);
      g.lineTo(bx, by);
      g.stroke();
      g.setLineDash([]);
      g.globalAlpha = 1;
      var line = [];
      for (var _i4 = 0; _i4 <= 200; _i4++) {
        var _x2 = _i4 / 200;
        line.push(toPx(_x2, Curves.value(cur, _x2)));
      }
      var grad = g.createLinearGradient(0, PY, 0, H - PY);
      grad.addColorStop(0, col.line);
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      g.beginPath();
      g.moveTo(ax, ay);
      line.forEach(function (p) {
        return g.lineTo(p[0], p[1]);
      });
      g.lineTo(bx, ay);
      g.closePath();
      g.globalAlpha = 0.22;
      g.fillStyle = grad;
      g.fill();
      g.globalAlpha = 1;
      g.strokeStyle = col.line;
      g.lineWidth = 3;
      g.lineJoin = 'round';
      g.shadowColor = col.line;
      g.shadowBlur = 10;
      g.beginPath();
      line.forEach(function (p, i) {
        return i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]);
      });
      g.stroke();
      g.shadowBlur = 0;
      var dot = function dot(p, r, filled) {
        g.beginPath();
        g.arc(p[0], p[1], r, 0, 7);
        if (filled) {
          g.fillStyle = col.line;
          g.fill();
        } else {
          g.fillStyle = col.bg;
          g.fill();
          g.lineWidth = 2.5;
          g.strokeStyle = col.line;
          g.stroke();
        }
      };
      if (cur.type === 'custom') {
        var h1 = toPx(cur.p[0], cur.p[1]),
          h2 = toPx(cur.p[2], cur.p[3]);
        g.setLineDash([3, 3]);
        g.lineWidth = 1.5;
        g.globalAlpha = 0.8;
        g.strokeStyle = col.line;
        g.beginPath();
        g.moveTo(ax, ay);
        g.lineTo(h1[0], h1[1]);
        g.moveTo(bx, by);
        g.lineTo(h2[0], h2[1]);
        g.stroke();
        g.setLineDash([]);
        g.globalAlpha = 1;
        dot(h1, 6, false);
        dot(h2, 6, false);
        (cur.pts || []).forEach(function (pt) {
          return dot(toPx(pt[0], pt[1]), 6, true);
        });
      }
      dot([ax, ay], 5, true);
      dot([bx, by], 5, true);
    };
    var renderParams = function renderParams() {
      $('[data-ctype]', el).value = cur.type;
      $('[data-chint]', el).style.display = cur.type === 'custom' ? '' : 'none';
      var defs = CURVE_PARAMS[cur.type] || [];
      $('[data-params]', el).innerHTML = cur.type === 'custom' ? '' : "\n        <div class=\"row\">".concat(UI.seg('_cmode', CURVE_MODES, cur.mode || 'out'), "</div>\n        <div class=\"cparams\">").concat(defs.map(function (d) {
        return "<label class=\"cparam\"><span>".concat(d[1], "</span><b data-pv=\"").concat(d[0], "\">").concat(cur[d[0]], "</b><input type=\"range\" data-cp=\"").concat(d[0], "\" min=\"").concat(d[2], "\" max=\"").concat(d[3], "\" step=\"").concat(d[4], "\" value=\"").concat(cur[d[0]], "\"></label>");
      }).join(''), "</div>");
    };
    var persist = function persist() {
      Store.set('curve', cur);
      drawMine();
      drawPresets();
    };
    var setCur = function setCur(c) {
      cur = Curves.clone(c);
      renderParams();
      draw();
      persist();
    };
    var drawPresets = function drawPresets() {
      var favIds = (Store.data.curvePresets || []).map(function (c) {
        return c.from;
      });
      $('[data-presets]', el).innerHTML = CURVE_PRESETS.map(function (c) {
        return "<div class=\"ctile ".concat(cur.id === c.id ? 'on' : '', "\" data-preset=\"").concat(c.id, "\" title=\"").concat(esc(c.name), "\">").concat(Curves.thumb(c, cur.id === c.id), "<span>").concat(esc(c.name), "</span><em data-favp=\"").concat(c.id, "\" class=\"").concat(favIds.indexOf(c.id) >= 0 ? 'fav' : '', "\">").concat(favIds.indexOf(c.id) >= 0 ? '★' : '☆', "</em></div>");
      }).join('');
    };
    var drawMine = function drawMine() {
      var mine = Store.data.curvePresets || [];
      $('[data-mine]', el).innerHTML = mine.length ? mine.map(function (c, i) {
        return "<div class=\"ctile ".concat(cur.id === c.id ? 'on' : '', "\" data-mine=\"").concat(i, "\" title=\"").concat(esc(c.name), "\">").concat(Curves.thumb(c, cur.id === c.id), "<span>").concat(esc(c.name), "</span><em data-delmine=\"").concat(i, "\" title=\"Excluir\">\xD7</em></div>");
      }).join('') : '<div class="muted chint">Salve suas curvas favoritas aqui.</div>';
    };
    var showTab = function showTab(t) {
      tab = t;
      Store.set('curveTab', t);
      $$('[data-ctab]', el).forEach(function (b) {
        return b.classList.toggle('on', b.getAttribute('data-ctab') === t);
      });
      $$('[data-pane]', el).forEach(function (p) {
        p.style.display = p.getAttribute('data-pane') === t ? '' : 'none';
      });
      if (t === 'graph') setTimeout(function () {
        return draw();
      }, 10);
    };
    var pos = function pos(e) {
      var r = cv.getBoundingClientRect();
      return [e.clientX - r.left, e.clientY - r.top];
    };
    var hit = function hit(mx, my) {
      var cands = [];
      var h1 = toPx(cur.p[0], cur.p[1]),
        h2 = toPx(cur.p[2], cur.p[3]);
      cands.push({
        k: 'h',
        i: 0,
        d: Math.hypot(h1[0] - mx, h1[1] - my)
      }, {
        k: 'h',
        i: 1,
        d: Math.hypot(h2[0] - mx, h2[1] - my)
      });
      (cur.pts || []).forEach(function (pt, i) {
        var q = toPx(pt[0], pt[1]);
        cands.push({
          k: 'p',
          i: i,
          d: Math.hypot(q[0] - mx, q[1] - my)
        });
      });
      cands.sort(function (a, b) {
        return a.d - b.d;
      });
      return cands[0] && cands[0].d < 16 ? cands[0] : null;
    };
    cv.addEventListener('mousedown', function (e) {
      if (cur.type !== 'custom') return;
      var _pos = pos(e),
        mx = _pos[0],
        my = _pos[1];
      drag = hit(mx, my);
      moved = false;
      if (drag) e.preventDefault();
    });
    var move = function move(e) {
      if (!drag) return;
      var _pos2 = pos(e),
        mx = _pos2[0],
        my = _pos2[1],
        xy = fromPx(mx, my),
        x = Math.round(xy[0] * 100) / 100,
        y = Math.round(xy[1] * 100) / 100;
      moved = true;
      if (drag.k === 'h') {
        cur.p[drag.i * 2] = x;
        cur.p[drag.i * 2 + 1] = y;
      } else cur.pts[drag.i] = [clamp(x, 0.02, 0.98), y];
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw(true);
    };
    var up = function up() {
      if (!drag) return;
      if (!moved && drag.k === 'p') cur.pts.splice(drag.i, 1);
      drag = null;
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw();
      persist();
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
    cv.addEventListener('dblclick', function (e) {
      if (cur.type !== 'custom') {
        setCur(Curves.ofType('custom', cur));
        return;
      }
      var _pos3 = pos(e),
        mx = _pos3[0],
        my = _pos3[1],
        xy = fromPx(mx, my);
      if (hit(mx, my)) return;
      cur.pts = (cur.pts || []).concat([[clamp(Math.round(xy[0] * 100) / 100, 0.02, 0.98), Math.round(xy[1] * 100) / 100]]).sort(function (a, b) {
        return a[0] - b[0];
      });
      cur.id = 'custom';
      cur.name = 'Personalizada';
      draw();
      persist();
    });
    window.addEventListener('resize', function () {
      if (document.body.contains(el) && !drag && tab === 'graph') draw();
    });
    $('[data-ctype]', el).addEventListener('change', function (e) {
      return setCur(Curves.ofType(e.target.value, cur));
    });
    el.addEventListener('input', function (e) {
      var k = e.target.getAttribute('data-cp');
      if (!k) return;
      cur[k] = parseFloat(e.target.value);
      var o = $("[data-pv=\"".concat(k, "\"]"), el);
      if (o) o.textContent = cur[k];
      cur.id = cur.type;
      cur.name = (CURVE_TYPES.find(function (t) {
        return t[0] === cur.type;
      }) || [0, ''])[1];
      draw();
    });
    el.addEventListener('change', function (e) {
      if (e.target.getAttribute('data-cp')) persist();
    });
    UI.bindSettings(el, function (key, v) {
      if (key === '_cmode') {
        cur.mode = v;
        draw();
        persist();
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      if (g('[data-ctab]')) return showTab(g('[data-ctab]').getAttribute('data-ctab'));
      if (g('[data-favp]')) {
        e.stopPropagation();
        var id = g('[data-favp]').getAttribute('data-favp'),
          list = (Store.data.curvePresets || []).slice();
        var i = list.findIndex(function (c) {
          return c.from === id;
        });
        if (i >= 0) list.splice(i, 1);else {
          var c = Curves.clone(CURVE_PRESETS.find(function (x) {
            return x.id === id;
          }));
          c.from = id;
          c.id = 'u_' + uid();
          list.push(c);
        }
        Store.data.curvePresets = list;
        Store.save();
        drawPresets();
        drawMine();
        return;
      }
      if (g('[data-delmine]')) {
        e.stopPropagation();
        Store.data.curvePresets.splice(parseInt(g('[data-delmine]').getAttribute('data-delmine'), 10), 1);
        Store.save();
        drawMine();
        drawPresets();
        return;
      }
      if (g('[data-preset]')) {
        setCur(CURVE_PRESETS.find(function (x) {
          return x.id === g('[data-preset]').getAttribute('data-preset');
        }));
        return;
      }
      if (g('[data-mine]')) {
        setCur(Store.data.curvePresets[parseInt(g('[data-mine]').getAttribute('data-mine'), 10)]);
        return;
      }
      if (g('[data-save]')) {
        return UI.prompt('Nome do preset', "Preset ".concat((Store.data.curvePresets || []).length + 1)).then(function (name) {
          if (!name) return;
          var c = Curves.clone(cur);
          c.id = 'u_' + uid();
          c.name = name;
          delete c.from;
          Store.data.curvePresets = (Store.data.curvePresets || []).concat([c]);
          Store.save();
          cur = Curves.clone(c);
          persist();
          UI.toast('Preset salvo nos favoritos', 'ok');
        });
      }
      var st = Store.s;
      var args = {
        scope: st.curveScope || 'motion',
        segment: st.curveSegment || 'all',
        step: 1
      };
      if (g('[data-apply]')) {
        UI.run(g('[data-apply]'), 'Curva', 'applyCurve', Object.assign(args, {
          samples: Curves.samples(cur)
        }), function (d) {
          return "\u201C".concat(cur.name || 'Curva', "\u201D em ").concat(d.segments, " trecho(s) \xB7 ").concat(d.params, " propriedade(s)");
        }).catch(function () {});
      }
      if (g('[data-undo]')) {
        UI.run(g('[data-undo]'), 'Curva', 'applyCurve', Object.assign(args, {
          remove: true
        }), function (d) {
          return "Keyframes originais de volta em ".concat(d.segments, " trecho(s)");
        }).catch(function () {});
      }
    });
    renderParams();
    drawMine();
    drawPresets();
    showTab(tab);
  }
});
(function () {
  var i = App.tools.findIndex(function (t) {
      return t.id === 'curves';
    }),
    j = App.tools.findIndex(function (t) {
      return t.id === 'motion';
    });
  if (i > j + 1) App.tools.splice(j + 1, 0, App.tools.splice(i, 1)[0]);
})();
var FX_CATS = [['trans', 'Transições'], ['move', 'Movimento'], ['look', 'Looks']];
var FX = {
  tpl: function tpl(fx) {
    return FE.inCEP ? FE.sysPath('extension').replace(/\\/g, '/') + '/assets/fx/items/' + fx.f + '.prproj' : '';
  },
  sized: function sized(fx) {
    var r = Sized.make(this.tpl(fx), [fx.i]);
    return {
      item: fx.i + r.tag,
      tpl: r.tpl
    };
  },
  apply: function apply(fx, btn) {
    var sel = App.info && App.info.seq && App.info.seq.selected || 0;
    var mode;
    if (fx.c === 'trans') mode = sel >= 2 ? 'cuts' : 'centerPlayhead';else if (fx.c === 'move' && fx.k) mode = sel ? 'clipStart' : 'playhead';else mode = sel ? 'perClip' : 'playhead';
    var t = this.sized(fx);
    return UI.run(btn, 'Efeito', 'overlay', {
      kind: 'fx',
      fxItem: t.item,
      fxTemplate: t.tpl,
      mode: mode,
      seconds: fx.s,
      opacity: fx.o && fx.o.length ? fx.o : null,
      clipFx: fx.w || null,
      label: fx.n
    }, function (d) {
      return "".concat(fx.n, " \xB7 ").concat(d.placed, " camada(s)");
    });
  }
};
App.registerTool({
  id: 'fxlib',
  module: 'after',
  icon: 'fx',
  title: 'Efeitos prontos',
  desc: 'Transições, movimentos e looks prontos em 1 clique',
  needs: 'seq',
  steps: ['Selecione os takes (ou posicione a agulha)', 'Toque no efeito'],
  keywords: 'efeito preset transição flash ghost vhs retro glitch zoom shake destruction mask split night vision opium print step aftermovie same day',
  render: function render(el) {
    var cat = Store.s.fxCat || 'trans',
      q = '';
    el.innerHTML = "\n      <div class=\"row\"><input class=\"input grow\" data-fxq placeholder=\"Buscar efeito\u2026\"></div>\n      <div class=\"chips\" data-fxcats></div>\n      <div class=\"fxgrid\" data-fxlist></div>";
    var draw = function draw() {
      var favs = Store.data.fxFavs || [];
      var counts = {
        fav: favs.length
      };
      FX_LIB.forEach(function (f) {
        counts[f.c] = (counts[f.c] || 0) + 1;
      });
      $('[data-fxcats]', el).innerHTML = [['fav', '★ Favoritos']].concat(FX_CATS).map(function (c) {
        return "<span class=\"chip ".concat(cat === c[0] ? 'on' : '', "\" data-fxcat=\"").concat(c[0], "\">").concat(c[1], "<em>").concat(counts[c[0]] || 0, "</em></span>");
      }).join('');
      var ql = q.toLowerCase();
      var rows = FX_LIB.filter(function (f) {
        return ql ? f.n.toLowerCase().includes(ql) : cat === 'fav' ? favs.includes(f.i) : f.c === cat;
      });
      $('[data-fxlist]', el).innerHTML = rows.length ? rows.map(function (f) {
        return "<div class=\"fxcard\" data-fx=\"".concat(esc(f.i), "\" title=\"").concat(esc(f.n), "\">\n          <div class=\"fxpv\"><img src=\"assets/prev/fx_").concat(f.f, ".webp\" alt=\"\" loading=\"lazy\" onerror=\"this.parentNode.className='fxpv none'\"><span class=\"fxic\">").concat(icon(f.c === 'trans' ? 'transition' : f.c === 'move' ? 'motion' : 'fx'), "</span></div>\n          <b>").concat(esc(f.n), "</b><small>").concat(f.k ? Math.max(1, Math.round(f.s * 30)) + ' fr' : 'look', "</small>\n          <em data-fxfav=\"").concat(esc(f.i), "\" class=\"").concat(favs.includes(f.i) ? 'on' : '', "\">").concat(favs.includes(f.i) ? '★' : '☆', "</em></div>");
      }).join('') : "<div class=\"empty\">".concat(cat === 'fav' && !ql ? 'Toque na ☆ de um efeito para guardar aqui.' : 'Nenhum efeito encontrado.', "</div>");
    };
    draw();
    $('[data-fxq]', el).addEventListener('input', function (e) {
      q = e.target.value;
      draw();
    });
    el.addEventListener('click', function (e) {
      var g = function g(s) {
        return e.target.closest(s);
      };
      if (g('[data-fxcat]')) {
        cat = g('[data-fxcat]').getAttribute('data-fxcat');
        Store.set('fxCat', cat);
        draw();
        return;
      }
      if (g('[data-fxfav]')) {
        e.stopPropagation();
        var id = g('[data-fxfav]').getAttribute('data-fxfav'),
          a = Store.data.fxFavs = Store.data.fxFavs || [],
          i = a.indexOf(id);
        if (i >= 0) a.splice(i, 1);else a.push(id);
        Store.save();
        draw();
        return;
      }
      var c = g('[data-fx]');
      if (c) {
        var fx = FX_LIB.find(function (f) {
          return f.i === c.getAttribute('data-fx');
        });
        if (fx) FX.apply(fx, c).catch(function () {});
      }
    });
  }
});
var GRID_PATTERNS = [['random', 'Aleatório'], ['center', 'Para o centro'], ['out', 'Do centro'], ['left', 'Da esquerda'], ['top', 'De cima'], ['diag', 'Diagonal']];
var hexRgb = function hexRgb(h) {
  var m = /^#?([0-9a-f]{6})$/i.exec(h || '');
  var n = m ? parseInt(m[1], 16) : 0xffffff;
  return [n >> 16 & 255, n >> 8 & 255, n & 255];
};
var Grid = {
  order: function order(cols, rows, pattern) {
    var x = 7;
    var rnd = function rnd() {
      x = (x * 1664525 + 1013904223) % 4294967296;
      return x / 4294967296;
    };
    var cx = (cols - 1) / 2,
      cy = (rows - 1) / 2,
      cells = [];
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
      var dist = Math.sqrt((c - cx) * (c - cx) + (r - cy) * (r - cy));
      var k = void 0;
      if (pattern === 'center') k = -dist + rnd() * 0.3;else if (pattern === 'out') k = dist + rnd() * 0.3;else if (pattern === 'left') k = c + rnd() * 0.5;else if (pattern === 'top') k = r + rnd() * 0.5;else if (pattern === 'diag') k = c + r + rnd() * 0.5;else k = rnd();
      cells.push({
        i: r * cols + c,
        k: k
      });
    }
    cells.sort(function (a, b) {
      return a.k - b.k;
    });
    var rank = [];
    cells.forEach(function (cell, n) {
      rank[cell.i] = n;
    });
    return rank;
  },
  linesPNG: function linesPNG(cols, rows, thick, color) {
    var sq = App.info && App.info.seq || {},
      W = sq.w || 1920,
      H = sq.h || 1080;
    var c = Gen.canvas(W, H),
      g = c.getContext('2d');
    g.fillStyle = color;
    for (var i = 1; i < cols; i++) {
      var x = Math.round(i * W / cols - thick / 2);
      g.fillRect(x, 0, thick, H);
    }
    for (var j = 1; j < rows; j++) {
      var y = Math.round(j * H / rows - thick / 2);
      g.fillRect(0, y, W, thick);
    }
    return Gen.savePNG(c, "grid_".concat(W, "x").concat(H, "_").concat(cols, "x").concat(rows, "_").concat(thick, "_").concat(color.replace('#', ''), ".png"));
  },
  preview: function preview(el) {
    var s = Store.s,
      cols = s.gridCols,
      rows = s.gridRows;
    var box = $('[data-gridpv]', el);
    box.style.gridTemplateColumns = "repeat(".concat(cols, ", 1fr)");
    box.style.gap = s.gridLines ? "".concat(Math.max(1, Math.round(s.gridThick / 2)), "px") : '0';
    box.style.background = s.gridLines ? s.gridLineColor : '#15161a';
    var n = cols * rows;
    var kf = document.getElementById('gridKf');
    if (!kf) {
      kf = document.createElement('style');
      kf.id = 'gridKf';
      document.head.appendChild(kf);
    }
    var hl = s.gridFlash ? s.gridFlashColor : '#e9a46b';
    kf.textContent = "@keyframes gridFlip { 0%, 8% { background: #3d5bd9; } 12% { background: ".concat(hl, "; } 24%, 90% { background: #e9a46b; } 100% { background: #3d5bd9; } } @-webkit-keyframes gridFlip { 0%, 8% { background: #3d5bd9; } 12% { background: ").concat(hl, "; } 24%, 90% { background: #e9a46b; } 100% { background: #3d5bd9; } }");
    var rank = this.order(cols, rows, s.gridPattern || 'random');
    box.innerHTML = Array.from({
      length: n
    }, function (_, i) {
      return "<i style=\"animation-delay:".concat(Math.round((n > 1 ? rank[i] / (n - 1) : 0) * 1500), "ms\"></i>");
    }).join('');
  }
};
App.registerTool({
  id: 'grid',
  module: 'after',
  icon: 'batch',
  title: 'Transição em grid',
  desc: 'A imagem troca em quadrículas no corte, com cor de destaque',
  needs: 'clips',
  steps: ['Selecione os takes colados', 'Ajuste quadrados, linhas e cor', 'Toque em Aplicar'],
  keywords: 'grid grade quadrícula quadrados blocos colunas filas linhas destaque clarão flash transição corte aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"gridpv\" data-gridpv></div>\n      <div class=\"row\"><label class=\"l\">Colunas</label>".concat(UI.range('gridCols', 2, 10, 1, s.gridCols, ''), "</div>\n      <div class=\"row\"><label class=\"l\">Filas</label>").concat(UI.range('gridRows', 2, 10, 1, s.gridRows, ''), "</div>\n      <div class=\"row\"><label class=\"l\">Padr\xE3o</label>").concat(UI.select('gridPattern', GRID_PATTERNS, s.gridPattern, 'grow'), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('gridFrames', 8, 48, 1, s.gridFrames, ' fr'), "</div>\n      <div class=\"section-label\">Linhas</div>\n      <div class=\"row\">").concat(UI.toggle('gridLines', 'Mostrar linhas', s.gridLines), "<input type=\"color\" class=\"swatch\" data-gcolor=\"gridLineColor\" value=\"").concat(s.gridLineColor, "\" title=\"Cor das linhas\"></div>\n      <div class=\"row\"><label class=\"l\">Grossura</label>").concat(UI.range('gridThick', 1, 20, 1, s.gridThick, ' px'), "</div>\n      <div class=\"section-label\">Cor de destaque na troca</div>\n      <div class=\"row\">").concat(UI.toggle('gridFlash', 'Destacar cada quadrado', s.gridFlash), "<input type=\"color\" class=\"swatch\" data-gcolor=\"gridFlashColor\" value=\"").concat(s.gridFlashColor, "\" title=\"Cor do destaque\"></div>\n      <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('gridFlashI', 10, 100, 5, s.gridFlashI, '%'), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('gridFlashF', 1, 20, 1, s.gridFlashF, ' fr'), "</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('batch'), "Aplicar</button></div>");
    UI.bindSettings(el, function () {
      return Grid.preview(el);
    });
    el.addEventListener('change', function (e) {
      if (e.target.getAttribute('data-select') === 'gridPattern') {
        Store.set('gridPattern', e.target.value);
        Grid.preview(el);
      }
    });
    var onColor = function onColor(e) {
      var k = e.target.getAttribute('data-gcolor');
      if (k) {
        Store.set(k, e.target.value);
        Grid.preview(el);
      }
    };
    el.addEventListener('input', onColor);
    el.addEventListener('change', onColor);
    Grid.preview(el);
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-apply]');
      if (!b) return;
      var st = Store.s;
      var lines = null;
      if (st.gridLines && FS.ok) {
        try {
          lines = Grid.linesPNG(st.gridCols, st.gridRows, st.gridThick, st.gridLineColor);
        } catch (err) {
          lines = null;
        }
      }
      UI.run(b, 'Grid', 'gridTransition', {
        cols: st.gridCols,
        rows: st.gridRows,
        frames: st.gridFrames,
        pattern: st.gridPattern,
        seed: Math.floor(Math.random() * 1e6),
        linesPng: lines,
        flash: !!st.gridFlash,
        flashColor: hexRgb(st.gridFlashColor),
        flashIntensity: st.gridFlashI,
        flashFrames: st.gridFlashF
      }, function (d) {
        return "Grid ".concat(st.gridCols, "\xD7").concat(st.gridRows, " em ").concat(d.cuts, " corte(s)").concat(d.noTint ? ' · não achei o efeito Tingir (Tint): o destaque ficou de fora' : '').concat(d.noHandle ? ' · sem sobra nos takes: o grid entra no fim do take anterior' : d.clipped ? ' · alguns takes tinham pouca sobra' : '');
      }).catch(function () {});
    });
  }
});
var MC = {
  takes: [],
  meta: null,
  timer: 0,
  subject: function subject(img) {
    var W = 96,
      H = 54,
      n = W * H,
      cv = document.createElement('canvas');
    cv.width = W;
    cv.height = H;
    var g = cv.getContext('2d');
    g.drawImage(img, 0, 0, W, H);
    var d = g.getImageData(0, 0, W, H).data;
    var L = new Float32Array(n),
      S = new Float32Array(n),
      K = new Float32Array(n);
    for (var i = 0; i < n; i++) {
      var r = d[i * 4],
        gg = d[i * 4 + 1],
        b = d[i * 4 + 2],
        mx = Math.max(r, gg, b),
        mn = Math.min(r, gg, b);
      L[i] = 0.299 * r + 0.587 * gg + 0.114 * b;
      S[i] = mx ? (mx - mn) / mx : 0;
      K[i] = r > 95 && gg > 40 && b > 20 && r > gg && r > b && r - gg > 15 && mx - mn > 15 ? 1 : 0;
    }
    var I = new Float32Array((W + 1) * (H + 1));
    for (var y = 0; y < H; y++) {
      var row = 0;
      for (var x = 0; x < W; x++) {
        row += L[y * W + x];
        I[(y + 1) * (W + 1) + x + 1] = I[y * (W + 1) + x + 1] + row;
      }
    }
    var R = 7,
      w = new Float32Array(n);
    var mE = 1e-6,
      mC = 1e-6;
    var E = new Float32Array(n),
      C = new Float32Array(n);
    for (var _y2 = 1; _y2 < H - 1; _y2++) {
      for (var _x3 = 1; _x3 < W - 1; _x3++) {
        var _i5 = _y2 * W + _x3;
        var gx = L[_i5 - W + 1] + 2 * L[_i5 + 1] + L[_i5 + W + 1] - L[_i5 - W - 1] - 2 * L[_i5 - 1] - L[_i5 + W - 1];
        var gy = L[_i5 + W - 1] + 2 * L[_i5 + W] + L[_i5 + W + 1] - L[_i5 - W - 1] - 2 * L[_i5 - W] - L[_i5 - W + 1];
        E[_i5] = Math.sqrt(gx * gx + gy * gy);
        var x0 = Math.max(0, _x3 - R),
          x1 = Math.min(W, _x3 + R + 1),
          y0 = Math.max(0, _y2 - R),
          y1 = Math.min(H, _y2 + R + 1);
        var sum = I[y1 * (W + 1) + x1] - I[y0 * (W + 1) + x1] - I[y1 * (W + 1) + x0] + I[y0 * (W + 1) + x0];
        C[_i5] = Math.abs(L[_i5] - sum / ((x1 - x0) * (y1 - y0)));
        if (E[_i5] > mE) mE = E[_i5];
        if (C[_i5] > mC) mC = C[_i5];
      }
    }
    for (var _y3 = 0; _y3 < H; _y3++) {
      for (var _x4 = 0; _x4 < W; _x4++) {
        var _i6 = _y3 * W + _x4,
          dx = (_x4 + 0.5) / W - 0.5,
          dy = (_y3 + 0.5) / H - 0.5;
        var bias = 0.35 + 0.65 * Math.exp(-(dx * dx + dy * dy) / (2 * 0.28 * 0.28));
        w[_i6] = (0.55 * E[_i6] / mE + C[_i6] / mC + 0.3 * S[_i6] + 0.45 * K[_i6]) * bias;
      }
    }
    var sorted = Array.prototype.slice.call(w).sort(function (a, b) {
        return a - b;
      }),
      thr = sorted[Math.floor(n * 0.86)];
    var sx = 0,
      sy = 0,
      sw = 0;
    for (var _i7 = 0; _i7 < n; _i7++) {
      var v = w[_i7] - thr;
      if (v > 0) {
        sx += v * (_i7 % W + 0.5) / W;
        sy += v * (Math.floor(_i7 / W) + 0.5) / H;
        sw += v;
      }
    }
    var cl = function cl(v) {
      return Math.max(0.12, Math.min(0.88, v));
    };
    return sw ? [cl(sx / sw), cl(sy / sw)] : [0.5, 0.5];
  },
  locate: function locate(img) {
    var _this20 = this;
    var fallback = function fallback() {
      return _this20.subject(img);
    };
    if (typeof window.FaceDetector !== 'function') return Promise.resolve(fallback());
    var det;
    try {
      det = new window.FaceDetector({
        fastMode: true,
        maxDetectedFaces: 5
      });
    } catch (e) {
      return Promise.resolve(fallback());
    }
    return det.detect(img).then(function (faces) {
      if (!faces || !faces.length) return fallback();
      var W = img.naturalWidth || img.width,
        H = img.naturalHeight || img.height;
      var f = faces.slice().sort(function (a, b) {
        return b.boundingBox.width * b.boundingBox.height - a.boundingBox.width * a.boundingBox.height;
      })[0].boundingBox;
      return [(f.x + f.width / 2) / W, (f.y + f.height / 2) / H];
    }).catch(fallback);
  },
  need: function need(c, t) {
    for (var k = 1; k <= 1.55; k += 0.01) {
      if (Math.abs(t[0] - 0.5 - k * (c[0] - 0.5)) <= (k - 1) / 2 + 1e-4 && Math.abs(t[1] - 0.5 - k * (c[1] - 0.5)) <= (k - 1) / 2 + 1e-4) return k;
    }
    return 1.55;
  },
  plan: function plan() {
    var _this21 = this;
    var s = Store.s,
      tk = this.takes,
      m = this.meta;
    if (!tk.length || !m) return [];
    var order = [];
    for (var l = 0; l < s.mcLoops; l++) tk.forEach(function (t, i) {
      return order.push(i);
    });
    var n = order.length,
      f = s.mcFrames,
      fps = m.fps || 30;
    var durs = order.map(function () {
      return f;
    });
    if (s.mcRhythm === 'accel' || s.mcRhythm === 'decel') {
      durs = order.map(function (_, i) {
        var u = n > 1 ? i / (n - 1) : 0;
        if (s.mcRhythm === 'decel') u = 1 - u;
        return Math.max(1, Math.round(f * 2.5 + (Math.max(1, f * 0.5) - f * 2.5) * Math.pow(u, 0.8)));
      });
    } else if (s.mcRhythm === 'beats') {
      var at = m.at || 0,
        mk = (m.markers || []).filter(function (x) {
          return x > at + 0.5 / fps;
        }).sort(function (a, b) {
          return a - b;
        });
      var prev = at;
      durs = order.map(function (_, i) {
        if (i < mk.length) {
          var d = Math.max(1, Math.round((mk[i] - prev) * fps));
          prev = mk[i];
          return d;
        }
        return f;
      });
    }
    var align = s.mcAlign;
    var target = align === 'first' ? tk[0].c : [0.5, 0.5];
    var K = 1;
    if (align !== 'none') {
      tk.forEach(function (t) {
        K = Math.max(K, _this21.need(t.c, target));
      });
      K = Math.min(1 + s.mcZoom / 100, K);
    }
    return order.map(function (ti, i) {
      var t = tk[ti];
      if (align === 'none') return {
        ti: ti,
        frames: durs[i],
        k: 1,
        p: [0.5, 0.5],
        tt: null
      };
      var lim = (K - 1) / 2;
      var p = [0, 1].map(function (a) {
        return Math.max(0.5 - lim, Math.min(0.5 + lim, target[a] - K * (t.c[a] - 0.5)));
      });
      var tt = [0, 1].map(function (a) {
        return p[a] + K * (t.c[a] - 0.5);
      });
      return {
        ti: ti,
        frames: durs[i],
        k: K,
        p: p,
        tt: tt
      };
    });
  },
  waitFile: function waitFile(path, ms) {
    var t0 = Date.now();
    return new Promise(function (res) {
      var _tick2 = function tick() {
        if (!FE.inCEP || FS.exists(path)) return setTimeout(function () {
          return res(true);
        }, 120);
        if (Date.now() - t0 > ms) return res(false);
        setTimeout(_tick2, 150);
      };
      _tick2();
    });
  },
  loadImg: function loadImg(src) {
    return new Promise(function (res) {
      var im = new Image();
      im.onload = function () {
        return res(im);
      };
      im.onerror = function () {
        return res(null);
      };
      im.src = src;
    });
  },
  fakeImg: function fakeImg(i) {
    var c = document.createElement('canvas');
    c.width = 320;
    c.height = 180;
    var g = c.getContext('2d'),
      hue = i * 67 % 360;
    g.fillStyle = "hsl(".concat(hue, ",35%,22%)");
    g.fillRect(0, 0, 320, 180);
    var x = 70 + i * 97 % 180,
      y = 50 + i * 53 % 80;
    g.fillStyle = '#f1c9a5';
    g.beginPath();
    g.arc(x, y, 22, 0, 6.3);
    g.fill();
    g.fillStyle = "hsl(".concat(hue + 180, ",60%,55%)");
    g.fillRect(x - 26, y + 24, 52, 60);
    return this.loadImg(c.toDataURL());
  },
  read: function read(btn, el) {
    var _this22 = this;
    var dir = "".concat(Gen.dir(), "/match");
    FS.mkdirp(dir);
    btn.classList.add('busy');
    FE.call('matchRead', {
      dir: dir
    }).then(function (d) {
      var takes = d && d.takes || (FE.inCEP ? [] : [1, 2, 3, 4, 5].map(function (i) {
        return {
          id: 'm' + i,
          name: "Take ".concat(i),
          png: ''
        };
      }));
      _this22.meta = {
        w: d.w || 1920,
        h: d.h || 1080,
        fps: d.fps || 30,
        at: d.at || 0,
        markers: d.markers || []
      };
      return Promise.all(takes.map(function (t, i) {
        return (t.png ? _this22.waitFile(t.png, 8000).then(function () {
          return _this22.loadImg(FS.fileURL(t.png) + '?' + Date.now());
        }) : _this22.fakeImg(i)).then(function (img) {
          return img ? _this22.locate(img).then(function (c) {
            return {
              id: t.id,
              name: t.name,
              img: img,
              c: c
            };
          }) : null;
        });
      }));
    }).then(function (list) {
      _this22.takes = list.filter(Boolean);
      btn.classList.remove('busy');
      if (_this22.takes.length < 2) {
        UI.toast('Não consegui ler os frames dos takes. Tente de novo.', 'err');
        return;
      }
      UI.toast("".concat(_this22.takes.length, " takes lidos \xB7 toque no assunto para ajustar"), 'ok');
      _this22.draw(el);
    }).catch(function (e) {
      btn.classList.remove('busy');
      UI.toast(e.message, 'err');
    });
  },
  draw: function draw(el) {
    var _this23 = this;
    var box = $('[data-mcstrip]', el),
      info = $('[data-mcinfo]', el);
    if (!box) return;
    var go = $('[data-mcgo]', el);
    if (!this.takes.length) {
      box.innerHTML = '';
      info.textContent = 'Selecione os takes na timeline e toque em Ler takes.';
      if (go) go.disabled = true;
      this.play(el);
      return;
    }
    if (go) go.disabled = false;
    box.innerHTML = this.takes.map(function (t, i) {
      return "<div class=\"mcthumb\" data-mci=\"".concat(i, "\" title=\"").concat(esc(t.name), "\"><canvas width=\"128\" height=\"").concat(Math.round(128 * _this23.meta.h / _this23.meta.w), "\"></canvas><i style=\"left:").concat(t.c[0] * 100, "%;top:").concat(t.c[1] * 100, "%\"></i><b>").concat(i + 1, "</b></div>");
    }).join('');
    $$('.mcthumb', box).forEach(function (n, i) {
      var cv = $('canvas', n);
      cv.getContext('2d').drawImage(_this23.takes[i].img, 0, 0, cv.width, cv.height);
    });
    var plan = this.plan(),
      fr = plan.reduce(function (a, c) {
        return a + c.frames;
      }, 0);
    info.textContent = "".concat(plan.length, " cortes \xB7 ").concat((fr / (this.meta.fps || 30)).toFixed(1).replace('.', ','), " s \xB7 zoom ").concat(Math.round((plan[0] && plan[0].k || 1) * 100), "%");
    this.play(el);
  },
  play: function play(el) {
    var _this24 = this;
    clearTimeout(this.timer);
    var cv = $('[data-mcpv]', el);
    if (!cv) return;
    var g = cv.getContext('2d'),
      W = cv.width,
      H = cv.height;
    var plan = this.plan();
    if (!plan.length) {
      g.fillStyle = '#111';
      g.fillRect(0, 0, W, H);
      g.fillStyle = 'rgba(255,255,255,.5)';
      g.font = '600 15px sans-serif';
      g.textAlign = 'center';
      g.fillText('A prévia do match cut aparece aqui', W / 2, H / 2 + 5);
      return;
    }
    var fps = this.meta.fps || 30;
    var i = 0;
    var _step2 = function step() {
      if (!cv.isConnected) return;
      var c = plan[i],
        t = _this24.takes[c.ti];
      g.fillStyle = '#000';
      g.fillRect(0, 0, W, H);
      g.drawImage(t.img, c.p[0] * W - c.k * W / 2, c.p[1] * H - c.k * H / 2, c.k * W, c.k * H);
      if (c.tt) {
        g.strokeStyle = 'rgba(255,255,255,.55)';
        g.lineWidth = 1.5;
        var x = c.tt[0] * W,
          y = c.tt[1] * H;
        g.beginPath();
        g.moveTo(x - 10, y);
        g.lineTo(x + 10, y);
        g.moveTo(x, y - 10);
        g.lineTo(x, y + 10);
        g.stroke();
      }
      var ms = c.frames / fps * 1000 + (i === plan.length - 1 ? 450 : 0);
      i = (i + 1) % plan.length;
      _this24.timer = setTimeout(_step2, Math.max(30, ms));
    };
    _step2();
  },
  build: function build(btn) {
    var _this25 = this;
    var plan = this.plan();
    if (plan.length < 2) {
      UI.toast('Leia os takes primeiro.', 'err');
      return;
    }
    var cuts = plan.map(function (c) {
      var t = _this25.takes[c.ti];
      return c.tt ? {
        id: t.id,
        frames: c.frames,
        k: c.k,
        c: t.c,
        t: c.tt
      } : {
        id: t.id,
        frames: c.frames
      };
    });
    UI.run(btn, 'Match cut', 'matchCut', {
      cuts: cuts
    }, function (d) {
      return "Match cut com ".concat(d.placed, " cortes na trilha V").concat(d.track).concat(d.tooShort ? ' · alguns takes eram curtos e repetiram' : '');
    }).catch(function () {});
  }
};
App.registerTool({
  id: 'matchcut',
  module: 'after',
  icon: 'match',
  title: 'Match cut',
  desc: 'Vários takes trocando rápido, com o assunto sempre no mesmo lugar',
  needs: 'clips',
  steps: ['Selecione os takes na timeline', 'Toque em Ler takes e confira a prévia', 'Toque em Criar match cut'],
  keywords: 'match cut corte combinado takes alinhar assunto sequência rápida montagem ritmo aftermovie same day',
  render: function render(el) {
    var s = Store.s,
      ar = MC.meta ? MC.meta.h / MC.meta.w : 9 / 16;
    el.innerHTML = "\n      <canvas class=\"mcpv\" data-mcpv width=\"480\" height=\"".concat(Math.round(480 * ar), "\"></canvas>\n      <div class=\"mcinfo\" data-mcinfo></div>\n      <div class=\"mcstrip\" data-mcstrip></div>\n      <div class=\"btns\"><button class=\"btn\" data-mcread>").concat(icon('match'), "Ler takes selecionados</button></div>\n      <div class=\"row\"><label class=\"l\">Alinhar</label>").concat(UI.seg('mcAlign', [['center', 'No centro'], ['first', 'Como o 1º'], ['none', 'Não']], s.mcAlign), "</div>\n      <div class=\"row\"><label class=\"l\">Cada take</label>").concat(UI.seg('mcFrames', [[2, '2 fr'], [3, '3 fr'], [4, '4 fr'], [6, '6 fr'], [8, '8 fr']], s.mcFrames), "</div>\n      <div class=\"row\"><label class=\"l\">Ritmo</label>").concat(UI.seg('mcRhythm', [['const', 'Igual'], ['accel', 'Acelera'], ['decel', 'Freia'], ['beats', 'Marcas']], s.mcRhythm), "</div>\n      <details class=\"adv\"><summary>Ajustes</summary><div>\n        <div class=\"row\"><label class=\"l\">Voltas</label>").concat(UI.seg('mcLoops', [[1, '1×'], [2, '2×'], [3, '3×']], s.mcLoops), "</div>\n        <div class=\"row\"><label class=\"l\">Zoom m\xE1ximo</label>").concat(UI.range('mcZoom', 5, 60, 5, s.mcZoom, '%'), "</div>\n      </div></details>\n      <div class=\"btns\"><button class=\"btn primary\" data-mcgo>").concat(icon('match'), "Criar match cut no cursor</button></div>");
    UI.bindSettings(el, function () {
      return MC.draw(el);
    });
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-mcread]')) {
        MC.read(e.target.closest('[data-mcread]'), el);
        return;
      }
      if (e.target.closest('[data-mcgo]')) {
        MC.build(e.target.closest('[data-mcgo]'));
        return;
      }
      var th = e.target.closest('[data-mci]');
      if (th) {
        var r = th.getBoundingClientRect(),
          t = MC.takes[parseInt(th.getAttribute('data-mci'), 10)];
        t.c = [Math.max(0.05, Math.min(0.95, (e.clientX - r.left) / r.width)), Math.max(0.05, Math.min(0.95, (e.clientY - r.top) / r.height))];
        MC.draw(el);
      }
    });
    MC.draw(el);
  }
});
var PRISM_STYLES = [['h', 'Horizontal', 'Desliza de lado'], ['v', 'Vertical', 'Desliza para cima'], ['d', 'Diagonal', 'Desliza na diagonal'], ['twist', 'Torção', 'Gira e distorce'], ['zoom', 'Zoom', 'Entra com zoom']];
var Prism = {
  args: function args() {
    var s = Store.s;
    return {
      style: s.prStyle,
      frames: s.prFrames,
      intensity: s.prIntensity,
      flash: !!s.prFlash,
      nodeId: s.adjNodeId,
      template: Stack.template()
    };
  },
  run: function run(btn) {
    var st = PRISM_STYLES.find(function (x) {
      return x[0] === Store.s.prStyle;
    }) || PRISM_STYLES[0];
    return UI.run(btn, 'Prisma', 'prismTransition', this.args(), function (d) {
      return "Prisma ".concat(st[1].toLowerCase(), " em ").concat(d.cuts, " corte(s)").concat(d.missing && d.missing.length ? " \xB7 faltou: ".concat(d.missing.join(', ')) : '');
    }).catch(function () {});
  }
};
App.registerTool({
  id: 'prism',
  module: 'after',
  icon: 'prism',
  title: 'Transição prisma',
  desc: 'Refração líquida, rastro e clarão entre dois takes',
  needs: 'stack',
  steps: ['Selecione os takes colados (ou deixe a agulha no corte)', 'Escolha o estilo', 'Toque em Aplicar'],
  keywords: 'prisma prism lente refração líquido vidro distorção transição corte dois takes whip aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"tiles prtiles\">".concat(PRISM_STYLES.map(function (x) {
      return "<div class=\"ctile lkpv ".concat(s.prStyle === x[0] ? 'on' : '', "\" data-prs=\"").concat(x[0], "\"><div class=\"pvbox\"><img src=\"assets/prev/pr_").concat(x[0], ".webp\" alt=\"\" loading=\"lazy\" onerror=\"this.style.display='none'\"></div><span>").concat(x[1], "</span></div>");
    }).join(''), "</div>\n      <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('prFrames', 8, 30, 1, s.prFrames, ' fr'), "</div>\n      <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('prIntensity', 0.4, 1.6, 0.1, s.prIntensity, '×'), "</div>\n      <div class=\"row\">").concat(UI.toggle('prFlash', 'Clarão no corte', s.prFlash), "</div>\n      <div class=\"hint\">A transi\xE7\xE3o fica numa camada de ajuste chamada \"Prisma\" em cima do corte: d\xE1 para mover, encurtar ou apagar.</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('prism'), "Aplicar no corte</button></div>");
    UI.bindSettings(el);
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-prs]');
      if (t) {
        Store.set('prStyle', t.getAttribute('data-prs'));
        $$('[data-prs]', el).forEach(function (x) {
          return x.classList.toggle('on', x === t);
        });
        return;
      }
      var b = e.target.closest('[data-apply]');
      if (b) Prism.run(b);
    });
  }
});
var RAMP_PRESETS = [['whip', 'Acelera no meio', 'Normal, voa no meio e volta'], ['impact', 'Lento no impacto', 'Rápido, câmera lenta no momento, rápido'], ['slowmid', 'Câmera lenta no meio', 'Normal, desacelera e volta'], ['down', 'Rápido → lento', 'Chega voando e termina em câmera lenta'], ['up', 'Lento → rápido', 'Começa lento e sai voando'], ['custom', 'Do seu jeito', 'Arraste os pontos no gráfico']];
var Ramp = {
  curve: function curve(p, u, M, m, pts) {
    var sm = function sm(x) {
      x = Math.max(0, Math.min(1, x));
      return x * x * (3 - 2 * x);
    };
    if (p === 'custom') return Ramp.custom(pts || Ramp.pts(), u);
    var bell = function bell(x) {
      var b = Math.sin(Math.PI * Math.max(0, Math.min(1, x)));
      return b * b;
    };
    if (p === 'whip') return 1 + (M - 1) * bell(u);
    if (p === 'impact') return M + (m - M) * bell(u);
    if (p === 'slowmid') return 1 + (m - 1) * bell(u);
    if (p === 'down') return M + (m - M) * sm(u * 1.15);
    if (p === 'up') return m + (M - m) * sm(u * 1.15 - 0.15);
    return 1;
  },
  custom: function custom(pts, u, hard) {
    if (hard === undefined) hard = !!Store.s.rampHard;
    var a = pts.slice().sort(function (x, y) {
      return x[0] - y[0];
    });
    if (!a.length) return 1;
    if (u <= a[0][0]) return a[0][1];
    for (var i = 1; i < a.length; i++) {
      if (u <= a[i][0]) {
        var t = (u - a[i - 1][0]) / Math.max(1e-6, a[i][0] - a[i - 1][0]),
          e = hard ? t : t * t * (3 - 2 * t);
        return a[i - 1][1] + (a[i][1] - a[i - 1][1]) * e;
      }
    }
    return a[a.length - 1][1];
  },
  pts: function pts() {
    var p = Store.s.rampPts;
    return Array.isArray(p) && p.length >= 2 ? p : [[0, 1], [0.5, 3], [1, 1]];
  },
  top: function top() {
    var s = Store.s;
    return _callSpread(Math.max, Math, [s.rampMax / 100, 1.2].concat(s.rampPreset === 'custom' ? Ramp.pts().map(function (x) {
      return x[1];
    }) : []));
  },
  svg: function svg(p, big) {
    var s = Store.s,
      M = s.rampMax / 100,
      m = s.rampMin / 100,
      W = 120,
      H = big ? 54 : 40,
      top = big ? this.top() : _callSpread(Math.max, Math, [M, 1.2].concat(p === 'custom' ? this.pts().map(function (x) {
        return x[1];
      }) : []));
    var y = function y(v) {
      return H - 4 - v / top * (H - 8);
    };
    var d = '';
    for (var i = 0; i <= 48; i++) {
      var u = i / 48;
      d += "".concat(i ? 'L' : 'M').concat((u * W).toFixed(1), ",").concat(y(this.curve(p, u, M, m)).toFixed(1));
    }
    return "<svg class=\"rampsvg\" viewBox=\"0 0 ".concat(W, " ").concat(H, "\" preserveAspectRatio=\"none\"><path d=\"M0,").concat(y(1).toFixed(1), "H").concat(W, "\" class=\"r100\"/><path d=\"").concat(d, "\" class=\"rline\"/></svg>");
  },
  handles: function handles() {
    if (Store.s.rampPreset !== 'custom') return '';
    var top = this.top(),
      H = 54;
    return this.pts().map(function (q, i) {
      return "<i class=\"rh\" data-rh=\"".concat(i, "\" style=\"left:").concat((q[0] * 100).toFixed(2), "%;top:").concat(((H - 4 - q[1] / top * (H - 8)) / H * 100).toFixed(2), "%\" title=\"").concat(Math.round(q[1] * 100), "% \xB7 duplo clique remove\"></i>");
    }).join('');
  },
  dot: function dot(el) {
    var _this26 = this;
    if (Ramp._raf) cancelAnimationFrame(Ramp._raf);
    var s = Store.s,
      M = s.rampMax / 100,
      m = s.rampMin / 100,
      p = s.rampPreset,
      N = 240,
      H = 54,
      top = this.top();
    var sp = function sp(u) {
      return Math.max(0.05, _this26.curve(p, u, M, m));
    };
    var T = [0];
    for (var i = 1; i <= N; i++) T.push(T[i - 1] + 1 / N / sp((i - 0.5) / N));
    var total = T[N],
      dur = Math.max(1400, Math.min(6000, total * 2400)),
      t0 = performance.now();
    var _tick3 = function tick(now) {
      var d = el.querySelector('[data-rdot]');
      if (!d || !document.body.contains(d)) return;
      var k = (now - t0) % (dur + 500) / dur,
        t = Math.min(1, k) * total;
      var lo = 0,
        hi = N;
      while (hi - lo > 1) {
        var mid = lo + hi >> 1;
        if (T[mid] <= t) lo = mid;else hi = mid;
      }
      var u = Math.min(1, (lo + (t - T[lo]) / Math.max(1e-9, T[hi] - T[lo])) / N),
        v = sp(u);
      d.style.left = (u * 100).toFixed(2) + '%';
      d.style.top = ((H - 4 - v / top * (H - 8)) / H * 100).toFixed(2) + '%';
      var lab = el.querySelector('[data-rspd]');
      if (lab) lab.textContent = Math.round(v * 100) + '%';
      Ramp._raf = requestAnimationFrame(_tick3);
    };
    Ramp._raf = requestAnimationFrame(_tick3);
  },
  toCustom: function toCustom() {
    var _this27 = this;
    var s = Store.s;
    if (s.rampPreset === 'custom') return;
    var M = s.rampMax / 100,
      m = s.rampMin / 100;
    Store.set('rampPts', [0, 0.25, 0.5, 0.75, 1].map(function (u) {
      return [u, Math.round(_this27.curve(s.rampPreset, u, M, m) * 100) / 100];
    }));
    Store.set('rampPreset', 'custom');
  },
  run: function run(btn) {
    var s = Store.s,
      pr = RAMP_PRESETS.find(function (x) {
        return x[0] === s.rampPreset;
      }) || RAMP_PRESETS[0];
    return UI.run(btn, 'Speed ramp', 'speedRamp', {
      preset: s.rampPreset,
      max: s.rampMax,
      min: s.rampMin,
      step: s.rampStep,
      pts: s.rampPreset === 'custom' ? Ramp.pts() : null,
      hard: !!s.rampHard
    }, function (d) {
      return "".concat(pr[1], " em ").concat(d.done, " take(s) \xB7 cada take virou um clipe \u201CSpeed ramp\u201D").concat(d.clipped ? ' · faltou mídia no fim do take, a rampa ficou mais suave' : '');
    }).catch(function () {});
  }
};
App.registerTool({
  id: 'ramp',
  module: 'after',
  icon: 'ramp',
  title: 'Speed ramp',
  desc: 'Acelera e desacelera o take num toque, sem mexer em keyframes',
  needs: 'clips',
  steps: ['Selecione os takes', 'Escolha a rampa', 'Toque em Aplicar'],
  keywords: 'speed ramp rampa velocidade acelerar desacelerar câmera lenta slow motion rápido time remapping aftermovie same day',
  render: function render(el) {
    var s = Store.s;
    var tiles = function tiles() {
      return RAMP_PRESETS.map(function (x) {
        return "<div class=\"ramptile ".concat(s.rampPreset === x[0] ? 'on' : '', "\" data-rp=\"").concat(x[0], "\">").concat(Ramp.svg(x[0]), "<b>").concat(x[1], "</b><span>").concat(x[2], "</span></div>");
      }).join('');
    };
    el.innerHTML = "\n      <div class=\"rampbig\" data-rbig></div>\n      <div class=\"row rshape\"><label class=\"l\">Forma</label>".concat(UI.seg('rampHard', [[0, 'Curvas'], [1, 'Retas']], s.rampHard ? 1 : 0), "</div>\n      <div class=\"hint rhint\">Arraste o gr\xE1fico para mudar a rampa: clique para criar um ponto, arraste para mover, duplo clique para apagar.</div>\n      <div class=\"ramptiles\" data-rtiles>").concat(tiles(), "</div>\n      <div class=\"row\"><label class=\"l\">Mais r\xE1pido</label>").concat(UI.range('rampMax', 150, 800, 25, s.rampMax, '%'), "</div>\n      <div class=\"row\"><label class=\"l\">Mais lento</label>").concat(UI.range('rampMin', 10, 80, 5, s.rampMin, '%'), "</div>\n      <div class=\"row\"><label class=\"l\">Suavidade</label>").concat(UI.seg('rampStep', [[1, 'Máxima'], [2, 'Suave'], [3, 'Leve']], s.rampStep), "</div>\n      <div class=\"hint\">O take mant\xE9m a dura\xE7\xE3o na timeline. C\xE2mera lenta fica mais bonita em v\xEDdeo gravado a 50/60 fps. O \xE1udio do take \xE9 retirado (ficaria fora de sincronia).</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('ramp'), "Aplicar nos takes</button></div>");
    var big = function big() {
      return "<div class=\"redit\" data-redit>".concat(Ramp.svg(Store.s.rampPreset, true)).concat(Ramp.handles(), "<i class=\"rdot2\" data-rdot></i></div><div class=\"rlab\"><span>").concat(Math.round(Ramp.top() * 100), "%</span><span>0%</span></div><div class=\"rspd\" data-rspd></div>");
    };
    var redraw = function redraw() {
      $('[data-rbig]', el).innerHTML = big();
      Ramp.dot(el);
      $('[data-rtiles]', el).innerHTML = RAMP_PRESETS.map(function (x) {
        return "<div class=\"ramptile ".concat(Store.s.rampPreset === x[0] ? 'on' : '', "\" data-rp=\"").concat(x[0], "\">").concat(Ramp.svg(x[0]), "<b>").concat(x[1], "</b><span>").concat(x[2], "</span></div>");
      }).join('');
    };
    redraw();
    UI.bindSettings(el, function (k, v) {
      if (k === 'rampHard') {
        Store.set('rampHard', !!v);
        if (v) Ramp.toCustom();
      }
      redraw();
    });
    var at = function at(e) {
      var r = $('[data-redit]', el).getBoundingClientRect(),
        H = 54,
        top = Ramp.top();
      var u = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
      var yy = (e.clientY - r.top) / r.height * H,
        v = (H - 4 - yy) / (H - 8) * top;
      return [Math.round(u * 1000) / 1000, Math.round(Math.max(0.1, Math.min(top, v)) * 100) / 100];
    };
    var drag = -1;
    var big0 = $('[data-rbig]', el);
    big0.addEventListener('pointerdown', function (e) {
      if (!e.target.closest('[data-redit]')) return;
      Ramp.toCustom();
      var pts = Ramp.pts().map(function (q) {
          return q.slice();
        }),
        h = e.target.closest('[data-rh]');
      if (h) drag = +h.getAttribute('data-rh');else {
        var q = at(e);
        pts.push(q);
        pts.sort(function (a, b) {
          return a[0] - b[0];
        });
        drag = pts.indexOf(q);
        Store.set('rampPts', pts);
      }
      redraw();
      try {
        big0.setPointerCapture(e.pointerId);
      } catch (er) {}
      e.preventDefault();
    });
    big0.addEventListener('pointermove', function (e) {
      if (drag < 0) return;
      var pts = Ramp.pts().map(function (q) {
          return q.slice();
        }),
        q = at(e);
      var lo = drag > 0 ? pts[drag - 1][0] + 0.01 : 0,
        hi = drag < pts.length - 1 ? pts[drag + 1][0] - 0.01 : 1;
      pts[drag] = [Math.max(lo, Math.min(hi, q[0])), q[1]];
      Store.set('rampPts', pts);
      redraw();
    });
    var up = function up() {
      drag = -1;
    };
    big0.addEventListener('pointerup', up);
    big0.addEventListener('pointercancel', up);
    big0.addEventListener('dblclick', function (e) {
      var h = e.target.closest('[data-rh]');
      if (!h) return;
      var pts = Ramp.pts().map(function (q) {
        return q.slice();
      });
      if (pts.length <= 2) {
        UI.toast('A rampa precisa de pelo menos 2 pontos', 'info');
        return;
      }
      pts.splice(+h.getAttribute('data-rh'), 1);
      Store.set('rampPts', pts);
      redraw();
    });
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-rp]');
      if (t) {
        Store.set('rampPreset', t.getAttribute('data-rp'));
        redraw();
        return;
      }
      var b = e.target.closest('[data-apply]');
      if (b) Ramp.run(b);
    });
  }
});
var Workflow = {
  seqSize: function seqSize() {
    return FE.call('info').then(function (i) {
      if (!i || !i.seq) throw new Error('Abra uma sequência na timeline primeiro.');
      return i.seq;
    });
  },
  placeGuide: function placeGuide(btn, platform, opts) {
    if (btn) btn.classList.add('busy');
    opts = opts || {
      zones: true,
      crop: false
    };
    var name = platform === 'generic' ? 'Grade' : GUIDE_SPECS[platform].name;
    return this.seqSize().then(function (s) {
      var path = Gen.guide(s.w, s.h, platform, opts);
      return FE.call('overlay', {
        kind: 'file',
        path: path,
        mode: 'full',
        label: 'FE_Guide_' + platform
      });
    }).then(function (d) {
      UI.toast("Guia do ".concat(name, " adicionada no topo. A sequ\xEAncia n\xE3o foi alterada."), 'ok');
      App.log(true, "Guia ".concat(name));
      return d;
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Guia: ' + e.message);
    }).then(function () {
      return btn && btn.classList.remove('busy');
    });
  }
};
var STACK_LENGTHS = [1, 2, 3, 4, 5, 8, 10, 15, 25, 50];
var Stack = {
  template: function template() {
    if (!FE.inCEP) return '';
    var dir = FE.sysPath('extension').replace(/\\/g, '/') + '/assets/template/';
    var r = Sized.make(dir + 'FE_AdjustmentLayer.prproj', ['Fast Edit Adjustment Layer', 'Adjustment Layer']);
    if (r.tag) {
      Sized.make(dir + 'FE_ZoomIn.prproj', ['Fast Edit Zoom in']);
      Sized.make(dir + 'FE_ZoomOut.prproj', ['Fast Edit Zoom out']);
    }
    return r.tpl;
  },
  frames: function frames() {
    return Store.s.stackFrames || 3;
  },
  effectLabel: function effectLabel() {
    var v = Store.s.stackEffect || '';
    if (!v) return 'Nenhum';
    if (v.indexOf('stack:') === 0) {
      var st = Store.data.stacks.find(function (x) {
        return x.id === v.slice(6);
      });
      return st ? st.name : 'Nenhum';
    }
    return v.slice(3);
  },
  effectNames: function effectNames() {
    var v = Store.s.stackEffect || '';
    if (v.indexOf('stack:') === 0) {
      var st = Store.data.stacks.find(function (x) {
        return x.id === v.slice(6);
      });
      return st ? st.effects : [];
    }
    if (v.indexOf('fx:') === 0) return [v.slice(3)];
    return [];
  },
  apply: function apply(kind, cuts, btn) {
    var _this28 = this;
    var s = Store.s;
    var base = {
      mode: cuts ? 'cuts' : 'auto',
      frames: this.frames()
    };
    var msg = function msg(d) {
      var what = kind === 'adjustment' ? 'Camada de ajuste' : 'Matte';
      var where = d.mode === 'playhead' ? "no playhead (".concat(_this28.frames(), " fr)") : d.mode === 'cuts' ? "em ".concat(d.placed, " corte(s)") : "em ".concat(d.placed, " take(s)");
      return "".concat(what, " ").concat(where).concat(d.effects && d.effects.applied ? " \xB7 ".concat(d.effects.applied, " efeito(s)") : '');
    };
    if (kind === 'adjustment') {
      return UI.run(btn, 'Stack', 'overlay', Object.assign(base, {
        kind: 'adjustment',
        nodeId: s.adjNodeId,
        template: this.template(),
        effects: this.effectNames()
      }), msg).catch(function () {});
    }
    if (btn) btn.classList.add('busy');
    return Workflow.seqSize().then(function (sz) {
      var path = Gen.matte(sz.w, sz.h, s.matteColor, s.matteAlpha);
      if (btn) btn.classList.remove('busy');
      return UI.run(btn, 'Stack', 'overlay', Object.assign(base, {
        kind: 'file',
        path: path
      }), msg);
    }).catch(function (er) {
      if (btn) btn.classList.remove('busy');
      if (er && !er._shown) UI.toast(er.message, 'err');
    });
  }
};
NEEDS.stack = function (sq) {
  return sq && sq.selected ? ["".concat(sq.selected, " take").concat(sq.selected > 1 ? 's' : '', " selecionado").concat(sq.selected > 1 ? 's' : ''), 'ok'] : ["Nada selecionado \u2014 vai na agulha (".concat(Stack.frames(), " fr)"), 'ok'];
};
App.registerTool({
  id: 'stack',
  module: 'workflow',
  icon: 'layers',
  title: 'Stack',
  desc: 'Camada de ajuste ou matte nos takes ou na agulha',
  keywords: 'stack adjustment layer camada de ajuste color matte cor sólida flash letterbox overlay corte agulha playhead frames',
  render: function render(el) {
    var s = Store.s;
    var swatches = ['#000000', '#ffffff', '#2340C8', '#C4F82A', '#f87171', '#fbbf24', '#34d399', '#a78bfa'];
    var tip = '<b>Clique:</b> nos takes selecionados ou na agulha<br><b>Shift:</b> um em cada corte';
    el.innerHTML = "\n      <div class=\"stack-btns\">\n        <div class=\"stack-btn\" data-stack=\"adjustment\" data-tip>".concat(icon('adjust'), "<span>Camada de ajuste</span><div class=\"tipbox\">").concat(tip, "</div></div>\n        <div class=\"stack-btn\" data-stack=\"matte\" data-tip><i class=\"matte-sw\" data-mattesw></i><span>Matte</span><div class=\"tipbox\">").concat(tip, "</div></div>\n      </div>\n      <div class=\"stack-sum\"><span data-sum></span><button class=\"btn sm\" data-cfg>").concat(icon('settings'), "Configurar</button></div>\n      <div class=\"stack-cfg\" data-cfgbox style=\"display:none\">\n        <div class=\"section-label\" style=\"margin-top:4px\">Dura\xE7\xE3o na agulha</div>\n        <div class=\"chips\" data-lens></div>\n        <div class=\"row\"><input class=\"input num\" type=\"number\" min=\"1\" max=\"600\" data-lencustom value=\"").concat(s.stackFrames || 3, "\"><span class=\"muted\">frames</span></div>\n        <div class=\"section-label\">Efeito na camada</div>\n        <div class=\"row\"><input class=\"input grow\" data-fxq placeholder=\"Buscar nos efeitos do Premiere\u2026\"></div>\n        <div class=\"fxres\" data-fxres></div>\n        <div class=\"row\"><select class=\"select grow\" data-stackfx></select></div>\n        <div class=\"hint\" data-fxhint></div>\n        <div class=\"section-label\">Cor do matte</div>\n        <div class=\"row\"><div class=\"swatches\">").concat(swatches.map(function (c) {
      return "<div class=\"sw ".concat(c.toLowerCase() === (s.matteColor || '').toLowerCase() ? 'on' : '', "\" data-sw=\"").concat(c, "\" style=\"background:").concat(c, "\"></div>");
    }).join(''), "</div><input type=\"color\" data-color value=\"").concat(s.matteColor, "\"></div>\n        <div class=\"row\"><label class=\"l\">Opacidade</label>").concat(UI.range('matteAlpha', 5, 100, 5, s.matteAlpha, '%'), "</div>\n      </div>\n      <details class=\"adv\"><summary>Letterbox</summary><div>\n        <div class=\"btns\">").concat([['2.39', '2.39:1'], ['2', '2:1'], ['1.85', '1.85:1'], ['1.333', '4:3']].map(function (r) {
      return "<button class=\"btn sm\" data-lb=\"".concat(r[0], "\">").concat(r[1], "</button>");
    }).join(''), "</div>\n      </div></details>");
    var sum = function sum() {
      var c = Store.s.matteColor;
      $('[data-sum]', el).innerHTML = "<b>".concat(Stack.frames(), " fr</b> \xB7 efeito: <b>").concat(esc(Stack.effectLabel()), "</b> \xB7 matte <i class=\"dot-sw\" style=\"background:").concat(c, ";opacity:").concat((Store.s.matteAlpha || 100) / 100, "\"></i>");
      $('[data-mattesw]', el).style.background = c;
      $('[data-mattesw]', el).style.opacity = Math.max(0.25, (Store.s.matteAlpha || 100) / 100);
      el.classList.toggle('no-tips', Store.s.stackTips === false);
      $$('[data-lens] .chip', el).forEach(function (ch) {
        return ch.classList.toggle('on', parseInt(ch.getAttribute('data-len'), 10) === Stack.frames());
      });
      App.updateCtx();
    };
    $('[data-lens]', el).innerHTML = STACK_LENGTHS.map(function (n) {
      return "<span class=\"chip\" data-len=\"".concat(n, "\">").concat(n, "</span>");
    }).join('');
    var allFx = [];
    var fillFx = function fillFx() {
      var sel = $('[data-stackfx]', el),
        q = (($('[data-fxq]', el) || {}).value || '').trim().toLowerCase();
      var hit = function hit(n) {
        return !q || n.toLowerCase().indexOf(q) >= 0;
      };
      var stacks = Store.data.stacks.filter(function (x) {
        return !x.audio && hit(x.name);
      });
      var favs = Store.data.effectFavs.filter(function (k) {
        return k.indexOf('video:') === 0;
      }).map(function (k) {
        return k.slice(6);
      }).filter(hit);
      var cur = Store.s.stackEffect || '';
      var all = allFx.filter(hit);
      var curOpt = '';
      if (cur.indexOf('fx:') === 0 && favs.indexOf(cur.slice(3)) < 0 && all.indexOf(cur.slice(3)) < 0) curOpt = "<option value=\"".concat(esc(cur), "\">").concat(esc(cur.slice(3)), "</option>");
      sel.innerHTML = '<option value="">Nenhum (só a camada)</option>' + curOpt + (stacks.length ? "<optgroup label=\"Meus stacks\">".concat(stacks.map(function (x) {
        return "<option value=\"stack:".concat(x.id, "\">").concat(esc(x.name), "</option>");
      }).join(''), "</optgroup>") : '') + (favs.length ? "<optgroup label=\"Efeitos favoritos\">".concat(favs.map(function (n) {
        return "<option value=\"fx:".concat(esc(n), "\">").concat(esc(n), "</option>");
      }).join(''), "</optgroup>") : '') + (all.length ? "<optgroup label=\"Todos os efeitos de v\xEDdeo (".concat(all.length, ")\">").concat(all.map(function (n) {
        return "<option value=\"fx:".concat(esc(n), "\">").concat(esc(n), "</option>");
      }).join(''), "</optgroup>") : '');
      sel.value = cur;
      $('[data-fxhint]', el).innerHTML = allFx.length ? '' : 'Carregando os efeitos do Premiere…';
      var res = $('[data-fxres]', el);
      var list = q ? stacks.map(function (x) {
        return ['stack:' + x.id, x.name];
      }).concat(favs.concat(all.filter(function (n) {
        return favs.indexOf(n) < 0;
      })).map(function (n) {
        return ['fx:' + n, n];
      })).slice(0, 40) : [];
      res.innerHTML = q ? list.length ? list.map(function (o) {
        return "<div class=\"fxrow ".concat(o[0] === cur ? 'on' : '', "\" data-fxpick=\"").concat(esc(o[0]), "\">").concat(esc(o[1]), "</div>");
      }).join('') : '<div class="hint">Nenhum efeito com esse nome.</div>' : '';
    };
    Animate.loadEffects().then(function (d) {
      allFx = (d && d.video || []).slice().sort(function (a, b) {
        return a.localeCompare(b, 'pt');
      });
      fillFx();
    }).catch(function () {
      $('[data-fxhint]', el).innerHTML = 'Não consegui ler os efeitos do Premiere agora.';
    });
    var status = function status() {
      FE.call('findAdjustment', {
        nodeId: Store.s.adjNodeId
      }).then(function (r) {
        var tag = $('[data-adjstatus]', el);
        if (!tag) return;
        if (r) {
          tag.className = 'tag ok';
          tag.textContent = '✓ ' + r.name;
          Store.set('adjNodeId', r.nodeId);
        } else {
          tag.className = 'tag warn';
          tag.textContent = 'Crie uma vez: Project > New Item > Adjustment Layer';
        }
      }).catch(function () {});
    };
    fillFx();
    sum();
    UI.bindSettings(el, function () {
      return sum();
    });
    $('[data-lencustom]', el).addEventListener('change', function (e) {
      Store.set('stackFrames', clamp(parseInt(e.target.value, 10) || 3, 1, 600));
      sum();
    });
    $('[data-stackfx]', el).addEventListener('change', function (e) {
      Store.set('stackEffect', e.target.value);
      sum();
    });
    $('[data-fxq]', el).addEventListener('input', function () {
      return fillFx();
    });
    $('[data-color]', el).addEventListener('input', function (e) {
      Store.set('matteColor', e.target.value);
      $$('[data-sw]', el).forEach(function (x) {
        return x.classList.remove('on');
      });
      sum();
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      var b = g('[data-stack]');
      if (b) return Stack.apply(b.getAttribute('data-stack'), e.shiftKey, b);
      var pk = g('[data-fxpick]');
      if (pk) {
        Store.set('stackEffect', pk.getAttribute('data-fxpick'));
        $('[data-fxq]', el).value = '';
        fillFx();
        sum();
        UI.toast('Efeito da camada: ' + Stack.effectLabel(), 'ok');
        return;
      }
      if (g('[data-cfg]')) {
        var bx = $('[data-cfgbox]', el);
        bx.style.display = bx.style.display === 'none' ? '' : 'none';
        return;
      }
      var ln = g('[data-len]');
      if (ln) {
        Store.set('stackFrames', parseInt(ln.getAttribute('data-len'), 10));
        $('[data-lencustom]', el).value = Stack.frames();
        sum();
        return;
      }
      var sw = g('[data-sw]');
      if (sw) {
        Store.set('matteColor', sw.getAttribute('data-sw'));
        $('[data-color]', el).value = Store.s.matteColor;
        $$('[data-sw]', el).forEach(function (x) {
          return x.classList.toggle('on', x === sw);
        });
        sum();
        return;
      }
      if (g('[data-adjsel]')) {
        FE.call('adjustmentFromSelection').then(function (r) {
          Store.set('adjNodeId', r.nodeId);
          UI.toast('Camada de ajuste definida: ' + r.name, 'ok');
          status();
        }).catch(function (er) {
          return UI.toast(er.message, 'err');
        });
        return;
      }
      var lb = g('[data-lb]');
      if (lb) {
        lb.classList.add('busy');
        Workflow.seqSize().then(function (sz) {
          var path = Gen.letterbox(sz.w, sz.h, parseFloat(lb.getAttribute('data-lb')));
          lb.classList.remove('busy');
          return UI.run(lb, 'Letterbox', 'overlay', {
            kind: 'file',
            path: path,
            mode: 'auto',
            frames: Stack.frames()
          }, function (d) {
            return "Letterbox em ".concat(d.placed, " lugar(es)");
          });
        }).catch(function (er) {
          lb.classList.remove('busy');
          if (er && !er._shown) UI.toast(er.message, 'err');
        });
      }
    });
  }
});
var SETUP_TEMPLATES = [{
  id: 'youtube',
  name: 'YouTube / Conteúdo',
  text: '01 Sequências\n02 Brutos\n  Câmera A\n  Câmera B\n  Tela\n03 Áudio\n  Voz\n  Trilhas\n  SFX\n04 Gráficos\n  Thumbs\n  Lower Thirds\n05 B-Roll\n06 Exports'
}, {
  id: 'comercial',
  name: 'Comercial / Publicidade',
  text: '00 Entregas\n01 Sequências\n  Master\n  Cortes 30s\n  Cortes 15s\n  Versões Sociais\n02 Vídeo\n  Diárias\n  Selecionados\n03 Áudio\n  Locução\n  Trilha\n  SFX\n04 Gráficos\n  Logos\n  Cartelas\n  MOGRTs\n05 Referências\n06 Color & Finalização'
}, {
  id: 'doc',
  name: 'Documentário',
  text: '01 Sequências\n  Strings\n  Cortes\n02 Entrevistas\n03 B-Roll\n04 Arquivo\n05 Áudio\n  Ambiente\n  Trilha\n  SFX\n06 Gráficos\n07 Legendas'
}, {
  id: 'social',
  name: 'Social Media',
  text: '01 Sequências\n  9x16\n  1x1\n  4x5\n  16x9\n02 Brutos\n03 Áudio\n  Músicas\n  SFX\n04 Gráficos\n  Legendas\n  Stickers\n05 Exports'
}, {
  id: 'evento',
  name: 'Casamento / Evento',
  text: '01 Sequências\n  Teaser\n  Filme\n02 Câmeras\n  Cam 1\n  Cam 2\n  Drone\n03 Áudio\n  Lapela\n  Ambiente\n  Músicas\n04 Gráficos\n05 Exports'
}];
function parseTree(text) {
  var root = {
      children: []
    },
    stack = [{
      depth: -1,
      node: root
    }];
  text.split(/\r?\n/).forEach(function (line) {
    if (!line.trim()) return;
    var depth = line.match(/^[\t ]*/)[0].replace(/\t/g, '  ').length / 2 | 0;
    var node = {
      name: line.trim().replace(/^[-*•]\s*/, ''),
      children: []
    };
    while (stack.length > 1 && stack[stack.length - 1].depth >= depth) stack.pop();
    stack[stack.length - 1].node.children.push(node);
    stack.push({
      depth: depth,
      node: node
    });
  });
  return root.children;
}
App.registerTool({
  id: 'setup',
  module: 'workflow',
  icon: 'bins',
  title: 'Iniciar projeto',
  desc: 'Cria a estrutura de bins a partir de um modelo',
  needs: 'project',
  steps: ['Escolha um modelo', 'Edite se quiser', 'Toque em Criar'],
  keywords: 'pastas bins estrutura template projeto setup organizar criar',
  render: function render(el) {
    var all = function all() {
      return SETUP_TEMPLATES.concat(Store.s.customTemplates || []);
    };
    el.innerHTML = "\n      <div class=\"row\"><label class=\"l\">Template</label><select class=\"select grow\" data-tpl></select></div>\n      <textarea class=\"input\" rows=\"10\" data-tree style=\"width:100%\"></textarea>\n      <div class=\"btns\"><button class=\"btn primary\" data-create>".concat(icon('folder'), "Criar estrutura</button><button class=\"btn\" data-save>").concat(icon('plus'), "Salvar template</button><button class=\"btn ghost danger\" data-del title=\"Excluir template personalizado\">").concat(icon('trash'), "</button></div>");
    var sel = $('[data-tpl]', el),
      ta = $('[data-tree]', el);
    var fill = function fill(id) {
      sel.innerHTML = all().map(function (t) {
        return "<option value=\"".concat(t.id, "\">").concat(esc(t.name)).concat(t.custom ? ' ★' : '', "</option>");
      }).join('');
      if (id) sel.value = id;
      var t = all().find(function (x) {
        return x.id === sel.value;
      }) || all()[0];
      ta.value = t.text;
      $('[data-del]', el).style.display = t.custom ? '' : 'none';
    };
    fill();
    sel.addEventListener('change', function () {
      return fill(sel.value);
    });
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-create]')) {
        var tree = parseTree(ta.value);
        if (!tree.length) return UI.toast('Template vazio', 'err');
        UI.run(e.target.closest('[data-create]'), 'Project Setup', 'projectSetup', {
          tree: tree
        }, function (d) {
          return "".concat(d.created, " bin(s) criado(s)").concat(d.skipped ? " \xB7 ".concat(d.skipped, " j\xE1 existia(m)") : '');
        }).catch(function () {});
      }
      if (e.target.closest('[data-save]')) {
        UI.prompt('Nome do template', 'Meu template').then(function (name) {
          if (!name) return;
          var t = {
            id: 'c_' + uid(),
            name: name,
            text: ta.value,
            custom: true
          };
          Store.s.customTemplates = (Store.s.customTemplates || []).concat([t]);
          Store.save();
          fill(t.id);
          UI.toast('Template salvo', 'ok');
        });
      }
      if (e.target.closest('[data-del]')) {
        Store.s.customTemplates = (Store.s.customTemplates || []).filter(function (t) {
          return t.id !== sel.value;
        });
        Store.save();
        fill();
      }
    });
  }
});
var ORG_CATS = [['seq', 'Sequências'], ['video', 'Vídeos'], ['audio', 'Áudios'], ['image', 'Imagens'], ['graphic', 'Gráficos / Sintéticos'], ['other', 'Outros']];
App.registerTool({
  id: 'organizer',
  module: 'workflow',
  icon: 'organize',
  title: 'Organizar projeto',
  desc: 'Coloca cada mídia no bin certo, com prévia',
  needs: 'project',
  steps: ['Confira os bins', 'Veja a prévia', 'Toque em Organizar'],
  keywords: 'organizar bins mídia tipo project painel limpar ordenar pastas automático',
  render: function render(el) {
    var b = Store.s.orgBins;
    el.innerHTML = "\n      <table class=\"tbl\"><tr><th>Tipo</th><th>Mover para o bin</th></tr>\n        ".concat(ORG_CATS.map(function (c) {
      return "<tr><td>".concat(c[1], "</td><td><input class=\"input\" style=\"width:100%\" data-bin=\"").concat(c[0], "\" value=\"").concat(esc(b[c[0]] || ''), "\" placeholder=\"(n\xE3o mover)\"></td></tr>");
    }).join(''), "\n      </table>\n      <div class=\"row\" style=\"margin-top:8px\">").concat(UI.toggle('orgNested', 'Incluir subpastas', Store.s.orgNested), "</div>\n      <div data-preview></div>\n      <div class=\"btns\"><button class=\"btn\" data-prev>").concat(icon('search'), "Pr\xE9via</button><button class=\"btn primary\" data-apply>").concat(icon('check'), "Organizar</button></div>");
    UI.bindSettings(el);
    el.addEventListener('change', function (e) {
      var k = e.target.getAttribute('data-bin');
      if (k) {
        Store.s.orgBins[k] = e.target.value.trim();
        Store.save();
      }
    });
    var run = function run(apply, btn) {
      return UI.run(btn, 'Organizer', 'organize', {
        bins: Store.s.orgBins,
        nested: Store.s.orgNested,
        apply: apply
      }, function (d) {
        return apply ? "".concat(Object.values(d.plan).reduce(function (a, x) {
          return a + x.count;
        }, 0), " item(ns) organizado(s)") : null;
      }).then(function (d) {
        var rows = Object.keys(d.plan).map(function (k) {
          return d.plan[k];
        });
        $('[data-preview]', el).innerHTML = "<div class=\"banner info\" style=\"margin-top:8px\">".concat(rows.length ? rows.map(function (r) {
          return "<div><b>".concat(r.count, "</b> \u2192 ").concat(esc(r.bin), " <span class=\"muted\">(").concat(r.samples.map(esc).join(', ')).concat(r.count > r.samples.length ? '…' : '', ")</span></div>");
        }).join('') : 'Tudo já está organizado.', "</div>");
      }).catch(function () {});
    };
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-prev]')) run(false, e.target.closest('[data-prev]'));
      if (e.target.closest('[data-apply]')) run(true, e.target.closest('[data-apply]'));
    });
  }
});
App.registerTool({
  id: 'sort',
  module: 'workflow',
  icon: 'sort',
  title: 'Ordenar takes',
  desc: 'Reordena os clipes por nome, duração ou sorteio',
  needs: 'clips',
  steps: ['Selecione clipes de 1 trilha', 'Escolha a ordem', 'Pronto'],
  keywords: 'ordenar takes nome sequência reorganizar clipes ordem shuffle aleatório duração',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-sort=\"name\">A \u2192 Z</button><button class=\"btn\" data-sort=\"nameDesc\">Z \u2192 A</button><button class=\"btn\" data-sort=\"reverse\">Inverter</button></div>\n      <div class=\"btns\"><button class=\"btn\" data-sort=\"duration\">Curto \u2192 Longo</button><button class=\"btn\" data-sort=\"durationDesc\">Longo \u2192 Curto</button><button class=\"btn\" data-sort=\"shuffle\">Aleat\xF3rio</button></div>";
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-sort]');
      if (b) UI.run(b, 'Sort Clips', 'sortClips', {
        mode: b.getAttribute('data-sort')
      }, function (d) {
        return "".concat(d.sorted, " clipes reordenados");
      }).catch(function () {});
    });
  }
});
var LABELS = [[0, 'Violeta'], [1, 'Íris'], [2, 'Caribe'], [3, 'Lavanda'], [4, 'Cerúleo'], [5, 'Floresta'], [6, 'Rosa'], [7, 'Manga'], [8, 'Púrpura'], [9, 'Azul'], [10, 'Verde-azulado'], [11, 'Magenta'], [12, 'Bronze'], [13, 'Verde'], [14, 'Marrom'], [15, 'Amarelo']];
App.registerTool({
  id: 'batch',
  module: 'workflow',
  icon: 'batch',
  title: 'Ações em lote',
  desc: 'Desativar, velocidade, remover efeitos e mais',
  needs: 'clips',
  steps: ['Selecione os clipes', 'Escolha a ação', 'Pronto'],
  keywords: 'lote batch desativar ativar efeitos remover velocidade speed escala frame size reverso link unlink cor label disable',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"section-label\" style=\"margin-top:0\">Clipes</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-op=\"disable\">Desativar</button><button class=\"btn\" data-op=\"enable\">Ativar</button><button class=\"btn\" data-op=\"toggle\">Inverter</button></div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-op=\"unlink\">Desvincular A/V</button><button class=\"btn\" data-op=\"link\">Vincular A/V</button></div>\n      <div class=\"section-label\">Efeitos e imagem</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn danger\" data-op=\"removeEffects\">Remover efeitos</button><button class=\"btn\" data-op=\"scaleToFrame\">Ajustar ao quadro</button></div>\n      <div class=\"row\"><label class=\"l\">Velocidade</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"10000\" value=\"100\" data-speed><span class=\"muted\">%</span>".concat(UI.toggle('_ripple', 'Ripple', true), "<button class=\"btn sm right\" data-op=\"speed\">Aplicar</button></div>\n      <div class=\"row\"><button class=\"btn sm\" data-op=\"reverse\">Reproduzir ao contr\xE1rio</button></div>\n      <div class=\"section-label\">Cor do r\xF3tulo (m\xEDdia)</div>\n      <div class=\"row\">").concat(UI.select('_label', LABELS, 7, 'grow'), "<button class=\"btn sm\" data-op=\"label\">Aplicar</button></div>");
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-op]');
      if (!b) return;
      var op = b.getAttribute('data-op');
      var args = {
        op: op
      };
      if (op === 'speed') {
        args.value = parseFloat($('[data-speed]', el).value) || 100;
        args.ripple = $('[data-toggle="_ripple"]', el).checked;
      }
      if (op === 'label') args.value = parseInt($('[data-select="_label"]', el).value, 10);
      var go = function go() {
        return UI.run(b, 'Batch', 'batch', args, function (d) {
          return "".concat(d.done, " clipe(s) atualizado(s)").concat(d.failed ? " \xB7 ".concat(d.failed, " falha(s)") : '');
        }).catch(function () {});
      };
      if (op === 'removeEffects') UI.confirm('Remover efeitos', 'Remove todos os efeitos aplicados aos clipes selecionados (Ctrl+Z desfaz).', 'Remover').then(function (ok) {
        return ok && go();
      });else go();
    });
  }
});
App.registerTool({
  id: 'cleaner',
  module: 'workflow',
  icon: 'clean',
  title: 'Limpar timeline',
  desc: 'Fecha buracos, tira flash frames e trilhas vazias',
  needs: 'seq',
  steps: ['Abra a sequência', 'Escolha a limpeza', 'Pronto'],
  keywords: 'limpar timeline gaps espaços vazios flash frame clipes curtos desativados trilhas vazias cleaner',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"col\"><label>Espa\xE7os vazios (em todas as trilhas, mantendo sincronia)</label>\n        <div class=\"row\" style=\"margin:0\">".concat(UI.toggle('_fromStart', 'Incluir início da sequência', true), "<button class=\"btn sm right\" data-c=\"gaps\">").concat(icon('clean'), "Fechar espa\xE7os</button></div></div>\n      <div class=\"col\"><label>Flash frames / sobras de corte</label>\n        <div class=\"row\" style=\"margin:0\"><span class=\"muted\">Clipes com menos de</span><input class=\"input num\" type=\"number\" min=\"1\" max=\"30\" value=\"3\" data-short><span class=\"muted\">frames</span><button class=\"btn sm right\" data-c=\"short\">Remover</button></div></div>\n      <div class=\"btns\" style=\"margin-top:4px\"><button class=\"btn\" data-c=\"disabled\">Remover desativados</button><button class=\"btn\" data-c=\"tracks\">Remover trilhas vazias</button></div>");
    el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-c]');
      if (!b) return;
      var c = b.getAttribute('data-c');
      if (c === 'gaps') UI.run(b, 'Cleaner', 'closeGaps', {
        minFrames: 1,
        fromStart: $('[data-toggle="_fromStart"]', el).checked
      }, function (d) {
        return d.gaps ? "".concat(d.gaps, " espa\xE7o(s) removido(s) \xB7 ").concat(d.seconds, "s") : 'Nenhum espaço vazio encontrado';
      }).catch(function () {});
      if (c === 'short') {
        var fr = parseInt($('[data-short]', el).value, 10) || 3;
        UI.confirm('Remover clipes curtos', "Remove todos os clipes com menos de ".concat(fr, " frame(s) na sequ\xEAncia ativa."), 'Remover').then(function (ok) {
          return ok && UI.run(b, 'Cleaner', 'removeShort', {
            frames: fr
          }, function (d) {
            return "".concat(d.removed, " clipe(s) removido(s)");
          }).catch(function () {});
        });
      }
      if (c === 'disabled') UI.confirm('Remover desativados', 'Remove da timeline todos os clipes desativados.', 'Remover').then(function (ok) {
        return ok && UI.run(b, 'Cleaner', 'removeDisabled', {}, function (d) {
          return "".concat(d.removed, " clipe(s) removido(s)");
        }).catch(function () {});
      });
      if (c === 'tracks') UI.run(b, 'Cleaner', 'removeEmptyTracks', {}, 'Trilhas vazias removidas').catch(function () {});
    });
  }
});
var SOCIAL_FORMATS = [['9:16', 1080, 1920, 'Reels · TikTok · Shorts'], ['1:1', 1080, 1080, 'Feed quadrado'], ['4:5', 1080, 1350, 'Feed vertical'], ['16:9', 1920, 1080, 'YouTube'], ['4:3', 1440, 1080, 'Clássico']];
App.registerTool({
  id: 'social',
  module: 'workflow',
  icon: 'social',
  title: 'Guias de redes sociais',
  desc: 'Veja os botões do Reels, Shorts e TikTok por cima do vídeo',
  needs: 'seq',
  steps: ['Escolha o app', 'Confira a prévia', 'Adicione por cima'],
  keywords: 'guia faca safe zone reels tiktok shorts instagram youtube botões legenda cortando interface enquadramento vertical 9:16',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"row\">".concat(UI.seg('_gPlat', [['reels', 'Reels'], ['shorts', 'Shorts'], ['tiktok', 'TikTok'], ['generic', 'Só grade']], 'reels'), "</div>\n      <div class=\"guide-prev\"><canvas data-prev width=\"270\" height=\"480\"></canvas></div>\n      <div class=\"row\">").concat(UI.toggle('_gZones', 'Áreas de risco', true)).concat(UI.toggle('_gCrop', 'Corte lateral', false), "</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-guide>").concat(icon('social'), "Adicionar guia</button></div>\n      <div class=\"guide-state\" data-gstate></div>");
    var plat = 'reels';
    var draw = function draw() {
      var cv = $('[data-prev]', el),
        g = cv.getContext('2d');
      var grd = g.createLinearGradient(0, 0, 270, 480);
      grd.addColorStop(0, '#5a6b8c');
      grd.addColorStop(1, '#2b3346');
      g.fillStyle = grd;
      g.fillRect(0, 0, 270, 480);
      g.fillStyle = 'rgba(255,255,255,0.10)';
      g.font = '600 15px "DM Sans", sans-serif';
      g.textAlign = 'center';
      g.fillText('seu vídeo', 135, 245);
      var c = Gen.guideCanvas(270, 480, plat, {
        zones: $('[data-toggle="_gZones"]', el).checked,
        crop: $('[data-toggle="_gCrop"]', el).checked
      });
      g.drawImage(c, 0, 0);
    };
    UI.bindSettings(el, function (k, v) {
      if (k === '_gPlat') plat = v;
      draw();
    });
    setTimeout(draw, 30);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(draw);
    var gstate = function gstate(st) {
      var box = $('[data-gstate]', el);
      if (!box) return;
      if (!st || !st.count) {
        box.innerHTML = '';
        return;
      }
      box.innerHTML = "<div class=\"guide-switch ".concat(st.visible ? 'on' : '', "\" data-gtoggle>\n          <div class=\"gs-t\"><b>").concat(st.visible ? 'Guia visível' : 'Guia escondida', "</b></div>\n          <label class=\"toggle\" style=\"margin:0;pointer-events:none\"><input type=\"checkbox\" ").concat(st.visible ? 'checked' : '', "><i></i></label></div>\n        <div class=\"btns\" style=\"margin-top:2px\"><button class=\"btn sm\" data-rmguide>").concat(icon('trash'), "Remover guias</button></div>");
    };
    var refresh = function refresh() {
      return FE.call('guidesState').then(gstate).catch(function () {
        return gstate(null);
      });
    };
    refresh();
    el.addEventListener('click', function (e) {
      if (e.target.closest('[data-guide]')) Workflow.placeGuide(e.target.closest('[data-guide]'), plat, {
        zones: $('[data-toggle="_gZones"]', el).checked,
        crop: $('[data-toggle="_gCrop"]', el).checked
      }).then(refresh);
      if (e.target.closest('[data-gtoggle]')) FE.call('toggleGuides', {}).then(function (st) {
        gstate(st);
        UI.toast(st.visible ? 'Guia visível' : 'Guia escondida', 'info');
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
      if (e.target.closest('[data-rmguide]')) UI.run(e.target.closest('[data-rmguide]'), 'Guias', 'removeGuides', {}, function (d) {
        return d.removed ? "".concat(d.removed, " guia(s) removida(s)") : 'Nenhuma guia na sequência';
      }).then(refresh).catch(function () {});
    });
  }
});
App.registerTool({
  id: 'formats',
  module: 'workflow',
  icon: 'batch',
  title: 'Cópia em outro formato',
  desc: 'Cria uma CÓPIA da sequência em 9:16, 1:1, 4:5… (a original fica igual)',
  needs: 'seq',
  steps: ['Abra a sequência', 'Escolha o formato', 'Uma cópia é criada'],
  keywords: 'formato vertical 9:16 1:1 4:5 auto reframe duplicar sequência redimensionar',
  render: function render(el) {
    el.innerHTML = "\n      <div class=\"tiles\">".concat(SOCIAL_FORMATS.map(function (f) {
      return "<div class=\"tile\" data-fmt=\"".concat(f[0], "\"><b style=\"font-size:14px\">").concat(f[0], "</b><span>").concat(f[3], "</span></div>");
    }).join(''), "</div>\n      <div class=\"row\">").concat(UI.toggle('_reframe', 'Auto Reframe', true), "</div>");
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-fmt]');
      if (!t) return;
      var f = SOCIAL_FORMATS.find(function (x) {
        return x[0] === t.getAttribute('data-fmt');
      });
      var _f$0$split$map = f[0].split(':').map(Number),
        num = _f$0$split$map[0],
        den = _f$0$split$map[1];
      UI.run(t, 'Formato', 'socialSequence', {
        w: f[1],
        h: f[2],
        num: num,
        den: den,
        label: f[0].replace(':', 'x'),
        autoReframe: $('[data-toggle="_reframe"]', el).checked
      }, function (d) {
        return "C\xF3pia \u201C".concat(d.name, "\u201D criada").concat(d.size ? ' em ' + d.size : '').concat(d.method === 'autoReframe' ? ' com Auto Reframe' : '');
      }).catch(function () {});
    });
  }
});
var ZOOM_MOTIONS = [['static', 'Parado (corte seco no zoom)'], ['in', 'Zoom in (aproxima)'], ['out', 'Zoom out (afasta)'], ['alt', 'Alternado: in, out, in…'], ['pulse', 'Pulso (vai e volta)'], ['punch', 'Punch rápido no início'], ['altpunch', 'Alternado: punch e parado']];
var ZOOM_DRIFTS = [['none', 'Sem deslocar'], ['left', 'Para a esquerda'], ['right', 'Para a direita'], ['up', 'Para cima'], ['down', 'Para baixo'], ['altlr', 'Alternado esquerda/direita'], ['random', 'Aleatório']];
var ZoomTakes = {
  args: function args() {
    var s = Store.s;
    return {
      scope: s.zmScope,
      pattern: s.zmPattern,
      every: s.zmEvery,
      offset: s.zmOffset ? 1 : 0,
      zooms: (s.zmZooms && s.zmZooms.length ? s.zmZooms : [10]).slice(),
      order: s.zmOrder,
      motion: s.zmMotion,
      animFrames: s.zmDurMode === 'take' ? 0 : s.zmFrames,
      outAtEnd: !!s.zmOutEnd,
      ease: s.zmEase,
      drift: s.zmDrift,
      driftAmt: s.zmDriftAmt,
      blur: !!s.zmBlur,
      colorize: s.zmColor !== false,
      labelIn: s.zmLabelIn,
      labelOut: s.zmLabelOut,
      nodeId: s.adjNodeId,
      template: Stack.template()
    };
  },
  plan: function plan(n) {
    var a = this.args(),
      out = [];
    var picked = 0;
    for (var k = 0; k < n; k++) {
      var on = true;
      if (a.pattern === 'alt' && (k + a.offset) % 2 !== 0) on = false;
      if (a.pattern === 'every' && (k + a.offset) % Math.max(1, a.every) !== 0) on = false;
      if (!on) {
        out.push(null);
        continue;
      }
      var z = a.order === 'random' ? a.zooms[(k * 7 + 3) % a.zooms.length] : a.zooms[picked % a.zooms.length];
      var mo = a.motion;
      if (mo === 'alt') mo = picked % 2 === 0 ? 'in' : 'out';
      if (mo === 'altpunch') mo = picked % 2 === 0 ? 'punch' : 'static';
      var dr = a.drift;
      if (dr === 'altlr') dr = picked % 2 ? 'left' : 'right';
      if (dr === 'random') dr = ['left', 'right', 'up', 'down'][(k * 5 + 1) % 4];
      picked++;
      out.push({
        z: z,
        mo: mo,
        dr: dr
      });
    }
    return out;
  },
  preview: function preview(el) {
    var box = $('[data-zprev]', el);
    if (!box) return;
    var a = this.args(),
      p = this.plan(8);
    var dur = a.animFrames ? Math.max(0.35, Math.min(1.6, a.animFrames / 24)) : 1.6;
    var ease = {
      linear: 'linear',
      smooth: 'cubic-bezier(.65,0,.35,1)',
      fast: 'cubic-bezier(.16,1,.3,1)',
      slow: 'cubic-bezier(.7,0,.84,0)'
    }[a.ease] || 'ease-in-out';
    box.innerHTML = p.map(function (t, i) {
      if (!t) return "<div class=\"ztake off\"><i></i><b>\u2014</b></div>";
      var Z = 1 + t.z / 100;
      var d = {
          left: [-1, 0],
          right: [1, 0],
          up: [0, -1],
          down: [0, 1]
        }[t.dr] || [0, 0],
        m = a.driftAmt / 2;
      var name = "zt".concat(i, "_").concat(Date.now() % 100000);
      var from = 1,
        to = 1,
        mid = null;
      if (t.mo === 'static') {
        from = Z;
        to = Z;
      }
      if (t.mo === 'in') {
        from = 1;
        to = Z;
      }
      if (t.mo === 'out') {
        from = Z;
        to = 1;
      }
      if (t.mo === 'pulse') {
        from = 1;
        to = 1;
        mid = Z;
      }
      if (t.mo === 'punch') {
        from = 1;
        to = Z;
      }
      var tr = function tr(s, k) {
        return "transform:translate(".concat((d[0] * m * k).toFixed(1), "%,").concat((d[1] * m * k).toFixed(1), "%) scale(").concat(s, ")");
      };
      var anim = t.mo === 'punch' ? "@keyframes ".concat(name, "{0%{").concat(tr(from, -1), "}12%{").concat(tr(to, -0.7), "}100%{").concat(tr(to, 1), "}}") : mid ? "@keyframes ".concat(name, "{0%{").concat(tr(from, -1), "}50%{").concat(tr(mid, 0), "}100%{").concat(tr(to, 1), "}}") : "@keyframes ".concat(name, "{0%{").concat(tr(from, -1), "}").concat(a.outAtEnd && t.mo === 'out' ? "55%{".concat(tr(from, 0), "}") : '', "100%{").concat(tr(to, 1), "}}");
      return "<div class=\"ztake\"><style>".concat(anim, "</style><i style=\"animation:").concat(name, " ").concat(t.mo === 'static' && !a.drift.match(/^(left|right|up|down|altlr|random)$/) ? 1.6 : dur, "s ").concat(ease, " infinite alternate\"></i><b>").concat(t.z, "%</b></div>");
    }).join('');
  },
  run: function run(btn) {
    return UI.run(btn, 'Zoom nos takes', 'zoomTakes', this.args(), function (d) {
      return "Zoom em ".concat(d.done, " take(s)");
    }).then(function (d) {
      if (d && d.labelIn >= 0) Store.set('zmLabelIn', d.labelIn);
      if (d && d.labelOut >= 0) Store.set('zmLabelOut', d.labelOut);
    }).catch(function () {});
  }
};
App.registerTool({
  id: 'zoomtakes',
  module: 'after',
  icon: 'zoom',
  title: 'Zoom nos takes',
  desc: 'Camada de ajuste com zoom em cada take: 10%, 30%, 50%, alternado, in e out',
  needs: 'clips',
  steps: ['Selecione os takes (ou escolha todos da trilha)', 'Monte o padrão de zoom', 'Toque em Aplicar'],
  keywords: 'zoom take camada de ajuste transformar escala punch in out alternado ken burns aftermovie same day 10% 30% 50%',
  render: function render(el) {
    var s = Store.s;
    var chips = [5, 10, 15, 20, 30, 40, 50, 75];
    var zs = function zs() {
      return Store.s.zmZooms || [];
    };
    el.innerHTML = "\n      <div class=\"zprev\" data-zprev></div>\n      <div class=\"hint\">Pr\xE9via de 8 takes seguidos: assim vai ficar o zoom em cada um.</div>\n      <div class=\"row\"><label class=\"l\">Aplicar em</label>".concat(UI.seg('zmScope', [['sel', 'Selecionados'], ['track', 'Todos da trilha']], s.zmScope), "</div>\n      <div class=\"row\"><label class=\"l\">Quais takes</label>").concat(UI.seg('zmPattern', [['all', 'Todos'], ['alt', 'Alternado'], ['every', 'A cada N']], s.zmPattern), "</div>\n      <div class=\"row\" data-zevery style=\"").concat(s.zmPattern === 'every' ? '' : 'display:none', "\"><label class=\"l\">N</label>").concat(UI.range('zmEvery', 2, 8, 1, s.zmEvery, ' takes'), "</div>\n      <div class=\"row\" data-zoff style=\"").concat(s.zmPattern === 'all' ? 'display:none' : '', "\">").concat(UI.toggle('zmOffset', 'Começar pelo 2º take', s.zmOffset), "</div>\n      <div class=\"row\"><label class=\"l\">Zoom</label><div class=\"zchips\"><span data-zcl></span><input class=\"input num\" data-zcustom type=\"number\" min=\"1\" max=\"300\" placeholder=\"outro\"></div></div>\n      <div class=\"row\"><label class=\"l\">Ordem</label>").concat(UI.seg('zmOrder', [['cycle', 'Em sequência'], ['random', 'Aleatória']], s.zmOrder), "</div>\n      <div class=\"row\"><label class=\"l\">Movimento</label>").concat(UI.select('zmMotion', ZOOM_MOTIONS, s.zmMotion), "</div>\n      <div class=\"row\" data-zdur><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.seg('zmDurMode', [['take', 'Take inteiro'], ['frames', 'Personalizada']], s.zmDurMode), "</div>\n      <div class=\"row\" data-zfr style=\"").concat(s.zmDurMode === 'frames' ? '' : 'display:none', "\"><label class=\"l\">Quadros</label>").concat(UI.range('zmFrames', 3, 60, 1, s.zmFrames, ' fr'), "</div>\n      <div class=\"row\" data-zoe>").concat(UI.toggle('zmOutEnd', 'Zoom out no fim do take', s.zmOutEnd), "</div>\n      <div class=\"row\"><label class=\"l\">Suavidade</label>").concat(UI.seg('zmEase', [['linear', 'Linear'], ['smooth', 'Suave'], ['fast', 'Rápida'], ['slow', 'Lenta']], s.zmEase), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Deslocar</label>").concat(UI.select('zmDrift', ZOOM_DRIFTS, s.zmDrift), "</div>\n        <div class=\"row\"><label class=\"l\">Quanto</label>").concat(UI.range('zmDriftAmt', 1, 15, 1, s.zmDriftAmt, '%'), "</div>\n        <div class=\"row\">").concat(UI.toggle('zmBlur', 'Desfoque de movimento no zoom', s.zmBlur), "</div>\n        <div class=\"row\">").concat(UI.toggle('zmColor', 'Zoom in e zoom out com as cores das suas camadas', s.zmColor !== false), "</div>\n        <div class=\"hint\">Usa as mesmas cores das camadas de ajuste \"Zoom in\" e \"Zoom out\" que voc\xEA j\xE1 tem no projeto. Sem elas, usa marrom e amarelo.</div>\n      </div></details>\n      <div class=\"hint\">Cada take ganha uma camada de ajuste \"Zoom in X%\" ou \"Zoom out X%\" com o efeito Transformar: d\xE1 para mudar ou apagar depois.</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('zoom'), "Aplicar zoom</button></div>");
    var chipsHTML = function chipsHTML() {
      return Array.from(new Set(chips.concat(zs()))).sort(function (x, y) {
        return x - y;
      }).map(function (c) {
        return "<button class=\"zchip ".concat(zs().includes(c) ? 'on' : '', "\" data-zc=\"").concat(c, "\">").concat(c, "%</button>");
      }).join('');
    };
    $('[data-zcl]', el).innerHTML = chipsHTML();
    var sync = function sync() {
      var st = Store.s,
        anim = st.zmMotion !== 'static';
      $('[data-zevery]', el).style.display = st.zmPattern === 'every' ? '' : 'none';
      $('[data-zoff]', el).style.display = st.zmPattern === 'all' ? 'none' : '';
      $('[data-zdur]', el).style.display = anim ? '' : 'none';
      $('[data-zfr]', el).style.display = anim && st.zmDurMode === 'frames' ? '' : 'none';
      $('[data-zoe]', el).style.display = (st.zmMotion === 'out' || st.zmMotion === 'alt') && st.zmDurMode === 'frames' ? '' : 'none';
      ZoomTakes.preview(el);
    };
    UI.bindSettings(el, sync);
    el.addEventListener('change', function () {
      return setTimeout(sync, 0);
    });
    el.addEventListener('click', function (e) {
      var c = e.target.closest('[data-zc]');
      if (c) {
        var v = +c.getAttribute('data-zc');
        var list = zs().slice();
        list = list.includes(v) ? list.filter(function (x) {
          return x !== v;
        }) : list.concat(v).sort(function (x, y) {
          return x - y;
        });
        if (!list.length) {
          UI.toast('Escolha pelo menos um zoom', 'info');
          return;
        }
        Store.set('zmZooms', list);
        c.classList.toggle('on');
        sync();
        return;
      }
      var b = e.target.closest('[data-apply]');
      if (b) ZoomTakes.run(b);
    });
    $('[data-zcustom]', el).addEventListener('change', function (e) {
      var v = Math.round(+e.target.value);
      if (!(v > 0 && v <= 300)) return;
      var list = zs().includes(v) ? zs() : zs().concat(v).sort(function (x, y) {
        return x - y;
      });
      Store.set('zmZooms', list);
      e.target.value = '';
      $('[data-zcl]', el).innerHTML = chipsHTML();
      sync();
    });
    sync();
  }
});
var GL_LOOKS = [['cone', 'Cone', 'Centro limpo e anéis de vidro girando em volta'], ['fantasma', 'Fantasma', 'Borda redonda que repete a imagem maior e desfocada'], ['ondas', 'Ondas', 'Ondas circulares de vidro na imagem toda'], ['esferico', 'Esférico', 'Lente redonda suave, borda desfocada'], ['foco', 'Foco duplo', 'Um lado nítido e o outro desfocado com fantasma'], ['icosaedro', 'Icosaedro', 'Facetas grandes nas bordas deslocando a imagem'], ['octaedro', 'Octaedro', 'Prisma com arco-íris nas quinas'], ['replicador', 'Replicador', 'Cópias lado a lado, cada vez mais transparentes'], ['esticar', 'Esticar', 'A imagem estica para o lado a partir do assunto'], ['gotas', 'Gotas', 'Gotas d’água no vidro'], ['ondulado', 'Ondulado', 'Bordas tortas e moles, centro firme'], ['caleidoscopio', 'Caleidoscópio', 'Facetas grandes que repetem o assunto'], ['icosfera', 'Icosfera', 'Muitas facetas pequenas, cada uma com o assunto'], ['colmeia', 'Colmeia', 'Colmeia de cópias do assunto']];
var GL_ANIMS = [['none', 'Fixo'], ['slide', 'Passa'], ['pulse', 'Pulso'], ['in', 'Entra'], ['spin', 'Gira']];
var GlassPV = {
  W: 1920,
  H: 1080,
  SW: 640,
  SH: 360,
  srcCanvas: null,
  portrait: false,
  scene: function scene() {
    if (this.srcCanvas) return this.srcCanvas;
    var c = document.createElement('canvas');
    c.width = this.SW;
    c.height = this.SH;
    var g = c.getContext('2d'),
      w = this.SW,
      h = this.SH;
    var gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#3a2412');
    gr.addColorStop(1, '#120a05');
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    var seed = 7;
    var rnd = function rnd() {
      return (seed = (seed * 9301 + 49297) % 233280) / 233280;
    };
    for (var i = 0; i < 40; i++) {
      var x = rnd() * w,
        y = rnd() * h * 0.7,
        r = 8 + rnd() * 22;
      g.fillStyle = "rgba(255,".concat(180 + rnd() * 60 | 0, ",").concat(90 + rnd() * 80 | 0, ",").concat(0.25 + rnd() * 0.45, ")");
      g.beginPath();
      g.arc(x, y, r, 0, 7);
      g.fill();
    }
    g.fillStyle = '#1a1410';
    g.beginPath();
    g.ellipse(w * 0.47, h * 1.05, w * 0.2, h * 0.45, 0, 0, 7);
    g.fill();
    gr = g.createRadialGradient(w * 0.46, h * 0.3, 4, w * 0.47, h * 0.33, h * 0.16);
    gr.addColorStop(0, '#c99474');
    gr.addColorStop(1, '#5c3a26');
    g.fillStyle = gr;
    g.beginPath();
    g.ellipse(w * 0.47, h * 0.34, w * 0.07, h * 0.15, 0, 0, 7);
    g.fill();
    this.srcCanvas = c;
    this._skey = 'demo';
    return c;
  },
  setAspect: function setAspect(portrait) {
    this.portrait = portrait;
    if (portrait) Object.assign(this, {
      W: 1080,
      H: 1920,
      SW: 360,
      SH: 640
    });else Object.assign(this, {
      W: 1920,
      H: 1080,
      SW: 640,
      SH: 360
    });
  },
  useImage: function useImage(img) {
    this.setAspect(img.height > img.width);
    var c = document.createElement('canvas');
    c.width = this.SW;
    c.height = this.SH;
    var g = c.getContext('2d'),
      r = Math.max(this.SW / img.width, this.SH / img.height),
      w = img.width * r,
      h = img.height * r;
    g.drawImage(img, (this.SW - w) / 2, (this.SH - h) / 2, w, h);
    this.srcCanvas = c;
    this.real = true;
    this._drawn = null;
    this._skey = 'img' + Date.now();
  },
  grab: function grab(btn, quiet) {
    var _this29 = this;
    if (!FE.inCEP) {
      if (!quiet) UI.toast('Abra no Premiere para usar o seu take', 'info');
      return Promise.resolve();
    }
    var path = "".concat(Gen.dir(), "/vidro/quadro_").concat(Date.now() % 1e6, ".png");
    FS.mkdirp(path.replace(/[\\/][^\\/]*$/, ''));
    if (btn) btn.classList.add('busy');
    return FE.call('exportFrame', {
      path: path
    }).then(function () {
      return MC.waitFile(path, 8000);
    }).then(function () {
      return MC.loadImg(FS.fileURL(path) + '?' + Date.now());
    }).then(function (img) {
      if (btn) btn.classList.remove('busy');
      if (!img) {
        if (!quiet) UI.toast('Não consegui ler o quadro. Tente de novo.', 'err');
        return;
      }
      _this29.useImage(img);
      try {
        FS.remove(path);
      } catch (e) {}
      if (!quiet) UI.toast('Prévia usando o quadro da agulha', 'ok');
    }).catch(function (e) {
      if (btn) btn.classList.remove('busy');
      if (!quiet) UI.toast(e.message, 'err');
    });
  },
  draw: function draw(cv, s, u) {
    var w = Math.round(this.W / 6),
      h = Math.round(this.H / 6);
    if (cv.width !== w || cv.height !== h) {
      cv.width = w;
      cv.height = h;
      cv.classList.toggle('portrait', !!this.portrait);
    }
    if (!GlassGL.init(cv)) return false;
    GlassGL.setSource(this.scene(), this._skey);
    GlassGL.draw(Object.assign(glassStateAt(s, u), {
      lite: true
    }), this.W, this.H);
    return true;
  },
  key: function key(s) {
    return [this._skey, s.glLook, s.glX, s.glY, s.glSize, s.glStr, s.glChroma, s.glSoft, s.glLight, s.glAnim, s.glFstop, s.glTiltX, s.glTiltY].join('|');
  },
  loop: function loop(cv) {
    var _this30 = this;
    if (this._raf) cancelAnimationFrame(this._raf);
    var t0 = performance.now();
    var last = 0;
    var _tick4 = function tick(now) {
      if (!document.body.contains(cv)) {
        _this30._raf = null;
        return;
      }
      _this30._raf = requestAnimationFrame(_tick4);
      if (document.hidden) return;
      var s = Store.s,
        k = _this30.key(s);
      if (k !== _this30._lastKey) {
        _this30._lastKey = k;
        _this30.animUntil = now + 3500;
      }
      var still = s.glAnim === 'none' || now > (_this30.animUntil || 0) && !_this30.hover;
      if (still && _this30._drawn === k) return;
      if (now - last < 66) return;
      last = now;
      _this30.draw(cv, s, still ? 0.5 : (now - t0) / 2400 % 1);
      _this30._drawn = still ? k : null;
    };
    this._drawn = null;
    this._raf = requestAnimationFrame(_tick4);
  }
};
var Glass = {
  busy: false,
  run: function run(btn) {
    var _this31 = this;
    return _asyncToGenerator(_regenerator().m(function _callee() {
      var fs, Bf, s, lk, label, set, info, dir, cv, R, N, B, firstOut, from, count, r, k, i, src, img, data, out, res, _t, _t2;
      return _regenerator().w(function (_context) {
        while (1) switch (_context.p = _context.n) {
          case 0:
            if (!_this31.busy) {
              _context.n = 1;
              break;
            }
            return _context.a(2);
          case 1:
            if (FE.inCEP) {
              _context.n = 2;
              break;
            }
            UI.toast('Disponível dentro do Premiere', 'info');
            return _context.a(2);
          case 2:
            fs = NodeX.req('fs'), Bf = (NodeX.req('buffer') || {}).Buffer || window.Buffer;
            if (!(!fs || !Bf)) {
              _context.n = 3;
              break;
            }
            UI.toast('Esta versão do Premiere não permite gravar os quadros.', 'err');
            return _context.a(2);
          case 3:
            s = JSON.parse(JSON.stringify(Store.s)), lk = GL_LOOKS.find(function (x) {
              return x[0] === s.glLook;
            }) || GL_LOOKS[0];
            _this31.busy = true;
            label = btn.innerHTML, set = function set(t) {
              btn.innerHTML = "".concat(icon('glass')).concat(t);
            };
            btn.classList.add('busy');
            info = null;
            _context.p = 4;
            _context.n = 5;
            return FE.call('glassBegin', {});
          case 5:
            info = _context.v;
            dir = "".concat(Gen.dir(), "/vidro/r").concat(Date.now() % 1e7);
            FS.mkdirp(dir);
            cv = document.createElement('canvas');
            cv.width = info.w;
            cv.height = info.h;
            R = makeGlassGL();
            if (R.init(cv)) {
              _context.n = 6;
              break;
            }
            throw new Error('A placa de vídeo não aceitou o motor do vidro.');
          case 6:
            N = info.n, B = 12;
            firstOut = '';
            from = 0;
          case 7:
            if (!(from < N)) {
              _context.n = 18;
              break;
            }
            count = Math.min(B, N - from);
            set("Lendo quadros ".concat(from + 1, "/").concat(N));
            _context.n = 8;
            return FE.call('glassFrames', {
              f0: info.f0,
              from: from,
              count: count,
              prefix: "".concat(dir, "/in_")
            });
          case 8:
            r = _context.v;
            k = 0;
          case 9:
            if (!(k < r.paths.length)) {
              _context.n = 17;
              break;
            }
            i = from + k, src = r.paths[k];
            set("Desenhando ".concat(i + 1, "/").concat(N));
            _context.n = 10;
            return MC.waitFile(src, 10000);
          case 10:
            _context.n = 11;
            return MC.loadImg(FS.fileURL(src) + '?' + i);
          case 11:
            img = _context.v;
            if (img) {
              _context.n = 14;
              break;
            }
            _context.n = 12;
            return new Promise(function (ok) {
              return setTimeout(ok, 300);
            });
          case 12:
            _context.n = 13;
            return MC.loadImg(FS.fileURL(src) + '?r' + i);
          case 13:
            img = _context.v;
          case 14:
            if (img) {
              _context.n = 15;
              break;
            }
            throw new Error("N\xE3o consegui ler o quadro ".concat(i + 1, "."));
          case 15:
            R.setSource(img, null);
            R.draw(glassStateAt(s, N > 1 ? i / (N - 1) : 0.5), info.w, info.h);
            data = cv.toDataURL('image/jpeg', 0.9).split(',')[1];
            out = "".concat(dir, "/vidro_").concat(String(i).padStart(5, '0'), ".jpg");
            fs.writeFileSync(out, Bf.from(data, 'base64'));
            if (!firstOut) firstOut = out;
            try {
              fs.unlinkSync(src);
            } catch (e) {}
            _context.n = 16;
            return new Promise(function (ok) {
              return setTimeout(ok, 0);
            });
          case 16:
            k++;
            _context.n = 9;
            break;
          case 17:
            from += B;
            _context.n = 7;
            break;
          case 18:
            set('Colocando na timeline…');
            _context.n = 19;
            return FE.call('glassPlace', {
              first: firstOut,
              f0: info.f0,
              n: N,
              top: info.top,
              cti: info.cti,
              name: "Vidro ".concat(lk[1])
            });
          case 19:
            res = _context.v;
            UI.toast("Vidro ".concat(lk[1], " aplicado na trilha V").concat(res.track), 'ok');
            App.log(true, "Vidro: ".concat(lk[1], " (").concat(N, " quadros)"));
            _context.n = 24;
            break;
          case 20:
            _context.p = 20;
            _t = _context.v;
            UI.toast(_t.message, 'err');
            App.log(false, "Vidro: ".concat(_t.message));
            if (!info) {
              _context.n = 24;
              break;
            }
            _context.p = 21;
            _context.n = 22;
            return FE.call('glassPlace', {
              restoreOnly: true,
              cti: info.cti
            });
          case 22:
            _context.n = 24;
            break;
          case 23:
            _context.p = 23;
            _t2 = _context.v;
          case 24:
            _context.p = 24;
            _this31.busy = false;
            btn.classList.remove('busy');
            btn.innerHTML = label;
            return _context.f(24);
          case 25:
            return _context.a(2);
        }
      }, _callee, null, [[21, 23], [4, 20, 24, 25]]);
    }))();
  }
};
App.registerTool({
  id: 'vidro',
  module: 'after',
  icon: 'glass',
  title: 'Vidro',
  desc: 'Vidros e prismas na frente da lente: cone, caleidoscópio, colmeia, replicador, gotas…',
  needs: 'clips',
  steps: ['Selecione os takes', 'Escolha o vidro e arraste na prévia', 'Toque em Aplicar'],
  keywords: 'vidro glass prisma lente diopter cone fantasma ondas esférico foco duplo icosaedro octaedro replicador esticar gotas ondulado caleidoscópio icosfera colmeia refração filtro aftermovie',
  render: function render(el) {
    var s = Store.s;
    if (!GL_LOOKS.find(function (x) {
      return x[0] === s.glLook;
    })) Store.set('glLook', 'cone');
    el.innerHTML = "\n      <div class=\"glpv\"><canvas data-glcv></canvas><span class=\"glhint\">arraste para mover o vidro</span><button class=\"glgrab\" data-glgrab data-qtip=\"Usa o quadro onde est\xE1 a agulha na timeline\">".concat(icon('zoom'), "Usar meu take</button></div>\n      <div class=\"tiles gltiles\">").concat(GL_LOOKS.map(function (x) {
      return "<button class=\"gltile ".concat(Store.s.glLook === x[0] ? 'on' : '', "\" data-gl=\"").concat(x[0], "\" data-qtip=\"").concat(esc(x[2]), "\">").concat(esc(x[1]), "</button>");
    }).join(''), "</div>\n      <div class=\"hint\" data-gldesc></div>\n      <div class=\"row\"><label class=\"l\">Tamanho</label>").concat(UI.range('glSize', 0.2, 1.4, 0.05, s.glSize, ''), "</div>\n      <div class=\"glsec\">Refra\xE7\xE3o</div>\n      <div class=\"row\"><label class=\"l\">For\xE7a (IOR)</label>").concat(UI.range('glStr', 0.2, 2, 0.1, s.glStr, '×'), "</div>\n      <div class=\"row\"><label class=\"l\">Inclinar \u2194</label>").concat(UI.range('glTiltX', -50, 50, 1, s.glTiltX || 0, '°'), "</div>\n      <div class=\"row\"><label class=\"l\">Inclinar \u2195</label>").concat(UI.range('glTiltY', -50, 50, 1, s.glTiltY || 0, '°'), "</div>\n      <div class=\"glsec\">Abertura</div>\n      <div class=\"row\"><label class=\"l\">f/</label>").concat(UI.range('glFstop', 1.4, 16, 0.1, s.glFstop || 8, ''), "</div>\n      <div class=\"hint glh\">f/16 deixa o vidro n\xEDtido e definido; f/1.4 desfoca o que passa por ele, abstrato e et\xE9reo.</div>\n      <div class=\"glsec\">Aberra\xE7\xE3o e luzes</div>\n      <div class=\"row\"><label class=\"l\">Aberra\xE7\xE3o</label>").concat(UI.range('glChroma', 0, 1, 0.05, s.glChroma, ''), "</div>\n      <div class=\"row\"><label class=\"l\">Realce das luzes</label>").concat(UI.range('glLight', 0, 1, 0.05, s.glLight, ''), "</div>\n      <div class=\"row\"><label class=\"l\">Movimento</label>").concat(UI.seg('glAnim', GL_ANIMS, s.glAnim), "</div>\n      <details class=\"adv\"><summary>Mais op\xE7\xF5es</summary><div>\n        <div class=\"row\"><label class=\"l\">Desfocar fora</label>").concat(UI.range('glSoft', 0, 1, 0.05, s.glSoft, ''), "</div>\n        <div class=\"row\"><button class=\"btn ghost\" data-glcenter>Centralizar e endireitar o vidro</button></div>\n      </div></details>\n      <div class=\"hint\">O Fast Edit desenha o vidro quadro a quadro e coloca o resultado numa trilha acima dos takes selecionados (sem sele\xE7\xE3o: 3 s na agulha). Fica igual \xE0 pr\xE9via.</div>\n      <div class=\"btns\"><button class=\"btn primary\" data-apply>").concat(icon('glass'), "Aplicar vidro</button></div>");
    var cv = $('[data-glcv]', el);
    var sync = function sync() {
      var lk = GL_LOOKS.find(function (x) {
        return x[0] === Store.s.glLook;
      }) || GL_LOOKS[0];
      $('[data-gldesc]', el).textContent = lk[2];
    };
    UI.bindSettings(el, sync);
    var setPos = function setPos(e) {
      var r = cv.getBoundingClientRect();
      Store.set('glX', Math.round(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * 100) / 100);
      Store.set('glY', Math.round(Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)) * 100) / 100);
    };
    cv.addEventListener('pointerdown', function (e) {
      cv.setPointerCapture(e.pointerId);
      setPos(e);
      cv.classList.add('drag');
    });
    cv.addEventListener('pointermove', function (e) {
      if (cv.hasPointerCapture(e.pointerId)) setPos(e);
    });
    cv.addEventListener('pointerup', function () {
      return cv.classList.remove('drag');
    });
    cv.addEventListener('pointerenter', function () {
      GlassPV.hover = true;
    });
    cv.addEventListener('pointerleave', function () {
      GlassPV.hover = false;
    });
    el.addEventListener('click', function (e) {
      var t = e.target.closest('[data-gl]');
      if (t) {
        Store.set('glLook', t.getAttribute('data-gl'));
        $$('[data-gl]', el).forEach(function (x) {
          return x.classList.toggle('on', x === t);
        });
        sync();
        return;
      }
      var gg = e.target.closest('[data-glgrab]');
      if (gg) {
        GlassPV.grab(gg);
        return;
      }
      if (e.target.closest('[data-glcenter]')) {
        Store.set('glX', 0.5);
        Store.set('glY', 0.45);
        Store.set('glTiltX', 0);
        Store.set('glTiltY', 0);
        return;
      }
      var b = e.target.closest('[data-apply]');
      if (b) Glass.run(b);
    });
    sync();
    GlassPV.loop(cv);
    if (!GlassPV.real && FE.inCEP) GlassPV.grab(null, true);
  }
});
var GL_LOOK_ID = {
  cone: 1,
  fantasma: 2,
  ondas: 3,
  esferico: 4,
  foco: 5,
  icosaedro: 6,
  octaedro: 7,
  replicador: 8,
  esticar: 9,
  gotas: 10,
  ondulado: 11,
  caleidoscopio: 12,
  icosfera: 13,
  colmeia: 14
};
var GLASS_FS = "\nprecision highp float;\nuniform sampler2D T; uniform vec2 res; uniform vec2 c; uniform float R, S, CA, soft, light, spin, tm, ap, lite; uniform vec2 tilt; uniform int look;\nvec2 gBias = vec2(0.0); float gCP = 1.0; float gAp = 0.0;\nvarying vec2 vUv;\nconst float PI = 3.14159265;\nvec3 tex(vec2 p) { vec2 u = p / res; u = 1.0 - abs(1.0 - mod(u, 2.0)); return texture2D(T, u).rgb; }\nvec3 texD0(vec2 p, vec2 n, float px) { return vec3(tex(p + n * px).r, tex(p).g, tex(p - n * px).b); }\n/* imagem vista atrav\xE9s do vidro: \xE2ngulo de refra\xE7\xE3o (gBias), abertura (desfoca) e realce das luzes */\nvec3 texD(vec2 p, vec2 n, float px) {\n  p += gBias;\n  vec3 a = texD0(p, n, px);\n  if (gAp > 0.01 && lite > 0.5) {\n    float r = gAp * R * 0.07;\n    a = (a + texD0(p + vec2(r, r) * 0.7, n, px) + texD0(p - vec2(r, r) * 0.7, n, px) + texD0(p + vec2(r, -r) * 0.7, n, px) + texD0(p - vec2(r, -r) * 0.7, n, px)) / 5.0;\n  } else if (gAp > 0.01) {\n    float r = gAp * R * 0.07;\n    a = (a * 2.0 + texD0(p + vec2(r, 0.0), n, px) + texD0(p - vec2(r, 0.0), n, px) + texD0(p + vec2(0.0, r), n, px) + texD0(p - vec2(0.0, r), n, px)\n       + texD0(p + vec2(r, r) * 0.7, n, px) + texD0(p - vec2(r, r) * 0.7, n, px)) / 8.0;\n  }\n  float lum = dot(a, vec3(0.299, 0.587, 0.114));\n  a += a * light * 2.2 * pow(max(0.0, lum - 0.45) / 0.55, 2.0);\n  return a;\n}\nvec3 blur(vec2 p, float rad) { vec3 a = vec3(0.0); float nn = 0.0; for (int i = 0; i < 16; i++) { if (lite > 0.5 && i >= 8) break; nn += 1.0; float an = float(i) * 2.39996; float rr = sqrt((float(i) + 0.5) / 16.0) * rad; a += tex(p + vec2(cos(an), sin(an)) * rr); } return a / nn; }\nvec3 blurD(vec2 p, float rad, vec2 n, float px) { vec3 a = vec3(0.0); float nn = 0.0; for (int i = 0; i < 12; i++) { if (lite > 0.5 && i >= 6) break; nn += 1.0; float an = float(i) * 2.39996; float rr = sqrt((float(i) + 0.5) / 12.0) * rad; a += texD(p + vec2(cos(an), sin(an)) * rr, n, px); } return a / nn; }\nfloat hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }\nvec2 hash2(vec2 p) { return vec2(hash(p), hash(p + 17.31)); }\nvec2 rot(vec2 v, float a) { float co = cos(a), si = sin(a); return vec2(v.x * co - v.y * si, v.x * si + v.y * co); }\nvec4 hexCell(vec2 p) {\n  vec2 r = vec2(1.0, 1.7320508), h = r * 0.5;\n  vec2 a = mod(p, r) - h, b = mod(p - h, r) - h;\n  vec2 g = dot(a, a) < dot(b, b) ? a : b;\n  return vec4(g, p - g);\n}\nfloat hexEdge(vec2 g) { g = abs(g); return 0.5 - max(dot(g, normalize(vec2(1.0, 1.7320508))), g.x); }\nvec3 voro(vec2 p) {\n  vec2 n = floor(p), f = fract(p), mc = vec2(0.0); float md = 8.0, md2 = 8.0;\n  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {\n    vec2 g = vec2(float(i), float(j)), o = 0.15 + 0.7 * hash2(n + g), r = g + o - f; float dd = dot(r, r);\n    if (dd < md) { md2 = md; md = dd; mc = n + g + o; } else if (dd < md2) { md2 = dd; }\n  }\n  return vec3(mc, sqrt(md2) - sqrt(md));\n}\nvec2 tq(vec2 v) { return vec2(v.x / max(0.35, cos(tilt.x)), v.y / max(0.35, cos(tilt.y))); }\n/* facetas que repetem o assunto. p = ponto da imagem; pg = ponto usado para decidir a faceta.\n   Com a abertura aberta, pg varia um pouco em volta de p: perto das divis\xF5es as facetas vizinhas se misturam\n   (borda suave), e no miolo de cada faceta a imagem continua n\xEDtida. */\nvec3 facetRepeat(vec2 p, vec2 pg) {\n  float size = look == 12 ? 1.75 : (look == 13 ? 0.62 : 1.05);\n  vec2 qg = tq(pg - c);\n  float d = length(qg) / R;\n  vec2 cc; float e;\n  vec2 qs = rot(qg, spin) / (R * size);\n  if (look == 13) { vec3 v = voro(qs + 5.0); cc = v.xy - 5.0; e = v.z; }\n  else { vec4 hx = hexCell(qs); cc = hx.zw; e = hexEdge(hx.xy) * 2.0; }\n  vec2 cellPx = c + rot(cc * R * size, -spin);\n  float isCenter = look == 13 ? 0.0 : step(length(cc), 0.01);\n  float sc = look == 13 ? 1.25 : (look == 12 ? 1.0 : 1.05);\n  vec2 jit = (hash2(cc + 1.3) - 0.5) * R * 0.18;\n  vec2 src = isCenter > 0.5 ? p : c + (p - cellPx) * sc / max(0.3, S) + jit * S;\n  src = mix(p, src, smoothstep(0.0, 0.25, S));\n  vec3 col = texD(src, normalize(p - cellPx + 0.001), gCP * 1.2);\n  float hard = 1.0 - ap;\n  col *= 1.0 - 0.1 * hard * (1.0 - smoothstep(0.0, 0.12, e));\n  col += vec3(1.0, 0.85, 0.6) * smoothstep(0.06, 0.0, e) * 0.12 * (0.3 + light) * hard;\n  col *= 1.0 - 0.08 * smoothstep(0.6, 1.8, d) * (1.0 - isCenter);\n  return col;\n}\n/* icosaedro / octaedro: facetas grandes nas bordas, cada uma desloca a imagem (mesma ideia de pg) */\nvec3 facetPoly(vec2 p, vec2 pg, vec3 base) {\n  bool oct = look == 7;\n  vec2 qg = tq(pg - c);\n  float d = length(qg) / R, an = atan(qg.y, qg.x);\n  vec2 nq = d > 0.0001 ? qg / (d * R) : vec2(1.0, 0.0);\n  float r0 = oct ? 1.0 : 1.05;\n  float t = smoothstep(r0 - 0.05 - 0.15 * ap, r0 + 0.08 + 0.15 * ap, d);\n  vec2 cell; float edge;\n  if (oct) {\n    float sec = PI / 2.0, a = an + spin + PI * 0.25 + PI, k = floor(a / sec), fa = fract(a / sec);\n    cell = vec2(k, 0.0); edge = min(fa, 1.0 - fa) * d * 2.0;\n  } else {\n    vec3 v = voro(rot(qg, spin) / (R * 1.3) + 3.0); cell = v.xy; edge = v.z;\n  }\n  vec2 h = hash2(cell) - 0.5;\n  vec2 off = (normalize(h + nq * 0.4) * R * (0.25 + 0.25 * hash(cell + 3.1))) * S;\n  vec3 fac = texD(p + off, normalize(off + 0.001), gCP * (oct ? 4.0 : 2.0));\n  float rainbow = smoothstep(oct ? 0.25 : 0.06, 0.0, edge);\n  vec3 rb = 0.5 + 0.5 * cos(6.2832 * (an * 0.5 + d + vec3(0.0, 0.33, 0.67)));\n  fac += rb * rainbow * (oct ? 0.3 : 0.08) * (0.4 + light) * (1.0 - 0.6 * ap);\n  fac *= 0.92;\n  return mix(base, fac, t);\n}\nvoid main() {\n  vec2 p = vec2(vUv.x, 1.0 - vUv.y) * res;\n  vec2 q = p - c;\n  /* vidro inclinado no espa\xE7o: encurta o vidro e muda o \xE2ngulo da refra\xE7\xE3o */\n  q = vec2(q.x / max(0.35, cos(tilt.x)), q.y / max(0.35, cos(tilt.y)));\n  gBias = vec2(sin(tilt.x), sin(tilt.y)) * R * 0.35 * S;\n  float d = length(q) / R; float an = atan(q.y, q.x);\n  vec2 nq = d > 0.0001 ? q / (d * R) : vec2(1.0, 0.0);\n  float cp = 1.0 + CA * R * 0.04 * (0.6 + 0.4 * S);\n  gCP = cp;\n  bool facety = look == 6 || look == 7 || look >= 12;\n  gAp = facety ? ap * 0.2 : ap;\n  vec3 base = tex(p), col = base;\n  if (look == 1) {\n    float r0 = 0.7, t = max(0.0, d - r0);\n    if (t > 0.0) {\n      vec3 acc = vec3(0.0);\n      for (int i = 0; i < 24; i++) {\n        float k = float(i) / 23.0 - 0.5;\n        vec2 qq = rot(q * (1.0 - 0.3 * S * t), k * (0.25 + 0.6 * t) * S + spin);\n        acc += texD(c + qq + nq * R * 0.02 * sin(float(i) * 1.7), nq, cp * (0.25 + 0.9 * t));\n      }\n      col = acc / 24.0 * (1.0 - 0.15 * smoothstep(0.2, 0.8, t));\n      float ring = pow(abs(sin((d - r0) * 9.0 + an * 0.5)), 6.0);\n      col += vec3(1.0, 0.85, 0.6) * ring * 0.06 * (0.5 + light) * smoothstep(0.0, 0.3, t);\n      col = mix(base, col, smoothstep(0.0, 0.08, t));\n    }\n  } else if (look == 2) {\n    float r0 = 0.95, t = smoothstep(r0 - 0.08, r0 + 0.12, d);\n    vec3 ghost = blurD(c + q * (0.62 - 0.12 * S), R * 0.06, nq, cp);\n    vec3 outb = blur(p, R * 0.08 * t);\n    col = mix(base, mix(outb, ghost * 1.25, clamp(0.6 * S, 0.0, 0.9)), t);\n    col += vec3(1.0, 0.85, 0.6) * exp(-pow((d - r0) * 14.0, 2.0)) * 0.05 * (0.5 + light);\n  } else if (look == 3) {\n    float w = sin(d * 7.0 * PI - spin * 4.0);\n    float amp = R * 0.11 * S * smoothstep(0.15, 0.7, d);\n    vec2 src = p + nq * w * amp;\n    col = texD(src, nq, cp * (0.4 + abs(w)));\n    col *= 1.0 + 0.08 * light * w;\n  } else if (look == 4) {\n    float t = smoothstep(0.75, 1.15, d);\n    vec3 big = blurD(c + q * (0.93 - 0.05 * S), R * 0.06 * S, nq, cp);\n    col = mix(base, mix(blur(p, R * 0.04), big, 0.7), t * (0.6 + 0.3 * S));\n  } else if (look == 5) {\n    float side = smoothstep(-R * 0.1, R * 0.35, p.x - c.x);\n    vec3 a = blur(p, R * 0.07 * S), b = blur(p - vec2(R * 0.22 * S, -R * 0.02), R * 0.05 * S);\n    col = mix(base, mix(a, b, 0.42), side);\n    col = mix(col, blur(p, R * 0.05), 0.35 * smoothstep(0.2, 0.0, p.x / res.x));\n  } else if (look == 6 || look == 7) {\n    float rad = R * (0.012 + 0.2 * ap);\n    vec3 acc = vec3(0.0); float nn = 0.0;\n    for (int i = 0; i < 20; i++) { if (lite > 0.5 && i >= 8) break; float a2 = float(i) * 2.39996, rr = sqrt((float(i) + 0.5) / (lite > 0.5 ? 8.0 : 20.0)) * rad; acc += facetPoly(p, p + vec2(cos(a2), sin(a2)) * rr, base); nn += 1.0; }\n    col = acc / nn;\n  } else if (look == 8) {\n    float dx = R * 0.7 * S;\n    col = tex(p) * 0.36;\n    col += texD(p - vec2(dx, 0.0), vec2(1.0, 0.0), cp) * 0.23 + texD(p + vec2(dx, 0.0), vec2(1.0, 0.0), cp) * 0.23;\n    col += texD(p - vec2(dx * 2.0, 0.0), vec2(1.0, 0.0), cp * 1.5) * 0.09 + texD(p + vec2(dx * 2.0, 0.0), vec2(1.0, 0.0), cp * 1.5) * 0.09;\n    col *= 1.08;\n  } else if (look == 9) {\n    float edgeX = c.x + R * 0.35;\n    float t = smoothstep(edgeX + R * 0.05, edgeX - R * 0.25, p.x) * smoothstep(c.y + R * 1.2, c.y + R * 0.6, p.y);\n    vec3 acc = vec3(0.0);\n    for (int i = 0; i < 12; i++) {\n      float k = float(i) / 11.0;\n      float sx = mix(p.x, edgeX, (0.35 + 0.6 * k) * min(S, 1.5) * 0.66);\n      acc += tex(vec2(sx, p.y + (k - 0.5) * R * 0.02));\n    }\n    col = mix(base, acc / 12.0, t);\n  } else if (look == 10) {\n    float gs = R * 0.42;\n    vec2 g = p / gs, n = floor(g);\n    vec3 acc = base; float best = 0.0;\n    for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {\n      vec2 cell = n + vec2(float(i), float(j));\n      float hh = hash(cell * 1.7 + 0.3);\n      if (hh > 0.8 * min(S, 1.2)) continue;\n      vec2 dc = (cell + 0.2 + 0.6 * hash2(cell)) * gs;\n      float rr = gs * (0.25 + 0.2 * hash(cell + 9.1));\n      float dd = length(p - dc) / rr;\n      if (dd < 1.0) {\n        float m = smoothstep(1.0, 0.75, dd);\n        vec3 dr = blurD(dc - (p - dc) * 1.6, rr * 0.35, normalize(p - dc + 0.001), cp);\n        if (m > best) { acc = mix(base, dr * 1.1, m * 0.6); best = m; }\n      }\n    }\n    col = acc;\n  } else if (look == 11) {\n    float t = smoothstep(0.35, 1.2, d);\n    vec2 w = vec2(sin(p.y / R * 3.1 + spin * 3.0 + sin(p.x / R * 1.3)), cos(p.x / R * 2.7 - spin * 2.0 + sin(p.y / R * 1.7)));\n    vec2 src = p + w * R * 0.12 * S * t;\n    col = blurD(src, R * 0.07 * t, normalize(w + 0.001), cp * 0.8 * t);\n  } else {\n    float rad = R * (0.012 + 0.22 * ap);\n    vec3 acc = vec3(0.0); float nn = 0.0;\n    for (int i = 0; i < 20; i++) { if (lite > 0.5 && i >= 8) break; float a2 = float(i) * 2.39996, rr = sqrt((float(i) + 0.5) / (lite > 0.5 ? 8.0 : 20.0)) * rad; acc += facetRepeat(p, p + vec2(cos(a2), sin(a2)) * rr); nn += 1.0; }\n    col = acc / nn;\n  }\n  if (soft > 0.0) col = mix(col, blur(p, soft * R * 0.1), soft * 0.5 * smoothstep(0.5, 1.4, d));\n  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);\n}";
function makeGlassGL() {
  return {
    ok: null,
    init: function init(canvas) {
      if (this.canvas === canvas && this.gl) return true;
      var gl = canvas.getContext('webgl', {
        preserveDrawingBuffer: true,
        premultipliedAlpha: false
      });
      if (!gl) {
        this.ok = false;
        return false;
      }
      var sh = function sh(type, src) {
        var s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
        return s;
      };
      try {
        var pr = gl.createProgram();
        gl.attachShader(pr, sh(gl.VERTEX_SHADER, 'attribute vec2 a; varying vec2 vUv; void main(){ vUv = a * 0.5 + 0.5; gl_Position = vec4(a, 0.0, 1.0); }'));
        gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, GLASS_FS));
        gl.linkProgram(pr);
        if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
        gl.useProgram(pr);
        var b = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, b);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
        var loc = gl.getAttribLocation(pr, 'a');
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
        var t = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, t);
        [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T].forEach(function (w) {
          return gl.texParameteri(gl.TEXTURE_2D, w, gl.CLAMP_TO_EDGE);
        });
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        var U = {};
        ['T', 'res', 'c', 'R', 'S', 'CA', 'soft', 'light', 'spin', 'tm', 'look', 'ap', 'tilt', 'lite'].forEach(function (n) {
          U[n] = gl.getUniformLocation(pr, n);
        });
        Object.assign(this, {
          gl: gl,
          canvas: canvas,
          U: U,
          srcKey: null
        });
        this.ok = true;
        return true;
      } catch (e) {
        console.error('Vidro GL', e);
        this.ok = false;
        return false;
      }
    },
    setSource: function setSource(src, key) {
      var gl = this.gl;
      if (key && key === this.srcKey) return;
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
      this.srcKey = key || null;
    },
    draw: function draw(p, W, H) {
      var gl = this.gl,
        U = this.U,
        cv = this.canvas;
      gl.viewport(0, 0, cv.width, cv.height);
      gl.uniform1i(U.T, 0);
      gl.uniform2f(U.res, W, H);
      gl.uniform2f(U.c, p.x * W, p.y * H);
      gl.uniform1f(U.R, Math.max(4, p.size * Math.min(W, H) / 2));
      gl.uniform1f(U.S, p.strength);
      gl.uniform1f(U.CA, p.chroma);
      gl.uniform1f(U.soft, p.soft);
      gl.uniform1f(U.light, p.light);
      gl.uniform1f(U.spin, p.spin || 0);
      gl.uniform1f(U.tm, p.t || 0);
      gl.uniform1f(U.ap, p.ap || 0);
      gl.uniform1f(U.lite, p.lite ? 1 : 0);
      gl.uniform2f(U.tilt, (p.tiltX || 0) * Math.PI / 180, (p.tiltY || 0) * Math.PI / 180);
      gl.uniform1i(U.look, GL_LOOK_ID[p.look] || 1);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
  };
}
var GlassGL = makeGlassGL();
function glassStateAt(s, u) {
  var x = s.glX,
    k = 1,
    spin = 0;
  if (s.glAnim === 'slide') x = s.glX + (u - 0.5) * 0.5;
  if (s.glAnim === 'pulse') k = Math.sin(Math.PI * u);
  if (s.glAnim === 'in') k = Math.min(1, u * 4);
  if (s.glAnim === 'spin') spin = u * Math.PI * 0.6;
  var f = s.glFstop || 8;
  return {
    look: s.glLook,
    x: x,
    y: s.glY,
    size: s.glSize,
    strength: s.glStr * k,
    chroma: s.glChroma * k,
    soft: s.glSoft,
    light: s.glLight,
    spin: spin,
    t: u,
    ap: Math.max(0, Math.min(1, (16 - f) / 14.6)),
    tiltX: s.glTiltX || 0,
    tiltY: s.glTiltY || 0
  };
}
var NodeX = {
  req: function req(m) {
    try {
      if (window.cep_node && window.cep_node.require) return window.cep_node.require(m);
      if (typeof window.require === 'function') return window.require(m);
    } catch (e) {}
    return null;
  },
  get ok() {
    return !!this.req('child_process');
  },
  run: function run(cmd, args, timeout) {
    var cp = this.req('child_process');
    if (!cp) return Promise.reject(new Error('Node indisponível'));
    return new Promise(function (resolve, reject) {
      cp.execFile(cmd, args, {
        windowsHide: true,
        timeout: timeout || 20000,
        maxBuffer: 4 * 1024 * 1024
      }, function (err, stdout, stderr) {
        if (err) reject(new Error(String(stderr || err.message).trim().slice(0, 300)));else resolve(String(stdout || '').trim());
      });
    });
  }
};
var Clip = {
  stamp: function stamp() {
    var d = new Date();
    return "".concat(d.getFullYear()).concat(pad2(d.getMonth() + 1)).concat(pad2(d.getDate()), "_").concat(pad2(d.getHours())).concat(pad2(d.getMinutes())).concat(pad2(d.getSeconds()));
  },
  projectDir: function projectDir() {
    var pp = App.info && App.info.projectPath;
    return pp && /[\\/]/.test(pp) ? pp.replace(/\\/g, '/').replace(/\/[^/]*$/, '') : '';
  },
  pasteDir: function pasteDir() {
    var d = this.projectDir();
    return d ? d + '/colagens' : (Store.dataDir || '') + '/colagens';
  },
  fresh: function fresh() {
    return FE.call('info').then(function (i) {
      App.info = i;
      return i;
    }).catch(function () {
      return App.info;
    });
  },
  psq: function psq(s) {
    return "'" + String(s).replace(/'/g, "''") + "'";
  },
  isMac: function isMac() {
    return navigator.platform.indexOf('Mac') >= 0;
  },
  readSystem: function readSystem() {
    var _this32 = this;
    var out = this.pasteDir() + "/colagem_".concat(this.stamp(), ".png");
    FS.mkdirp(this.pasteDir());
    if (this.isMac()) {
      var script = ['try', 'set fl to (the clipboard as «class furl»)', 'return "FILE:" & POSIX path of fl', 'end try', 'try', "set f to open for access (POSIX file ".concat(JSON.stringify(out), ") with write permission"), 'write (the clipboard as «class PNGf») to f', 'close access f', "return \"IMG:".concat(out, "\""), 'on error', 'try', 'return "TXT:" & (the clipboard as text)', 'on error', 'return "NONE"', 'end try', 'end try'];
      var args = [];
      script.forEach(function (l) {
        args.push('-e', l);
      });
      return NodeX.run('osascript', args).then(function (r) {
        return _this32.parse(r);
      });
    }
    var ps = ['Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing;', "$out = ".concat(this.psq(out), ";"), '$d = [Windows.Forms.Clipboard]::GetDataObject();', 'if ($d -eq $null) { "NONE"; exit }', 'if ($d.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) { $d.GetData([Windows.Forms.DataFormats]::FileDrop) | ForEach-Object { "FILE:" + $_ }; exit }', 'if ($d.GetDataPresent("PNG")) { $ms = $d.GetData("PNG"); if ($ms -is [IO.MemoryStream]) { [IO.File]::WriteAllBytes($out, $ms.ToArray()); "IMG:" + $out; exit } }', 'if ([Windows.Forms.Clipboard]::ContainsImage()) { $i = [Windows.Forms.Clipboard]::GetImage(); $i.Save($out, [Drawing.Imaging.ImageFormat]::Png); "IMG:" + $out; exit }', 'if ([Windows.Forms.Clipboard]::ContainsText()) { "TXT:" + [Windows.Forms.Clipboard]::GetText(); exit }', '"NONE"'].join(' ');
    return NodeX.run('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps]).then(function (r) {
      return _this32.parse(r);
    });
  },
  parse: function parse(r) {
    var lines = String(r).split(/\r?\n/).map(function (l) {
      return l.trim();
    }).filter(Boolean);
    var files = lines.filter(function (l) {
      return l.indexOf('FILE:') === 0;
    }).map(function (l) {
      return l.slice(5);
    });
    if (files.length) return {
      type: 'files',
      paths: files
    };
    var img = lines.find(function (l) {
      return l.indexOf('IMG:') === 0;
    });
    if (img) return {
      type: 'image',
      paths: [img.slice(4)]
    };
    var txt = lines.find(function (l) {
      return l.indexOf('TXT:') === 0;
    });
    if (txt) {
      var t = txt.slice(4).trim();
      if (/^https?:\/\/\S+$/i.test(t)) return {
        type: 'url',
        url: t
      };
      if (/^[a-z]:[\\/]|^\//i.test(t) && FS.exists(t)) return {
        type: 'files',
        paths: [t]
      };
    }
    return {
      type: 'none'
    };
  },
  download: function download(url) {
    var _this33 = this;
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', url, true);
      x.responseType = 'arraybuffer';
      x.timeout = 30000;
      x.onload = function () {
        if (x.status < 200 || x.status >= 300) return reject(new Error('Não consegui baixar a imagem do link.'));
        var type = (x.getResponseHeader('Content-Type') || '').toLowerCase();
        if (type.indexOf('image/') !== 0) return reject(new Error('O link copiado não é de uma imagem.'));
        var ext = (type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '').slice(0, 4) || 'png';
        var bytes = new Uint8Array(x.response);
        var bin = '';
        for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        var p = _this33.pasteDir() + "/colagem_".concat(_this33.stamp(), ".").concat(ext === 'svgxml' ? 'svg' : ext);
        if (!FS.write(p, btoa(bin), true)) return reject(new Error('Não consegui salvar a imagem.'));
        resolve(p);
      };
      x.onerror = function () {
        return reject(new Error('Sem conexão para baixar a imagem.'));
      };
      x.ontimeout = function () {
        return reject(new Error('O download demorou demais.'));
      };
      x.send();
    });
  },
  saveBlob: function saveBlob(blob) {
    var _this34 = this;
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        var b64 = String(r.result).split(',')[1];
        var ext = (blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
        var p = _this34.pasteDir() + "/colagem_".concat(_this34.stamp(), ".").concat(ext);
        FS.write(p, b64, true) ? resolve(p) : reject(new Error('Não consegui salvar a imagem colada.'));
      };
      r.onerror = function () {
        return reject(new Error('Não consegui ler a imagem colada.'));
      };
      r.readAsDataURL(blob);
    });
  },
  place: function place(paths, btn, cuts) {
    if (!paths || !paths.length) return Promise.resolve();
    var s = Store.s;
    var imgRx = /\.(png|jpe?g|gif|bmp|tiff?|webp|psd|svg|heic)$/i;
    var frames = Math.round((s.clipSeconds || 3) * (App.info && App.info.seq && App.info.seq.fps || 30));
    var at = null,
      placed = 0;
    var _next2 = function next(i) {
      if (i >= paths.length) return Promise.resolve();
      var isImg = imgRx.test(paths[i]);
      var args = {
        kind: 'file',
        path: paths[i],
        mode: paths.length > 1 ? 'playhead' : cuts ? 'cuts' : 'auto',
        frames: frames,
        fit: isImg && s.clipFit !== false,
        natural: !isImg
      };
      if (at !== null) args.atSec = at;
      return FE.call('overlay', args).then(function (d) {
        placed += d.placed;
        if (d.lastEnd !== null && d.lastEnd !== undefined) at = d.lastEnd;
        return _next2(i + 1);
      });
    };
    if (btn) btn.classList.add('busy');
    return _next2(0).then(function () {
      var msg = paths.length > 1 ? "".concat(paths.length, " arquivos colados em sequ\xEAncia") : "Colado ".concat(placed > 1 ? "em ".concat(placed, " takes") : 'na timeline');
      UI.toast(msg, 'ok');
      App.log(true, 'Colar: ' + msg);
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Colar: ' + e.message);
    }).then(function () {
      if (btn) btn.classList.remove('busy');
    });
  },
  paste: function paste(btn, cuts) {
    var _this35 = this;
    if (!FE.inCEP) {
      UI.toast('Disponível dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    if (!NodeX.ok) {
      UI.toast('Use Ctrl+V aqui no painel para colar (reinicie o Premiere para liberar o botão).', 'info');
      return Promise.resolve();
    }
    if (btn) btn.classList.add('busy');
    return this.fresh().then(function () {
      return _this35.readSystem();
    }).then(function (r) {
      if (btn) btn.classList.remove('busy');
      if (r.type === 'none') throw new Error('A área de transferência não tem imagem nem arquivos.');
      if (r.type === 'url') return _this35.download(r.url).then(function (p) {
        return _this35.place([p], btn, cuts);
      });
      return _this35.place(r.paths, btn, cuts);
    }).catch(function (e) {
      if (btn) btn.classList.remove('busy');
      UI.toast(e.message, 'err');
    });
  },
  onPaste: function onPaste(e) {
    var _this36 = this;
    if (/INPUT|TEXTAREA/.test((document.activeElement || {}).tagName || '')) return;
    if (!FE.inCEP) return;
    var items = e.clipboardData ? Array.from(e.clipboardData.items || []) : [];
    var img = items.find(function (it) {
      return it.kind === 'file' && /^image\//.test(it.type);
    });
    if (img) {
      e.preventDefault();
      var f = img.getAsFile();
      this.fresh().then(function () {
        return _this36.saveBlob(f);
      }).then(function (p) {
        return _this36.place([p]);
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
      return;
    }
    if (NodeX.ok) {
      e.preventDefault();
      this.paste(null);
      return;
    }
    var txt = e.clipboardData ? e.clipboardData.getData('text') : '';
    if (/^https?:\/\/\S+$/i.test((txt || '').trim())) {
      e.preventDefault();
      this.fresh().then(function () {
        return _this36.download(txt.trim());
      }).then(function (p) {
        return _this36.place([p]);
      }).catch(function (er) {
        return UI.toast(er.message, 'err');
      });
    }
  },
  copyFrame: function copyFrame(btn, alsoSave) {
    var _this37 = this;
    if (!FE.inCEP) {
      UI.toast('Disponível dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    var dir = (Store.dataDir || '') + '/frames';
    FS.mkdirp(dir);
    var tmp = "".concat(dir, "/frame_").concat(this.stamp(), ".png");
    if (btn) btn.classList.add('busy');
    return FE.call('exportFrame', {
      path: tmp
    }).then(function () {
      return _this37.waitFile([tmp, tmp + '.png']);
    }).then(function (p) {
      var saves = [];
      if (alsoSave) {
        var target = (_this37.projectDir() || Store.dataDir) + '/frames';
        var name = "".concat((App.info && App.info.seq ? App.info.seq.name : 'frame').replace(/[\\/:*?"<>|]/g, '_'), "_").concat(_this37.stamp(), ".png");
        var r = window.cep.fs.readFile(p, window.cep.encoding.Base64);
        if (r.err === 0 && FS.write(target + '/' + name, r.data, true)) saves.push(target + '/' + name);
      }
      return _this37.toClipboard(p).then(function () {
        UI.toast(saves.length ? 'Frame copiado e salvo em /frames' : 'Frame copiado!', 'ok');
        App.log(true, 'Frame copiado para a área de transferência');
      });
    }).catch(function (e) {
      UI.toast(e.message, 'err');
      App.log(false, 'Copiar frame: ' + e.message);
    }).then(function () {
      if (btn) btn.classList.remove('busy');
    });
  },
  waitFile: function waitFile(cands) {
    var t0 = Date.now();
    return new Promise(function (resolve, reject) {
      var _tick5 = function tick() {
        var hit = cands.find(function (p) {
          return FS.exists(p);
        });
        if (hit) {
          setTimeout(function () {
            return resolve(hit);
          }, 250);
          return;
        }
        if (Date.now() - t0 > 8000) return reject(new Error('O Premiere não gerou o frame (tente de novo com a timeline focada).'));
        setTimeout(_tick5, 150);
      };
      _tick5();
    });
  },
  toClipboard: function toClipboard(path) {
    if (NodeX.ok) {
      if (this.isMac()) return NodeX.run('osascript', ['-e', "set the clipboard to (read (POSIX file ".concat(JSON.stringify(path), ") as \xABclass PNGf\xBB)")]);
      var ps = ['Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing;', "$img = [Drawing.Image]::FromFile(".concat(this.psq(path), ");"), '$d = New-Object Windows.Forms.DataObject; $d.SetImage($img);', '$ms = New-Object IO.MemoryStream; $img.Save($ms, [Drawing.Imaging.ImageFormat]::Png); $d.SetData("PNG", $ms);', '[Windows.Forms.Clipboard]::SetDataObject($d, $true); "OK"'].join(' ');
      return NodeX.run('powershell.exe', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps]);
    }
    if (navigator.clipboard && window.ClipboardItem) {
      var r = window.cep.fs.readFile(path, window.cep.encoding.Base64);
      if (r.err !== 0) return Promise.reject(new Error('Frame não encontrado.'));
      var bin = atob(r.data),
        arr = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return navigator.clipboard.write([new window.ClipboardItem({
        'image/png': new Blob([arr], {
          type: 'image/png'
        })
      })]);
    }
    return Promise.reject(new Error('Reinicie o Premiere para liberar a cópia para a área de transferência.'));
  }
};
document.addEventListener('paste', function (e) {
  return Clip.onPaste(e);
});
NEEDS.clip = function (sq) {
  return sq && sq.selected ? ["".concat(sq.selected, " take").concat(sq.selected > 1 ? 's' : '', " selecionado").concat(sq.selected > 1 ? 's' : ''), 'ok'] : sq ? ['Nada selecionado — vai na agulha', 'ok'] : ['Abra uma sequência', 'warn'];
};
App.registerTool({
  id: 'clipboard',
  module: 'workflow',
  icon: 'paste',
  title: 'Copiar & Colar',
  desc: 'Cole imagens na timeline e copie o frame da agulha',
  keywords: 'colar copiar clipboard área de transferência imagem print screenshot navegador frame exportar png ctrl+v',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"stack-btns\">\n        <div class=\"stack-btn\" data-cb=\"paste\">".concat(icon('paste'), "<span>Colar imagem</span><div class=\"tipbox\"><b>Clique:</b> nos takes selecionados ou na agulha<br><b>Shift:</b> um em cada corte<br><b>Ctrl+V</b> no painel tamb\xE9m cola</div></div>\n        <div class=\"stack-btn\" data-cb=\"copy\">").concat(icon('camera'), "<span>Copiar frame</span><div class=\"tipbox\"><b>Clique:</b> copia o frame da agulha<br><b>Shift:</b> tamb\xE9m salva o PNG</div></div>\n      </div>\n      <div class=\"stack-sum\"><span data-sum></span><button class=\"btn sm\" data-cfg>").concat(icon('settings'), "Configurar</button></div>\n      <div class=\"stack-cfg\" data-cfgbox style=\"display:none\">\n        <div class=\"section-label\" style=\"margin-top:4px\">Dura\xE7\xE3o na agulha</div>\n        <div class=\"chips\">").concat([1, 2, 3, 5, 10].map(function (n) {
      return "<span class=\"chip\" data-sec=\"".concat(n, "\">").concat(n, "s</span>");
    }).join(''), "</div>\n        <div class=\"row\">").concat(UI.toggle('clipFit', 'Ajustar ao quadro', s.clipFit !== false), "</div>\n      </div>\n      ").concat(FE.inCEP && !NodeX.ok ? '<div class="hint">Reinicie o Premiere uma vez para liberar os botões.</div>' : '');
    var sum = function sum() {
      var d = Clip.projectDir();
      $('[data-sum]', el).innerHTML = "<b>".concat(Store.s.clipSeconds || 3, "s</b> \xB7 salva em <b>").concat(d ? esc(d.split('/').pop()) + '/colagens' : 'colagens', "</b>");
      $$('[data-sec]', el).forEach(function (c) {
        return c.classList.toggle('on', parseFloat(c.getAttribute('data-sec')) === (Store.s.clipSeconds || 3));
      });
    };
    sum();
    UI.bindSettings(el, sum);
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      var b = g('[data-cb]');
      if (b) return b.getAttribute('data-cb') === 'paste' ? Clip.paste(b, e.shiftKey) : Clip.copyFrame(b, e.shiftKey);
      if (g('[data-cfg]')) {
        var bx = $('[data-cfgbox]', el);
        bx.style.display = bx.style.display === 'none' ? '' : 'none';
        return;
      }
      var sc = g('[data-sec]');
      if (sc) {
        Store.set('clipSeconds', parseFloat(sc.getAttribute('data-sec')));
        sum();
      }
    });
  }
});
var SFX_CATS = [['whoosh', 'Whoosh', /whoosh|swoosh|swish|woosh|whizz|swipe|swoop|pass[\s_-]?by|fly[\s_-]?by/i], ['impact', 'Impacts', /impact|hit|boom|punch|thud|slam|bang|kick|braam|bass|drop|sub\b/i], ['riser', 'Risers', /riser|rise|build|uplift|tension|power[\s_-]?up|reverse/i], ['transition', 'Transições', /transition|sweep|transform|zap|warp|speed|hyperlapse/i], ['ui', 'Cliques & UI', /pop|click|button|select|\bui\b|bubble|tick|blip|notification|ding|beep|enter|typing|keyboard|type|count|number|acent|accent/i], ['glitch', 'Glitch', /glitch|digital|error|static|flicker|distort|data|sci[\s_-]?fi/i], ['camera', 'Câmera', /camera|shutter|flash|snap|photo/i], ['ambience', 'Ambiente', /ambien|atmos|room|wind|rain|city|crowd|forest|seaside|rural|public places|transport|nature|waterfall|jungle|office|airport/i], ['drone', 'Drones', /drone/i], ['foley', 'Foley', /foley|footstep|kitchen|movement|cloth|door|gym|stone|water|fire|mechanic|car\b|cars\b|vehicle|horror|magic|monster|battle/i]];
var SFX_DEFAULT_FOLDERS = ['F:/FIRST VIDEO/SFX', 'E:/Clickup Project File/Clickup Project File/Copied_Brain clcik up AI', 'E:/IGOR ESCOUTO/sfx'];
var SFX_EXTS = /\.(wav|mp3|aif|aiff|m4a|aac|ogg|flac)$/i;
var SFX_SKIP_DIR = /^(__MACOSX|\.|Media Cache|Adobe Premiere Pro |.*\.PRV$|.*PREVIEWS?$|Peak Files)/i;
var SFX_SKIP_FILE = /\.(mp4|mov|mxf|png|jpe?g|gif|pdf|txt|html?|csv|xlsx?|docx?|zip|rar|7z|prproj|prin|pek|cfa|ds_store|json|xml|psd|ai|aep|mogrt|exe|dmg|ini|lnk)$/i;
var Wave = {
  N: 120,
  mem: {},
  queue: [],
  busy: 0,
  ctx: null,
  dirty: false,
  loaded: false,
  file: function file() {
    return Store.dataDir ? Store.dataDir + '/sfx-waves.json' : '';
  },
  load: function load() {
    if (this.loaded) return;
    this.loaded = true;
    try {
      var t = this.file() && FS.read(this.file());
      if (t) this.mem = JSON.parse(t) || {};
    } catch (e) {
      this.mem = {};
    }
  },
  save: debounce(function () {
    if (Wave.file()) FS.write(Wave.file(), JSON.stringify(Wave.mem));
  }, 1500),
  enc: function enc(a) {
    return a.map(function (v) {
      return ('0' + Math.round(v * 255).toString(16)).slice(-2);
    }).join('');
  },
  bad: function bad(path) {
    this.load();
    return this.mem[path] === '!';
  },
  markBad: function markBad(path) {
    var _this38 = this;
    if (!FE.inCEP || this.mem[path] === '!') return;
    this.mem[path] = '!';
    this.save();
    this.badNew = (this.badNew || 0) + 1;
    clearTimeout(this.badT);
    this.badT = setTimeout(function () {
      if (_this38.onBad) _this38.onBad(_this38.badNew);
      _this38.badNew = 0;
    }, 900);
  },
  dec: function dec(t) {
    var a = [];
    for (var i = 0; i < t.length; i += 2) a.push(parseInt(t.substr(i, 2), 16) / 255);
    return a;
  },
  fake: function fake(path) {
    var h = 0;
    for (var i = 0; i < path.length; i++) h = h * 31 + path.charCodeAt(i) >>> 0;
    var a = [],
      atk = 0.05 + h % 7 / 40;
    for (var _i8 = 0; _i8 < this.N; _i8++) {
      var u = _i8 / this.N;
      h = h * 1103515245 + 12345 >>> 0;
      a.push(Math.min(1, (u < atk ? u / atk : Math.exp(-(u - atk) * (2 + h % 5))) * (0.6 + h % 100 / 250)));
    }
    return a;
  },
  readBuf: function readBuf(path) {
    return new Promise(function (res, rej) {
      try {
        var fs = require('fs'),
          st = fs.statSync(path);
        if (st.size > 40 * 1048576) return rej(new Error('grande'));
        var b = fs.readFileSync(path);
        return res(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
      } catch (e) {
        var x = new XMLHttpRequest();
        x.open('GET', FS.fileURL(path), true);
        x.responseType = 'arraybuffer';
        x.onload = function () {
          return x.response ? res(x.response) : rej(new Error('vazio'));
        };
        x.onerror = function () {
          return rej(new Error('erro'));
        };
        x.send();
      }
    });
  },
  compute: function compute(path) {
    var _this39 = this;
    if (!FE.inCEP) return Promise.resolve(this.fake(path));
    if (!this.ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
    }
    return this.readBuf(path).then(function (buf) {
      return new Promise(function (res, rej) {
        return _this39.ctx.decodeAudioData(buf, res, rej);
      });
    }).then(function (ab) {
      var N = _this39.N,
        len = ab.length,
        out = new Array(N).fill(0),
        chs = [];
      for (var c = 0; c < Math.min(2, ab.numberOfChannels); c++) chs.push(ab.getChannelData(c));
      for (var i = 0; i < N; i++) {
        var a = Math.floor(i * len / N),
          b = Math.max(a + 1, Math.floor((i + 1) * len / N)),
          step = Math.max(1, Math.floor((b - a) / 400));
        var m = 0;
        for (var _c = 0; _c < chs.length; _c++) for (var j = a; j < b; j += step) {
          var v = Math.abs(chs[_c][j]);
          if (v > m) m = v;
        }
        out[i] = m;
      }
      var mx = Math.max.apply(null, out) || 1;
      return out.map(function (v) {
        return Math.sqrt(v / mx);
      });
    });
  },
  get: function get(path) {
    var _this40 = this;
    this.load();
    if (this.mem[path] === '!') return Promise.resolve(null);
    if (this.mem[path]) return Promise.resolve(this.dec(this.mem[path]));
    return new Promise(function (res) {
      _this40.queue.unshift({
        path: path,
        res: res
      });
      _this40.pump();
    });
  },
  pump: function pump() {
    var _this41 = this;
    var _loop = function _loop() {
      var job = _this41.queue.shift();
      if (_this41.mem[job.path]) {
        job.res(_this41.mem[job.path] === '!' ? null : _this41.dec(_this41.mem[job.path]));
        return 1;
      }
      _this41.busy++;
      _this41.compute(job.path).then(function (a) {
        if (FE.inCEP) {
          _this41.mem[job.path] = _this41.enc(a);
          _this41.save();
        }
        job.res(a);
      }).catch(function (e) {
        if (!e || e.message !== 'grande') _this41.markBad(job.path);
        job.res(null);
      }).then(function () {
        _this41.busy--;
        _this41.pump();
      });
    };
    while (this.busy < 2 && this.queue.length) {
      if (_loop()) continue;
    }
  },
  validateAll: function validateAll(items) {
    var _this42 = this;
    if (!FE.inCEP || this.validating) return;
    this.load();
    var todo = items.filter(function (x) {
      return !_this42.mem[x.path];
    });
    if (!todo.length) return;
    this.validating = true;
    var left = todo.length;
    todo.forEach(function (x) {
      return _this42.queue.push({
        path: x.path,
        res: function res() {
          if (--left <= 0) _this42.validating = false;
        }
      });
    });
    this.pump();
  },
  draw: function draw(cv, peaks, prog) {
    var dpr = window.devicePixelRatio || 1,
      W = cv.clientWidth || 200,
      H = cv.clientHeight || 26;
    if (cv.width !== Math.round(W * dpr)) {
      cv.width = Math.round(W * dpr);
      cv.height = Math.round(H * dpr);
    }
    var g = cv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, W, H);
    if (!peaks) {
      g.fillStyle = Wave.col(cv, 0.25);
      g.fillRect(0, H / 2 - 0.5, W, 1);
      return;
    }
    var n = peaks.length,
      bw = W / n,
      mid = H / 2;
    for (var i = 0; i < n; i++) {
      var h = Math.max(1, peaks[i] * (H - 2));
      g.fillStyle = Wave.col(cv, prog != null && i / n <= prog ? 1 : 0.55);
      g.fillRect(i * bw, mid - h / 2, Math.max(1, bw - 0.6), h);
    }
  },
  col: function col(cv, a) {
    if (!this.accent) {
      var c = getComputedStyle(cv).color || 'rgb(196,248,42)';
      this.accent = c;
    }
    var m = this.accent.match(/\d+(\.\d+)?/g) || [196, 248, 42];
    return "rgba(".concat(m[0], ",").concat(m[1], ",").concat(m[2], ",").concat(a, ")");
  },
  attach: function attach(root) {
    var _this43 = this;
    this.accent = null;
    var cvs = $$('canvas[data-wave]', root);
    var show = function show(cv) {
      if (cv._done) return;
      cv._done = true;
      var p = cv.getAttribute('data-wave');
      Wave.draw(cv, null);
      Wave.get(p).then(function (pk) {
        cv._peaks = pk;
        Wave.draw(cv, pk, SFX.playing === p ? Wave.prog() : null);
      });
    };
    if (window.IntersectionObserver) {
      if (this.io) this.io.disconnect();
      this.io = new IntersectionObserver(function (es) {
        return es.forEach(function (e) {
          if (e.isIntersecting) {
            show(e.target);
            Wave.io.unobserve(e.target);
          }
        });
      }, {
        rootMargin: '200px'
      });
      cvs.forEach(function (cv) {
        return _this43.io.observe(cv);
      });
    } else cvs.slice(0, 80).forEach(show);
  },
  prog: function prog() {
    var a = SFX.audio;
    return a && a.duration ? a.currentTime / a.duration : 0;
  },
  tick: function tick() {
    var _this44 = this;
    cancelAnimationFrame(this.raf);
    var _loop2 = function loop() {
      $$('canvas[data-wave]').forEach(function (cv) {
        var on = cv.getAttribute('data-wave') === SFX.playing;
        if (on || cv._was) {
          Wave.draw(cv, cv._peaks, on ? Wave.prog() : null);
          cv._was = on;
        }
      });
      if (SFX.playing) _this44.raf = requestAnimationFrame(_loop2);
    };
    _loop2();
  }
};
var SFX = {
  items: null,
  scanning: false,
  playing: null,
  lastPlayed: null,
  audio: null,
  cat: 'all',
  q: '',
  onScan: null,
  cachePath: function cachePath() {
    return Store.dataDir ? Store.dataDir + '/sfx-index.json' : '';
  },
  seedFolders: function seedFolders() {
    if (Store.data.sfxSeeded || !FS.ok) return;
    var have = Store.s.sfxFolders || [];
    SFX_DEFAULT_FOLDERS.forEach(function (f) {
      if (FS.isDir(f) && have.indexOf(f) < 0) have.push(f);
    });
    Store.s.sfxFolders = have;
    Store.data.sfxSeeded = true;
    Store.save();
  },
  cleanName: function cleanName(raw, cat) {
    var n = String(raw).replace(SFX_EXTS, '').replace(/[^\s_(]*@[\w.]+/g, ' ').replace(/[_]+/g, ' ').replace(/\s{2,}/g, ' ').replace(/^[\s\-–·.]+|[\s\-–·.]+$/g, '').trim();
    n = n.replace(/^pack\s*[-–]\s*/i, '').replace(/^(\d+)\s+(\D.*)$/, '$2 $1');
    var label = (SFX_CATS.find(function (c) {
      return c[0] === cat;
    }) || [0, 'Som'])[1].replace(/s$/, '');
    if (!n) n = label;else if (/^[\d\s()]+$/.test(n)) n = label + ' ' + n.replace(/[()]/g, '').trim();
    return n;
  },
  categorize: function categorize(path) {
    var parts = path.replace(/\\/g, '/').split('/');
    var file = parts[parts.length - 1].replace(SFX_EXTS, '');
    for (var i = 0; i < SFX_CATS.length; i++) if (SFX_CATS[i][2].test(file)) return SFX_CATS[i][0];
    var dirs = parts.slice(-5, -1).reverse();
    for (var d = 0; d < dirs.length; d++) for (var _i9 = 0; _i9 < SFX_CATS.length; _i9++) if (SFX_CATS[_i9][2].test(dirs[d])) return SFX_CATS[_i9][0];
    return 'other';
  },
  load: function load() {
    if (this.items) return;
    this.seedFolders();
    var raw = this.cachePath() ? FS.read(this.cachePath()) : null;
    var cache = null;
    try {
      cache = raw ? JSON.parse(raw) : null;
    } catch (e) {
      cache = null;
    }
    var key = 'v2|' + (Store.s.sfxFolders || []).join('|');
    if (cache && cache.key === key && cache.items) {
      var gone = (Store.s.sfxFolders || []).filter(function (f) {
        return !FS.isDir(f);
      }).map(function (f) {
        return f.replace(/\\/g, '/').toLowerCase();
      });
      this.items = gone.length ? cache.items.filter(function (x) {
        return !gone.some(function (g) {
          return x.path.replace(/\\/g, '/').toLowerCase().indexOf(g) === 0;
        });
      }) : cache.items;
      if (Date.now() - cache.t > 6 * 3600000) this.scan();
    } else {
      this.items = [];
      this.scan();
    }
  },
  scan: function scan() {
    var _this45 = this;
    if (this.scanning) return;
    this.scanning = true;
    var folders = (Store.s.sfxFolders || []).slice();
    var out = [];
    var clean = function clean(n) {
      return n.replace(/-\d{8}T\d{6}Z(-\d+)*(-\d+)?$/i, '').replace(/\.(zip|rar)$/i, '').replace(/(^|\s)@[\w.]+/g, '$1').replace(/^[\s\-–]+|[\s\-–]+$/g, '').trim() || n;
    };
    var rootLabel = function rootLabel(f) {
      var parts = f.replace(/\\/g, '/').replace(/\/$/, '').split('/');
      var n = parts.pop();
      if (/^(sfx|sounds?|sons|audios?|efeitos)$/i.test(n) && parts.length > 1) n = parts.pop();
      return clean(n);
    };
    var queue = folders.filter(function (f) {
      return FS.isDir(f);
    }).map(function (f) {
      return {
        dir: f,
        depth: 0,
        label: rootLabel(f)
      };
    });
    var seen = {};
    var _step3 = function step() {
      var budget = 160;
      var _loop3 = function _loop3() {
        var job = queue.shift();
        FS.list(job.dir).forEach(function (n) {
          budget--;
          var p = job.dir.replace(/[\\/]$/, '') + '/' + n;
          if (SFX_EXTS.test(n)) {
            if (n.indexOf('._') === 0) return;
            var k = p.toLowerCase();
            if (seen[k]) return;
            seen[k] = true;
            var cat = _this45.categorize(p);
            out.push({
              path: p,
              name: _this45.cleanName(n, cat),
              cat: cat,
              src: job.label
            });
          } else if (!SFX_SKIP_FILE.test(n) && !SFX_SKIP_DIR.test(n) && job.depth < 10 && FS.isDir(p)) {
            queue.push({
              dir: p,
              depth: job.depth + 1,
              label: job.depth === 0 ? clean(n) : job.label
            });
          }
        });
      };
      while (queue.length && budget > 0) {
        _loop3();
      }
      if (_this45.onScan) _this45.onScan(out.length, false);
      if (queue.length && out.length < 30000) {
        setTimeout(_step3, 0);
        return;
      }
      _this45.items = out;
      _this45.scanning = false;
      if (_this45.cachePath()) FS.write(_this45.cachePath(), JSON.stringify({
        t: Date.now(),
        key: 'v2|' + folders.join('|'),
        items: out
      }));
      if (_this45.onScan) _this45.onScan(out.length, true);
    };
    setTimeout(_step3, 0);
  },
  byCat: function byCat(cat) {
    this.load();
    var favs = Store.data.sfxFavs || [];
    var list = (this.items || []).filter(function (x) {
      return x.cat === cat;
    });
    var pick = list.find(function (x) {
      return favs.includes(x.path);
    }) || list[0];
    return pick ? pick.path : null;
  },
  whoosh: function whoosh() {
    var s = Store.s;
    if (s.sfxWhoosh && (!FS.ok || FS.exists(s.sfxWhoosh))) return s.sfxWhoosh;
    this.load();
    var favs = Store.data.sfxFavs;
    var list = (this.items || []).filter(function (x) {
      return x.cat === 'whoosh';
    });
    var pick = list.find(function (x) {
      return favs.includes(x.path);
    }) || list[0];
    return pick ? pick.path : null;
  },
  play: function play(path, at) {
    var _this46 = this;
    if (!this.audio) this.audio = new Audio();
    var a = this.audio;
    if (at != null && this.playing === path && !a.paused && a.duration) {
      a.currentTime = at * a.duration;
      return;
    }
    if (this.playing === path && !a.paused) {
      a.pause();
      this.playing = null;
      this.markPlaying();
      return;
    }
    if (at != null) {
      var _seek = function seek() {
        a.removeEventListener('loadedmetadata', _seek);
        if (a.duration) a.currentTime = at * a.duration;
      };
      a.addEventListener('loadedmetadata', _seek);
    }
    a.src = FE.inCEP ? FS.fileURL(path) : path;
    a.volume = Store.s.sfxVolume;
    a.onerror = function () {
      if (_this46.playing !== path) return;
      _this46.playing = null;
      _this46.markPlaying();
      if (FS.exists(path)) {
        Wave.markBad(path);
        return;
      }
      var ext = (path.match(/\.(\w+)$/) || [0, ''])[1].toUpperCase();
      UI.toast(FS.exists(path) ? "Pr\xE9via indispon\xEDvel para ".concat(ext || 'este arquivo', " \u2014 inserir na timeline funciona normal.") : 'Arquivo não encontrado. A pasta foi movida ou o HD está desconectado?', 'info');
    };
    var pr = a.play();
    if (pr && pr.catch) pr.catch(function () {});
    this.playing = path;
    this.lastPlayed = path;
    a.onended = function () {
      _this46.playing = null;
      _this46.markPlaying();
    };
    this.markPlaying();
    if (this.onPlay) this.onPlay(path);
  },
  markPlaying: function markPlaying() {
    var _this47 = this;
    $$('[data-play]').forEach(function (b) {
      var on = b.getAttribute('data-play') === _this47.playing;
      b.classList.toggle('playing', on);
      b.innerHTML = icon(on ? 'stop' : 'play');
    });
    Wave.tick();
  },
  insert: function insert(path, btn) {
    var s = Store.s;
    return UI.run(btn, 'Som', 'placeSfx', {
      path: path,
      mode: s.sfxMode,
      track: s.sfxTrack,
      offsetFrames: s.sfxOffset,
      gainDb: s.sfxGain
    }, function (d) {
      return "".concat(d.item, " inserido").concat(d.placed > 1 ? " ".concat(d.placed, "\xD7") : '');
    }).catch(function () {});
  }
};
var SfxPacks = {
  list: null,
  busy: {},
  url: function url() {
    return "https://raw.githubusercontent.com/".concat(UPDATE_REPO, "/main/sfx/packs.json?t=").concat(Date.now());
  },
  dir: function dir(id) {
    return (Store.dataDir || '') + '/SFX/' + id;
  },
  installed: function installed(id) {
    return FS.isDir(this.dir(id)) && (Store.s.sfxFolders || []).indexOf(this.dir(id)) >= 0;
  },
  load: function load() {
    var _this48 = this;
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', _this48.url(), true);
      x.timeout = 20000;
      x.onload = function () {
        if (x.status !== 200) return reject(new Error('Não consegui ver os pacotes agora.'));
        try {
          _this48.list = JSON.parse(x.responseText).packs || [];
          resolve(_this48.list);
        } catch (e) {
          reject(new Error('Lista de pacotes inválida.'));
        }
      };
      x.onerror = x.ontimeout = function () {
        return reject(new Error('Sem internet para buscar os pacotes.'));
      };
      x.send();
    });
  },
  fetchTo: function fetchTo(url, dest, onProg, hops) {
    var _this49 = this;
    var https = NodeX.req('https'),
      fs = NodeX.req('fs');
    if (!https || !fs) return Promise.reject(new Error('Download indisponível nesta versão do Premiere.'));
    return new Promise(function (resolve, reject) {
      var req = https.get(url, {
        headers: {
          'User-Agent': 'FastEdit'
        }
      }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          if ((hops || 0) > 6) return reject(new Error('Muitos redirecionamentos.'));
          return resolve(_this49.fetchTo(res.headers.location, dest, onProg, (hops || 0) + 1));
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error("Falha no download (".concat(res.statusCode, ").")));
        }
        var total = parseInt(res.headers['content-length'] || '0', 10);
        var got = 0;
        var out = fs.createWriteStream(dest);
        res.on('data', function (c) {
          got += c.length;
          if (onProg) onProg(got, total);
        });
        res.pipe(out);
        out.on('finish', function () {
          return out.close(function () {
            return resolve(dest);
          });
        });
        out.on('error', reject);
        res.on('error', reject);
      });
      req.on('error', function () {
        return reject(new Error('A conexão caiu durante o download.'));
      });
      req.setTimeout(60000, function () {
        req.abort();
        reject(new Error('O download parou de responder.'));
      });
    });
  },
  unzip: function unzip(zip, dir) {
    FS.mkdirp(dir);
    var isWin = /^win/i.test(navigator.platform) || /Windows/i.test(navigator.userAgent);
    if (isWin) {
      var q = function q(v) {
        return "'" + String(v).replace(/'/g, "''") + "'";
      };
      return NodeX.run('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', "$ProgressPreference='SilentlyContinue'; Expand-Archive -LiteralPath ".concat(q(zip), " -DestinationPath ").concat(q(dir), " -Force")], 30 * 60000);
    }
    return NodeX.run('/usr/bin/ditto', ['-x', '-k', zip, dir], 30 * 60000);
  },
  install: function install(pack, onState) {
    var _this50 = this;
    if (this.busy[pack.id]) return Promise.resolve();
    this.busy[pack.id] = true;
    var dir = this.dir(pack.id),
      tmp = (Store.dataDir || '') + '/SFX/_download';
    FS.mkdirp(tmp);
    var parts = pack.parts || [pack.url];
    var sizes = pack.partSizes || parts.map(function () {
      return (pack.bytes || 0) / parts.length;
    });
    var totalAll = sizes.reduce(function (a, b) {
      return a + b;
    }, 0) || 1;
    var doneBytes = 0,
      chain = Promise.resolve();
    parts.forEach(function (u, i) {
      chain = chain.then(function () {
        var zip = "".concat(tmp, "/").concat(pack.id, "_").concat(i, ".zip");
        return _this50.fetchTo(u, zip, function (got) {
          return onState('down', Math.min(99, Math.round((doneBytes + got) / totalAll * 100)));
        }).then(function () {
          doneBytes += sizes[i];
          onState('unzip', i + 1, parts.length);
          return _this50.unzip(zip, dir);
        }).then(function () {
          return FS.remove(zip);
        });
      });
    });
    return chain.then(function () {
      var f = (Store.s.sfxFolders || []).slice();
      if (f.indexOf(dir) < 0) f.push(dir);
      Store.set('sfxFolders', f);
      SFX.items = [];
      SFX.scan();
      onState('ok');
    }).catch(function (e) {
      onState('err', e.message);
      throw e;
    }).then(function () {
      _this50.busy[pack.id] = false;
    }, function (e) {
      _this50.busy[pack.id] = false;
      throw e;
    });
  },
  remove: function remove(pack) {
    var dir = this.dir(pack.id);
    Store.set('sfxFolders', (Store.s.sfxFolders || []).filter(function (f) {
      return f !== dir;
    }));
    var isWin = /Windows/i.test(navigator.userAgent);
    var p = isWin ? NodeX.run('cmd', ['/c', 'rmdir', '/s', '/q', dir.replace(/\//g, '\\')], 120000) : NodeX.run('/bin/rm', ['-rf', dir], 120000);
    return p.catch(function () {}).then(function () {
      SFX.items = [];
      SFX.scan();
    });
  },
  mb: function mb(b) {
    return b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB';
  }
};
App.registerTool({
  id: 'sfx',
  module: 'sfx',
  icon: 'sfx',
  title: 'Biblioteca de sons',
  full: true,
  desc: 'Seus efeitos sonoros com prévia, favoritos e inserção em 1 clique',
  keywords: 'som sound design whoosh impacto riser transição sfx efeito sonoro biblioteca áudio inserir',
  render: function render(el) {
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"hero\"><h1>Seus sons<span class=\"hand\">em um clique</span></h1><p><span class=\"tag\" data-count></span></p></div>\n      ".concat(App.connBanner(), "\n      <div class=\"row\"><input class=\"input grow\" data-q placeholder=\"Buscar som\u2026\" value=\"").concat(esc(SFX.q), "\"><button class=\"btn sm\" data-packs title=\"Baixar os pacotes de SFX do Fast Edit\">").concat(icon('download'), "Baixar SFX</button><button class=\"btn sm\" data-addfolder title=\"Adicionar uma pasta sua\">").concat(icon('plus'), "Pasta</button></div>\n      <div data-packlist></div>\n      <div class=\"chips\" data-cats></div>\n      <div class=\"list tall\" data-list></div>\n      <div class=\"panel\"><div class=\"panel-t\">Onde colocar<span class=\"hand\">\u2913</span></div>\n        <div class=\"row\"><label class=\"l\">Inserir no</label>").concat(UI.seg('sfxMode', [['playhead', 'Playhead'], ['selection', 'Clipes'], ['markers', 'Marcadores']], s.sfxMode), "</div>\n        <div class=\"row\"><label class=\"l\">Trilha A</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"99\" data-track value=\"").concat(s.sfxTrack, "\"><label class=\"l\" style=\"min-width:0\">Offset</label><input class=\"input num\" type=\"number\" min=\"-120\" max=\"120\" data-off value=\"").concat(s.sfxOffset, "\"><span class=\"muted\">fr</span></div>\n        <div class=\"row\"><label class=\"l\">Ganho</label>").concat(UI.range('sfxGain', -24, 12, 1, s.sfxGain, ' dB'), "</div>\n        <div class=\"row\"><label class=\"l\">Whoosh padr\xE3o</label><span class=\"grow\" data-whoosh style=\"font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\"></span><button class=\"btn sm\" data-setwhoosh title=\"Usa o \xFAltimo som que voc\xEA ouviu\">Usar o \xFAltimo ouvido</button></div>\n      </div>\n      <div data-folders></div>");
    var listEl = $('[data-list]', el);
    var drawFolders = function drawFolders() {
      var f = Store.s.sfxFolders || [];
      $('[data-folders]', el).innerHTML = f.length ? "<div class=\"section-label\">Suas pastas</div><div class=\"list\">".concat(f.map(function (p, i) {
        return "<div class=\"li\"><span class=\"ic\">".concat(icon('folder'), "</span><span class=\"nm\" title=\"").concat(esc(p), "\">").concat(esc(p), "</span><span class=\"ic\" data-rmfolder=\"").concat(i, "\" title=\"Remover\">").concat(icon('x'), "</span></div>");
      }).join(''), "</div><button class=\"btn sm\" data-rescan>").concat(icon('refresh'), "Procurar sons novos</button>") : '';
    };
    var drawWhoosh = function drawWhoosh() {
      var w = SFX.whoosh();
      $('[data-whoosh]', el).textContent = w ? w.replace(/\\/g, '/').split('/').pop().replace(SFX_EXTS, '') : 'nenhum ainda';
    };
    var draw = function draw() {
      SFX.load();
      Wave.load();
      var all = SFX.items.filter(function (x) {
        return !Wave.bad(x.path);
      });
      var favs = Store.data.sfxFavs,
        q = SFX.q.toLowerCase();
      var counts = {
        all: all.length,
        fav: all.filter(function (x) {
          return favs.includes(x.path);
        }).length
      };
      all.forEach(function (x) {
        counts[x.cat] = (counts[x.cat] || 0) + 1;
      });
      var cats = [['all', 'Todos'], ['fav', '★ Favoritos']].concat(SFX_CATS.map(function (c) {
        return [c[0], c[1]];
      })).concat([['other', 'Outros']]).filter(function (c) {
        return c[0] === 'all' || c[0] === 'fav' || counts[c[0]];
      });
      $('[data-cats]', el).innerHTML = cats.map(function (c) {
        return "<span class=\"chip ".concat(SFX.cat === c[0] ? 'on' : '', "\" data-cat=\"").concat(c[0], "\">").concat(c[1], "<em>").concat(counts[c[0]] || 0, "</em></span>");
      }).join('');
      var rows = all.filter(function (x) {
        return (SFX.cat === 'all' || (SFX.cat === 'fav' ? favs.includes(x.path) : x.cat === SFX.cat)) && (!q || (x.name + ' ' + x.src).toLowerCase().includes(q));
      });
      rows.sort(function (a, b) {
        return favs.includes(b.path) - favs.includes(a.path) || a.name.localeCompare(b.name);
      });
      $('[data-count]', el).textContent = SFX.scanning ? "procurando\u2026 ".concat(SFX.items.length || '') : "".concat(all.length, " sons");
      listEl.innerHTML = rows.length ? rows.slice(0, 500).map(function (x) {
        return "<div class=\"li\" data-row=\"".concat(esc(x.path), "\">\n          <span class=\"ic play ").concat(SFX.playing === x.path ? 'playing' : '', "\" data-play=\"").concat(esc(x.path), "\">").concat(icon(SFX.playing === x.path ? 'stop' : 'play'), "</span>\n          <span class=\"nmw\"><span class=\"nm\" title=\"").concat(esc(x.src), "\">").concat(esc(x.name), "</span><canvas class=\"wave\" data-wave=\"").concat(esc(x.path), "\"></canvas></span>\n          <span class=\"ic ").concat(favs.includes(x.path) ? 'on' : '', "\" data-fav=\"").concat(esc(x.path), "\">").concat(icon('star'), "</span>\n          <span class=\"ic\" data-ins=\"").concat(esc(x.path), "\" title=\"Inserir\">").concat(icon('insert'), "</span></div>");
      }).join('') : "<div class=\"empty\">".concat(art('waves')).concat(SFX.scanning ? 'Procurando seus sons…' : (Store.s.sfxFolders || []).length ? 'Nenhum som encontrado.' : 'Baixe os sons do Fast Edit ou use uma pasta sua.<br><button class="btn primary" data-packs style="margin-top:10px">' + icon('download') + 'Baixar SFX</button> <button class="btn" data-addfolder style="margin-top:10px">' + icon('folder') + 'Minha pasta</button>', "</div>");
      drawWhoosh();
      Wave.attach(listEl);
      if (!SFX.scanning) Wave.validateAll(SFX.items);
    };
    Wave.onBad = function (n) {
      if (!document.body.contains(el)) return;
      draw();
      UI.toast("".concat(n, " som(ns) que n\xE3o abrem foram tirados da lista"), 'info');
    };
    var packEl = $('[data-packlist]', el);
    var drawPacks = function drawPacks(msg) {
      if (!SfxPacks.list) {
        packEl.innerHTML = "<div class=\"panel packs\"><div class=\"muted\">".concat(msg || 'Buscando pacotes…', "</div></div>");
        return;
      }
      packEl.innerHTML = "<div class=\"panel packs\"><div class=\"panel-t\">Sons do Fast Edit<span class=\"ic\" data-closepacks>".concat(icon('x'), "</span></div>").concat(SfxPacks.list.length ? SfxPacks.list.map(function (p) {
        var inst = SfxPacks.installed(p.id);
        return "<div class=\"pack\" data-pack=\"".concat(esc(p.id), "\"><div class=\"pk-t\"><b>").concat(esc(p.name), "</b><span>").concat(p.count ? p.count + ' sons · ' : '').concat(SfxPacks.mb(p.bytes || 0), "</span></div>\n          <div class=\"pk-a\">").concat(inst ? "<span class=\"ok-tag\">".concat(icon('check'), "Instalado</span><span class=\"ic\" data-rmpack=\"").concat(esc(p.id), "\" title=\"Remover\">").concat(icon('trash'), "</span>") : "<button class=\"btn primary sm\" data-getpack=\"".concat(esc(p.id), "\">").concat(icon('download'), "Baixar</button>"), "</div>\n          <div class=\"pk-bar\"><i></i></div></div>");
      }).join('') : '<div class="muted">Nenhum pacote disponível ainda.</div>', "</div>");
    };
    var openPacks = function openPacks() {
      drawPacks();
      SfxPacks.load().then(function () {
        return drawPacks();
      }).catch(function (e) {
        return drawPacks(e.message);
      });
    };
    SFX.onScan = function (n, done) {
      if (!el.isConnected && !document.body.contains(el)) return;
      if (done) draw();else $('[data-count]', el).textContent = "procurando\u2026 ".concat(n);
    };
    draw();
    drawFolders();
    if (FS.ok && !(Store.s.sfxFolders || []).length) openPacks();
    UI.bindSettings(el, function (k, v) {
      if (k === 'sfxVolume' && SFX.audio) SFX.audio.volume = v;
    });
    $('[data-q]', el).addEventListener('input', function (e) {
      SFX.q = e.target.value;
      draw();
    });
    $('[data-track]', el).addEventListener('change', function (e) {
      return Store.set('sfxTrack', clamp(parseInt(e.target.value, 10) || 1, 1, 99));
    });
    $('[data-off]', el).addEventListener('change', function (e) {
      return Store.set('sfxOffset', clamp(parseInt(e.target.value, 10) || 0, -120, 120));
    });
    el.addEventListener('dblclick', function (e) {
      var r = e.target.closest('[data-row]');
      if (r && !e.target.closest('.ic')) SFX.insert(r.getAttribute('data-row'), r);
    });
    el.addEventListener('click', function (e) {
      var g = function g(s2) {
        return e.target.closest(s2);
      };
      if (g('[data-cat]')) {
        SFX.cat = g('[data-cat]').getAttribute('data-cat');
        draw();
        return;
      }
      if (g('[data-play]')) {
        SFX.play(g('[data-play]').getAttribute('data-play'));
        return;
      }
      var wv = g('canvas[data-wave]');
      if (wv) {
        var r = wv.getBoundingClientRect();
        SFX.play(wv.getAttribute('data-wave'), clamp((e.clientX - r.left) / r.width, 0, 0.98));
        return;
      }
      if (g('[data-fav]')) {
        var p = g('[data-fav]').getAttribute('data-fav'),
          a = Store.data.sfxFavs,
          i = a.indexOf(p);
        if (i >= 0) a.splice(i, 1);else a.push(p);
        Store.save();
        draw();
        return;
      }
      if (g('[data-ins]')) {
        SFX.insert(g('[data-ins]').getAttribute('data-ins'), g('[data-ins]'));
        return;
      }
      if (g('[data-row]') && !g('.ic')) {
        SFX.play(g('[data-row]').getAttribute('data-row'));
        return;
      }
      if (g('[data-addfolder]')) {
        var d = FS.pickFolder('Escolha a pasta da sua biblioteca de SFX');
        if (d) {
          Store.s.sfxFolders = (Store.s.sfxFolders || []).concat([d]);
          Store.save();
          SFX.items = [];
          SFX.scan();
          draw();
          drawFolders();
          UI.toast('Pasta adicionada — procurando sons…', 'ok');
        } else if (!FS.ok) UI.toast('Disponível apenas dentro do Premiere', 'info');
        return;
      }
      if (g('[data-packs]')) {
        if (!FS.ok) return UI.toast('Disponível apenas dentro do Premiere', 'info');
        openPacks();
        return;
      }
      if (g('[data-closepacks]')) {
        packEl.innerHTML = '';
        return;
      }
      if (g('[data-getpack]')) {
        var id = g('[data-getpack]').getAttribute('data-getpack'),
          pack = SfxPacks.list.find(function (p) {
            return p.id === id;
          }),
          row = g('[data-pack]');
        var bar = $('.pk-bar i', row),
          act = $('.pk-a', row);
        row.classList.add('loading');
        SfxPacks.install(pack, function (st, a, b) {
          if (st === 'down') {
            bar.style.width = a + '%';
            act.innerHTML = "<span class=\"muted\">".concat(a, "%</span>");
          }
          if (st === 'unzip') act.innerHTML = '<span class="muted">extraindo…</span>';
          if (st === 'ok') {
            UI.toast("".concat(pack.name, " instalado \u2014 sons vinculados"), 'ok');
            drawPacks();
            draw();
            drawFolders();
          }
          if (st === 'err') {
            UI.toast(a, 'err');
            drawPacks();
          }
        }).catch(function () {});
        return;
      }
      if (g('[data-rmpack]')) {
        var _id = g('[data-rmpack]').getAttribute('data-rmpack'),
          _pack = SfxPacks.list.find(function (p) {
            return p.id === _id;
          });
        UI.confirm('Remover pacote', "Apaga os sons de \u201C".concat(_pack.name, "\u201D deste computador."), 'Remover').then(function (ok) {
          if (ok) SfxPacks.remove(_pack).then(function () {
            drawPacks();
            draw();
            drawFolders();
          });
        });
        return;
      }
      if (g('[data-rescan]')) {
        SFX.scan();
        draw();
        UI.toast('Procurando sons novos…', 'info');
        return;
      }
      if (g('[data-setwhoosh]')) {
        if (!SFX.lastPlayed) return UI.toast('Ouça um som (▶) primeiro e depois toque aqui.', 'info');
        Store.set('sfxWhoosh', SFX.lastPlayed);
        drawWhoosh();
        UI.toast('Whoosh padrão definido', 'ok');
        return;
      }
      if (g('[data-rmfolder]')) {
        Store.s.sfxFolders.splice(parseInt(g('[data-rmfolder]').getAttribute('data-rmfolder'), 10), 1);
        Store.save();
        SFX.items = [];
        SFX.scan();
        draw();
        drawFolders();
      }
    });
  }
});
var Timer = {
  state: 'stopped',
  fingerprint: '',
  lastActivity: Date.now(),
  manualPause: false,
  get T() {
    return Store.data.time;
  },
  keyFor: function keyFor(info) {
    return info && info.project ? info.projectPath || info.project : '';
  },
  nameFor: function nameFor(key) {
    var p = this.T.projects[key];
    return p && p.name ? p.name : String(key).replace(/\\/g, '/').split('/').pop().replace(/\.prproj$/i, '');
  },
  project: function project(key) {
    if (!this.T.projects[key]) this.T.projects[key] = {
      name: this.nameFor(key),
      estimateH: 0,
      rate: 0
    };
    return this.T.projects[key];
  },
  init: function init() {
    var _this51 = this;
    var r = this.T.running;
    if (r && Date.now() - r.last > 120000) this.close(r.last);else if (r) this.state = 'running';
    setInterval(function () {
      return _this51.tick();
    }, 1000);
    document.addEventListener('mousedown', function () {
      return _this51.activity();
    }, true);
    document.addEventListener('keydown', function () {
      return _this51.activity();
    }, true);
    App.onInfo(function (info) {
      return _this51.onInfo(info);
    });
  },
  activity: function activity() {
    this.lastActivity = Date.now();
  },
  onInfo: function onInfo(info) {
    var key = this.keyFor(info);
    var s = info && info.seq;
    var fp = s ? [key, s.name, s.clips, s.duration, s.playhead, s.selected, s.vTracks, s.aTracks].join('|') : key;
    if (fp !== this.fingerprint) {
      this.fingerprint = fp;
      this.activity();
    }
    var r = this.T.running;
    if (!Store.s.autoTimer) return;
    if (!key) {
      if (r) this.close(Date.now());
      return;
    }
    if (r && r.key !== key) this.close(Date.now());
    if (!this.T.running && !this.manualPause && this.state !== 'idle') this.start(key);
  },
  start: function start(key) {
    if (!key) {
      var k = this.keyFor(App.info);
      if (!k) {
        UI.toast('Abra um projeto no Premiere para cronometrar.', 'info');
        return;
      }
      key = k;
    }
    if (this.T.running) return;
    this.project(key);
    this.T.running = {
      key: key,
      start: Date.now(),
      last: Date.now()
    };
    this.state = 'running';
    this.manualPause = false;
    this.activity();
    Store.save();
  },
  close: function close(endTs) {
    var r = this.T.running;
    if (!r) return;
    var end = Math.max(r.start, endTs || Date.now());
    var sec = Math.round((end - r.start) / 1000);
    if (sec >= 10) this.T.sessions.push({
      id: uid(),
      key: r.key,
      start: r.start,
      end: end,
      sec: sec
    });
    this.T.running = null;
    this.state = 'stopped';
    Store.save();
  },
  pause: function pause() {
    this.manualPause = true;
    this.close(Date.now());
    this.state = 'paused';
  },
  toggle: function toggle() {
    if (this.T.running) this.pause();else {
      this.manualPause = false;
      this.start();
    }
  },
  persist: function persist() {
    if (this.T.running) {
      this.T.running.last = Date.now();
      Store.saveNow();
    }
  },
  tick: function tick() {
    var r = this.T.running;
    var idleMs = (Store.s.idleMinutes || 0) * 60000;
    if (r) {
      r.last = Date.now();
      if (idleMs && Date.now() - this.lastActivity > idleMs) {
        this.close(this.lastActivity);
        this.state = 'idle';
      }
      if (Date.now() % 15000 < 1000) Store.save();
    } else if (this.state === 'idle' && Date.now() - this.lastActivity < 2000 && Store.s.autoTimer) {
      this.state = 'stopped';
      this.start(this.keyFor(App.info));
    }
    this.renderChip();
    if (App.current === 'time') TimeView.live();
  },
  currentSec: function currentSec() {
    var r = this.T.running;
    return r ? (Date.now() - r.start) / 1000 : 0;
  },
  totalFor: function totalFor(key, sinceTs) {
    var t = 0;
    this.T.sessions.forEach(function (s) {
      if ((!key || s.key === key) && (!sinceTs || s.start >= sinceTs)) t += s.sec;
    });
    var r = this.T.running;
    if (r && (!key || r.key === key)) t += this.currentSec();
    return t;
  },
  todayFor: function todayFor(key) {
    var d = new Date();
    d.setHours(0, 0, 0, 0);
    return this.totalFor(key, d.getTime());
  },
  rateFor: function rateFor(key) {
    var p = this.T.projects[key];
    return p && p.rate ? p.rate : Store.s.hourlyRate;
  },
  renderChip: function renderChip() {
    var chip = $('#timerChip');
    if (!chip) return;
    var key = this.T.running ? this.T.running.key : this.keyFor(App.info);
    chip.className = 'timer-chip ' + (this.T.running ? 'run' : this.state === 'idle' ? 'idle' : '');
    $('span', chip).textContent = fmtDur(key ? this.totalFor(key) : 0);
    chip.title = this.T.running ? 'Cronometrando · clique para detalhes' : this.state === 'idle' ? 'Pausado por inatividade' : 'Cronômetro parado';
  }
};
var TimeView = {
  filter: '',
  render: function render(el) {
    var _this52 = this;
    var s = Store.s;
    el.innerHTML = "\n      <div class=\"hero\"><h1>Seu tempo<span class=\"hand\">vale ouro</span></h1></div>\n      <div class=\"timecard\"><div class=\"clock\">\n        <div class=\"big\" data-big>00:00:00</div>\n        <div class=\"whoc\" data-who></div>\n        <span class=\"state\" data-state></span>\n      </div><button class=\"btn\" data-toggle-timer></button></div>\n      <div class=\"stats\" style=\"margin:0 -3px 8px\">\n        <div class=\"stat\"><b data-today>\u2013</b><span>hoje</span></div>\n        <div class=\"stat\"><b data-total>\u2013</b><span>no projeto</span></div>\n        <div class=\"stat\"><b data-cost>\u2013</b><span>custo</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Quanto cobrar<span class=\"hand\">$$</span></div>\n        <div class=\"row\"><label class=\"l\">Valor/hora</label><input class=\"input num\" style=\"width:84px\" type=\"number\" min=\"0\" step=\"5\" data-rate><span class=\"muted\" data-rate-hint></span></div>\n        <div class=\"row\"><label class=\"l\">Estimativa</label><input class=\"input num\" style=\"width:84px\" type=\"number\" min=\"0\" step=\"0.5\" data-est><span class=\"muted\">horas</span></div>\n        <div data-budget></div>\n        <div class=\"row\" style=\"margin-top:4px\"><label class=\"l\">Margem</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"500\" data-margin value=\"".concat(s.margin, "\"><span class=\"muted\">%</span></div>\n        <div data-quote></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">\xDAltimos 7 dias</div><div class=\"chart\" data-chart></div></div>\n      <div class=\"panel\"><div class=\"panel-t\">Projetos<span class=\"muted\" style=\"margin-left:auto;font-weight:400;font-size:11px\">toque para filtrar</span></div><table class=\"tbl\" data-projects></table></div>\n      <div class=\"section-label\">Sess\xF5es</div>\n      <div class=\"list\" data-sessions></div>\n      <div class=\"btns\"><button class=\"btn\" data-csv>").concat(icon('download'), "Exportar planilha</button><button class=\"btn\" data-addmanual>").concat(icon('plus'), "Lan\xE7ar horas</button></div>\n      <div class=\"panel\" style=\"margin-top:10px\"><div class=\"panel-t\">Cron\xF4metro</div>\n        <div class=\"row\">").concat(UI.toggle('autoTimer', 'Automático', s.autoTimer), "</div>\n        <div class=\"row\"><label class=\"l\">Pausar ap\xF3s</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"120\" data-idle value=\"").concat(s.idleMinutes, "\"><span class=\"muted\">min parado</span></div>\n      </div>");
    UI.bindSettings(el);
    $('[data-idle]', el).addEventListener('change', function (e) {
      return Store.set('idleMinutes', clamp(parseInt(e.target.value, 10) || 0, 0, 120));
    });
    $('[data-margin]', el).addEventListener('input', function (e) {
      Store.set('margin', parseFloat(e.target.value) || 0);
      _this52.live();
    });
    $('[data-rate]', el).addEventListener('change', function (e) {
      var key = _this52.key();
      var v = parseFloat(e.target.value) || 0;
      if (key) {
        _this52.projectCfg(key).rate = v;
        Store.save();
      } else Store.set('hourlyRate', v);
      _this52.live(true);
    });
    $('[data-est]', el).addEventListener('change', function (e) {
      var key = _this52.key();
      if (key) {
        _this52.projectCfg(key).estimateH = parseFloat(e.target.value) || 0;
        Store.save();
        _this52.live(true);
      }
    });
    el.addEventListener('click', function (e) {
      var g = function g(q) {
        return e.target.closest(q);
      };
      if (g('[data-toggle-timer]')) {
        Timer.toggle();
        _this52.live(true);
      }
      if (g('[data-csv]')) _this52.exportCSV();
      if (g('[data-addmanual]')) _this52.manual();
      if (g('[data-delsession]')) {
        var id = g('[data-delsession]').getAttribute('data-delsession');
        UI.confirm('Excluir sessão', 'Remover esta sessão do histórico?', 'Excluir').then(function (ok) {
          if (ok) {
            Store.data.time.sessions = Store.data.time.sessions.filter(function (x) {
              return x.id !== id;
            });
            Store.save();
            _this52.live(true);
          }
        });
      }
      if (g('[data-proj]')) {
        var k = g('[data-proj]').getAttribute('data-proj');
        _this52.filter = _this52.filter === k ? '' : k;
        _this52.live(true);
      }
    });
    this.live(true);
  },
  key: function key() {
    return Timer.T.running ? Timer.T.running.key : Timer.keyFor(App.info);
  },
  projectCfg: function projectCfg(key) {
    return Timer.project(key);
  },
  live: function live(full) {
    var _this53 = this;
    var el = $('#view');
    if (!$('[data-big]', el)) return;
    var s = Store.s,
      key = this.key(),
      cur = s.currency;
    var total = key ? Timer.totalFor(key) : 0;
    var rate = key ? Timer.rateFor(key) : s.hourlyRate;
    $('[data-big]', el).textContent = fmtDur(Timer.T.running ? Timer.currentSec() : 0);
    $('[data-who]', el).textContent = key ? Timer.nameFor(key) : 'Nenhum projeto aberto';
    var st = $('[data-state]', el);
    var states = {
      running: ['Gravando', 'ok'],
      idle: ['Pausado por inatividade', 'warn'],
      paused: ['Pausado', ''],
      stopped: ['Parado', '']
    };
    var cs = Timer.T.running ? states.running : states[Timer.state] || states.stopped;
    st.textContent = cs[0];
    $('[data-toggle-timer]', el).innerHTML = Timer.T.running ? "".concat(icon('pause'), "Pausar") : "".concat(icon('play'), "Come\xE7ar a contar");
    $('[data-today]', el).textContent = fmtDur(key ? Timer.todayFor(key) : 0, false);
    $('[data-total]', el).textContent = fmtDur(total, false);
    $('[data-cost]', el).textContent = fmtMoney(total / 3600 * rate, cur);
    var p = key ? Timer.T.projects[key] : null;
    var est = p ? p.estimateH || 0 : 0;
    if (est) {
      var pct = total / 3600 / est * 100;
      $('[data-budget]', el).innerHTML = "<div class=\"bar ".concat(pct > 100 ? 'over' : '', "\"><i style=\"width:").concat(clamp(pct, 0, 100), "%\"></i></div><div class=\"hint ").concat(pct > 100 ? 'warn' : '', "\">").concat((total / 3600).toFixed(1), "h de ").concat(est, "h estimadas (").concat(Math.round(pct), "%)").concat(pct > 100 ? ' · acima da estimativa' : '', "</div>");
    } else $('[data-budget]', el).innerHTML = '';
    var hours = Math.max(est, total / 3600);
    var price = hours * rate * (1 + (s.margin || 0) / 100);
    $('[data-quote]', el).innerHTML = "<div class=\"quote\"><span>pre\xE7o sugerido</span><b>".concat(fmtMoney(price, cur), "</b><span>").concat(hours.toFixed(1), "h \xD7 ").concat(fmtMoney(rate, cur)).concat(s.margin ? " + ".concat(s.margin, "% de margem") : '', " ").concat(est && est > total / 3600 ? '· pela estimativa' : '· pelo tempo real', "</span></div>");
    if (!full) return;
    var ri = $('[data-rate]', el),
      ei = $('[data-est]', el);
    if (document.activeElement !== ri) ri.value = rate;
    if (document.activeElement !== ei) ei.value = est || '';
    $('[data-rate-hint]', el).textContent = key && p && p.rate ? 'deste projeto' : 'padrão';
    var days = [];
    for (var i = 6; i >= 0; i--) {
      var d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      days.push(d);
    }
    var totals = days.map(function (d) {
      var a = d.getTime(),
        b = a + 86400000;
      var t = 0;
      Timer.T.sessions.forEach(function (x) {
        if (x.start >= a && x.start < b) t += x.sec;
      });
      if (Timer.T.running && Timer.T.running.start >= a && Timer.T.running.start < b) t += Timer.currentSec();
      return t;
    });
    var max = Math.max.apply(null, totals.concat([3600]));
    var wd = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
    $('[data-chart]', el).innerHTML = days.map(function (d, i) {
      return "<div class=\"c\"><em>".concat(totals[i] ? (totals[i] / 3600).toFixed(1) + 'h' : '', "</em><i class=\"").concat(i === 6 ? 'today' : '', "\" style=\"height:").concat(Math.round(totals[i] / max * 60), "px\"></i><span>").concat(wd[d.getDay()], "</span></div>");
    }).join('');
    var keys = {};
    Timer.T.sessions.forEach(function (x) {
      keys[x.key] = (keys[x.key] || 0) + x.sec;
    });
    if (Timer.T.running) keys[Timer.T.running.key] = (keys[Timer.T.running.key] || 0) + Timer.currentSec();
    var rows = Object.keys(keys).sort(function (a, b) {
      return keys[b] - keys[a];
    });
    $('[data-projects]', el).innerHTML = rows.length ? "<tr><th>Projeto</th><th class=\"r\">Horas</th><th class=\"r\">Custo</th></tr>" + rows.map(function (k) {
      return "<tr data-proj=\"".concat(esc(k), "\" style=\"cursor:pointer;").concat(_this53.filter === k ? 'font-weight:700' : '', "\"><td>").concat(esc(Timer.nameFor(k)), "</td><td class=\"r\">").concat((keys[k] / 3600).toFixed(2), "</td><td class=\"r\">").concat(fmtMoney(keys[k] / 3600 * Timer.rateFor(k), cur), "</td></tr>");
    }).join('') : '<tr><td class="muted" style="padding:6px">Nenhuma sessão ainda — o cronômetro começa ao abrir um projeto.</td></tr>';
    var ss = Timer.T.sessions.filter(function (x) {
      return !_this53.filter || x.key === _this53.filter;
    }).slice(-40).reverse();
    $('[data-sessions]', el).innerHTML = ss.length ? ss.map(function (x) {
      var d = new Date(x.start);
      return "<div class=\"li\"><span class=\"nm\">".concat(esc(Timer.nameFor(x.key))).concat(x.manual ? ' <span class="tag">manual</span>' : '', "</span><span class=\"sub\">").concat(pad2(d.getDate()), "/").concat(pad2(d.getMonth() + 1), " ").concat(pad2(d.getHours()), ":").concat(pad2(d.getMinutes()), " \xB7 ").concat(fmtDur(x.sec, false), "</span><span class=\"ic\" data-delsession=\"").concat(x.id, "\">").concat(icon('trash'), "</span></div>");
    }).join('') : "<div class=\"empty\">".concat(art('clock'), "Sem sess\xF5es por enquanto.</div>");
  },
  manual: function manual() {
    var _this54 = this;
    var key = this.key();
    if (!key) return UI.toast('Abra um projeto para lançar tempo.', 'info');
    UI.prompt('Lançar quantas horas neste projeto? (ex: 1,5)', '1').then(function (v) {
      var h = parseFloat(String(v || '').replace(',', '.'));
      if (!h || h <= 0) return;
      var end = Date.now();
      Timer.T.sessions.push({
        id: uid(),
        key: key,
        start: end - h * 3600000,
        end: end,
        sec: Math.round(h * 3600),
        manual: true
      });
      Store.save();
      _this54.live(true);
      UI.toast("".concat(h, "h lan\xE7adas"), 'ok');
    });
  },
  exportCSV: function exportCSV() {
    var cur = Store.s.currency;
    var lines = [['Projeto', 'Início', 'Fim', 'Duração (h)', "Valor/hora (".concat(cur, ")"), "Custo (".concat(cur, ")"), 'Tipo'].join(';')];
    Timer.T.sessions.forEach(function (x) {
      var r = Timer.rateFor(x.key),
        h = x.sec / 3600;
      lines.push([Timer.nameFor(x.key), new Date(x.start).toLocaleString('pt-BR'), new Date(x.end).toLocaleString('pt-BR'), h.toFixed(3).replace('.', ','), String(r).replace('.', ','), (h * r).toFixed(2).replace('.', ','), x.manual ? 'manual' : 'automático'].map(function (c) {
        return "\"".concat(String(c).replace(/"/g, '""'), "\"");
      }).join(';'));
    });
    var csv = '﻿' + lines.join('\r\n');
    var name = "FastEdit-relatorio-".concat(dayKey(Date.now()), ".csv");
    var path = FS.saveDialog('Salvar relatório', name, ['csv']);
    if (path) {
      FS.write(/\.csv$/i.test(path) ? path : path + '.csv', csv);
      UI.toast('Relatório salvo', 'ok');
    } else if (!FS.ok) {
      var a = document.createElement('a');
      a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
      a.download = name;
      a.click();
    }
  }
};
App.registerTool({
  id: 'time',
  module: 'time',
  icon: 'time',
  title: 'Cronômetro',
  full: true,
  desc: 'Cronômetro automático por projeto, custo por hora e relatórios',
  keywords: 'tempo cronômetro timer horas custo preço orçamento relatório produtividade sessões',
  render: function render(el) {
    TimeView.render(el);
  }
});
var Settings = {
  render: function render(outer) {
    var _this55 = this;
    var s = Store.s;
    outer.innerHTML = '';
    var view = document.createElement('div');
    outer.appendChild(view);
    view.innerHTML = "\n      <div class=\"page-head\"><div class=\"back\" data-a=\"back\">".concat(icon('back'), "</div><h2>Ajustes<small>Salvos no seu computador</small></h2></div>\n      <div class=\"panel\"><div class=\"panel-t\">Apar\xEAncia</div>\n        <div class=\"row\">").concat(UI.seg('theme', [['cream', 'Creme'], ['cobalt', 'Cobalto'], ['neon', 'Neon']], s.theme || 'cream'), "</div>\n        <button class=\"btn sm\" data-a=\"tour\">Tutorial guiado</button>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Anima\xE7\xE3o (padr\xF5es)</div>\n        <div class=\"row\"><label class=\"l\">Dura\xE7\xE3o</label>").concat(UI.range('frames', 2, 60, 1, s.frames, ' fr'), "</div>\n        <div class=\"row\"><label class=\"l\">Intensidade</label>").concat(UI.range('intensity', 0.2, 2, 0.1, s.intensity, '×'), "</div>\n        <div class=\"row\">").concat(UI.toggle('ease', 'Movimento suave', s.ease)).concat(UI.toggle('replace', 'Substituir animação anterior', s.replace), "</div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Tempo & pre\xE7o</div>\n        <div class=\"row\"><label class=\"l\">Valor/hora</label><input class=\"input num\" style=\"width:80px\" type=\"number\" min=\"0\" step=\"5\" data-k=\"hourlyRate\" value=\"").concat(s.hourlyRate, "\"><label class=\"l\" style=\"min-width:0\">Moeda</label>").concat(UI.select('currency', [['R$', 'R$'], ['US$', 'US$'], ['€', '€'], ['£', '£']], s.currency), "</div>\n        <div class=\"row\">").concat(UI.toggle('autoTimer', 'Cronômetro automático', s.autoTimer), "</div>\n        <div class=\"row\"><label class=\"l\">Inatividade</label><input class=\"input num\" type=\"number\" min=\"0\" max=\"120\" data-k=\"idleMinutes\" value=\"").concat(s.idleMinutes, "\"><span class=\"muted\">min</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Sons</div>\n        <div class=\"row\"><label class=\"l\">Trilha padr\xE3o</label><input class=\"input num\" type=\"number\" min=\"1\" max=\"99\" data-k=\"sfxTrack\" value=\"").concat(s.sfxTrack, "\"><label class=\"l\" style=\"min-width:0\">Offset</label><input class=\"input num\" type=\"number\" min=\"-120\" max=\"120\" data-k=\"sfxOffset\" value=\"").concat(s.sfxOffset, "\"><span class=\"muted\">fr</span></div>\n      </div>\n      <div class=\"panel\"><div class=\"panel-t\">Atualiza\xE7\xF5es</div><div data-upd></div></div>\n      <div class=\"section-label\">Seus dados</div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-a=\"export\">").concat(icon('download'), "Backup</button><button class=\"btn\" data-a=\"import\">").concat(icon('upload'), "Restaurar</button></div>\n      <div class=\"btns\" style=\"margin-bottom:6px\"><button class=\"btn\" data-a=\"cache\">").concat(icon('trash'), "Limpar imagens geradas</button><button class=\"btn danger\" data-a=\"reset\">").concat(icon('refresh'), "Restaurar padr\xF5es</button></div>\n      <div class=\"section-label\">Sobre</div>\n      <div class=\"panel sel-text\"><div>\n        <b>Fast Edit ").concat(APP_VERSION, "</b> \xB7 Creative Workflow Suite<br><span class=\"hand\" data-credit style=\"font-size:18px;cursor:pointer;text-decoration:underline\">feito por @odalluz</span>\n      </div></div>");
    UI.bindSettings(view, function (k, v) {
      if (k === 'theme') Theme.apply(v);
    });
    this.renderUpdate();
    view.addEventListener('change', function (e) {
      if (e.target.hasAttribute('data-updurl')) {
        Store.set('updateUrl', e.target.value.trim());
        Updater.available = null;
        _this55.renderUpdate();
        return;
      }
      var k = e.target.getAttribute('data-k');
      if (k) Store.set(k, parseFloat(e.target.value) || 0);
    });
    view.addEventListener('click', function (e) {
      if (e.target.closest('[data-credit]')) return FE.openURL(CREDIT_URL);
      if (e.target.closest('[data-checkupd]')) return Updater.check(true);
      if (e.target.closest('[data-doupd]')) return Updater.install(e.target.closest('[data-doupd]'));
      var b = e.target.closest('[data-a]');
      if (!b) return;
      var a = b.getAttribute('data-a');
      if (a === 'back') {
        App.go('home');
        return;
      }
      if (a === 'tour') {
        Tour.start();
        return;
      }
      if (a === 'reconnect') {
        FE.hostReady = false;
        App.poll(true);
      }
      if (a === 'reload') {
        Timer.persist();
        Store.saveNow();
        FE.reload();
      }
      if (a === 'export') {
        var p = FS.saveDialog('Salvar backup do Fast Edit', "FastEdit-backup-".concat(dayKey(Date.now()), ".json"), ['json']);
        if (p) {
          FS.write(p, JSON.stringify(Store.data, null, 2));
          UI.toast('Backup salvo', 'ok');
        }
      }
      if (a === 'import') {
        var _p = FS.pickFile('Escolha um backup do Fast Edit', ['json']);
        if (!_p) return;
        try {
          var d = JSON.parse(FS.read(_p));
          Store.data = Store.merge(JSON.parse(JSON.stringify(DEFAULTS)), d);
          Store.saveNow();
          UI.toast('Backup restaurado', 'ok');
          _this55.render(outer);
        } catch (er) {
          UI.toast('Arquivo inválido', 'err');
        }
      }
      if (a === 'cache') {
        var dir = Gen.dir();
        var files = FS.list(dir);
        files.forEach(function (f) {
          return FS.remove(dir + '/' + f);
        });
        UI.toast("".concat(files.length, " imagem(ns) removida(s). Itens j\xE1 importados no projeto continuam l\xE1."), 'info');
      }
      if (a === 'reset') {
        UI.confirm('Restaurar padrões', 'Volta todas as preferências ao padrão. Sessões de tempo, stacks e favoritos são mantidos.', 'Restaurar').then(function (ok) {
          if (!ok) return;
          Store.data.settings = JSON.parse(JSON.stringify(DEFAULTS.settings));
          Store.saveNow();
          _this55.render(outer);
          UI.toast('Padrões restaurados', 'ok');
        });
      }
    });
  }
};
Settings.renderUpdate = function () {
  var el = $('[data-upd]');
  if (!el) return;
  var u = Updater.available;
  el.innerHTML = "<div class=\"row\" style=\"margin:0\"><span>Vers\xE3o <b>".concat(APP_VERSION, "</b></span>\n    ").concat(u ? "<button class=\"btn primary sm right\" data-doupd>".concat(icon('download'), "Atualizar para ").concat(esc(u.version), "</button>") : "<button class=\"btn sm right\" data-checkupd>".concat(icon('refresh')).concat(Updater.checking ? 'Procurando…' : 'Procurar atualização', "</button>"), "</div>");
};
(function boot() {
  var start = function start() {
    try {
      App.init();
    } catch (e) {
      document.body.innerHTML = "<div style=\"padding:16px;color:#f87171;font:12px Segoe UI\">Erro ao iniciar o Fast Edit: ".concat(esc(e.message), "</div>");
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);else start();
})();
var UPDATE_REPO = 'thauanfelippepro-ux/fast-edit';
var CREDIT_URL = 'https://instagram.com/odalluz';
var Updater = {
  available: null,
  checking: false,
  installing: false,
  lastError: '',
  base: function base() {
    var custom = (Store.s.updateUrl || '').trim();
    return custom ? custom.replace(/\/?$/, '/') : "https://raw.githubusercontent.com/".concat(UPDATE_REPO, "/main/updates/");
  },
  cmp: function cmp(a, b) {
    var pa = String(a).split('.').map(function (n) {
        return parseInt(n, 10) || 0;
      }),
      pb = String(b).split('.').map(function (n) {
        return parseInt(n, 10) || 0;
      });
    for (var i = 0; i < 3; i++) {
      if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    }
    return 0;
  },
  get: function get(url, onProgress) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('GET', url + (url.indexOf('?') < 0 ? '?t=' : '&t=') + Date.now(), true);
      x.timeout = 30000;
      x.onload = function () {
        return x.status >= 200 && x.status < 300 ? resolve(x.responseText) : reject(new Error(x.status === 404 ? 'Nenhuma versão publicada ainda.' : "Servidor respondeu ".concat(x.status, ".")));
      };
      x.onerror = function () {
        return reject(new Error('Sem conexão com a internet.'));
      };
      x.ontimeout = function () {
        return reject(new Error('A conexão demorou demais.'));
      };
      if (onProgress) x.onprogress = function (e) {
        if (e.lengthComputable) onProgress(e.loaded / e.total);
      };
      x.send();
    });
  },
  fetchLatest: function fetchLatest() {
    var _this56 = this;
    var tries = [this.get(this.base() + 'latest.json')];
    if (!(Store.s.updateUrl || '').trim()) {
      tries.push(new Promise(function (resolve, reject) {
        var x = new XMLHttpRequest();
        x.open('GET', "https://api.github.com/repos/".concat(UPDATE_REPO, "/contents/updates/latest.json?ref=main&t=").concat(Date.now()), true);
        x.setRequestHeader('Accept', 'application/vnd.github.raw');
        x.timeout = 20000;
        x.onload = function () {
          return x.status >= 200 && x.status < 300 ? resolve(x.responseText) : reject(new Error("Servidor respondeu ".concat(x.status, ".")));
        };
        x.onerror = function () {
          return reject(new Error('Sem conexão com a internet.'));
        };
        x.ontimeout = function () {
          return reject(new Error('A conexão demorou demais.'));
        };
        x.send();
      }));
    }
    var ok = [],
      errs = [];
    return Promise.all(tries.map(function (p) {
      return p.then(function (t) {
        try {
          var r = JSON.parse(t);
          if (r && r.version) ok.push(r);
        } catch (e) {
          errs.push(e);
        }
      }, function (e) {
        return errs.push(e);
      });
    })).then(function () {
      if (!ok.length) throw errs[0] || new Error('Arquivo de versão inválido.');
      return ok.sort(function (a, b) {
        return _this56.cmp(b.version, a.version);
      })[0];
    });
  },
  check: function check(manual) {
    var _this57 = this;
    if (this.checking || this.installing) return Promise.resolve(this.available);
    this.checking = true;
    Store.data.lastUpdateCheck = Date.now();
    Store.save();
    return this.fetchLatest().then(function (r) {
      _this57.lastError = '';
      if (_this57.cmp(r.version, APP_VERSION) > 0) {
        _this57.available = r;
        Store.data.pendingUpdate = r;
        if (manual || Store.data.notifiedVersion !== r.version) UI.toast("Nova vers\xE3o ".concat(r.version, " dispon\xEDvel!"), 'info');
        Store.data.notifiedVersion = r.version;
        Store.save();
      } else {
        _this57.available = null;
        Store.data.pendingUpdate = null;
        Store.save();
        if (manual) UI.toast("Voc\xEA j\xE1 est\xE1 na vers\xE3o mais nova (".concat(APP_VERSION, ")."), 'ok');
      }
      return _this57.available;
    }).catch(function (e) {
      _this57.lastError = e.message;
      if (manual) UI.toast('Não consegui verificar: ' + e.message, 'err');
      return null;
    }).then(function (r) {
      _this57.checking = false;
      _this57.refreshUI();
      return r;
    });
  },
  install: function install(btn) {
    var _this58 = this;
    var info = this.available;
    if (!info || this.installing) return Promise.resolve();
    if (!FE.inCEP || !FS.ok) {
      UI.toast('A atualização só funciona dentro do Premiere.', 'info');
      return Promise.resolve();
    }
    this.installing = true;
    var label = btn ? btn.innerHTML : '';
    var setBtn = function setBtn(t) {
      if (btn) btn.innerHTML = t;
    };
    if (btn) btn.classList.add('busy');
    setBtn('Baixando… 0%');
    var extDir = FE.sysPath('extension').replace(/\\/g, '/').replace(/\/$/, '');
    var backupDir = Store.dataDir + '/backup/' + APP_VERSION;
    return this.get(this.base() + (info.package || 'fastedit-update.json'), function (p) {
      return setBtn("Baixando\u2026 ".concat(Math.round(p * 100), "%"));
    }).then(function (txt) {
      setBtn('Instalando…');
      var pkg = JSON.parse(txt);
      if (!pkg.version || !pkg.files || !pkg.files.length) throw new Error('Pacote de atualização inválido.');
      if (_this58.cmp(pkg.version, APP_VERSION) <= 0) throw new Error('Você já está na versão mais nova.');
      pkg.files.forEach(function (f) {
        if (!/^[\w\-. /]+$/.test(f.path) || f.path.indexOf('..') >= 0 || f.path[0] === '/') throw new Error('Pacote contém caminho inválido: ' + f.path);
      });
      var backed = [];
      pkg.files.forEach(function (f) {
        var target = extDir + '/' + f.path;
        if (FS.exists(target)) {
          var r = window.cep.fs.readFile(target, window.cep.encoding.Base64);
          if (r.err === 0) {
            FS.write(backupDir + '/' + f.path, r.data, true);
            backed.push(f.path);
          }
        }
      });
      var written = [];
      try {
        pkg.files.forEach(function (f) {
          if (!FS.write(extDir + '/' + f.path, f.b64, true)) throw new Error('Sem permissão para gravar ' + f.path);
          written.push(f.path);
        });
      } catch (e) {
        backed.forEach(function (p) {
          var r = window.cep.fs.readFile(backupDir + '/' + p, window.cep.encoding.Base64);
          if (r.err === 0) FS.write(extDir + '/' + p, r.data, true);
        });
        throw e;
      }
      Store.data.justUpdated = {
        from: APP_VERSION,
        to: pkg.version,
        notes: info.notes || '',
        restart: !!pkg.restartPremiere,
        t: Date.now()
      };
      Store.saveNow();
      setBtn('Recarregando…');
      var hostFile = extDir + '/host/fastedit.jsx';
      return FE.evalScript("try{$.evalFile(".concat(JSON.stringify(hostFile), ");\"ok\"}catch(e){\"ERR:\"+e.message}")).then(function () {
        setTimeout(function () {
          Timer.persist();
          FE.reload();
        }, 400);
      });
    }).catch(function (e) {
      _this58.installing = false;
      if (btn) {
        btn.classList.remove('busy');
        btn.innerHTML = label;
      }
      UI.toast('Atualização falhou: ' + e.message, 'err');
      App.log(false, 'Atualização: ' + e.message);
    });
  },
  maybeCheck: function maybeCheck() {
    if (Date.now() - (Store.data.lastUpdateCheck || 0) > 60000) this.check(false);
  },
  init: function init() {
    var _this59 = this;
    var j = Store.data.justUpdated;
    if (j && j.to === APP_VERSION) {
      Store.data.justUpdated = null;
      Store.save();
      setTimeout(function () {
        UI.toast("Fast Edit atualizado para ".concat(APP_VERSION, "!"), 'ok');
        App.log(true, "Atualizado de ".concat(j.from, " para ").concat(j.to));
        if (j.restart) UI.confirm('Quase lá', 'Esta versão mudou a configuração do painel. Feche e abra o Premiere quando puder para concluir.', 'Entendi');
      }, 1800);
    }
    var p = Store.data.pendingUpdate;
    if (p && p.version && this.cmp(p.version, APP_VERSION) > 0) this.available = p;
    setTimeout(function () {
      return _this59.check(false);
    }, 1500);
    setInterval(function () {
      return _this59.check(false);
    }, 10 * 60000);
    window.addEventListener('focus', function () {
      return _this59.maybeCheck();
    });
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) _this59.maybeCheck();
    });
  },
  refreshUI: function refreshUI() {
    var g = $('#gear');
    if (g) g.classList.toggle('badge', !!this.available);
    if (App.current === 'home' && !App.page) Home.renderUpdate();
    if (App.current === 'settings') Settings.renderUpdate();
  }
};
