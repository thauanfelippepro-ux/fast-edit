/*
 * FAST EDIT — Host (ExtendScript / ES3)
 * Camada de integração com o Adobe Premiere Pro.
 * Todas as funções recebem um objeto de argumentos e retornam dados;
 * o despachante $._FE.run() embrulha tudo em {ok, data|error}.
 * IMPORTANTE: manter este arquivo em ES3 (sem let/const, arrow, trailing commas).
 */

/* ------------------------------------------------------------------ JSON (polyfill mínimo) */
if (typeof $._FEJSON === 'undefined') {
    $._FEJSON = (function () {
        function esc(s) {
            return '"' + String(s)
                .replace(/\\/g, '\\\\')
                .replace(/"/g, '\\"')
                .replace(/\n/g, '\\n')
                .replace(/\r/g, '\\r')
                .replace(/\t/g, '\\t')
                .replace(/[\u0000-\u001f]/g, function (c) {
                    var h = c.charCodeAt(0).toString(16);
                    return '\\u' + ('0000' + h).slice(-4);
                }) + '"';
        }
        function str(v) {
            var t = typeof v, i, out, k;
            if (v === null || v === undefined) { return 'null'; }
            if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
            if (t === 'boolean') { return v ? 'true' : 'false'; }
            if (t === 'string') { return esc(v); }
            if (t === 'function') { return 'null'; }
            if (v instanceof Array) {
                out = [];
                for (i = 0; i < v.length; i++) { out.push(str(v[i])); }
                return '[' + out.join(',') + ']';
            }
            out = [];
            for (k in v) {
                if (v.hasOwnProperty(k)) {
                    if (typeof v[k] === 'function' || v[k] === undefined) { continue; }
                    out.push(esc(k) + ':' + str(v[k]));
                }
            }
            return '{' + out.join(',') + '}';
        }
        return {
            stringify: str,
            parse: function (s) {
                if (!s) { return {}; }
                return eval('(' + s + ')');
            }
        };
    })();
}

/* ------------------------------------------------------------------ Constantes & utilitários */
var FE_TPS = 254016000000;
var FE_EPS = 0.0005;
var FE_BIN_MAIN = 'Fast Edit';
var FE_BIN_SFX = 'Fast Edit SFX';
var FE_GUIDE_PREFIX = 'FE_Guide_';

function fe_err(msg) { throw new Error(msg); }

function fe_seq() {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var s = app.project.activeSequence;
    if (!s) { fe_err('Abra uma sequência na timeline primeiro.'); }
    return s;
}

function fe_frameDur(seq) {
    var tb = parseFloat(seq.timebase);
    if (!tb || tb <= 0) { return 1 / 30; }
    return tb / FE_TPS;
}

function fe_time(sec) {
    var t = new Time();
    t.seconds = sec;
    return t;
}

function fe_secOf(v) {
    if (v === null || v === undefined) { return 0; }
    if (typeof v === 'number') { return v; }
    if (typeof v === 'string') { return parseFloat(v) / FE_TPS; }
    if (v.seconds !== undefined) { return v.seconds; }
    return 0;
}

function fe_normPath(p) {
    return String(p || '').replace(/\\/g, '/').toLowerCase();
}

function fe_extOf(p) {
    var m = String(p || '').match(/\.([a-z0-9]+)$/i);
    return m ? m[1].toLowerCase() : '';
}

function fe_qe() {
    try { app.enableQE(); } catch (e) {}
    if (typeof qe === 'undefined' || !qe.project) { fe_err('QE DOM indisponível nesta versão do Premiere.'); }
    return qe;
}

function fe_qeSeq() {
    var q = fe_qe();
    var s = q.project.getActiveSequence();
    if (!s) { fe_err('Sequência QE não encontrada.'); }
    return s;
}

function fe_toList(v) {
    var out = [], i;
    if (!v) { return out; }
    if (typeof v === 'string') {
        var parts = v.split(/[\n,]/);
        for (i = 0; i < parts.length; i++) { if (parts[i]) { out.push(parts[i]); } }
        return out;
    }
    if (v.length !== undefined) {
        for (i = 0; i < v.length; i++) { out.push(String(v[i])); }
    }
    return out;
}

function fe_timecode(frames, fps) {
    var f = Math.max(1, Math.round(frames));
    var r = Math.max(1, Math.round(fps));
    var ff = f % r;
    var totalSec = Math.floor(f / r);
    var ss = totalSec % 60;
    var mm = Math.floor(totalSec / 60) % 60;
    var hh = Math.floor(totalSec / 3600);
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return p(hh) + ':' + p(mm) + ':' + p(ss) + ':' + p(ff);
}

/* ------------------------------------------------------------------ Coleta de clipes */
function fe_eachClip(seq, fn) {
    var t, c, tr, clip;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        tr = seq.videoTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) {
            clip = tr.clips[c];
            if (fn(clip, t, true, tr) === false) { return; }
        }
    }
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        tr = seq.audioTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) {
            clip = tr.clips[c];
            if (fn(clip, t, false, tr) === false) { return; }
        }
    }
}

/* Retorna [{clip, track, video, start, end}] dos clipes selecionados. kind: 'video'|'audio'|'all' */
function fe_selected(seq, kind) {
    var out = [];
    var useIsSel = true;
    try {
        if (seq.videoTracks.numTracks > 0 && seq.videoTracks[0].clips.numItems > 0) {
            seq.videoTracks[0].clips[0].isSelected();
        }
    } catch (e) { useIsSel = false; }

    if (useIsSel) {
        fe_eachClip(seq, function (clip, t, isV) {
            if (kind === 'video' && !isV) { return; }
            if (kind === 'audio' && isV) { return; }
            var sel = false;
            try { sel = clip.isSelected(); } catch (e2) {}
            if (sel) {
                out.push({ clip: clip, track: t, video: isV, start: clip.start.seconds, end: clip.end.seconds });
            }
        });
    } else {
        var s = seq.getSelection();
        var ids = {};
        var i;
        for (i = 0; i < s.length; i++) { ids[s[i].nodeId] = true; }
        fe_eachClip(seq, function (clip, t, isV) {
            if (kind === 'video' && !isV) { return; }
            if (kind === 'audio' && isV) { return; }
            if (ids[clip.nodeId]) {
                out.push({ clip: clip, track: t, video: isV, start: clip.start.seconds, end: clip.end.seconds });
            }
        });
    }
    out.sort(function (a, b) { return a.start - b.start; });
    return out;
}

function fe_requireSel(seq, kind) {
    var s = fe_selected(seq, kind);
    if (!s.length) {
        fe_err(kind === 'audio' ? 'Selecione clipes de áudio na timeline.' : 'Selecione um ou mais clipes na timeline.');
    }
    return s;
}

/* ------------------------------------------------------------------ Projeto & bins */
function fe_findBin(parent, name) {
    var i, ch;
    for (i = 0; i < parent.children.numItems; i++) {
        ch = parent.children[i];
        if (ch && ch.type === ProjectItemType.BIN && ch.name === name) { return ch; }
    }
    return null;
}

function fe_getOrCreateBin(parent, name) {
    var b = fe_findBin(parent, name);
    if (b) { return b; }
    var r = null;
    try { r = parent.createBin(name); } catch (e) {}
    if (r && r.type === ProjectItemType.BIN) { return r; }
    b = fe_findBin(parent, name);
    if (!b) { fe_err('Não foi possível criar o bin "' + name + '".'); }
    return b;
}

function fe_findItemByPath(bin, normPath, depth) {
    var i, ch, p, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findItemByPath(ch, normPath, depth + 1);
            if (f) { return f; }
        } else {
            p = '';
            try { p = ch.getMediaPath(); } catch (e) {}
            if (p && fe_normPath(p) === normPath) { return ch; }
        }
    }
    return null;
}

/* Importa um arquivo uma única vez (reaproveita se já estiver no projeto). */
function fe_importOnce(path, binName) {
    var root = app.project.rootItem;
    var np = fe_normPath(path);
    var bin = fe_getOrCreateBin(root, binName);
    var item = fe_findItemByPath(bin, np, 0);
    if (item) { return item; }
    item = fe_findItemByPath(root, np, 0);
    if (item) { return item; }
    var f = new File(path);
    if (!f.exists) { fe_err('Arquivo não encontrado: ' + path); }
    app.project.importFiles([f.fsName], true, bin, false);
    item = fe_findItemByPath(bin, np, 0);
    if (!item) { item = fe_findItemByPath(root, np, 0); }
    if (!item) { fe_err('Falha ao importar: ' + path); }
    return item;
}

function fe_findByNodeId(bin, id, depth) {
    var i, ch, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.nodeId === id) { return ch; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findByNodeId(ch, id, depth + 1);
            if (f) { return f; }
        }
    }
    return null;
}

var FE_ADJ_RX = /adjust|ajuste|einstellung|calque|regola|correcci|aanpassing|korekc|調整|조정/i;

function fe_isSequenceItem(it) {
    try { return it.isSequence(); } catch (e) { return false; }
}

function fe_findAdjustment(bin, depth) {
    var i, ch, f, p;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            f = fe_findAdjustment(ch, depth + 1);
            if (f) { return f; }
        } else if (ch.type === ProjectItemType.CLIP && !fe_isSequenceItem(ch)) {
            var isAdj = null;
            try { isAdj = ch.isAdjustmentLayer(); } catch (e0) { isAdj = null; }
            if (isAdj === true) { return ch; }
            if (isAdj === null) {
                p = '';
                try { p = ch.getMediaPath(); } catch (e) {}
                if (!p && FE_ADJ_RX.test(ch.name)) { return ch; }
            }
        }
    }
    return null;
}

/* ------------------------------------------------------------------ Trilhas */
function fe_trackFree(track, start, end, ignoreNode) {
    var i, c;
    for (i = 0; i < track.clips.numItems; i++) {
        c = track.clips[i];
        if (ignoreNode && c.nodeId === ignoreNode) { continue; }
        if (c.start.seconds < end - FE_EPS && c.end.seconds > start + FE_EPS) { return false; }
    }
    return true;
}

function fe_addVideoTrack(seq) {
    var n = seq.videoTracks.numTracks;
    var q = fe_qeSeq();
    try { q.addTracks(1, n, 0); } catch (e) {
        try { q.addTracks(1, n, 0, 0, 0, 0, 0); } catch (e2) { fe_err('Não foi possível adicionar trilha de vídeo.'); }
    }
    return seq.videoTracks.numTracks - 1;
}

function fe_addAudioTrack(seq) {
    var n = seq.audioTracks.numTracks;
    var q = fe_qeSeq();
    var ok = false;
    try { q.addTracks(0, 0, 1, 1, n, 0, 0); ok = true; } catch (e) {}
    if (!ok) { try { q.addTracks(0, 0, 1); ok = true; } catch (e2) {} }
    if (!ok || seq.audioTracks.numTracks === n) { fe_err('Não foi possível adicionar trilha de áudio.'); }
    return seq.audioTracks.numTracks - 1;
}

function fe_freeVideoTrack(seq, fromIdx, start, end) {
    var i;
    for (i = Math.max(0, fromIdx); i < seq.videoTracks.numTracks; i++) {
        if (fe_trackFree(seq.videoTracks[i], start, end)) { return i; }
    }
    return fe_addVideoTrack(seq);
}

function fe_freeAudioTrack(seq, fromIdx, start, end) {
    var i;
    for (i = Math.max(0, fromIdx); i < seq.audioTracks.numTracks; i++) {
        if (fe_trackFree(seq.audioTracks[i], start, end)) { return i; }
    }
    return fe_addAudioTrack(seq);
}

function fe_clipAt(track, startSec, tol) {
    var i, c, best = null, bd = 1e9, d;
    for (i = 0; i < track.clips.numItems; i++) {
        c = track.clips[i];
        d = Math.abs(c.start.seconds - startSec);
        if (d < bd) { bd = d; best = c; }
    }
    return (best && bd <= tol) ? best : null;
}

/* Coloca projectItem em track no tempo start, ajustando a duração (se dur > 0). */
function fe_place(seq, track, item, start, dur) {
    var fd = fe_frameDur(seq);
    track.overwriteClip(item, start);
    var clip = fe_clipAt(track, start, fd * 0.75);
    if (clip && dur && dur > 0) {
        try { clip.end = fe_time(start + dur); } catch (e) {}
    }
    return clip;
}

/* ------------------------------------------------------------------ QE helpers */
function fe_qeItem(qeSeq, isVideo, trackIdx, clip) {
    var tr = isVideo ? qeSeq.getVideoTrackAt(trackIdx) : qeSeq.getAudioTrackAt(trackIdx);
    if (!tr) { return null; }
    var i, it, s, target = clip.start.seconds, tTicks = String(clip.start.ticks);
    for (i = 0; i < tr.numItems; i++) {
        it = tr.getItemAt(i);
        if (!it || it.type === 'Empty') { continue; }
        try { if (String(it.start.ticks) === tTicks) { return it; } } catch (e) {}
        try {
            s = it.start.secs;
            if (s !== undefined && Math.abs(s - target) < 0.002) { return it; }
        } catch (e2) {}
    }
    return null;
}

/* ------------------------------------------------------------------ Keyframes / Motion */
function fe_comp(clip, matchName) {
    var i, c;
    for (i = 0; i < clip.components.numItems; i++) {
        c = clip.components[i];
        if (c && c.matchName === matchName) { return c; }
    }
    return null;
}

function fe_params(clip) {
    var m = fe_comp(clip, 'AE.ADBE Motion');
    var o = fe_comp(clip, 'AE.ADBE Opacity');
    var r = { pos: null, scale: null, rot: null, opacity: null };
    if (m) {
        r.pos = m.properties[0] || null;
        r.scale = m.properties[1] || null;
        r.rot = m.properties[4] || null;
    }
    if (o) { r.opacity = o.properties[0] || null; }
    return r;
}

function fe_baseVal(param, t) {
    if (!param) { return null; }
    var v = null;
    try {
        if (param.isTimeVarying()) { v = param.getValueAtTime(t); }
    } catch (e) {}
    if (v === null || v === undefined) {
        try { v = param.getValue(); } catch (e2) {}
    }
    return v;
}

function fe_clearRange(param, t0, t1) {
    try {
        if (param.isTimeVarying()) { param.removeKeyRange(t0 - 0.0001, t1 + 0.0001, true); }
    } catch (e) {}
}

function fe_setKey(param, t, value, ease) {
    try { if (!param.isTimeVarying()) { param.setTimeVarying(true); } } catch (e) {}
    param.addKey(t);
    param.setValueAtKey(t, value, true);
    try { param.setInterpolationTypeAtKey(t, ease ? 5 : 0, true); } catch (e2) {}
}

/* Presets de animação. Cada preset descreve keyframes da ENTRADA: lista de
   {p: 'pos'|'scale'|'rot'|'opacity', k: [[u (0..1), fn(base, ctx)]]}.
   A SAÍDA é a entrada espelhada no tempo. */
function fe_px(b, ctx, dx, dy) {
    return [b[0] + dx * ctx.ux, b[1] + dy * ctx.uy];
}

var FE_PRESETS = {
    fade: [{ p: 'opacity', k: [[0, function () { return 0; }], [1, function (b) { return b; }]] }],
    zoom_in: [
        { p: 'scale', k: [[0, function (b, c) { return b * (1 - 0.4 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.6, function (b) { return b; }]] }
    ],
    zoom_out: [
        { p: 'scale', k: [[0, function (b, c) { return b * (1 + 0.6 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.6, function (b) { return b; }]] }
    ],
    pop: [
        { p: 'scale', k: [[0, function () { return 0; }], [0.65, function (b, c) { return b * (1 + 0.15 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.3, function (b) { return b; }]] }
    ],
    bounce: [
        { p: 'scale', k: [[0, function () { return 0; }], [0.45, function (b, c) { return b * (1 + 0.22 * c.I); }], [0.72, function (b, c) { return b * (1 - 0.1 * c.I); }], [1, function (b) { return b; }]] }
    ],
    slide_l: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, -1 * c.I, 0); }], [1, function (b) { return b; }]] }],
    slide_r: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 1 * c.I, 0); }], [1, function (b) { return b; }]] }],
    slide_u: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, -1 * c.I); }], [1, function (b) { return b; }]] }],
    slide_d: [{ p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, 1 * c.I); }], [1, function (b) { return b; }]] }],
    rise: [
        { p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, 0.08 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.7, function (b) { return b; }]] }
    ],
    drop: [
        { p: 'pos', k: [[0, function (b, c) { return fe_px(b, c, 0, -0.12 * c.I); }], [0.7, function (b, c) { return fe_px(b, c, 0, 0.015 * c.I); }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.4, function (b) { return b; }]] }
    ],
    spin: [
        { p: 'rot', k: [[0, function (b, c) { return b - 180 * c.I; }], [1, function (b) { return b; }]] },
        { p: 'scale', k: [[0, function () { return 0; }], [1, function (b) { return b; }]] }
    ],
    swing: [
        { p: 'rot', k: [[0, function (b, c) { return b - 25 * c.I; }], [0.55, function (b, c) { return b + 8 * c.I; }], [0.8, function (b, c) { return b - 3 * c.I; }], [1, function (b) { return b; }]] },
        { p: 'opacity', k: [[0, function () { return 0; }], [0.3, function (b) { return b; }]] }
    ]
};

/* Presets "únicos" (não têm entrada/saída) */
var FE_SINGLE = { punch: true, kenburns: true, shake: true, pulse: true };

function fe_ctxFor(seq, posBase, intensity) {
    var px = posBase && (Math.abs(posBase[0]) > 2 || Math.abs(posBase[1]) > 2);
    return {
        ux: px ? seq.frameSizeHorizontal : 1,
        uy: px ? seq.frameSizeVertical : 1,
        I: intensity || 1
    };
}

/* Aplica um preset em um clipe. phase: 'in'|'out'. Retorna nº de keyframes. */
function fe_animate(seq, clip, preset, phase, durSec, ease, replace, intensity, offsetSec, samples) {
    var def = FE_PRESETS[preset];
    if (!def) { fe_err('Preset desconhecido: ' + preset); }
    var P = fe_params(clip);
    var clipLen = clip.end.seconds - clip.start.seconds;
    var d = Math.min(durSec, clipLen * (phase === 'both' ? 0.5 : 1));
    var mediaIn = clip.inPoint.seconds;
    var t0 = phase === 'out' ? mediaIn + clipLen - d : mediaIn + (offsetSec || 0);
    if (phase !== 'out' && (offsetSec || 0) + d > clipLen) { d = Math.max(0.02, clipLen - (offsetSec || 0)); }
    var t1 = t0 + d;
    var count = 0, i, j, tr, param, base, ctx, u, t, keys;
    for (i = 0; i < def.length; i++) {
        tr = def[i];
        param = P[tr.p];
        if (!param) { continue; }
        base = fe_baseVal(param, phase === 'out' ? t0 : t1);
        if (base === null || base === undefined) { continue; }
        ctx = fe_ctxFor(seq, tr.p === 'pos' ? base : null, intensity);
        if (replace) { fe_clearRange(param, t0, t1); }
        keys = tr.k;
        for (j = 0; j < keys.length; j++) {
            u = keys[j][0];
            t = phase === 'out' ? t0 + (1 - u) * d : t0 + u * d;
            fe_setKey(param, t, keys[j][1](base, ctx), samples ? false : ease);
            count++;
        }
        if (samples) { fe_bakeRange(param, t0, t1, samples, fe_frameDur(seq)); }
    }
    return count;
}

function fe_animateSingle(seq, clip, preset, durSec, ease, replace, intensity, atSec) {
    var P = fe_params(clip);
    var clipLen = clip.end.seconds - clip.start.seconds;
    var mediaIn = clip.inPoint.seconds;
    var count = 0, base, ctx, t0, t1, i, n, fd, decay, amp;
    var I = intensity || 1;
    if (preset === 'kenburns') {
        t0 = mediaIn; t1 = mediaIn + clipLen;
        if (P.scale) {
            base = fe_baseVal(P.scale, t0);
            if (replace) { fe_clearRange(P.scale, t0, t1); }
            fe_setKey(P.scale, t0, base, false);
            fe_setKey(P.scale, t1 - 0.001, base * (1 + 0.12 * I), false);
            count += 2;
        }
        if (P.pos) {
            base = fe_baseVal(P.pos, t0);
            ctx = fe_ctxFor(seq, base, I);
            if (replace) { fe_clearRange(P.pos, t0, t1); }
            fe_setKey(P.pos, t0, base, false);
            fe_setKey(P.pos, t1 - 0.001, fe_px(base, ctx, 0.02 * I, -0.01 * I), false);
            count += 2;
        }
        return count;
    }
    var rel = (atSec !== undefined && atSec !== null) ? atSec - clip.start.seconds : 0;
    if (rel < 0 || rel > clipLen) { rel = 0; }
    t0 = mediaIn + rel;
    var d = Math.min(durSec, clipLen - rel);
    t1 = t0 + d;
    if (preset === 'punch' || preset === 'pulse') {
        if (!P.scale) { return 0; }
        base = fe_baseVal(P.scale, t0);
        if (replace) { fe_clearRange(P.scale, t0, t1); }
        var peak = preset === 'punch' ? 1 + 0.18 * I : 1 + 0.08 * I;
        if (preset === 'punch') {
            fe_setKey(P.scale, t0, base * peak, ease);
            fe_setKey(P.scale, t1, base, ease);
            count += 2;
        } else {
            fe_setKey(P.scale, t0, base, ease);
            fe_setKey(P.scale, t0 + d * 0.35, base * peak, ease);
            fe_setKey(P.scale, t1, base, ease);
            count += 3;
        }
        return count;
    }
    if (preset === 'shake') {
        if (!P.pos) { return 0; }
        base = fe_baseVal(P.pos, t0);
        ctx = fe_ctxFor(seq, base, I);
        if (replace) { fe_clearRange(P.pos, t0, t1); }
        fd = fe_frameDur(seq);
        n = Math.max(3, Math.floor(d / (fd * 2)));
        for (i = 0; i <= n; i++) {
            decay = 1 - i / n;
            amp = 0.025 * I * decay;
            var dx = (i === n) ? 0 : (Math.random() * 2 - 1) * amp;
            var dy = (i === n) ? 0 : (Math.random() * 2 - 1) * amp * 0.8;
            fe_setKey(P.pos, t0 + (d * i / n), fe_px(base, ctx, dx, dy), false);
            count++;
        }
        if (P.scale) {
            var sb = fe_baseVal(P.scale, t0);
            if (replace) { fe_clearRange(P.scale, t0, t1); }
            fe_setKey(P.scale, t0, sb * (1 + 0.06 * I), false);
            fe_setKey(P.scale, t1, sb, false);
            count += 2;
        }
        return count;
    }
    fe_err('Preset desconhecido: ' + preset);
    return 0;
}

/* ------------------------------------------------------------------ Curvas (bake) */
/* A API do Premiere não expõe as alças de bezier dos keyframes. Para aplicar uma
   curva personalizada, geramos keyframes intermediários (lineares) que seguem a curva.
   samples: array com N+1 valores y da curva em u = i/N (y pode passar de 0..1: overshoot). */
if (!$._FE_BAKED) { $._FE_BAKED = {}; }

function fe_curveAt(samples, u) {
    var n = samples.length - 1;
    if (u <= 0) { return samples[0]; }
    if (u >= 1) { return samples[n]; }
    var x = u * n, i = Math.floor(x), f = x - i;
    return samples[i] + (samples[i + 1] - samples[i]) * f;
}

function fe_lerpVal(a, b, e) {
    var i, out;
    if (a instanceof Array) {
        out = [];
        for (i = 0; i < a.length; i++) { out.push(a[i] + (b[i] - a[i]) * e); }
        return out;
    }
    return a + (b - a) * e;
}

function fe_isNumVal(v) {
    if (typeof v === 'number') { return true; }
    if (v instanceof Array && v.length && typeof v[0] === 'number') { return true; }
    return false;
}

function fe_keyTimes(param) {
    var out = [], ks, i, t;
    try { ks = param.getKeys(); } catch (e) { ks = null; }
    if (!ks) { return out; }
    for (i = 0; i < ks.length; i++) {
        t = ks[i];
        out.push(typeof t === 'number' ? t : (t.seconds !== undefined ? t.seconds : parseFloat(t)));
    }
    out.sort(function (a, b) { return a - b; });
    return out;
}

/* assa a curva em um segmento [a,b] de um parâmetro */
/* pontos da curva que realmente importam (Ramer-Douglas-Peucker + picos), em vez de um keyframe por frame */
function fe_curveKeyIdx(S, eps) {
    var N = S.length - 1, keep = {}, stack = [[0, N]], i, seg, a, b, k, dmax, idx, d, ux, uy, len;
    keep[0] = true; keep[N] = true;
    while (stack.length) {
        seg = stack.pop(); a = seg[0]; b = seg[1];
        if (b - a < 2) { continue; }
        ux = (b - a) / N; uy = S[b] - S[a]; len = Math.sqrt(ux * ux + uy * uy) || 1e-9;
        dmax = -1; idx = -1;
        for (k = a + 1; k < b; k++) {
            d = Math.abs(uy * ((k - a) / N) - ux * (S[k] - S[a])) / len;
            if (d > dmax) { dmax = d; idx = k; }
        }
        if (dmax > eps) { keep[idx] = true; stack.push([a, idx]); stack.push([idx, b]); }
    }
    /* picos e vales (bounce, elastic, back) sempre entram */
    for (i = 1; i < N; i++) { if ((S[i] - S[i - 1]) * (S[i + 1] - S[i]) < 0) { keep[i] = true; } }
    var out = [];
    for (i = 0; i <= N; i++) { if (keep[i]) { out.push(i); } }
    return out;
}
/* aplica a curva entre dois keyframes com poucos keyframes: Bézier onde a curva fica plana
   (começo/fim lento, topo de quique), automático no meio e linear nas quinas (chão do bounce) */
function fe_bakeSegment(param, a, b, samples, step, precise, simple) {
    var v0 = param.getValueAtKey(a), v1 = param.getValueAtKey(b);
    if (!fe_isNumVal(v0) || !fe_isNumVal(v1)) { return 0; }
    var S = samples, N = S.length - 1, span = Math.abs(S[N] - S[0]) || 1, nF = Math.max(2, Math.round((b - a) / step));
    var idx = fe_curveKeyIdx(S, precise ? 0.012 : 0.03), i, k, u, t, cnt = 0, last = -1, slope, sl, sr, it;
    try { param.removeKeyRange(a + 0.0005, b - 0.0005, true); } catch (e0) {}
    /* curva simples (sem passar do valor final): tenta só os 2 keyframes com a suavização do Premiere */
    var mono = true, dir = S[N] - S[0];
    for (i = 1; i <= N; i++) { if ((S[i] - S[i - 1]) * dir < -0.0005 * span) { mono = false; break; } }
    if (mono && typeof v0 === 'number') {
        var combos = [[3, 3], [0, 3], [3, 0], [1, 3], [3, 1], [0, 0]], bestC = null, bestE = 1e9, ci, j, e, worst, got, want;
        for (ci = 0; ci < combos.length; ci++) {
            try { param.setInterpolationTypeAtKey(a, combos[ci][0], false); param.setInterpolationTypeAtKey(b, combos[ci][1], false); } catch (eC) { continue; }
            worst = 0;
            for (j = 1; j < 10; j++) {
                u = j / 10; want = (S[Math.round(u * N)] - S[0]) / (dir || 1);
                got = (param.getValueAtTime(a + u * (b - a)) - v0) / ((v1 - v0) || 1);
                e = Math.abs(want - got); if (e > worst) { worst = e; }
            }
            if (worst < bestE) { bestE = worst; bestC = combos[ci]; }
        }
        if (bestC && (simple || bestE < (precise ? 0.04 : 0.08))) {
            try { param.setInterpolationTypeAtKey(a, bestC[0], false); param.setInterpolationTypeAtKey(b, bestC[1], true); } catch (eB) {}
            return 0;
        }
    }
    for (i = 0; i < idx.length; i++) {
        k = idx[i]; u = k / N;
        /* encaixa no frame e evita dois keyframes no mesmo frame */
        var f = Math.round(u * nF);
        if (k !== 0 && k !== N) { if (f <= last || f >= nF) { continue; } }
        last = f;
        t = (k === 0) ? a : (k === N ? b : a + f * step);
        sl = k > 0 ? (S[k] - S[k - 1]) * N / span : 0;
        sr = k < N ? (S[k + 1] - S[k]) * N / span : 0;
        slope = k === 0 ? Math.abs(sr) : (k === N ? Math.abs(sl) : Math.abs(sl + sr) / 2);
        if (slope < 0.35) { it = 3; }
        else if (k > 0 && k < N && sl * sr < 0) { it = 0; }
        else if (k === 0 || k === N) { it = 0; }
        else { it = 1; }
        if (k !== 0 && k !== N) {
            param.addKey(t);
            param.setValueAtKey(t, fe_lerpVal(v0, v1, S[k]), true);
            cnt++;
        }
        try { param.setInterpolationTypeAtKey(t, it, true); } catch (e1) {}
    }
    return cnt;
}

/* keyframes "principais" de um parâmetro (ignora os que o Fast Edit criou ao assar) */
function fe_mainKeys(regKey, param) {
    var cur = fe_keyTimes(param);
    var orig = $._FE_BAKED[regKey];
    if (orig && orig.length >= 2) {
        var ok = true, i, j, found;
        for (i = 0; i < orig.length && ok; i++) {
            found = false;
            for (j = 0; j < cur.length; j++) { if (Math.abs(cur[j] - orig[i]) < 0.0015) { found = true; break; } }
            if (!found) { ok = false; }
        }
        if (ok) { return orig; }
    }
    return cur;
}

/* aplica a curva em todos os parâmetros animados de um clipe */
function fe_curveClip(seq, clip, a) {
    var fd = fe_frameDur(seq);
    var step = fd * (a.step || 1);
    var res = { params: 0, segments: 0, keys: 0 };
    var ppMedia = null;
    if (a.segment === 'playhead') {
        try { ppMedia = clip.inPoint.seconds + (seq.getPlayerPosition().seconds - clip.start.seconds); } catch (e) {}
    }
    var ci, pi, comp, param, keys, k, regKey, did;
    for (ci = 0; ci < clip.components.numItems; ci++) {
        comp = clip.components[ci];
        if (!comp) { continue; }
        if (a.scope !== 'all' && comp.matchName !== 'AE.ADBE Motion' && comp.matchName !== 'AE.ADBE Opacity') { continue; }
        for (pi = 0; pi < comp.properties.numItems; pi++) {
            param = comp.properties[pi];
            if (!param) { continue; }
            try { if (!param.isTimeVarying()) { continue; } } catch (e1) { continue; }
            regKey = clip.nodeId + '|' + ci + '|' + pi;
            keys = fe_mainKeys(regKey, param);
            if (keys.length < 2) { continue; }
            did = false;
            for (k = 0; k < keys.length - 1; k++) {
                if (ppMedia !== null && !(ppMedia >= keys[k] - 0.001 && ppMedia <= keys[k + 1] + 0.001)) { continue; }
                if (keys[k + 1] - keys[k] < step * 1.5) { continue; }
                try {
                    if (a.remove) {
                        param.removeKeyRange(keys[k] + 0.0005, keys[k + 1] - 0.0005, true);
                        try { param.setInterpolationTypeAtKey(keys[k], 5, true); param.setInterpolationTypeAtKey(keys[k + 1], 5, true); } catch (e3) {}
                    } else {
                        res.keys += fe_bakeSegment(param, keys[k], keys[k + 1], a.samples, step, a.keysMode === 'fiel', a.keysMode !== 'min' && a.keysMode !== 'fiel');
                    }
                    res.segments++;
                    did = true;
                } catch (e2) {}
            }
            if (did) {
                res.params++;
                $._FE_BAKED[regKey] = a.remove ? null : keys;
            }
        }
    }
    return res;
}

/* usado pelos presets de animação: assa a curva entre os keys recém-criados */
function fe_bakeRange(param, t0, t1, samples, fd) {
    var keys = fe_keyTimes(param), i, list = [];
    for (i = 0; i < keys.length; i++) { if (keys[i] >= t0 - 0.0015 && keys[i] <= t1 + 0.0015) { list.push(keys[i]); } }
    for (i = 0; i < list.length - 1; i++) {
        if (list[i + 1] - list[i] >= fd * 1.5) { fe_bakeSegment(param, list[i], list[i + 1], samples, fd); }
    }
}

/* ------------------------------------------------------------------ API */
var FE_API = {};

FE_API.ping = function () {
    return { version: app.version, build: app.build || '', project: app.project ? app.project.name : null };
};

FE_API.info = function () {
    var r = { version: app.version, project: null, projectPath: null, seq: null };
    if (!app.project) { return r; }
    r.project = app.project.name;
    r.projectPath = app.project.path;
    var s = app.project.activeSequence;
    if (s) {
        var fd = fe_frameDur(s);
        var clips = 0;
        var sel = 0;
        fe_eachClip(s, function (c) {
            clips++;
            try { if (c.isSelected()) { sel++; } } catch (e) {}
        });
        var pp = 0;
        try { pp = s.getPlayerPosition().seconds; } catch (e2) {}
        r.seq = {
            name: s.name,
            id: s.sequenceID,
            w: s.frameSizeHorizontal,
            h: s.frameSizeVertical,
            fps: Math.round((1 / fd) * 100) / 100,
            duration: fe_secOf(s.end),
            playhead: pp,
            vTracks: s.videoTracks.numTracks,
            aTracks: s.audioTracks.numTracks,
            clips: clips,
            selected: sel
        };
    }
    return r;
};

/* --- ANIMATE: Motion presets ----------------------------------------------- */
FE_API.motion = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var dur = (a.frames || 12) * fd;
    var ease = a.ease !== false;
    var replace = a.replace !== false;
    var I = a.intensity || 1;
    var stagger = (a.stagger || 0) * fd;
    var keys = 0, i, pp = null;
    try { pp = seq.getPlayerPosition().seconds; } catch (e) {}
    for (i = 0; i < sel.length; i++) {
        var clip = sel[i].clip;
        if (FE_SINGLE[a.preset]) {
            keys += fe_animateSingle(seq, clip, a.preset, dur, ease, replace, I, a.atPlayhead ? pp : null);
        } else {
            var where = a.where || 'in';
            if (where === 'in' || where === 'both') { keys += fe_animate(seq, clip, a.preset, 'in', dur, ease, replace, I, stagger * i, a.samples || null); }
            if (where === 'out' || where === 'both') { keys += fe_animate(seq, clip, a.preset, 'out', dur, ease, replace, I, 0, a.samples || null); }
        }
    }
    return { clips: sel.length, keys: keys };
};

/* Remove keyframes de Motion/Opacity dos selecionados (reset) */
FE_API.resetMotion = function () {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var i, P, k, p;
    for (i = 0; i < sel.length; i++) {
        P = fe_params(sel[i].clip);
        for (k in P) {
            if (!P.hasOwnProperty(k)) { continue; }
            p = P[k];
            if (!p) { continue; }
            try {
                if (p.isTimeVarying()) {
                    var v = p.getValueAtTime(sel[i].clip.inPoint.seconds);
                    p.setTimeVarying(false);
                    if (k === 'opacity') { p.setValue(100, true); }
                    else if (k === 'scale') { p.setValue(100, true); }
                    else if (k === 'rot') { p.setValue(0, true); }
                    else if (v) { p.setValue(v, true); }
                }
            } catch (e) {}
        }
    }
    return { clips: sel.length };
};

/* --- ANIMATE: Curvas -------------------------------------------------------- */
FE_API.applyCurve = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, a.scope === 'all' ? 'all' : 'video');
    if (!a.remove && (!a.samples || a.samples.length < 3)) { fe_err('Curva inválida.'); }
    var tot = { clips: sel.length, params: 0, segments: 0, keys: 0 }, i, r;
    for (i = 0; i < sel.length; i++) {
        r = fe_curveClip(seq, sel[i].clip, a);
        tot.params += r.params; tot.segments += r.segments; tot.keys += r.keys;
    }
    if (!tot.segments) {
        fe_err(a.segment === 'playhead' ? 'Nenhum par de keyframes sob o playhead nos clipes selecionados.' : 'Os clipes selecionados não têm keyframes (precisa de pelo menos 2 numa propriedade).');
    }
    return tot;
};

/* --- ANIMATE: Caption animator --------------------------------------------- */
FE_API.captions = function (a) {
    var seq = fe_seq();
    var sel = fe_selected(seq, 'video');
    var targets = [];
    var i;
    if (a.wholeTrack) {
        if (!sel.length) { fe_err('Selecione ao menos uma legenda/texto na trilha desejada.'); }
        var tr = seq.videoTracks[sel[0].track];
        for (i = 0; i < tr.clips.numItems; i++) { targets.push(tr.clips[i]); }
    } else {
        if (!sel.length) { fe_err('Selecione as legendas/textos (clipes gráficos) na timeline.'); }
        for (i = 0; i < sel.length; i++) { targets.push(sel[i].clip); }
    }
    var fd = fe_frameDur(seq);
    var inDur = (a.inFrames || 6) * fd;
    var outDur = (a.outFrames || 4) * fd;
    var keys = 0;
    for (i = 0; i < targets.length; i++) {
        keys += fe_animate(seq, targets[i], a.preset || 'pop', 'in', inDur, true, true, a.intensity || 1, 0);
        if (a.outPreset && a.outPreset !== 'none') {
            keys += fe_animate(seq, targets[i], a.outPreset, 'out', outDur, true, true, a.intensity || 1, 0);
        }
    }
    return { clips: targets.length, keys: keys };
};

/* --- ANIMATE: Transições por keyframe (entre clipes adjacentes) ------------- */
var FE_KTRANS = {
    push_l: { a: [{ p: 'pos', dx: -1, dy: 0 }], b: [{ p: 'pos', dx: 1, dy: 0 }] },
    push_r: { a: [{ p: 'pos', dx: 1, dy: 0 }], b: [{ p: 'pos', dx: -1, dy: 0 }] },
    push_u: { a: [{ p: 'pos', dx: 0, dy: -1 }], b: [{ p: 'pos', dx: 0, dy: 1 }] },
    push_d: { a: [{ p: 'pos', dx: 0, dy: 1 }], b: [{ p: 'pos', dx: 0, dy: -1 }] },
    zoom: { a: [{ p: 'scale', m: 2.6 }], b: [{ p: 'scale', m: 0.35 }] },
    zoom_out: { a: [{ p: 'scale', m: 0.35 }], b: [{ p: 'scale', m: 2.6 }] },
    spin: { a: [{ p: 'rot', r: 90 }, { p: 'scale', m: 1.6 }], b: [{ p: 'rot', r: -90 }, { p: 'scale', m: 1.6 }] },
    flash_zoom: { a: [{ p: 'scale', m: 1.35 }, { p: 'opacity', o: 0 }], b: [{ p: 'scale', m: 1.35 }, { p: 'opacity', o: 0 }] }
};

function fe_ktransSide(seq, clip, specs, isOut, d, I, samples) {
    var P = fe_params(clip);
    var len = clip.end.seconds - clip.start.seconds;
    var dd = Math.min(d, len * 0.5);
    var mediaIn = clip.inPoint.seconds;
    var tA = isOut ? mediaIn + len - dd : mediaIn;
    var tB = tA + dd;
    var n = 0, i, s, param, base, ctx, moved;
    for (i = 0; i < specs.length; i++) {
        s = specs[i];
        param = P[s.p];
        if (!param) { continue; }
        base = fe_baseVal(param, isOut ? tA : tB);
        if (base === null || base === undefined) { continue; }
        fe_clearRange(param, tA, tB);
        if (s.p === 'pos') {
            ctx = fe_ctxFor(seq, base, I);
            moved = fe_px(base, ctx, s.dx * I, s.dy * I);
        } else if (s.p === 'scale') {
            moved = base * (1 + (s.m - 1) * I);
        } else if (s.p === 'rot') {
            moved = base + s.r * I;
        } else {
            moved = s.o;
        }
        if (isOut) {
            fe_setKey(param, tA, base, !samples);
            fe_setKey(param, tB - 0.0005, moved, !samples);
        } else {
            fe_setKey(param, tA, moved, !samples);
            fe_setKey(param, tB, base, !samples);
        }
        if (samples) { fe_bakeRange(param, tA, tB, isOut ? samples : samples, fe_frameDur(seq)); }
        n += 2;
    }
    return n;
}

FE_API.ktransition = function (a) {
    var seq = fe_seq();
    var spec = FE_KTRANS[a.type];
    if (!spec) { fe_err('Transição desconhecida.'); }
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var half = Math.max(2, a.frames || 8) * fd;
    var I = a.intensity || 1;
    var pairs = [];
    var i, j, tr, A, B;
    var byTrack = {};
    for (i = 0; i < sel.length; i++) {
        if (!byTrack[sel[i].track]) { byTrack[sel[i].track] = []; }
        byTrack[sel[i].track].push(sel[i]);
    }
    var t;
    for (t in byTrack) {
        if (!byTrack.hasOwnProperty(t)) { continue; }
        var arr = byTrack[t];
        tr = seq.videoTracks[parseInt(t, 10)];
        if (arr.length === 1) {
            /* um clipe: transição com o clipe anterior (corte de entrada) */
            for (j = 0; j < tr.clips.numItems; j++) {
                if (Math.abs(tr.clips[j].end.seconds - arr[0].start) < fd * 0.6) {
                    pairs.push([tr.clips[j], arr[0].clip]);
                    break;
                }
            }
            if (!pairs.length) {
                for (j = 0; j < tr.clips.numItems; j++) {
                    if (Math.abs(tr.clips[j].start.seconds - arr[0].end) < fd * 0.6) {
                        pairs.push([arr[0].clip, tr.clips[j]]);
                        break;
                    }
                }
            }
        } else {
            for (j = 0; j < arr.length - 1; j++) {
                if (Math.abs(arr[j].end - arr[j + 1].start) < fd * 0.6) {
                    pairs.push([arr[j].clip, arr[j + 1].clip]);
                }
            }
        }
    }
    if (!pairs.length) { fe_err('Nenhum corte encontrado. Selecione clipes vizinhos (colados) na mesma trilha.'); }
    var keys = 0, cuts = [];
    for (i = 0; i < pairs.length; i++) {
        A = pairs[i][0]; B = pairs[i][1];
        keys += fe_ktransSide(seq, A, spec.a, true, half, I, a.samples || null);
        keys += fe_ktransSide(seq, B, spec.b, false, half, I, a.samples || null);
        cuts.push(B.start.seconds);
    }
    return { cuts: cuts, keys: keys };
};

/* --- ANIMATE: Transições nativas (QE) -------------------------------------- */
FE_API.listTransitions = function () {
    var q = fe_qe();
    var v = [], au = [];
    try { v = fe_toList(q.project.getVideoTransitionList()); } catch (e) {}
    try { au = fe_toList(q.project.getAudioTransitionList()); } catch (e2) {}
    return { video: v, audio: au };
};

function fe_addTransition(qi, tr, atStart, frames, fps) {
    var tc = fe_timecode(frames, fps);
    try { qi.addTransition(tr, atStart, tc, '00:00:00:00', 0.5, false, true); return true; } catch (e) {}
    try { qi.addTransition(tr, atStart, String(frames)); return true; } catch (e2) {}
    try { qi.addTransition(tr, atStart); return true; } catch (e3) {}
    return false;
}

FE_API.nativeTransition = function (a) {
    var seq = fe_seq();
    var q = fe_qe();
    var qs = fe_qeSeq();
    var isAudio = !!a.audio;
    var tr = isAudio ? q.project.getAudioTransitionByName(a.name) : q.project.getVideoTransitionByName(a.name);
    if (!tr) { fe_err('Transição "' + a.name + '" não encontrada.'); }
    var sel = fe_requireSel(seq, isAudio ? 'audio' : 'video');
    var fd = fe_frameDur(seq);
    var fps = 1 / fd;
    var frames = a.frames || 15;
    var where = a.where || 'both';
    var n = 0, fail = 0, i, qi;
    for (i = 0; i < sel.length; i++) {
        qi = fe_qeItem(qs, !isAudio, sel[i].track, sel[i].clip);
        if (!qi) { fail++; continue; }
        if (where === 'start' || where === 'both') { if (fe_addTransition(qi, tr, true, frames, fps)) { n++; } else { fail++; } }
        if (where === 'end' || where === 'both') { if (fe_addTransition(qi, tr, false, frames, fps)) { n++; } else { fail++; } }
    }
    return { added: n, failed: fail };
};

/* --- ANIMATE: Efeitos (QE) ------------------------------------------------- */
FE_API.listEffects = function () {
    var q = fe_qe();
    var v = [], au = [];
    try { v = fe_toList(q.project.getVideoEffectList()); } catch (e) {}
    try { au = fe_toList(q.project.getAudioEffectList()); } catch (e2) {}
    return { video: v, audio: au };
};

function fe_applyEffectsTo(qs, list, names, isAudio) {
    var q = fe_qe();
    var applied = 0, missing = {}, i, j, qi, eff;
    var cache = {};
    for (j = 0; j < names.length; j++) {
        try {
            eff = isAudio ? q.project.getAudioEffectByName(names[j]) : q.project.getVideoEffectByName(names[j]);
        } catch (e) { eff = null; }
        cache[names[j]] = eff;
    }
    for (i = 0; i < list.length; i++) {
        qi = fe_qeItem(qs, !isAudio, list[i].track, list[i].clip);
        if (!qi) { continue; }
        for (j = 0; j < names.length; j++) {
            eff = cache[names[j]];
            if (!eff) { missing[names[j]] = true; continue; }
            try {
                if (isAudio) { qi.addAudioEffect(eff); } else { qi.addVideoEffect(eff); }
                applied++;
            } catch (e2) { missing[names[j]] = true; }
        }
    }
    var miss = [], k;
    for (k in missing) { if (missing.hasOwnProperty(k)) { miss.push(k); } }
    return { applied: applied, missing: miss };
}

FE_API.applyEffects = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var names = a.names || [];
    if (!names.length) { fe_err('Nenhum efeito escolhido.'); }
    var isAudio = !!a.audio;
    var sel = fe_requireSel(seq, isAudio ? 'audio' : 'video');
    var r = fe_applyEffectsTo(qs, sel, names, isAudio);
    r.clips = sel.length;
    return r;
};

/* --- WORKFLOW: Overlays (Adjustment Layer / Color Matte / PNG) ------------- */
FE_API.findAdjustment = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var it = null;
    if (a && a.nodeId) { it = fe_findByNodeId(app.project.rootItem, a.nodeId, 0); }
    if (!it) { it = fe_findAdjustment(app.project.rootItem, 0); }
    return it ? { nodeId: it.nodeId, name: it.name } : null;
};

FE_API.adjustmentFromSelection = function () {
    var seq = app.project.activeSequence;
    var it = null;
    if (seq) {
        var sel = fe_selected(seq, 'video');
        if (sel.length) { it = sel[0].clip.projectItem; }
    }
    if (!it) {
        try {
            var v = app.getCurrentProjectViewSelection();
            if (v && v.length) { it = v[0]; }
        } catch (e) {}
    }
    if (!it) { fe_err('Selecione uma Adjustment Layer na timeline ou no painel Project.'); }
    return { nodeId: it.nodeId, name: it.name };
};

/* garante uma camada de ajuste no projeto: usa a existente ou importa o modelo do Fast Edit */
function fe_ensureAdjustment(nodeId, template) {
    var item = null;
    if (nodeId) { item = fe_findByNodeId(app.project.rootItem, nodeId, 0); }
    if (item) { try { if (item.isAdjustmentLayer() === false) { item = null; } } catch (e0) {} }
    /* modelo no tamanho da sequência (…/sized/LxA/…): usa só a camada desse tamanho */
    var sz = template ? String(template).match(/sized[\\\/](\d+x\d+)[\\\/]/) : null;
    if (!item && template) { item = fe_findByName(app.project.rootItem, 'Fast Edit Adjustment Layer' + (sz ? ' (' + sz[1] + ')' : ''), 0); }
    if (!item && !sz) { item = fe_findAdjustment(app.project.rootItem, 0); }
    if (!item && template) {
        var f = new File(template);
        if (f.exists) {
            var bin = fe_getOrCreateBin(app.project.rootItem, FE_BIN_MAIN);
            try { app.project.importFiles([f.fsName], true, bin, false); } catch (e1) {}
            var tries = 0;
            item = fe_findByName(bin, 'Fast Edit Adjustment Layer' + (sz ? ' (' + sz[1] + ')' : ''), 0);
            while (!item && sz && tries < 15) { $.sleep(200); tries++; item = fe_findByName(bin, 'Fast Edit Adjustment Layer (' + sz[1] + ')', 0); }
            if (!item && !sz) { item = fe_findAdjustment(bin, 0) || fe_findAdjustment(app.project.rootItem, 0); }
            if (item) { try { item.moveBin(bin); } catch (e2) {} }
        }
    }
    return item;
}

/* efeitos do After: camadas de ajuste com preset no clipe mestre, vindas do molde FE_Efeitos.prproj */
var FE_BIN_FX = 'Fast Edit \u00b7 Efeitos prontos';
function fe_findByName(bin, name, depth) {
    var i, ch, f;
    if (depth > 12) { return null; }
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type !== ProjectItemType.BIN && ch.name === name) { return ch; }
        if (ch.type === ProjectItemType.BIN) { f = fe_findByName(ch, name, depth + 1); if (f) { return f; } }
    }
    return null;
}
function fe_ensureFx(name, tpl) {
    var root = app.project.rootItem, bin = fe_getOrCreateBin(root, FE_BIN_FX), it = fe_findByName(bin, name, 0);
    if (it) { return it; }
    var f = new File(tpl);
    if (!f.exists) { fe_err('Efeito não encontrado na instalação. Reinstale o Fast Edit.'); }
    app.project.importFiles([f.fsName], true, bin, false);
    var tries = 0;
    it = fe_findByName(bin, name, 0);
    while (!it && tries < 15) { $.sleep(200); tries++; it = fe_findByName(bin, name, 0); }
    if (!it) { fe_err('Não consegui trazer o efeito “' + name + '” para o projeto.'); }
    return it;
}

/* a referência devolvida ao colocar o clipe não enxerga efeitos adicionados pelo QE: busca de novo na trilha */
function fe_refetchClip(pl) {
    try {
        var tr = app.project.activeSequence.videoTracks[pl.track], i, c, tk = String(pl.clip.start.ticks);
        for (i = 0; i < tr.clips.numItems; i++) { c = tr.clips[i]; if (String(c.start.ticks) === tk) { return c; } }
    } catch (e) {}
    return null;
}
/* spec: [{e:'Wave Warp', m:'AE.ADBE Wave Warp', p:[[indice, valorInicial, [[seg, valor, interp], ...]], ...]}] */
function fe_applyClipFx(pl, specs) {
    var qs = fe_qeSeq(), qi = fe_qeItem(qs, true, pl.track, pl.clip), clip = pl.clip, s, k, j, fx, cp, n, ci, pr, pp, keys, tk, base;
    if (!qi) { return; }
    base = Math.abs(clip.inPoint.seconds - 3600) < 1 ? 3600 : clip.inPoint.seconds;
    for (s = 0; s < specs.length; s++) {
        fx = qe.project.getVideoEffectByName(specs[s].e);
        if (!fx) { continue; }
        n = clip.components.numItems;
        qi.addVideoEffect(fx);
        clip = fe_refetchClip(pl) || clip;
        cp = null;
        for (ci = clip.components.numItems - 1; ci >= n - 1 && ci >= 0; ci--) {
            if (clip.components[ci].matchName === specs[s].m) { cp = clip.components[ci]; break; }
        }
        if (!cp) { continue; }
        for (j = 0; j < specs[s].p.length; j++) {
            pp = specs[s].p[j];
            pr = cp.properties[pp[0]];
            if (!pr) { continue; }
            keys = pp[2] || [];
            if (!keys.length) { try { pr.setValue(pp[1], true); } catch (eV) {} continue; }
            try { pr.setTimeVarying(true); } catch (eT) {}
            for (k = 0; k < keys.length; k++) {
                tk = new Time(); tk.seconds = base + keys[k][0];
                try {
                    pr.addKey(tk);
                    pr.setValueAtKey(tk, keys[k][1], k === keys.length - 1);
                    if (keys[k][2]) { pr.setInterpolationTypeAtKey(tk, keys[k][2], false); }
                } catch (eK) {}
            }
        }
    }
}

FE_API.overlay = function (a) {
    var seq = fe_seq();
    var item = null;
    if (a.kind === 'fx') {
        item = fe_ensureFx(a.fxItem, a.fxTemplate);
    } else if (a.kind === 'adjustment') {
        item = fe_ensureAdjustment(a.nodeId, a.template);
        if (!item) { fe_err('Não consegui criar a camada de ajuste neste projeto.'); }
    } else {
        item = fe_importOnce(a.path, FE_BIN_MAIN);
    }
    var fd = fe_frameDur(seq);
    var ranges = [];
    var i, j, sel;
    var mode = a.mode || 'selection';
    var snap = function (t) { return Math.round(t / fd) * fd; };
    var lenSec = (a.frames ? a.frames * fd : (a.seconds || 5));
    /* trilha mais alta ocupada num instante (para a camada ir por cima de tudo) */
    var topAt = function (t) {
        var k, top = -1;
        for (k = 0; k < seq.videoTracks.numTracks; k++) {
            if (!fe_trackFree(seq.videoTracks[k], t, t + fd * 0.5)) { top = k; }
        }
        return top;
    };
    if (mode === 'auto') {
        sel = fe_selected(seq, 'video');
        if (sel.length) { mode = 'perClip'; }
        else { mode = 'playhead'; }
    }
    if (mode === 'playhead') {
        var pp = snap(a.atSec !== undefined && a.atSec !== null ? a.atSec : seq.getPlayerPosition().seconds);
        ranges.push({ s: pp, e: pp + lenSec, from: topAt(pp) + 1 });
    } else if (mode === 'centerPlayhead') {
        var pc = snap(seq.getPlayerPosition().seconds - lenSec / 2);
        ranges.push({ s: Math.max(0, pc), e: Math.max(0, pc) + lenSec, from: topAt(pc + lenSec / 2) + 1 });
    } else if (mode === 'clipStart') {
        sel = fe_requireSel(seq, 'video');
        for (i = 0; i < sel.length; i++) { ranges.push({ s: sel[i].start, e: Math.min(sel[i].end, sel[i].start + lenSec), from: sel[i].track + 1 }); }
    } else if (mode === 'full') {
        ranges.push({ s: 0, e: fe_secOf(seq.end), from: seq.videoTracks.numTracks });
    } else if (mode === 'cuts') {
        sel = fe_selected(seq, 'video');
        if (sel.length < 2) { fe_err('Selecione 2 ou mais takes colados para marcar os cortes entre eles.'); }
        var seen = {}, cut, key;
        for (i = 0; i < sel.length; i++) {
            for (j = 0; j < sel.length; j++) {
                if (i === j) { continue; }
                if (Math.abs(sel[i].end - sel[j].start) < fd * 0.6) {
                    cut = snap(sel[j].start);
                    key = String(Math.round(cut / fd));
                    if (seen[key]) { continue; }
                    seen[key] = true;
                    var half = snap(lenSec / 2);
                    var st = Math.max(0, cut - half);
                    ranges.push({ s: st, e: st + Math.max(fd, snap(lenSec)), from: Math.max(sel[i].track, sel[j].track, topAt(cut)) + 1 });
                }
            }
        }
        if (!ranges.length) { fe_err('Nenhum corte entre os takes selecionados (eles precisam estar colados).'); }
    } else {
        sel = fe_requireSel(seq, 'video');
        if (mode === 'perClip') {
            for (i = 0; i < sel.length; i++) { ranges.push({ s: sel[i].start, e: sel[i].end, from: sel[i].track + 1 }); }
        } else {
            var s0 = 1e9, e0 = -1, top = 0;
            for (i = 0; i < sel.length; i++) {
                if (sel[i].start < s0) { s0 = sel[i].start; }
                if (sel[i].end > e0) { e0 = sel[i].end; }
                if (sel[i].track > top) { top = sel[i].track; }
            }
            ranges.push({ s: s0, e: e0, from: top + 1 });
        }
    }
    var placed = [], ti, clip, qs = null;
    for (i = 0; i < ranges.length; i++) {
        if (ranges[i].e - ranges[i].s < fd) { continue; }
        ti = fe_freeVideoTrack(seq, ranges[i].from, ranges[i].s, a.natural ? ranges[i].s + fd : ranges[i].e);
        clip = fe_place(seq, seq.videoTracks[ti], item, ranges[i].s, a.natural ? 0 : ranges[i].e - ranges[i].s);
        if (clip) {
            if (a.label) { try { clip.name = a.label; } catch (e1) {} }
            placed.push({ clip: clip, track: ti, video: true });
        }
    }
    var lastEnd = null;
    for (i = 0; i < placed.length; i++) { try { lastEnd = placed[i].clip.end.seconds; } catch (eL) {} }
    if (a.fit && placed.length) {
        try {
            var qsf = fe_qeSeq(), qif;
            for (i = 0; i < placed.length; i++) {
                qif = fe_qeItem(qsf, true, placed[i].track, placed[i].clip);
                if (qif) { try { qif.setScaleToFrameSize(); } catch (eF) {} }
            }
        } catch (eQ) {}
    }
    /* opacidade animada do preset (não cabe no clipe mestre): aplica na camada colocada */
    if (a.opacity && a.opacity.length) {
        for (i = 0; i < placed.length; i++) {
            try {
                var oc = fe_comp(placed[i].clip, 'AE.ADBE Opacity'), op = oc ? oc.properties[0] : null, t0o = placed[i].clip.inPoint.seconds, kk;
                if (!op) { continue; }
                op.setTimeVarying(true);
                for (kk = 0; kk < a.opacity.length; kk++) {
                    op.addKey(t0o + a.opacity[kk][0]);
                    op.setValueAtKey(t0o + a.opacity[kk][0], a.opacity[kk][1], kk === a.opacity.length - 1);
                }
            } catch (eO) {}
        }
    }
    /* efeitos que o Premiere não anima a partir do clipe mestre (ex.: Wave Warp): entram animados na camada */
    if (a.clipFx && a.clipFx.length && placed.length) {
        for (i = 0; i < placed.length; i++) { try { fe_applyClipFx(placed[i], a.clipFx); } catch (eC) {} }
    }
    var fx = null;
    if (a.effects && a.effects.length && placed.length) {
        try { qs = fe_qeSeq(); fx = fe_applyEffectsTo(qs, placed, a.effects, false); } catch (e2) {}
    }
    return { placed: placed.length, item: item.name, effects: fx, mode: mode, lastEnd: lastEnd };
};

/* --- WORKFLOW: Project Setup ----------------------------------------------- */
function fe_buildTree(parent, nodes, stats) {
    var i, b, existed;
    for (i = 0; i < nodes.length; i++) {
        if (!nodes[i] || !nodes[i].name) { continue; }
        existed = fe_findBin(parent, nodes[i].name);
        b = existed || fe_getOrCreateBin(parent, nodes[i].name);
        if (existed) { stats.skipped++; } else { stats.created++; }
        if (nodes[i].children && nodes[i].children.length) { fe_buildTree(b, nodes[i].children, stats); }
    }
}

FE_API.projectSetup = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var stats = { created: 0, skipped: 0 };
    fe_buildTree(app.project.rootItem, a.tree || [], stats);
    return stats;
};

/* --- WORKFLOW: Project Organizer ------------------------------------------- */
var FE_EXT = {
    video: 'mp4,mov,mxf,avi,mkv,m4v,mts,m2ts,wmv,mpg,mpeg,r3d,braw,webm,3gp,dv,vob,flv,crm,ari',
    audio: 'wav,mp3,aif,aiff,m4a,aac,flac,ogg,wma,bwf',
    image: 'png,jpg,jpeg,tif,tiff,psd,ai,eps,gif,bmp,heic,webp,exr,dpx,tga,svg,dng,cr2,nef,arw',
    graphic: 'mogrt,aegraphic,prtl,aep,aepx,motn'
};

function fe_classify(it) {
    if (fe_isSequenceItem(it)) { return 'seq'; }
    var p = '';
    try { p = it.getMediaPath(); } catch (e) {}
    if (!p) { return 'graphic'; }
    var ext = fe_extOf(p), k;
    for (k in FE_EXT) {
        if (FE_EXT.hasOwnProperty(k) && (',' + FE_EXT[k] + ',').indexOf(',' + ext + ',') >= 0) { return k; }
    }
    return 'other';
}

function fe_collectItems(bin, nested, skipNames, out, depth) {
    var i, ch;
    for (i = 0; i < bin.children.numItems; i++) {
        ch = bin.children[i];
        if (!ch) { continue; }
        if (ch.type === ProjectItemType.BIN) {
            if (nested && !skipNames[ch.name] && depth < 10) { fe_collectItems(ch, nested, skipNames, out, depth + 1); }
        } else if (ch.type === ProjectItemType.CLIP || ch.type === ProjectItemType.FILE) {
            out.push(ch);
        }
    }
}

FE_API.organize = function (a) {
    if (!app.project) { fe_err('Nenhum projeto aberto.'); }
    var root = app.project.rootItem;
    var bins = a.bins || {};
    var skip = {}, k;
    for (k in bins) { if (bins.hasOwnProperty(k) && bins[k]) { skip[bins[k]] = true; } }
    skip[FE_BIN_MAIN] = true;
    skip[FE_BIN_SFX] = true;
    var items = [];
    fe_collectItems(root, !!a.nested, skip, items, 0);
    var plan = {}, i, cat;
    for (i = 0; i < items.length; i++) {
        cat = fe_classify(items[i]);
        if (!bins[cat]) { continue; }
        if (!plan[cat]) { plan[cat] = { bin: bins[cat], count: 0, samples: [] }; }
        plan[cat].count++;
        if (plan[cat].samples.length < 4) { plan[cat].samples.push(items[i].name); }
        if (a.apply) {
            var target = fe_getOrCreateBin(root, bins[cat]);
            try { items[i].moveBin(target); } catch (e) {}
        }
    }
    return { plan: plan, total: items.length, applied: !!a.apply };
};

/* --- WORKFLOW: Batch -------------------------------------------------------- */
FE_API.batch = function (a) {
    var seq = fe_seq();
    var op = a.op;
    var kind = (op === 'speed' || op === 'reverse' || op === 'removeEffects' || op === 'label' || op === 'disable' || op === 'enable' || op === 'toggle') ? 'all' : 'video';
    var sel = fe_requireSel(seq, kind);
    var n = 0, fail = 0, i, c, qs = null, qi;
    if (op === 'unlink' || op === 'link') {
        try { if (op === 'unlink') { seq.unlinkSelection(); } else { seq.linkSelection(); } n = sel.length; }
        catch (e0) { fe_err('Sua versão do Premiere não suporta essa operação via script.'); }
        return { done: n, failed: 0 };
    }
    if (op === 'removeEffects' || op === 'scaleToFrame' || op === 'speed' || op === 'reverse') { qs = fe_qeSeq(); }
    for (i = 0; i < sel.length; i++) {
        c = sel[i].clip;
        try {
            if (op === 'disable') { c.disabled = true; }
            else if (op === 'enable') { c.disabled = false; }
            else if (op === 'toggle') { c.disabled = !c.disabled; }
            else if (op === 'label') { c.projectItem.setColorLabel(a.value || 0); }
            else {
                qi = fe_qeItem(qs, sel[i].video, sel[i].track, c);
                if (!qi) { fail++; continue; }
                if (op === 'removeEffects') {
                    try { qi.removeEffects(true, true, true, true, true); } catch (e1) { qi.removeEffects(); }
                } else if (op === 'scaleToFrame') {
                    qi.setScaleToFrameSize();
                } else if (op === 'speed') {
                    qi.setSpeed((a.value || 100) / 100, '', false, !!a.ripple, true);
                } else if (op === 'reverse') {
                    try { qi.setReverse(true); } catch (e2) { qi.setSpeed(1, '', true, false, true); }
                }
            }
            n++;
        } catch (e) { fail++; }
    }
    return { done: n, failed: fail };
};

/* --- WORKFLOW: Sort clips (sem subclipes, preserva efeitos) ---------------- */
function fe_natCmp(a, b) {
    var ax = String(a).toLowerCase().match(/(\d+|\D+)/g) || [];
    var bx = String(b).toLowerCase().match(/(\d+|\D+)/g) || [];
    var i, x, y, nx, ny;
    for (i = 0; i < Math.min(ax.length, bx.length); i++) {
        x = ax[i]; y = bx[i];
        nx = parseInt(x, 10); ny = parseInt(y, 10);
        if (!isNaN(nx) && !isNaN(ny)) { if (nx !== ny) { return nx - ny; } }
        else if (x !== y) { return x < y ? -1 : 1; }
    }
    return ax.length - bx.length;
}

function fe_linked(clip) {
    var out = [];
    try {
        var l = clip.getLinkedItems();
        var i;
        if (l) { for (i = 0; i < l.numItems; i++) { if (l[i].nodeId !== clip.nodeId) { out.push(l[i]); } } }
    } catch (e) {}
    return out;
}

/* Move clip por delta segundos; move vinculados se o Premiere não os mover junto. */
function fe_moveWithLinked(clip, linked, delta) {
    var before = [], i;
    for (i = 0; i < linked.length; i++) { before.push(linked[i].start.seconds); }
    clip.move(fe_time(delta));
    for (i = 0; i < linked.length; i++) {
        if (Math.abs(linked[i].start.seconds - before[i]) < FE_EPS) {
            try { linked[i].move(fe_time(delta)); } catch (e) {}
        }
    }
}

FE_API.sortClips = function (a) {
    var seq = fe_seq();
    var sel = fe_requireSel(seq, 'video');
    var track = sel[0].track, i;
    for (i = 0; i < sel.length; i++) {
        if (sel[i].track !== track) { fe_err('Selecione clipes de UMA única trilha de vídeo.'); }
    }
    if (sel.length < 2) { fe_err('Selecione pelo menos 2 clipes.'); }
    if (typeof sel[0].clip.move !== 'function') { fe_err('Sua versão do Premiere não permite mover clipes via script (requer 2019+).'); }
    var items = [];
    for (i = 0; i < sel.length; i++) {
        items.push({ clip: sel[i].clip, name: sel[i].clip.name, dur: sel[i].end - sel[i].start, linked: fe_linked(sel[i].clip), r: Math.random() });
    }
    var origStart = sel[0].start;
    var mode = a.mode || 'name';
    if (mode === 'name') { items.sort(function (x, y) { return fe_natCmp(x.name, y.name); }); }
    else if (mode === 'nameDesc') { items.sort(function (x, y) { return fe_natCmp(y.name, x.name); }); }
    else if (mode === 'duration') { items.sort(function (x, y) { return x.dur - y.dur; }); }
    else if (mode === 'durationDesc') { items.sort(function (x, y) { return y.dur - x.dur; }); }
    else if (mode === 'shuffle') { items.sort(function (x, y) { return x.r - y.r; }); }
    else if (mode === 'reverse') { items.reverse(); }
    var D = fe_secOf(seq.end) + 30 - origStart;
    for (i = 0; i < items.length; i++) { fe_moveWithLinked(items[i].clip, items[i].linked, D); }
    var cursor = origStart;
    for (i = 0; i < items.length; i++) {
        fe_moveWithLinked(items[i].clip, items[i].linked, cursor - items[i].clip.start.seconds);
        cursor += items[i].dur;
    }
    return { sorted: items.length };
};

/* --- WORKFLOW: Timeline cleaner -------------------------------------------- */
function fe_allClips(seq) {
    var out = [];
    fe_eachClip(seq, function (c, t, v) { out.push({ clip: c, track: t, video: v }); });
    return out;
}

FE_API.closeGaps = function (a) {
    var seq = fe_seq();
    var all = fe_allClips(seq);
    if (!all.length) { return { gaps: 0, seconds: 0 }; }
    if (typeof all[0].clip.move !== 'function') { fe_err('Sua versão do Premiere não permite mover clipes via script (requer 2019+).'); }
    var iv = [], i;
    for (i = 0; i < all.length; i++) { iv.push([all[i].clip.start.seconds, all[i].clip.end.seconds]); }
    iv.sort(function (x, y) { return x[0] - y[0]; });
    var merged = [iv[0].slice(0)];
    for (i = 1; i < iv.length; i++) {
        var last = merged[merged.length - 1];
        if (iv[i][0] <= last[1] + FE_EPS) { if (iv[i][1] > last[1]) { last[1] = iv[i][1]; } }
        else { merged.push(iv[i].slice(0)); }
    }
    var fd = fe_frameDur(seq);
    var minGap = (a && a.minFrames ? a.minFrames : 1) * fd - FE_EPS;
    var gaps = [];
    if (a && a.fromStart && merged[0][0] > minGap) { gaps.push([0, merged[0][0]]); }
    for (i = 1; i < merged.length; i++) {
        if (merged[i][0] - merged[i - 1][1] > minGap) { gaps.push([merged[i - 1][1], merged[i][0]]); }
    }
    var total = 0, g, snap, j, len;
    for (g = gaps.length - 1; g >= 0; g--) {
        len = gaps[g][1] - gaps[g][0];
        all = fe_allClips(seq);
        snap = [];
        for (j = 0; j < all.length; j++) {
            if (all[j].clip.start.seconds >= gaps[g][1] - FE_EPS) { snap.push({ c: all[j].clip, s: all[j].clip.start.seconds }); }
        }
        snap.sort(function (x, y) { return x.s - y.s; });
        for (j = 0; j < snap.length; j++) {
            if (Math.abs(snap[j].c.start.seconds - snap[j].s) > FE_EPS) { continue; }
            try { snap[j].c.move(fe_time(-len)); } catch (e) {}
        }
        total += len;
    }
    return { gaps: gaps.length, seconds: Math.round(total * 100) / 100 };
};

FE_API.removeDisabled = function () {
    var seq = fe_seq();
    var all = fe_allClips(seq), n = 0, i;
    for (i = all.length - 1; i >= 0; i--) {
        if (all[i].clip.disabled) { try { all[i].clip.remove(false, false); n++; } catch (e) {} }
    }
    return { removed: n };
};

FE_API.removeShort = function (a) {
    var seq = fe_seq();
    var fd = fe_frameDur(seq);
    var lim = (a.frames || 3) * fd + FE_EPS;
    var all = fe_allClips(seq), n = 0, i;
    for (i = all.length - 1; i >= 0; i--) {
        var c = all[i].clip;
        if (c.end.seconds - c.start.seconds < lim) { try { c.remove(false, false); n++; } catch (e) {} }
    }
    return { removed: n };
};

FE_API.removeEmptyTracks = function () {
    fe_seq();
    var q = fe_qeSeq(), ok = 0;
    try { q.removeEmptyVideoTracks(); ok++; } catch (e) {}
    try { q.removeEmptyAudioTracks(); ok++; } catch (e2) {}
    if (!ok) { fe_err('Sua versão do Premiere não suporta remover trilhas vazias via script.'); }
    return { ok: true };
};

/* --- WORKFLOW: Social ------------------------------------------------------- */
/* multiplica a escala (Movimento > Escala, inclusive keyframes) de todos os clipes de vídeo */
function fe_scaleSeqClips(seq, k) {
    var t, j, c, m, sp, keys, x, n = 0;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        for (j = 0; j < seq.videoTracks[t].clips.numItems; j++) {
            c = seq.videoTracks[t].clips[j];
            m = c ? fe_comp(c, 'AE.ADBE Motion') : null;
            if (!m) { continue; }
            sp = m.properties[1];
            try {
                if (sp.isTimeVarying()) {
                    keys = fe_keyTimes(sp);
                    for (x = 0; x < keys.length; x++) { sp.setValueAtKey(keys[x], sp.getValueAtKey(keys[x]) * k, x === keys.length - 1); }
                } else {
                    sp.setValue(sp.getValue() * k, true);
                }
                n++;
            } catch (e) {}
        }
    }
    return n;
}

/* deixa a sequência em resolução cheia (ex.: 1080x1920) sem mudar o enquadramento */
function fe_fullRes(ns, w, h) {
    var st = ns.getSettings();
    var ow = st.videoFrameWidth, oh = st.videoFrameHeight;
    if (ow === w && oh === h) { return { w: w, h: h, scaled: 0 }; }
    var k = Math.max(w / ow, h / oh);
    st.videoFrameWidth = w;
    st.videoFrameHeight = h;
    try { if (st.previewFrameWidth !== undefined) { st.previewFrameWidth = w; st.previewFrameHeight = h; } } catch (e0) {}
    ns.setSettings(st);
    return { w: w, h: h, from: ow + 'x' + oh, scaled: fe_scaleSeqClips(ns, k) };
}

FE_API.socialSequence = function (a) {
    var seq = fe_seq();
    var name = a.name || (seq.name + ' ' + a.label);
    var before = {}, i, ns = null, method = 'clone';
    for (i = 0; i < app.project.sequences.numSequences; i++) { before[app.project.sequences[i].sequenceID] = true; }
    var findNew = function () {
        var j, found = null;
        for (j = 0; j < app.project.sequences.numSequences; j++) {
            if (!before[app.project.sequences[j].sequenceID]) { found = app.project.sequences[j]; }
        }
        return found;
    };
    if (a.autoReframe && typeof seq.autoReframeSequence === 'function') {
        try { ns = seq.autoReframeSequence(a.num, a.den, 'default', name, false); } catch (e) { ns = null; }
        if (ns && !ns.getSettings) { ns = findNew(); }
        if (ns) { method = 'autoReframe'; }
    }
    if (!ns) {
        seq.clone();
        ns = findNew();
        if (!ns) { fe_err('Não foi possível duplicar a sequência.'); }
        try { ns.name = name; } catch (e1) {}
    }
    var res = null;
    try { res = fe_fullRes(ns, a.w, a.h); } catch (e2) { res = null; }
    try { app.project.openSequence(ns.sequenceID); } catch (e3) {}
    return { name: name, method: method, size: res ? res.w + 'x' + res.h : '', from: res && res.from ? res.from : '' };
};

function fe_guideClips(seq) {
    var all = fe_allClips(seq), out = [], i, nm;
    for (i = 0; i < all.length; i++) {
        nm = '';
        try { nm = all[i].clip.projectItem.name; } catch (e) {}
        if (nm.indexOf(FE_GUIDE_PREFIX) === 0 || all[i].clip.name.indexOf(FE_GUIDE_PREFIX) === 0) { out.push(all[i].clip); }
    }
    return out;
}

FE_API.guidesState = function () {
    var seq = app.project ? app.project.activeSequence : null;
    if (!seq) { return { count: 0, visible: false }; }
    var g = fe_guideClips(seq), vis = false, i;
    for (i = 0; i < g.length; i++) { if (!g[i].disabled) { vis = true; } }
    return { count: g.length, visible: vis };
};

/* esconde/mostra as guias (desativa o clipe — não apaga nada) */
FE_API.toggleGuides = function (a) {
    var seq = fe_seq();
    var g = fe_guideClips(seq), i;
    if (!g.length) { fe_err('Não há guia nesta sequência. Adicione uma primeiro.'); }
    var visible = (a && a.visible !== undefined) ? !!a.visible : !!g[0].disabled;
    for (i = 0; i < g.length; i++) { try { g[i].disabled = !visible; } catch (e) {} }
    return { count: g.length, visible: visible };
};

FE_API.removeGuides = function () {
    var seq = fe_seq();
    var all = fe_allClips(seq), n = 0, i, nm;
    for (i = all.length - 1; i >= 0; i--) {
        nm = '';
        try { nm = all[i].clip.projectItem.name; } catch (e) {}
        if (nm.indexOf(FE_GUIDE_PREFIX) === 0 || all[i].clip.name.indexOf(FE_GUIDE_PREFIX) === 0) {
            try { all[i].clip.remove(false, false); n++; } catch (e2) {}
        }
    }
    return { removed: n };
};

/* --- Copiar frame -------------------------------------------------------------- */
/* --- ANIMATE: Rastro de luz (Time Blur) ------------------------------------
   Eco nativo (frames anteriores somados) + desfoque leve. O comprimento do
   rastro e o brilho seguem a curva do look, assada em keyframes por frame. */
function fe_findVideoEffect(rx, fallbackRx) {
    var q = fe_qe(), list = [], i, eff, pass, nm;
    try { list = fe_toList(q.project.getVideoEffectList()); } catch (e) {}
    /* versões novas renomeiam alguns efeitos para "Nome (Legacy)" / "(Herdado)" / "(Legado)": aceita também */
    var strip = function (n) { return String(n).replace(/\s*\((legacy|herdado|legado|antigo)\)\s*$/i, ''); };
    var rxs = fallbackRx ? [rx, fallbackRx] : [rx];
    for (var r = 0; r < rxs.length; r++) {
        for (pass = 0; pass < 2; pass++) {
            for (i = 0; i < list.length; i++) {
                nm = pass === 0 ? list[i] : strip(list[i]);
                if (rxs[r].test(nm)) { eff = q.project.getVideoEffectByName(list[i]); if (eff) { return eff; } }
            }
        }
    }
    return null;
}

function fe_lastComp(clip, mrx, nrx) {
    var i, c, found = null;
    for (i = 0; i < clip.components.numItems; i++) {
        c = clip.components[i];
        if (!c) { continue; }
        if (mrx.test(c.matchName || '') || (nrx && nrx.test(c.displayName || ''))) { found = c; }
    }
    return found;
}

function fe_tbNoise(i) {
    var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
}

/* valor suave de ruído (interpolado) para o tremido rápido */
function fe_tbSmooth(t, rate) {
    var x = t * rate, i = Math.floor(x), f = x - i;
    f = f * f * (3 - 2 * f);
    return fe_tbNoise(i) + (fe_tbNoise(i + 1) - fe_tbNoise(i)) * f;
}

function fe_tbClearParam(p) {
    try { if (p.isTimeVarying()) { p.setTimeVarying(false); } } catch (e) {}
}

function fe_tbKeysI(p, times, vals, interp) {
    var i;
    try { p.setTimeVarying(false); } catch (e0) {}
    try { p.setTimeVarying(true); } catch (e) { return 0; }
    for (i = 0; i < times.length; i++) {
        try { p.addKey(times[i]); p.setValueAtKey(times[i], vals[i], (i === times.length - 1)); } catch (e2) {}
        try { p.setInterpolationTypeAtKey(times[i], interp ? interp[i] : 1, false); } catch (e3) {}
    }
    return times.length;
}
function fe_tbKeys(p, times, vals) {
    var i;
    try { p.setTimeVarying(true); } catch (e) { return 0; }
    try { p.removeKeyRange(times[0] - 0.001, times[times.length - 1] + 0.001, true); } catch (e1) {}
    for (i = 0; i < times.length; i++) {
        try {
            p.addKey(times[i]);
            p.setValueAtKey(times[i], vals[i], (i === times.length - 1));
            p.setInterpolationTypeAtKey(times[i], 0, false);
        } catch (e2) {}
    }
    return times.length;
}

/* desfoque do rastro: Fast Blur > Gaussian Blur (Legacy) > Gaussian Blur. Reconhece pelo matchName e acha o
   controle de intensidade pelo NOME (a ordem dos parâmetros muda entre versões). */
var FE_TB_BLUR_MN = /ADBE Fast Blur|ADBE Gaussian Blur|Impact_Blur_FX|ADBE Box Blur/i;
function fe_tbBlurEffect() {
    var order = [/^fast blur$/i, /^desfoque r[aá]pido$/i, /^gaussian blur \(legacy\)$/i, /^desfoque gaussiano \((herdado|legado)\)$/i, /^gaussian blur$/i, /^desfoque gaussiano$/i], i, e;
    for (i = 0; i < order.length; i++) { e = fe_findVideoEffect(order[i], null); if (e) { return e; } }
    return null;
}
function fe_tbBlurParam(comp) {
    var i, p, nm, first = null, v;
    if (!comp) { return null; }
    for (i = 0; i < comp.properties.numItems; i++) {
        p = comp.properties[i]; nm = '';
        try { nm = p.displayName || ''; } catch (e) {}
        if (/blurriness|desfoque|amount|quantidade|intensidade|radius|raio/i.test(nm)) { return p; }
        if (!first) { try { v = p.getValue(); if (typeof v === 'number' && !/seed|angle|[aâ]ngulo|version|width|height|mode|ratio/i.test(nm)) { first = p; } } catch (e2) {} }
    }
    return first;
}

/* depois de adicionar efeito via QE, o objeto do clipe pode ter a lista de efeitos antiga: relê pelo nodeId */
function fe_refetch(seq, trackIdx, clip) {
    var tr = seq.videoTracks[trackIdx], j, c, id = clip.nodeId;
    if (!tr) { return clip; }
    for (j = 0; j < tr.clips.numItems; j++) { c = tr.clips[j]; if (c && c.nodeId === id) { return c; } }
    return clip;
}

FE_API.timeBlur = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var sel = fe_requireSel(seq, 'video');
    var fd = fe_frameDur(seq);
    var echoRx = /ADBE Echo/i, echoName = /^(echo|eco)$/i;
    var blurRx = FE_TB_BLUR_MN;
    var res = { clips: 0, keys: 0, missing: false };
    var echoEff = null, blurEff = null, i, j;

    if (a.remove) {
        /* Desligar = tira o Eco e o desfoque do rastro do clipe (QE component.remove) */
        for (i = 0; i < sel.length; i++) {
            var qr = fe_qeItem(qs, true, sel[i].track, sel[i].clip), removed = 0, ci, qc, mn;
            if (!qr) { continue; }
            for (ci = qr.numComponents - 1; ci >= 0; ci--) {
                qc = qr.getComponentAt(ci); mn = '';
                try { mn = qc.matchName || ''; } catch (eq) {}
                if (/ADBE Echo/i.test(mn) || FE_TB_BLUR_MN.test(mn)) { try { qc.remove(); removed++; } catch (er) {} }
            }
            if (!removed) {   /* versões sem remove(): neutraliza */
                var ce = fe_lastComp(sel[i].clip, echoRx, echoName);
                if (ce) { fe_tbClearParam(ce.properties[0]); try { ce.properties[1].setValue(0, true); } catch (er1) {} removed++; }
            }
            if (removed) { res.clips++; }
        }
        return res;
    }

    var S = a.samples || [0, 1];
    var period = a.period || 2;
    var maxF = Math.max(1, a.streak || 2.5);           /* distância entre ecos (frames) no pico */
    var minF = 1;
    var pulse = a.pulse === undefined ? 1 : a.pulse;      /* quanto a curva move o rastro */
    var shimmer = a.shimmer === undefined ? 0.12 : a.shimmer;
    var n = Math.max(1, Math.round(a.echoes || 6));
    var mix = a.mix === undefined ? 0.5 : a.mix;
    var glow = a.glow || 0;
    var step = Math.max(1, a.step || 1);
    var decay = a.decay || Math.min(0.92, 0.5 + 0.4 * mix);
    var sum = 0, k;
    for (k = 0; k <= n; k++) { sum += Math.pow(decay, k); }
    var gain = a.light ? (1.05 + 0.45 * mix) : 1;
    var startI = Math.min(1, gain / sum);

    for (i = 0; i < sel.length; i++) {
        var clip = sel[i].clip;
        var qi = null;
        var comp = fe_lastComp(clip, echoRx, echoName);
        /* o desfoque entra ANTES do eco: o rastro sai borrado (desfoque de movimento) */
        if (!comp && glow > 0 && !fe_lastComp(clip, blurRx, null)) {
            if (!blurEff) { blurEff = fe_tbBlurEffect(); }
            qi = fe_qeItem(qs, true, sel[i].track, clip);
            try { if (qi && blurEff) { qi.addVideoEffect(blurEff); clip = fe_refetch(seq, sel[i].track, clip); } } catch (eb) {}
        }
        if (!comp) {
            if (!echoEff) { echoEff = fe_findVideoEffect(echoName, /echo|\beco\b/i); }
            if (!echoEff) { res.missing = true; fe_err('Efeito Eco (Echo) não encontrado no Premiere.'); }
            if (!qi) { qi = fe_qeItem(qs, true, sel[i].track, clip); }
            if (!qi) { continue; }
            try { qi.addVideoEffect(echoEff); } catch (e0) { continue; }
            clip = fe_refetch(seq, sel[i].track, clip);
            comp = fe_lastComp(clip, echoRx, echoName);
            if (!comp) { continue; }
        }
        var P = comp.properties;
        /* operador: Máximo = só as partes claras deixam rastro (destaques); Mistura = rastro em tudo.
           Ordem do menu: Add, Maximum, Minimum, Screen, Comp. atrás, Comp. frente, Blend. Descobre se começa em 0 ou 1. */
        try {
            var opP = P[4], cur = opP.getValue();
            if ($._FE_ECHO_BASE === undefined) { $._FE_ECHO_BASE = (cur === 0) ? 0 : 1; }
            opP.setValue((a.light ? 1 : 6) + $._FE_ECHO_BASE, true);
        } catch (e1) {}
        try { P[1].setValue(n, true); } catch (e2) {}
        try { P[2].setValue(a.light ? 1 : startI, true); } catch (e3) {}

        /* tempos (mídia) e valores */
        var t0 = clip.inPoint.seconds, t1 = clip.outPoint.seconds;
        var len = Math.max(fd, t1 - t0);
        var times = [], echoV = [], blurV = [], decV = [], t, u, p, f, q;
        var count = Math.round(len / (fd * step));
        if (count > 1500) { step = Math.ceil(len / fd / 1500); count = Math.round(len / (fd * step)); }
        for (j = 0; j <= count; j++) {
            t = t0 + Math.min(len, j * fd * step);
            u = a.loop === false ? (t - t0) / len : ((t - t0) / period) % 1;
            p = fe_curveAt(S, u);
            p = p + shimmer * (fe_tbSmooth(t - t0, 9) - 0.5) * 2;
            p = Math.max(0, Math.min(1.2, p));
            q = Math.min(1, 1 - pulse + pulse * p);       /* 0 = sem rastro, 1 = rastro cheio */
            f = minF + (maxF - minF) * q;
            times.push(t);
            echoV.push(-f * fd);
            decV.push(0.08 + (decay - 0.08) * q);          /* a força do rastro "respira" com a curva */
            blurV.push(glow * (0.15 + 0.85 * q));
        }
        /* poucos keyframes: só os pontos que dão a forma da curva do look (picos, vales e onde ela dobra) */
        var qs2 = [], qmin = 1e9, qmax = -1e9, z;
        for (z = 0; z < echoV.length; z++) { if (echoV[z] < qmin) { qmin = echoV[z]; } if (echoV[z] > qmax) { qmax = echoV[z]; } }
        for (z = 0; z < echoV.length; z++) { qs2.push((echoV[z] - qmin) / ((qmax - qmin) || 1)); }
        var kIdx = fe_curveKeyIdx(qs2, 0.1);
        var kT = [], kE = [], kD = [], kB = [], kI = [];
        for (z = 0; z < kIdx.length; z++) {
            var ki = kIdx[z], slL = ki > 0 ? qs2[ki] - qs2[ki - 1] : 0, slR = ki < qs2.length - 1 ? qs2[ki + 1] - qs2[ki] : 0;
            kT.push(times[ki]); kE.push(echoV[ki]); kD.push(decV[ki]); kB.push(blurV[ki]);
            kI.push(Math.abs(slL + slR) < 0.02 || slL * slR < 0 && Math.abs(slL) + Math.abs(slR) < 0.08 ? 3 : (slL * slR < 0 ? 0 : 1));
        }
        res.keys += fe_tbKeysI(P[0], kT, kE, kI);
        res.keys += fe_tbKeysI(P[3], kT, kD, kI);
        times = kT; blurV = kB;

        if (glow > 0) {
            var bc = fe_lastComp(clip, blurRx, null);
            if (!bc) {
                if (!blurEff) { blurEff = fe_tbBlurEffect(); }
                if (blurEff) {
                    var qi2 = fe_qeItem(qs, true, sel[i].track, clip);
                    try { if (qi2) { qi2.addVideoEffect(blurEff); } } catch (e5) {}
                    clip = fe_refetch(seq, sel[i].track, clip);
                    bc = fe_lastComp(clip, blurRx, null);
                }
            }
            var bcp = fe_tbBlurParam(bc);
            if (bcp) { res.keys += fe_tbKeysI(bcp, times, blurV, kI); }
        } else {
            var bc0 = fe_lastComp(clip, blurRx, null);
            var bp0 = fe_tbBlurParam(bc0);
            if (bp0) { fe_tbClearParam(bp0); try { bp0.setValue(0, true); } catch (e6) {} }
        }
        res.clips++;
    }
    return res;
};

/* --- AFTER MOVIE: efeito em cada marcador (batida) -------------------------- */
FE_API.beatFx = function (a) {
    var seq = fe_seq();
    var fd = fe_frameDur(seq);
    var times = [], m = seq.markers.getFirstMarker();
    while (m) { times.push(m.start.seconds); m = seq.markers.getNextMarker(m); }
    if (!times.length) { fe_err('Marque as batidas com a tecla M na timeline.'); }
    var dur = (a.frames || 6) * fd, I = a.intensity || 1, preset = a.preset || 'punch';
    var done = 0, skipped = 0, i, t, ti, c, j, clip, tr;
    for (i = 0; i < times.length; i++) {
        t = times[i] + 0.0005;
        clip = null;
        for (ti = seq.videoTracks.numTracks - 1; ti >= 0 && !clip; ti--) {
            tr = seq.videoTracks[ti];
            for (j = 0; j < tr.clips.numItems; j++) {
                c = tr.clips[j];
                if (!c || c.start.seconds > t || c.end.seconds <= t) { continue; }
                try { if (c.disabled) { continue; } } catch (e0) {}
                try { if (c.projectItem && c.projectItem.isAdjustmentLayer && c.projectItem.isAdjustmentLayer()) { continue; } } catch (e1) {}
                if (fe_comp(c, 'AE.ADBE Motion')) { clip = c; break; }
            }
        }
        if (!clip) { skipped++; continue; }
        try { fe_animateSingle(seq, clip, preset, dur, true, false, I, times[i]); done++; } catch (e2) { skipped++; }
    }
    return { markers: times.length, done: done, skipped: skipped, times: times };
};

/* --- AFTER MOVIE: Transição em grid (quadrículas trocando de A para B) -------------------
   Cópia do take B por cima, revelada em blocos (Block Dissolve com bloco = tela/colunas x tela/filas);
   embaixo dela, depois do corte, uma cópia do fim do take A mostra os blocos que ainda não trocaram.
   Linhas = PNG de grade por cima. Clarão = Tint animado nos blocos já trocados. */
function fe_param(comp, rx) {
    var i, p;
    if (!comp) { return null; }
    for (i = 0; i < comp.properties.numItems; i++) { p = comp.properties[i]; try { if (rx.test(p.displayName)) { return p; } } catch (e) {} }
    return null;
}
/* escala do efeito Transformar: em algumas versões vem "Escala uniforme" desligada e não existe "Escala",
   só "Altura da escala" e "Largura da escala". Liga a uniforme e devolve o controle que vale para os dois. */
function fe_tfScale(cp) {
    if (!cp) { return null; }
    var un = fe_param(cp, /uniform|uniforme/i);
    if (un) { try { if (un.getValue() !== true) { un.setValue(true, true); } } catch (e) {} }
    return fe_param(cp, /^(scale|escala)$/i) || fe_param(cp, /scale height|altura/i) || cp.properties[3];
}
/* nomes dos efeitos em inglês e português (o Premiere pode estar em qualquer um dos dois idiomas) */
var FE_FX_NAMES = {
    'Transform': /^(transform|transformar)$/i,
    'Crop': /^(crop|cortar|recortar)$/i,
    'Tint': /^(tint|tingir|matiz|tonalidade|tingimento|colorir)$/i,
    'Offset': /^(offset|deslocamento|deslocar)$/i,
    'Directional Blur': /^(directional blur|desfoque direcional)$/i,
    'Brightness & Contrast': /^(brightness & contrast|brilho e contraste|brilho & contraste)$/i,
    'Turbulent Displace': /^(turbulent displace|deslocamento turbulento|deslocar turbulento)$/i
};
function fe_addFx(seq, trackIdx, clip, name) {
    var rx = FE_FX_NAMES[name] || new RegExp('^' + name.replace(/[&()]/g, '.') + '$', 'i');
    var qs = fe_qeSeq(), qi = fe_qeItem(qs, true, trackIdx, clip), eff = fe_findVideoEffect(rx, null);
    if (!qi || !eff) { return null; }
    var before = [], i, n = clip.components.numItems;
    for (i = 0; i < n; i++) { before.push(clip.components[i].matchName); }
    try { qi.addVideoEffect(eff); } catch (e) { return null; }
    clip = fe_refetch(seq, trackIdx, clip);
    if (!clip) { return null; }
    /* o efeito novo entra no fim ou logo abaixo do Movimento: acha onde a lista de efeitos mudou */
    for (i = 0; i < clip.components.numItems; i++) { if (i >= n || clip.components[i].matchName !== before[i]) { return { clip: clip, comp: clip.components[i] }; } }
    for (i = clip.components.numItems - 1; i >= 0; i--) { if (rx.test(clip.components[i].displayName)) { return { clip: clip, comp: clip.components[i] }; } }
    return { clip: clip, comp: null };
}
function fe_setKeys(p, pts) {
    var i;
    try { p.setTimeVarying(true); } catch (e) { return; }
    for (i = 0; i < pts.length; i++) { try { p.addKey(pts[i][0]); p.setValueAtKey(pts[i][0], pts[i][1], i === pts.length - 1); } catch (e2) {} }
}
/* coloca um trecho de mídia (srcIn..srcIn+dur) de um item, só vídeo, na trilha/tempo */
function fe_placeRange(seq, trackIdx, item, start, srcIn, dur) {
    var oi = null, oo = null, clip = null, fd = fe_frameDur(seq);
    try { oi = item.getInPoint(1).seconds; oo = item.getOutPoint(1).seconds; } catch (e) {}
    try { item.setInPoint(srcIn, 4); item.setOutPoint(srcIn + dur, 4); } catch (e1) {}
    var aBefore = fe_audioSnapshot(seq);
    seq.videoTracks[trackIdx].overwriteClip(item, start);
    clip = fe_clipAt(seq.videoTracks[trackIdx], start, fd * 0.75);
    fe_dropNewAudio(seq, aBefore);
    try { if (oi !== null) { item.setInPoint(oi, 4); item.setOutPoint(oo, 4); } } catch (e2) {}
    if (clip) { try { clip.end = fe_time(start + dur); } catch (e3) {} }
    return clip;
}
/* garante que nenhum áudio novo fique na timeline (overwriteClip pode trazer o áudio junto) */
function fe_audioSnapshot(seq) {
    var t, j, snap = {};
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        for (j = 0; j < seq.audioTracks[t].clips.numItems; j++) { snap[seq.audioTracks[t].clips[j].nodeId] = true; }
    }
    return snap;
}
function fe_dropNewAudio(seq, snap) {
    var t, j, c;
    for (t = 0; t < seq.audioTracks.numTracks; t++) {
        for (j = seq.audioTracks[t].clips.numItems - 1; j >= 0; j--) {
            c = seq.audioTracks[t].clips[j];
            if (!snap[c.nodeId]) { try { c.remove(false, false); } catch (e) {} }
        }
    }
}

/* ordem em que as quadrículas trocam */
function fe_gridOrder(cols, rows, pattern, seed) {
    var cells = [], r, c, i, j, t, x = (seed || 1) >>> 0;
    var rnd = function () { x = (x * 1664525 + 1013904223) % 4294967296; return x / 4294967296; };
    for (r = 0; r < rows; r++) { for (c = 0; c < cols; c++) { cells.push({ c: c, r: r, k: 0 }); } }
    var cx = (cols - 1) / 2, cy = (rows - 1) / 2;
    for (i = 0; i < cells.length; i++) {
        c = cells[i].c; r = cells[i].r;
        if (pattern === 'center') { cells[i].k = -Math.sqrt((c - cx) * (c - cx) + (r - cy) * (r - cy)) + rnd() * 0.3; }
        else if (pattern === 'out') { cells[i].k = Math.sqrt((c - cx) * (c - cx) + (r - cy) * (r - cy)) + rnd() * 0.3; }
        else if (pattern === 'left') { cells[i].k = c + rnd() * 0.5; }
        else if (pattern === 'top') { cells[i].k = r + rnd() * 0.5; }
        else if (pattern === 'diag') { cells[i].k = c + r + rnd() * 0.5; }
        else { cells[i].k = rnd(); }
    }
    for (i = 1; i < cells.length; i++) { t = cells[i]; j = i - 1; while (j >= 0 && cells[j].k > t.k) { cells[j + 1] = cells[j]; j--; } cells[j + 1] = t; }
    return cells;
}

FE_API.gridTransition = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq);
    var cols = Math.max(1, Math.min(12, a.cols || 5)), rows = Math.max(1, Math.min(12, a.rows || 5));
    var d = Math.max(4, a.frames || 18) * fd;
    var sel = fe_requireSel(seq, 'video'), pairs = [], i, j, k;
    for (i = 0; i < sel.length; i++) {
        for (j = 0; j < sel.length; j++) {
            if (i !== j && sel[i].track === sel[j].track && Math.abs(sel[i].end - sel[j].start) < fd * 0.6) { pairs.push([sel[i], sel[j]]); }
        }
    }
    if (!pairs.length) { fe_err('Selecione 2 ou mais takes colados na mesma trilha.'); }
    var snap = function (t) { return Math.round(t / fd) * fd; };
    var lines = null, done = 0, warn = 0, noHandle = 0, noTint = 0;
    if (a.linesPng) { try { lines = fe_importOnce(a.linesPng, FE_BIN_MAIN); } catch (eL) { lines = null; } }
    var bin = fe_getOrCreateBin(app.project.rootItem, 'Fast Edit · Grid');
    var mainId = seq.sequenceID;
    var copyMotion = function (src, dst) {
        var ms = fe_comp(src, 'AE.ADBE Motion'), md = fe_comp(dst, 'AE.ADBE Motion'), q;
        if (!ms || !md) { return; }
        for (q = 0; q < ms.properties.numItems && q < md.properties.numItems; q++) {
            try { if (!ms.properties[q].isTimeVarying()) { md.properties[q].setValue(ms.properties[q].getValue(), true); } } catch (em) {}
        }
    };
    for (i = 0; i < pairs.length; i++) {
        var A = pairs[i][0].clip, B = pairs[i][1].clip, tr = pairs[i][0].track, cut = snap(B.start.seconds);
        var half = snap(d / 2), hA = 0;
        try { hA = A.projectItem.getOutPoint(1).seconds - A.outPoint.seconds; } catch (eh) { hA = 0; }
        var pre = Math.min(half, snap(Math.max(0, B.inPoint.seconds))), post = Math.min(half, snap(Math.max(0, hA)));
        var D = pre + post, T0, aIn, bIn;
        if (D >= snap(d) - fd * 0.5 || D >= fd * 6) {
            if (pre < half || post < half) { warn++; }
            T0 = cut - pre; aIn = A.outPoint.seconds - pre; bIn = B.inPoint.seconds - pre;
        } else {
            /* takes sem sobra: o grid acontece no fim do take A, mostrando o começo do take B */
            var lenA = A.end.seconds - A.start.seconds, lenB = B.end.seconds - B.start.seconds;
            D = snap(Math.min(d, lenA * 0.8, lenB * 0.8));
            if (D < fd * 3) { continue; }
            T0 = cut - D; aIn = A.outPoint.seconds - D; bIn = B.inPoint.seconds;
            noHandle++;
        }
        /* sequência aninhada com as quadrículas */
        var ns = app.project.createNewSequenceFromClips('Grid ' + cols + 'x' + rows, [A.projectItem], bin);
        if (!ns) { fe_err('Não consegui criar a sequência do grid.'); }
        try { ns.setSettings(seq.getSettings()); } catch (eS) {}
        app.project.openSequence(ns.sequenceID);
        var t, c2;
        for (t = 0; t < ns.videoTracks.numTracks; t++) { for (c2 = ns.videoTracks[t].clips.numItems - 1; c2 >= 0; c2--) { ns.videoTracks[t].clips[c2].remove(false, false); } }
        for (t = 0; t < ns.audioTracks.numTracks; t++) { for (c2 = ns.audioTracks[t].clips.numItems - 1; c2 >= 0; c2--) { ns.audioTracks[t].clips[c2].remove(false, false); } }
        var cells = fe_gridOrder(cols, rows, a.pattern || 'random', a.seed || 7), N = cells.length;
        var need = N + (lines ? 2 : 1);
        while (ns.videoTracks.numTracks < need) { if (fe_addVideoTrack(ns) < 0) { break; } }
        /* base: A inteiro durante a janela */
        var base = fe_placeRange(ns, 0, A.projectItem, 0, aIn, D);
        if (base) { copyMotion(A, base); }
        var spanEnd = Math.max(fd, D - Math.max(1, a.flashFrames || 4) * fd - fd);
        var col = a.flashColor || [140, 220, 40], inten = a.flashIntensity === undefined ? 100 : a.flashIntensity, ff = Math.max(1, a.flashFrames || 4) * fd;
        for (k = 0; k < N; k++) {
            var tk = snap((N > 1 ? k / (N - 1) : 0) * spanEnd);
            if (tk >= D - fd) { tk = D - fd; }
            var tile = fe_placeRange(ns, k + 1, B.projectItem, tk, bIn + tk, D - tk);
            if (!tile) { continue; }
            copyMotion(B, tile);
            var cr = fe_addFx(ns, k + 1, tile, 'Crop');
            if (cr && cr.comp) {
                tile = cr.clip;
                var cc = cells[k];
                var pl = fe_param(cr.comp, /^left|esquerd/i), pt = fe_param(cr.comp, /^top|superior/i), pr = fe_param(cr.comp, /^right|direit/i), pb = fe_param(cr.comp, /^bottom|inferior/i);
                try { pl.setValue(cc.c / cols * 100, true); pr.setValue((cols - cc.c - 1) / cols * 100, true); pt.setValue(cc.r / rows * 100, true); pb.setValue((rows - cc.r - 1) / rows * 100, true); } catch (eC) {}
            }
            if (a.flash !== false && inten > 0) {
                var rt = fe_addFx(ns, k + 1, tile, 'Tint');
                if (!rt || !rt.comp) { noTint++; }
                if (rt && rt.comp) {
                    var m0 = rt.clip.inPoint.seconds;
                    var p1 = fe_param(rt.comp, /black|preto/i) || rt.comp.properties[0], p2 = fe_param(rt.comp, /white|branco/i) || rt.comp.properties[1], pa = fe_param(rt.comp, /amount|quantidade|intensidade/i) || rt.comp.properties[2];
                    try { p1.setColorValue(255, col[0], col[1], col[2], true); p2.setColorValue(255, col[0], col[1], col[2], true); } catch (e6) {}
                    if (pa) { fe_setKeys(pa, [[m0, inten], [m0 + ff, 0]]); }
                }
            }
        }
        if (lines) {
            var cl = fe_place(ns, ns.videoTracks[N + 1], lines, 0, D);
            if (cl) { try { cl.name = 'Linhas'; } catch (eN) {} }
        }
        /* volta para a sequência principal e põe o grid por cima do corte */
        app.project.openSequence(mainId);
        seq = app.project.activeSequence;
        var ti = fe_freeVideoTrack(seq, tr + 1, T0, T0 + D);
        var snapA = fe_audioSnapshot(seq);
        var nest = fe_place(seq, seq.videoTracks[ti], ns.projectItem, T0, D);
        fe_dropNewAudio(seq, snapA);
        if (nest) { try { nest.name = 'Grid ' + cols + 'x' + rows; } catch (eN2) {} done++; }
    }
    if (!done) { fe_err('Não consegui montar o grid: os takes são curtos demais para a duração escolhida.'); }
    return { cuts: done, clipped: warn, noHandle: noHandle, noTint: noTint };
};

/* o Premiere exige caminho nativo (\\ no Windows) e sempre acrescenta ".png" */
function fe_exportPNG(qs, tc, path) {
    var base = String(path).replace(/\.png$/i, '');
    qs.exportFramePNG(tc, new File(base).fsName);
    return base + '.png';
}
FE_API.exportFrame = function (a) {
    var seq = fe_seq();
    var qs = fe_qeSeq();
    var f = new File(a.path);
    try { if (f.exists) { f.remove(); } } catch (e0) {}
    var tc = null;
    try { tc = seq.CTI.timecode; } catch (e1) {}
    var ok = false, lastErr = '';
    if (tc) { try { fe_exportPNG(qs, tc, a.path); ok = true; } catch (e2) { lastErr = e2.message; } }
    if (!ok) {
        try {
            var fd = fe_frameDur(seq);
            var fr = Math.round(seq.getPlayerPosition().seconds / fd);
            fe_exportPNG(qs, fe_timecode(fr, 1 / fd), a.path);
            ok = true;
        } catch (e3) { lastErr = e3.message; }
    }
    if (!ok) { fe_err('Sua versão do Premiere não permite exportar frame via script. ' + lastErr); }
    return { path: a.path, w: seq.frameSizeHorizontal, h: seq.frameSizeVertical };
};

/* --- SFX -------------------------------------------------------------------- */
FE_API.placeSfx = function (a) {
    var seq = fe_seq();
    var item = fe_importOnce(a.path, FE_BIN_SFX);
    var fd = fe_frameDur(seq);
    var off = (a.offsetFrames || 0) * fd;
    var times = [], i;
    var mode = a.mode || 'playhead';
    if (mode === 'playhead') {
        times.push(seq.getPlayerPosition().seconds);
    } else if (mode === 'selection') {
        var sel = fe_requireSel(seq, 'video');
        var seen = {};
        for (i = 0; i < sel.length; i++) {
            var k = String(Math.round(sel[i].start / fd));
            if (!seen[k]) { seen[k] = true; times.push(sel[i].start); }
        }
    } else if (mode === 'markers') {
        var m = seq.markers.getFirstMarker();
        while (m) {
            times.push(m.start.seconds);
            m = seq.markers.getNextMarker(m);
        }
        if (!times.length) { fe_err('A sequência não tem marcadores.'); }
    } else if (mode === 'times') {
        times = a.times || [];
    }
    var dur = 1;
    try { dur = item.getOutPoint().seconds - item.getInPoint().seconds; } catch (e) {}
    if (!dur || dur <= 0) { dur = 1; }
    var pref = Math.max(0, (a.track || 1) - 1);
    var placed = 0, t, ti;
    for (i = 0; i < times.length; i++) {
        t = Math.max(0, times[i] + off);
        ti = fe_freeAudioTrack(seq, pref, t, t + dur);
        seq.audioTracks[ti].overwriteClip(item, t);
        placed++;
        if (a.gainDb) {
            var c = fe_clipAt(seq.audioTracks[ti], t, fd);
            if (c) {
                try {
                    var vol = fe_comp(c, 'audioeffect.volume') || c.components[0];
                    var lvl = vol.properties[1];
                    var cur = lvl.getValue();
                    lvl.setValue(cur * Math.pow(10, a.gainDb / 20), true);
                } catch (e2) {}
            }
        }
    }
    return { placed: placed, item: item.name };
};

FE_API.addMarker = function (a) {
    var seq = fe_seq(), t = seq.getPlayerPosition().seconds, m = seq.markers.createMarker(t);
    try { if (a && a.name) { m.name = a.name; } } catch (e) {}
    return { at: t };
};

FE_API.markerTimes = function () {
    var seq = fe_seq(), out = [];
    var m = seq.markers.getFirstMarker();
    while (m) { out.push(m.start.seconds); m = seq.markers.getNextMarker(m); }
    return out;
};

/* ------------------------------------------------------------------ Speed ramp (o Premiere não deixa script mexer no Remapeamento de tempo:
   a rampa é feita com pedacinhos de velocidade crescente dentro de uma sequência aninhada; na timeline fica um clipe só) */
function fe_rampCurve(preset, u, M, m, pts, hard) {
    var sm = function (x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
    if (preset === 'custom' && pts && pts.length) {
        var a = pts.slice(0), i, t;
        a.sort(function (p, q) { return p[0] - q[0]; });
        if (u <= a[0][0]) { return Math.max(0.05, a[0][1]); }
        for (i = 1; i < a.length; i++) {
            if (u <= a[i][0]) { t = (u - a[i - 1][0]) / Math.max(0.000001, a[i][0] - a[i - 1][0]); return Math.max(0.05, a[i - 1][1] + (a[i][1] - a[i - 1][1]) * (hard ? t : t * t * (3 - 2 * t))); }
        }
        return Math.max(0.05, a[a.length - 1][1]);
    }
    var bell = function (x) { var b = Math.sin(Math.PI * Math.max(0, Math.min(1, x))); return b * b; };
    if (preset === 'whip') { return 1 + (M - 1) * bell(u); }
    if (preset === 'impact') { return M + (m - M) * bell(u); }
    if (preset === 'slowmid') { return 1 + (m - 1) * bell(u); }
    if (preset === 'down') { return M + (m - M) * sm(u * 1.15); }
    if (preset === 'up') { return m + (M - m) * sm(u * 1.15 - 0.15); }
    return 1;
}
FE_API.speedRamp = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), mainId = seq.sequenceID;
    var sel0 = fe_requireSel(seq, 'video'), done = 0, clipped = 0, i, k;
    var M = Math.max(1.1, (a.max || 300) / 100), m = Math.min(0.95, Math.max(0.05, (a.min || 30) / 100)), step = Math.max(1, Math.round(a.step || 2));
    var list = [];
    for (i = 0; i < sel0.length; i++) { list.push({ track: sel0[i].track, start: sel0[i].start }); }
    var bin = null;
    for (i = list.length - 1; i >= 0; i--) {
        seq = app.project.activeSequence;
        var t = list[i].track, c = fe_clipAt(seq.videoTracks[t], list[i].start, fd * 0.75);
        if (!c || !c.projectItem) { continue; }
        var pi = c.projectItem, cname = c.name;
        var S = Math.round(c.start.seconds / fd) * fd, nF = Math.round((c.end.seconds - c.start.seconds) / fd), I = c.inPoint.seconds;
        if (nF < step * 3) { continue; }
        /* quanto de mídia existe depois do ponto de entrada */
        var mediaEnd = 1e9;
        try { var oo = pi.getOutPoint(1).seconds; pi.clearOutPoint(); mediaEnd = pi.getOutPoint(1).seconds; pi.setOutPoint(oo, 4); } catch (eM) {}
        var segs = [], need = 0, f0 = 0, d, u, sp;
        while (f0 < nF) { d = Math.min(step, nF - f0); u = (f0 + d / 2) / nF; sp = fe_rampCurve(a.preset, u, M, m, a.pts, !!a.hard); segs.push({ f: f0, d: d, s: sp }); need += d * fd * sp; f0 += d; }
        var avail = mediaEnd - I - fd;
        if (need > avail && avail > 0) { var kf = avail / need; for (k = 0; k < segs.length; k++) { segs[k].s = Math.max(0.05, segs[k].s * kf); } clipped++; }
        /* guarda o Motion do take e tira o original (e o áudio dele, que ficaria fora de sincronia) */
        var mv = [], mo = fe_comp(c, 'AE.ADBE Motion'), q;
        if (mo) { for (q = 0; q < mo.properties.numItems; q++) { try { mv.push(fe_baseVal(mo.properties[q], c.inPoint.seconds)); } catch (eV) { mv.push(null); } } }
        var linked = fe_linked(c);
        for (q = 0; q < linked.length; q++) { try { linked[q].remove(false, false); } catch (eL) {} }
        c.remove(false, false);
        /* a rampa é montada dentro de uma sequência aninhada: na timeline fica um clipe só */
        if (!bin) { bin = fe_getOrCreateBin(app.project.rootItem, 'Fast Edit \u00b7 Speed ramp'); }
        var ns = app.project.createNewSequenceFromClips('Speed ramp \u00b7 ' + cname, [pi], bin);
        if (!ns) { fe_err('Não consegui criar a sequência da rampa.'); }
        try { ns.setSettings(seq.getSettings()); } catch (eS0) {}
        app.project.openSequence(ns.sequenceID);
        ns = app.project.activeSequence;
        var tt, cc;
        for (tt = 0; tt < ns.videoTracks.numTracks; tt++) { for (cc = ns.videoTracks[tt].clips.numItems - 1; cc >= 0; cc--) { ns.videoTracks[tt].clips[cc].remove(false, false); } }
        for (tt = 0; tt < ns.audioTracks.numTracks; tt++) { for (cc = ns.audioTracks[tt].clips.numItems - 1; cc >= 0; cc--) { ns.audioTracks[tt].clips[cc].remove(false, false); } }
        var nqs = fe_qeSeq(), src = I, T, nc, qi, sl;
        for (k = 0; k < segs.length; k++) {
            T = segs[k].f * fd; sp = segs[k].s; sl = segs[k].d * fd * sp;
            nc = fe_placeRange(ns, 0, pi, T, src, Math.min(sl, segs[k].d * fd));
            if (!nc) { src += sl; continue; }
            if (Math.abs(sp - 1) > 0.01) {
                qi = fe_qeItem(nqs, true, 0, nc);
                if (qi) { try { qi.setSpeed(sp, '', false, false, false); } catch (eS) {} }
                nc = fe_clipAt(ns.videoTracks[0], T, fd * 0.75) || nc;
            }
            try { nc.end = fe_time(T + segs[k].d * fd); } catch (eE) {}
            var md = fe_comp(nc, 'AE.ADBE Motion');
            if (md && mv.length) { for (q = 0; q < md.properties.numItems && q < mv.length; q++) { if (mv[q] !== null) { try { md.properties[q].setValue(mv[q], true); } catch (eW) {} } } }
            src += sl;
        }
        for (tt = 0; tt < ns.audioTracks.numTracks; tt++) { for (cc = ns.audioTracks[tt].clips.numItems - 1; cc >= 0; cc--) { ns.audioTracks[tt].clips[cc].remove(false, false); } }
        /* volta para a sequência principal e põe a rampa no lugar do take */
        app.project.openSequence(mainId);
        seq = app.project.activeSequence;
        var snapA = fe_audioSnapshot(seq);
        var nest = fe_place(seq, seq.videoTracks[t], ns.projectItem, S, nF * fd);
        fe_dropNewAudio(seq, snapA);
        if (nest) { try { nest.name = 'Speed ramp \u00b7 ' + cname; } catch (eN) {} }
        done++;
    }
    if (!done) { fe_err('Selecione takes com pelo menos ' + (step * 3) + ' frames.'); }
    return { done: done, clipped: clipped };
};

/* ------------------------------------------------------------------ Transição prisma (camada de ajuste no corte) */
function fe_pfind(comp, rx, idx) {
    var p = fe_param(comp, rx);
    if (!p && comp && idx !== undefined && idx < comp.properties.numItems) { p = comp.properties[idx]; }
    return p;
}
function fe_bake(p, t0, n, fd, fn) {
    var times = [], vals = [], i;
    if (!p) { return 0; }
    for (i = 0; i <= n; i++) { times.push(t0 + i * fd); vals.push(fn(i / n)); }
    return fe_tbKeys(p, times, vals);
}
function fe_ease(u) { return u < 0.5 ? 16 * Math.pow(u, 5) : 1 - Math.pow(-2 * u + 2, 5) / 2; }
var FE_PRISM = {
    h: { dx: 1, dy: 0, ang: 90, warp: 1, zoom: 0 },
    v: { dx: 0, dy: 1, ang: 0, warp: 1, zoom: 0 },
    d: { dx: 1, dy: 1, ang: 135, warp: 1, zoom: 0 },
    twist: { dx: 0, dy: 0, ang: 30, warp: 1.8, zoom: 0.12 },
    zoom: { dx: 0, dy: 0, ang: 0, warp: 1.2, zoom: 0.45 }
};
FE_API.prismTransition = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), st = FE_PRISM[a.style] || FE_PRISM.h, I = a.intensity || 1;
    var nF = Math.max(6, Math.round(a.frames || 16)), D = nF * fd;
    var sel = fe_selected(seq, 'video'), cuts = [], i, j, top = 0;
    for (i = 0; i < sel.length; i++) {
        if (sel[i].track > top) { top = sel[i].track; }
        for (j = 0; j < sel.length; j++) {
            if (i !== j && sel[i].track === sel[j].track && Math.abs(sel[i].end - sel[j].start) < fd * 0.6) { cuts.push(sel[j].start); }
        }
    }
    if (!cuts.length) { cuts.push(Math.round(seq.getPlayerPosition().seconds / fd) * fd); }
    var adj = fe_ensureAdjustment(a.nodeId, a.template);
    if (!adj) { fe_err('Não encontrei uma camada de ajuste no projeto.'); }
    var done = 0, missing = {}, k;
    for (k = 0; k < cuts.length; k++) {
        var T = Math.round(cuts[k] / fd) * fd, t0 = Math.max(0, T - Math.floor(nF / 2) * fd);
        var ti = fe_freeVideoTrack(seq, top + 1, t0, t0 + D);
        var clip = fe_place(seq, seq.videoTracks[ti], adj, t0, D);
        if (!clip) { continue; }
        try { clip.name = 'Prisma'; } catch (eN) {}
        var m0 = clip.inPoint.seconds, cu = (T - t0) / D;
        var bell = function (u) { var x = Math.sin(Math.PI * Math.min(1, Math.max(0, u * 0.5 / cu))); return x * x; };
        if (cu !== 0.5) { bell = function (u) { var w = u < cu ? u / cu * 0.5 : 0.5 + (u - cu) / (1 - cu) * 0.5, x = Math.sin(Math.PI * w); return x * x; }; }
        var r, c, p, ctx;
        /* 1. distorção líquida */
        r = fe_addFx(seq, ti, clip, 'Turbulent Displace');
        if (r && r.comp) {
            clip = r.clip; c = r.comp;
            p = fe_pfind(c, /^(size|tamanho)$/i, 2); if (p) { try { p.setValue(150 + 60 * st.warp, true); } catch (e1) {} }
            p = fe_pfind(c, /complex/i, 4); if (p) { try { p.setValue(1.5, true); } catch (e2) {} }
            fe_bake(fe_pfind(c, /^(amount|quantidade)$/i, 1), m0, nF, fd, function (u) { return 170 * I * st.warp * bell(u); });
            fe_bake(fe_pfind(c, /evolu/i, 5), m0, nF, fd, function (u) { return 160 * u; });
        } else { missing['Turbulent Displace'] = 1; }
        /* 2. deslize com repetição da borda (o take A sai, o B entra) */
        if (st.dx || st.dy) {
            r = fe_addFx(seq, ti, clip, 'Offset');
            if (r && r.comp) {
                clip = r.clip; c = r.comp;
                p = fe_pfind(c, /shift|deslocar|centro/i, 0);
                if (p) {
                    ctx = fe_ctxFor(seq, p.getValue(), 1);
                    fe_bake(p, m0, nF, fd, function (u) { var e = fe_ease(u); return [(0.5 + st.dx * e) * ctx.ux, (0.5 + st.dy * e) * ctx.uy]; });
                }
            } else { missing.Offset = 1; }
        }
        /* 3. zoom (estilos torção e zoom) */
        if (st.zoom) {
            r = fe_addFx(seq, ti, clip, 'Transform');
            if (r && r.comp) {
                clip = r.clip; c = r.comp;
                fe_bake(fe_tfScale(c), m0, nF, fd, function (u) { return 100 * (1 + st.zoom * I * bell(u)); });
                if (a.style === 'twist') { fe_bake(fe_pfind(c, /rota/i, 6), m0, nF, fd, function (u) { return 18 * I * (fe_ease(u) - 0.5) * 2 * bell(u); }); }
            }
        }
        /* 4. rastro na direção do movimento */
        r = fe_addFx(seq, ti, clip, 'Directional Blur');
        if (r && r.comp) {
            clip = r.clip; c = r.comp;
            var dirP = fe_param(c, /^(angle|[aâ]ngulo|direction|dire[cç][aã]o)$/i), lenP = fe_param(c, /^(blur length|comprimento do desfoque)$/i), amtP = fe_param(c, /^(amount|quantidade)$/i);
            if (dirP) { try { dirP.setValue(st.ang, true); } catch (e3) {} }
            if (lenP) { fe_bake(lenP, m0, nF, fd, function (u) { return 140 * I * bell(u); }); }
            else if (amtP) { fe_bake(amtP, m0, nF, fd, function (u) { return 70 * I * bell(u); }); }
            var chP = fe_param(c, /chromatic|crom[aá]tica/i);
            if (chP) { fe_bake(chP, m0, nF, fd, function (u) { return 60 * I * bell(u); }); }
        } else { missing['Directional Blur'] = 1; }
        /* 5. clarão no corte */
        if (a.flash !== false) {
            r = fe_addFx(seq, ti, clip, 'Brightness & Contrast');
            if (r && r.comp) {
                clip = r.clip; c = r.comp;
                fe_bake(fe_pfind(c, /bright|brilho/i, 0), m0, nF, fd, function (u) { var d = Math.abs(u - cu) * nF; return d > 3 ? 0 : 75 * (1 - d / 3.2); });
            }
        }
        done++;
    }
    var miss = [], q; for (q in missing) { if (missing.hasOwnProperty(q)) { miss.push(q); } }
    return { cuts: done, missing: miss };
};

/* ------------------------------------------------------------------ Match cut */
function fe_findClipNode(seq, id) {
    var t, c, tr;
    for (t = 0; t < seq.videoTracks.numTracks; t++) {
        tr = seq.videoTracks[t];
        for (c = 0; c < tr.clips.numItems; c++) { if (tr.clips[c].nodeId === id) { return { clip: tr.clips[c], track: t }; } }
    }
    return null;
}
function fe_copyMotion(src, dst) {
    var ms = fe_comp(src, 'AE.ADBE Motion'), md = fe_comp(dst, 'AE.ADBE Motion'), q;
    if (!ms || !md) { return; }
    for (q = 0; q < ms.properties.numItems && q < md.properties.numItems; q++) {
        try { md.properties[q].setValue(fe_baseVal(ms.properties[q], src.inPoint.seconds), true); } catch (em) {}
    }
}
/* lê os takes selecionados e exporta o primeiro frame de cada um (para achar o assunto) */
FE_API.matchRead = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), qs = fe_qeSeq();
    var sel = fe_requireSel(seq, 'video'), out = [], seen = {}, i, s, path, f, tc, ok;
    var cti = seq.getPlayerPosition().ticks;
    try { var fo = new Folder(a.dir); if (!fo.exists) { fo.create(); } } catch (eF) {}
    for (i = 0; i < sel.length && out.length < 40; i++) {
        s = sel[i];
        if (seen[s.clip.nodeId] || !s.clip.projectItem) { continue; }
        seen[s.clip.nodeId] = true;
        path = a.dir + '/mc_' + out.length + '_' + (new Date().getTime() % 100000) + '.png';
        f = new File(path);
        try { if (f.exists) { f.remove(); } } catch (e0) {}
        ok = false;
        try {
            seq.setPlayerPosition(String(Math.round((Math.round(s.start / fd) + 0.5) * fd * FE_TPS)));
            tc = qs.CTI.timecode;
            path = fe_exportPNG(qs, tc, path); ok = true;
        } catch (e1) {}
        out.push({ id: s.clip.nodeId, name: s.clip.name, track: s.track, start: s.start, dur: s.end - s.start, png: ok ? path : '' });
    }
    try { seq.setPlayerPosition(cti); } catch (e2) {}
    if (out.length < 2) { fe_err('Selecione 2 ou mais takes de vídeo na timeline.'); }
    return { takes: out, w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, fps: 1 / fd, at: seq.getPlayerPosition().seconds, markers: FE_API.markerTimes() };
};
/* monta o match cut no cursor: cuts = [{id, frames, k, c:[x,y], t:[x,y]}] (c e t de 0 a 1) */
FE_API.matchCut = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), cuts = a.cuts || [], i, total = 0;
    if (cuts.length < 2) { fe_err('Leia os takes primeiro.'); }
    for (i = 0; i < cuts.length; i++) { total += Math.max(1, cuts[i].frames) * fd; }
    var T0 = Math.round(seq.getPlayerPosition().seconds / fd) * fd, T = T0;
    var trackIdx = fe_freeVideoTrack(seq, a.track || 0, T0, T0 + total);
    var used = {}, placed = 0, tooShort = 0, cut, src, dur, srcIn, clip, P, sP, k, s0, p0, ctx, nx, ny, avail;
    for (i = 0; i < cuts.length; i++) {
        cut = cuts[i]; dur = Math.max(1, cut.frames) * fd;
        src = fe_findClipNode(seq, cut.id);
        if (!src || !src.clip.projectItem) { T += dur; continue; }
        srcIn = src.clip.inPoint.seconds + (used[cut.id] || 0);
        avail = src.clip.end.seconds - src.clip.start.seconds - (used[cut.id] || 0);
        if (avail < dur - fd * 0.5) { srcIn = src.clip.inPoint.seconds; if (src.clip.end.seconds - src.clip.start.seconds < dur) { tooShort++; } }
        used[cut.id] = (srcIn - src.clip.inPoint.seconds) + dur;
        clip = fe_placeRange(seq, trackIdx, src.clip.projectItem, T, srcIn, dur);
        if (clip) {
            placed++;
            fe_copyMotion(src.clip, clip);
            if (cut.k && cut.c && cut.t) {
                P = fe_params(clip);
                k = cut.k;
                if (P.scale) { s0 = fe_baseVal(P.scale, clip.inPoint.seconds); try { P.scale.setValue(s0 * k, true); } catch (e1) {} }
                if (P.pos) {
                    p0 = fe_baseVal(P.pos, clip.inPoint.seconds);
                    ctx = fe_ctxFor(seq, p0, 1);
                    nx = cut.t[0] - k * (cut.c[0] - p0[0] / ctx.ux);
                    ny = cut.t[1] - k * (cut.c[1] - p0[1] / ctx.uy);
                    try { P.pos.setValue([nx * ctx.ux, ny * ctx.uy], true); } catch (e2) {}
                }
            }
        }
        T += dur;
    }
    return { placed: placed, start: T0, end: T, track: trackIdx + 1, tooShort: tooShort };
};

/* ------------------------------------------------------------------ Despachante */
$._FE = {
    version: '2.28.7',
    run: function (name, argStr) {
        var J = $._FEJSON;
        try {
            var fn = FE_API[name];
            if (!fn) { return J.stringify({ ok: false, error: 'Função desconhecida: ' + name }); }
            var args = argStr ? J.parse(argStr) : {};
            var data = fn(args || {});
            return J.stringify({ ok: true, data: data === undefined ? null : data });
        } catch (e) {
            return J.stringify({ ok: false, error: String(e && e.message ? e.message : e), line: e && e.line ? e.line : null });
        }
    }
};

'FastEdit host ready';

/* ------------------------------------------------------------------ Zoom nos takes (camada de ajuste + Transformar em cada take) */
function fe_zEase(kind, u) {
    u = Math.max(0, Math.min(1, u));
    if (kind === 'linear') { return u; }
    if (kind === 'fast') { return 1 - Math.pow(1 - u, 4); }
    if (kind === 'slow') { return u * u * u; }
    return u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2;
}
/* poucos keyframes (início e fim, ou início/meio/fim no pulso), fáceis de editar depois.
   A suavidade vem da interpolação do próprio Premiere (Bézier), não de um ponto por quadro. */
function fe_zKeys(p, m0, dur, fd, fn, us, ease) {
    if (!p) { return 0; }
    us = us || [0, 1];
    var n = Math.max(1, Math.round(dur / fd)), i, t, interp = ease === 'linear' ? 0 : 5;
    try { p.setTimeVarying(true); } catch (e) { return 0; }
    try { p.removeKeyRange(m0 - 0.001, m0 + n * fd + 0.001, true); } catch (e1) {}
    for (i = 0; i < us.length; i++) {
        t = m0 + Math.round(us[i] * n) * fd;
        try { p.addKey(t); p.setValueAtKey(t, fn(us[i]), i === us.length - 1); } catch (e2) {}
        try { p.setInterpolationTypeAtKey(t, interp, false); } catch (e3) {}
    }
    return us.length;
}
/* camadas próprias de zoom in / zoom out, com a cor (rótulo) que o editor usa */
function fe_userLabel(rx) {
    var found = -1;
    var walk = function (b, d) {
        var i, it;
        if (d > 8 || found >= 0) { return; }
        for (i = 0; i < b.children.numItems && found < 0; i++) {
            it = b.children[i];
            if (!it) { continue; }
            if (it.type === ProjectItemType.BIN) { walk(it, d + 1); continue; }
            if (/^Fast Edit Zoom/i.test(it.name)) { continue; }
            try { if (rx.test(it.name) && it.isAdjustmentLayer()) { found = it.getColorLabel(); } } catch (e) {}
        }
    };
    walk(app.project.rootItem, 0);
    return found;
}
function fe_zoomAdj(kind, tplDir, label) {
    var szm = String(tplDir).match(/sized[\\\/](\d+x\d+)$/);
    var name = (kind === 'out' ? 'Fast Edit Zoom out' : 'Fast Edit Zoom in') + (szm ? ' (' + szm[1] + ')' : '');
    var bin = fe_getOrCreateBin(app.project.rootItem, FE_BIN_MAIN), it = fe_findByName(bin, name, 0), tries = 0;
    if (!it) {
        var f = new File(tplDir + (kind === 'out' ? '/FE_ZoomOut.prproj' : '/FE_ZoomIn.prproj'));
        if (!f.exists) { return null; }
        try { app.project.importFiles([f.fsName], true, bin, false); } catch (e) {}
        it = fe_findByName(bin, name, 0);
        while (!it && tries < 15) { $.sleep(200); tries++; it = fe_findByName(bin, name, 0); }
        if (it) { try { it.moveBin(bin); } catch (e2) {} }
    }
    if (it && label >= 0) { try { if (it.getColorLabel() !== label) { it.setColorLabel(label); } } catch (e3) {} }
    return it;
}
FE_API.zoomTakes = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), sel = fe_selected(seq, 'video'), list = [], i, j;
    if (a.scope === 'track') {
        var tracks = {}, nT = 0;
        for (i = 0; i < sel.length; i++) { if (!tracks[sel[i].track]) { tracks[sel[i].track] = 1; nT++; } }
        if (!nT) { tracks[0] = 1; }
        for (var t in tracks) {
            if (!tracks.hasOwnProperty(t)) { continue; }
            var tr = seq.videoTracks[+t];
            for (j = 0; j < tr.clips.numItems; j++) { var c0 = tr.clips[j]; list.push({ clip: c0, track: +t, start: c0.start.seconds, end: c0.end.seconds }); }
        }
        list.sort(function (x, y) { return x.start - y.start; });
    } else {
        list = sel;
    }
    if (!list.length) { fe_err('Selecione os takes na timeline (ou escolha "Todos da trilha").'); }
    var adj = fe_ensureAdjustment(a.nodeId, a.template), adjIn = null, adjOut = null, labIn = -1, labOut = -1;
    if (a.colorize !== false && a.template) {
        var tdir = a.template.replace(/[\\\/][^\\\/]*$/, '');
        labIn = fe_userLabel(/zoom\s*in/i); labOut = fe_userLabel(/zoom\s*out/i);
        if (labIn < 0) { labIn = a.labelIn >= 0 ? a.labelIn : 14; }
        if (labOut < 0) { labOut = a.labelOut >= 0 ? a.labelOut : 15; }
        adjIn = fe_zoomAdj('in', tdir, labIn); adjOut = fe_zoomAdj('out', tdir, labOut);
    }
    if (!adj && !adjIn) { fe_err('Não encontrei uma camada de ajuste no projeto.'); }
    var zs = a.zooms && a.zooms.length ? a.zooms : [10], every = Math.max(1, a.every || 1), off = a.offset || 0;
    var motion = a.motion || 'static', ease = a.ease || 'smooth', top = 0, done = 0, picked = 0, k;
    for (i = 0; i < list.length; i++) { if (list[i].track > top) { top = list[i].track; } }
    for (k = 0; k < list.length; k++) {
        var it = list[k];
        if (a.pattern === 'alt' && (k + off) % 2 !== 0) { continue; }
        if (a.pattern === 'every' && (k + off) % every !== 0) { continue; }
        var s0 = Math.round(it.start / fd) * fd, D = Math.round((it.end - it.start) / fd) * fd;
        if (D < fd * 2) { continue; }
        var z = a.order === 'random' ? zs[Math.floor(Math.random() * zs.length)] : zs[picked % zs.length];
        var mo = motion;
        if (motion === 'alt') { mo = picked % 2 === 0 ? 'in' : 'out'; }
        if (motion === 'altpunch') { mo = picked % 2 === 0 ? 'punch' : 'static'; }
        picked++;
        var ti = fe_freeVideoTrack(seq, top + 1, s0, s0 + D);
        var src = (mo === 'out' ? adjOut : adjIn) || adj;
        var clip = fe_place(seq, seq.videoTracks[ti], src, s0, D);
        if (!clip) { continue; }
        try { clip.name = (mo === 'out' ? 'Zoom out ' : (mo === 'in' ? 'Zoom in ' : 'Zoom ')) + z + '%'; } catch (eN) {}
        var r = fe_addFx(seq, ti, clip, 'Transform');
        if (!r || !r.comp) { fe_err('Não encontrei o efeito Transformar (Transform) no Premiere.'); }
        clip = r.clip;
        var cp = r.comp, m0 = clip.inPoint.seconds, Z = 100 + z;
        var sc = fe_tfScale(cp);
        var an = a.animFrames > 0 ? Math.min(D, a.animFrames * fd) : D;
        var e = function (u) { return fe_zEase(ease, u); };
        if (mo === 'static') { try { sc.setValue(Z, true); } catch (e1) {} }
        else if (mo === 'in') { fe_zKeys(sc, m0, an, fd, function (u) { return 100 + z * u; }, [0, 1], ease); }
        else if (mo === 'out') { fe_zKeys(sc, m0 + (a.outAtEnd ? D - an : 0), an, fd, function (u) { return Z - z * u; }, [0, 1], ease); if (a.outAtEnd) { try { sc.addKey(m0); sc.setValueAtKey(m0, Z, true); } catch (e2) {} } }
        else if (mo === 'pulse') { fe_zKeys(sc, m0, an, fd, function (u) { return 100 + z * Math.sin(Math.PI * u); }, [0, 0.5, 1], ease); }
        else if (mo === 'punch') { fe_zKeys(sc, m0, Math.min(an, 3 * fd), fd, function (u) { return 100 + z * u; }, [0, 1], 'fast'); }
        /* deslocamento suave (Ken Burns) */
        if (a.drift && a.drift !== 'none') {
            var pp = fe_param(cp, /^(position|posi[cç][aã]o)$/i) || cp.properties[1];
            if (pp) {
                var b = pp.getValue(), ctx = fe_ctxFor(seq, b, 1), amt = (a.driftAmt || 4) / 100, dirs = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
                var dname = a.drift === 'random' ? ['left', 'right', 'up', 'down'][Math.floor(Math.random() * 4)] : (a.drift === 'altlr' ? (picked % 2 ? 'left' : 'right') : a.drift);
                var dv = dirs[dname] || [0, 0];
                fe_zKeys(pp, m0, D, fd, function (u) { var q = u - 0.5; return [b[0] + dv[0] * amt * q * ctx.ux, b[1] + dv[1] * amt * q * ctx.uy]; }, [0, 1], 'linear');
            }
        }
        /* desfoque de movimento do próprio Transformar */
        if (a.blur) {
            var comp = fe_param(cp, /composition|composi[cç][aã]o/i), sh = fe_param(cp, /shutter angle|[aâ]ngulo do obturador/i);
            if (comp) { try { comp.setValue(false, true); } catch (e3) {} }
            if (sh) { try { sh.setValue(a.shutter || 180, true); } catch (e4) {} }
        }
        done++;
    }
    if (!done) { fe_err('Nenhum take recebeu zoom: confira o padrão escolhido.'); }
    return { done: done, labelIn: labIn, labelOut: labOut };
};

/* ------------------------------------------------------------------ Vidro (lentes e prismas com efeitos nativos) */
var FE_GL_FX = {
    magnify: [/^magnify$/i, /^ampliar$/i],
    spherize: [/^spherize$/i, /^esferizar$/i],
    twirl: [/^twirl$/i, /^tor[cç][aã]o$/i],
    wave: [/^wave warp$/i, /^dobra de onda$|^distor[cç][aã]o de onda$/i],
    offset: [/^offset$/i, /^deslocamento$/i],
    replicate: [/^replicate$/i, /^replicar$/i],
    crop: [/^crop$/i, /^cortar$/i],
    dblur: [/^directional blur$/i, /^desfoque direcional$/i],
    gblur: [/^gaussian blur$/i, /^desfoque gaussiano$/i],
    bc: [/^brightness & contrast$/i, /^brilho e contraste$/i],
    transform: [/^transform$/i, /^transformar$/i],
    chroma: [/^vr chromatic aberrations$/i, /aberra[cç][oõ]es crom[aá]ticas/i],
    turb: [/^turbulent displace$/i, /deslocamento turbulento|deslocar turbulento/i],
    lens: [/^lens distortion$/i, /distor[cç][aã]o da lente|distor[cç][aã]o de lente/i]
};
function fe_gfx(seq, ti, clip, key) {
    var rx = FE_GL_FX[key], qs = fe_qeSeq(), qi = fe_qeItem(qs, true, ti, clip), eff = fe_findVideoEffect(rx[0], rx[1]), n;
    if (!qi || !eff) { return null; }
    var before = [], i;
    n = clip.components.numItems;
    for (i = 0; i < n; i++) { before.push(clip.components[i].matchName); }
    try { qi.addVideoEffect(eff); } catch (e) { return null; }
    clip = fe_refetch(seq, ti, clip);
    if (!clip || clip.components.numItems <= n) { return null; }
    /* o efeito novo pode entrar no fim ou logo abaixo do Movimento: acha onde a lista mudou */
    for (i = 0; i < clip.components.numItems; i++) { if (i >= n || clip.components[i].matchName !== before[i]) { return { clip: clip, comp: clip.components[i] }; } }
    return { clip: clip, comp: clip.components[clip.components.numItems - 1] };
}
/* valor de ponto: normalizado (0..1) ou em pixels, igual ao que o parâmetro já usa */
function fe_gpt(p, W, H) {
    var v = null;
    try { v = p.getValue(); } catch (e) {}
    var px = v && (Math.abs(v[0]) > 2 || Math.abs(v[1]) > 2);
    return function (x, y) { return px ? [x * W, y * H] : [x, y]; };
}
FE_API.glass = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    var sel = fe_selected(seq, 'video'), i, t0 = 1e9, t1 = -1, top = 0;
    for (i = 0; i < sel.length; i++) { if (sel[i].start < t0) { t0 = sel[i].start; } if (sel[i].end > t1) { t1 = sel[i].end; } if (sel[i].track > top) { top = sel[i].track; } }
    if (!sel.length) { t0 = seq.getPlayerPosition().seconds; t1 = t0 + 3; }
    t0 = Math.round(t0 / fd) * fd; var D = Math.max(fd * 2, Math.round((t1 - t0) / fd) * fd);
    var adj = fe_ensureAdjustment(a.nodeId, a.template);
    if (!adj) { fe_err('Não encontrei uma camada de ajuste no projeto.'); }
    var look = a.look || 'lupa', S = a.strength === undefined ? 1 : a.strength, X = a.x === undefined ? 0.5 : a.x, Y = a.y === undefined ? 0.5 : a.y;
    var SZ = a.size || 0.5, R = SZ * H / 2, CH = a.chroma || 0, SOFT = a.soft || 0, LT = a.light || 0, anim = a.anim || 'none';
    var missing = {}, layers = look === 'eco' ? (S < 0.8 ? 1 : (S < 1.5 ? 2 : 3)) : 1, L, made = 0;
    var NK = anim === 'none' ? 0 : Math.max(2, Math.min(40, Math.round(D / fd / 2)));
    var stAt = function (u) {
        var x = X, k = 1;
        if (anim === 'slide') { x = X + (u - 0.5) * 0.5; }
        if (anim === 'pulse') { k = Math.sin(Math.PI * u); }
        if (anim === 'in') { k = Math.min(1, u * 4); }
        return { x: x, y: Y, k: k };
    };
    for (L = 0; L < layers; L++) {
        var ti = fe_freeVideoTrack(seq, top + 1, t0, t0 + D);
        var clip = fe_place(seq, seq.videoTracks[ti], adj, t0, D);
        if (!clip) { continue; }
        top = ti;
        try { clip.name = 'Vidro ' + (a.lookName || look) + (layers > 1 ? ' ' + (L + 1) : ''); } catch (eN) {}
        var m0 = clip.inPoint.seconds, drv = [], c, p;
        var add = function (key) { var rr = fe_gfx(seq, ti, clip, key); if (!rr) { missing[key] = 1; return null; } clip = rr.clip; return rr.comp; };
        var drive = function (prm, fn) { if (prm) { drv.push([prm, fn]); } };
        var P = function (comp, rx, idx) { return fe_pfind(comp, rx, idx); };
        var ptd = function (prm, gx) { if (!prm) { return; } var ff = fe_gpt(prm, W, H); drv.push([prm, function (s) { var g = gx(s); return ff(g[0], g[1]); }]); };
        if (look === 'lupa') {
            c = add('magnify');
            if (c) {
                ptd(P(c, /^(center|centro)$/i, 1), function (s) { return [s.x, s.y]; });
                drive(P(c, /magnifica|amplia/i, 2), function (s) { return 100 + 110 * S * s.k; });
                p = P(c, /^(size|tamanho)$/i, 4); if (p) { try { p.setValue(R, true); } catch (e1) {} }
                p = P(c, /feather|difus|suaviz/i, 5); if (p) { try { p.setValue(R * 0.12, true); } catch (e2) {} }
            }
        } else if (look === 'anel' || look === 'redemoinho') {
            c = add('twirl');
            if (c) {
                drive(P(c, /^(angle|[aâ]ngulo)$/i, 0), function (s) { return (look === 'anel' ? 70 : 260) * S * s.k; });
                p = P(c, /radius|raio/i, 1); if (p) { try { p.setValue(Math.min(100, SZ * (look === 'anel' ? 45 : 70)), true); } catch (e3) {} }
                ptd(P(c, /center|centro/i, 2), function (s) { return [s.x, s.y]; });
            }
            c = add('spherize');
            if (c) {
                drive(P(c, /radius|raio/i, 0), function (s) { return Math.max(1, R * (look === 'anel' ? 1 : 0.8) * (0.4 + 0.6 * s.k)); });
                ptd(P(c, /center|centro/i, 1), function (s) { return [s.x, s.y]; });
            }
        } else if (look === 'mosaico') {
            c = add('replicate');
            if (c) { p = P(c, /count|contagem|quantidade/i, 0); if (p) { try { p.setValue(S < 0.7 ? 2 : (S < 1.2 ? 3 : 4), true); } catch (e4) {} } }
            c = add('spherize');
            if (c) {
                p = P(c, /radius|raio/i, 0); if (p) { try { p.setValue(R * 1.1, true); } catch (e5) {} }
                ptd(P(c, /center|centro/i, 1), function (s) { return [s.x, s.y]; });
            }
        } else if (look === 'bloco' || look === 'canelado') {
            if (look === 'bloco') {
                c = add('offset');
                if (c) { ptd(P(c, /shift|deslocar|centro/i, 0), function (s) { return [0.5 + 0.22 * S * s.k, 0.5]; }); }
            }
            c = add('wave');
            if (c) {
                p = P(c, /wave type|tipo de onda/i, 0); if (p && look === 'canelado') { try { p.setValue(4, true); } catch (e6) {} }
                drive(P(c, /wave height|altura/i, 1), function (s) { return (look === 'canelado' ? 40 : 25) * S * s.k; });
                p = P(c, /wave width|largura/i, 2); if (p) { try { p.setValue(Math.max(16, look === 'canelado' ? W * 0.035 : R * 0.5), true); } catch (e7) {} }
                p = P(c, /direction|dire[cç][aã]o/i, 3); if (p) { try { p.setValue(90, true); } catch (e8) {} }
                p = P(c, /speed|velocidade/i, 4); if (p) { try { p.setValue(0, true); } catch (e9) {} }
                p = P(c, /antialias|suaviza/i, 7); if (p) { try { p.setValue(0, true); } catch (e10) {} }
            }
        } else if (look === 'arrasto') {
            c = add('dblur');
            if (c) {
                p = P(c, /^(direction|dire[cç][aã]o|angle|[aâ]ngulo)$/i, 0); if (p) { try { p.setValue(90, true); } catch (e11) {} }
                var bl = fe_param(c, /length|comprimento/i);
                if (bl) { drive(bl, function (s) { return 30 + 140 * S * s.k; }); }
                else { drive(fe_param(c, /^(amount|quantidade)$/i), function (s) { return 25 + 45 * S * s.k; }); }
            }
        } else if (look === 'eco') {
            c = add('transform');
            if (c) {
                var dx = 0.06 * S * Math.pow(2, L) * (X < 0.5 ? -1 : 1);
                ptd(P(c, /^(position|posi[cç][aã]o)$/i, 1), function (s) { return [0.5 + dx * s.k, 0.5]; });
            }
            var op = fe_comp(clip, 'AE.ADBE Opacity');
            if (op && op.properties.numItems) { try { op.properties[0].setValue(50, true); } catch (e12) {} }
        }
        /* separação de cor, desfoque e brilho (no último layer do eco) */
        if (L === layers - 1 || look !== 'eco') {
            if (CH > 0 || look === 'rgb') {
                c = add('chroma');
                if (c) {
                    var amt = (look === 'rgb' ? Math.max(CH, 0.3) * (0.5 + S) : CH) * 10;
                    drive(P(c, /red|vermelh/i, 1), function (s) { return amt * s.k; });
                    drive(P(c, /blue|azul/i, 3), function (s) { return -amt * s.k; });
                }
            }
            var cropL = look === 'mosaico' || look === 'bloco' || look === 'arrasto' || (look === 'canelado' && SZ < 0.95);
            if (SOFT > 0 && (cropL || look === 'lupa')) { c = add('gblur'); if (c) { p = fe_param(c, /blurriness|desfoque|intensidade/i); if (p) { try { p.setValue(SOFT * 25, true); } catch (e13) {} } else { p = fe_param(c, /^(amount|quantidade)$/i); if (p) { try { p.setValue(SOFT * 20, true); } catch (e13b) {} } } } }
            if (LT > 0 && cropL) { c = add('bc'); if (c) { p = P(c, /bright|brilho/i, 0); if (p) { try { p.setValue(LT * 35, true); } catch (e14) {} } } }
        }
        /* recorte: o vidro só aparece dentro da área */
        var crop = null;
        if (look === 'mosaico' || look === 'bloco' || look === 'arrasto' || (look === 'canelado' && SZ < 0.95)) {
            c = add('crop');
            if (c) {
                var cl = P(c, /^left|esquerd/i, 0), ct = P(c, /^top|superior/i, 1), cr = P(c, /^right|direit/i, 2), cb = P(c, /^bottom|inferior/i, 3);
                var hw = look === 'arrasto' ? 0 : (look === 'canelado' ? R * 1.6 : R) / W, hh = (look === 'bloco' ? R * 1.2 : R) / H;
                if (look === 'arrasto') {
                    drive(cr, function (s) { return Math.max(0, Math.min(100, (1 - s.x) * 100)); });
                } else {
                    drive(cl, function (s) { return Math.max(0, (s.x - hw) * 100); });
                    drive(cr, function (s) { return Math.max(0, (1 - s.x - hw) * 100); });
                    if (ct) { try { ct.setValue(Math.max(0, (Y - hh) * 100), true); } catch (e15) {} }
                    if (cb) { try { cb.setValue(Math.max(0, (1 - Y - hh) * 100), true); } catch (e16) {} }
                }
                p = P(c, /feather|difus|suaviz/i, 5); if (p) { try { p.setValue(Math.round(R * (look === 'arrasto' ? 0.5 : 0.08)), true); } catch (e17) {} }
            }
        }
        /* aplica valores (parado) ou keyframes (animado) */
        var j, q;
        for (j = 0; j < drv.length; j++) {
            if (!NK) { try { drv[j][0].setValue(drv[j][1](stAt(0.5)), true); } catch (eV) {} continue; }
            var times = [], vals = [];
            for (q = 0; q <= NK; q++) { times.push(m0 + D * q / NK); vals.push(drv[j][1](stAt(q / NK))); }
            fe_tbKeys(drv[j][0], times, vals);
        }
        made++;
    }
    if (!made) { fe_err('Não consegui criar a camada de vidro.'); }
    var miss = [], mk; for (mk in missing) { if (missing.hasOwnProperty(mk)) { miss.push(mk); } }
    return { layers: made, missing: miss, sec: D };
};
/* teste do caminho "renderizar": de onde vem a mídia do take selecionado */
FE_API.glassProbe = function () {
    var seq = fe_seq(), sel = fe_selected(seq, 'video'), out = { w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, fd: fe_frameDur(seq), path: '', inSec: 0, name: '' };
    if (sel.length && sel[0].clip.projectItem) {
        try { out.path = sel[0].clip.projectItem.getMediaPath(); } catch (e) {}
        out.inSec = sel[0].clip.inPoint.seconds; out.name = sel[0].clip.name;
    }
    return out;
};

/* ------------------------------------------------------------------ Vidro real (render quadro a quadro pelo painel) */
FE_API.glassBegin = function () {
    var seq = fe_seq(), fd = fe_frameDur(seq), sel = fe_selected(seq, 'video'), i, t0 = 1e9, t1 = -1, top = 0;
    for (i = 0; i < sel.length; i++) { if (sel[i].start < t0) { t0 = sel[i].start; } if (sel[i].end > t1) { t1 = sel[i].end; } if (sel[i].track > top) { top = sel[i].track; } }
    if (!sel.length) { t0 = seq.getPlayerPosition().seconds; t1 = t0 + 3; }
    var f0 = Math.round(t0 / fd), n = Math.max(2, Math.round((t1 - t0) / fd));
    if (n > 1800) { fe_err('Trecho longo demais para o vidro (máx. 1 minuto). Selecione um pedaço menor.'); }
    return { f0: f0, n: n, fd: fd, w: seq.frameSizeHorizontal, h: seq.frameSizeVertical, top: top, cti: seq.getPlayerPosition().ticks, seq: seq.sequenceID };
};
/* exporta os quadros f0+from .. f0+from+count-1 como PNG (prefixo + número) */
FE_API.glassFrames = function (a) {
    var seq = fe_seq(), qs = fe_qeSeq(), fr = seq.getSettings().videoFrameRate, out = [], k, tc;
    for (k = 0; k < a.count; k++) {
        var idx = a.from + k, f = a.f0 + idx;
        seq.setPlayerPosition(String(f * fr.ticks));
        tc = qs.CTI.timecode;
        var p = a.prefix + ('0000' + idx).slice(-5);
        try { var old = new File(p + '.png'); if (old.exists) { old.remove(); } } catch (e0) {}
        qs.exportFramePNG(tc, new File(p).fsName);
        out.push(p + '.png');
    }
    return { paths: out };
};
FE_API.glassPlace = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq);
    try { if (a.cti) { seq.setPlayerPosition(a.cti); } } catch (eC) {}
    if (a.restoreOnly) { return { ok: true }; }
    var bin = fe_getOrCreateBin(fe_getOrCreateBin(app.project.rootItem, FE_BIN_MAIN), 'Vidro');
    var before = {}, i;
    for (i = 0; i < bin.children.numItems; i++) { before[bin.children[i].nodeId] = 1; }
    app.project.importFiles([new File(a.first).fsName], true, bin, true);
    var it = null, tries = 0;
    while (!it && tries < 25) {
        for (i = 0; i < bin.children.numItems; i++) { if (!before[bin.children[i].nodeId]) { it = bin.children[i]; } }
        if (!it) { $.sleep(200); tries++; }
    }
    if (!it) { fe_err('Não consegui importar os quadros do vidro.'); }
    try { it.name = a.name; } catch (eN) {}
    try { it.setOverrideFrameRate(1 / fd); } catch (eF) {}
    var t0 = a.f0 * fd, D = a.n * fd;
    var ti = fe_freeVideoTrack(seq, (a.top || 0) + 1, t0, t0 + D);
    var clip = fe_place(seq, seq.videoTracks[ti], it, t0, D);
    if (!clip) { fe_err('Não consegui colocar o vidro na timeline.'); }
    try { clip.name = a.name; } catch (eN2) {}
    return { track: ti + 1 };
};

/* ------------------------------------------------------------------ Vidro em camada de ajuste (efeitos do Premiere, sem render) */
FE_API.glassLayer = function (a) {
    var seq = fe_seq(), fd = fe_frameDur(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    var sel = fe_selected(seq, 'video'), i, t0 = 1e9, t1 = -1, top = 0;
    for (i = 0; i < sel.length; i++) { if (sel[i].start < t0) { t0 = sel[i].start; } if (sel[i].end > t1) { t1 = sel[i].end; } if (sel[i].track > top) { top = sel[i].track; } }
    if (!sel.length) { t0 = seq.getPlayerPosition().seconds; t1 = t0 + 3; }
    t0 = Math.round(t0 / fd) * fd; var D = Math.max(fd * 2, Math.round((t1 - t0) / fd) * fd);
    var adj = fe_ensureAdjustment(a.nodeId, a.template);
    if (!adj) { fe_err('Não encontrei uma camada de ajuste no projeto.'); }
    var look = a.look, S = a.strength === undefined ? 1 : a.strength, X = a.x === undefined ? 0.5 : a.x, Y = a.y === undefined ? 0.45 : a.y;
    var R = (a.size || 0.75) * Math.min(W, H) / 2, CH = a.chroma || 0, missing = {}, made = 0;
    var P = function (c, rx, idx) { return fe_pfind(c, rx, idx); };
    var set = function (p, v) { if (p) { try { p.setValue(v, true); } catch (e) {} } };
    var layer = function (nm, opac) {
        var ti = fe_freeVideoTrack(seq, top + 1, t0, t0 + D), clip = fe_place(seq, seq.videoTracks[ti], adj, t0, D);
        if (!clip) { return null; }
        top = ti; made++;
        try { clip.name = 'Vidro ' + (a.lookName || look) + (nm ? ' ' + nm : ''); } catch (eN) {}
        if (opac !== undefined) { var op = fe_comp(clip, 'AE.ADBE Opacity'); if (op) { set(op.properties[0], opac); } }
        return { ti: ti, clip: clip };
    };
    var fx = function (L, key) { var r = fe_gfx(seq, L.ti, L.clip, key); if (!r) { missing[key] = 1; return null; } L.clip = r.clip; return r.comp; };
    var pt = function (c, rx, idx, x, y) { var p = P(c, rx, idx); if (!p) { return; } var f = fe_gpt(p, W, H); set(p, f(x, y)); };
    var crop = function (L, l, tp, r, b, fe) {
        var c = fx(L, 'crop'); if (!c) { return; }
        set(P(c, /^left|esquerd/i, 0), l); set(P(c, /^top|superior/i, 1), tp); set(P(c, /^right|direit/i, 2), r); set(P(c, /^bottom|inferior/i, 3), b);
        set(P(c, /feather|difus|suaviz|borda/i, 5), fe || 0);
    };
    var chroma = function (L, amt) {
        if (amt <= 0) { return; }
        var c = fx(L, 'chroma'); if (!c) { return; }
        set(P(c, /red|vermelh/i, 1), amt * 10); set(P(c, /blue|azul/i, 3), -amt * 10);
    };
    var blur = function (L, v) { var c = fx(L, 'gblur'); if (!c) { return; } var p = fe_param(c, /blurriness|desfoque|intensidade/i) || fe_param(c, /^(amount|quantidade)$/i) || c.properties[0]; set(p, v); };
    var tf = function (L) { return fx(L, 'transform'); };
    var L, c, k;
    if (look === 'replicador') {
        var dx = R * 0.7 * S / W;
        L = layer('1', 42); c = tf(L); if (c) { pt(c, /^(position|posi[cç][aã]o)$/i, 1, 0.5 + dx, 0.5); }
        L = layer('2', 42); c = tf(L); if (c) { pt(c, /^(position|posi[cç][aã]o)$/i, 1, 0.5 - dx, 0.5); }
        chroma(L, CH);
    } else if (look === 'caleidoscopio' || look === 'colmeia' || look === 'icosfera') {
        L = layer();
        var n = look === 'caleidoscopio' ? 2 : (look === 'colmeia' ? 3 : 5);
        c = fx(L, 'replicate'); if (c) { set(P(c, /count|contagem|quantidade/i, 0), n); }
        c = tf(L); if (c) { var sc = fe_tfScale(c); set(sc, 100 + 25 * S); pt(c, /^(anchor|ponto de ancoragem|âncora|ancoragem)/i, 0, X, Y); pt(c, /^(position|posi[cç][aã]o)$/i, 1, X, Y); }
        chroma(L, CH);
    } else if (look === 'esticar') {
        L = layer();
        var ex = Math.min(0.95, X + R * 0.35 / W);
        c = tf(L);
        if (c) {
            var un = fe_param(c, /uniform|uniforme/i); set(un, false);
            pt(c, /^(anchor|ponto de ancoragem|âncora|ancoragem)/i, 0, ex, 0.5); pt(c, /^(position|posi[cç][aã]o)$/i, 1, ex, 0.5);
            set(fe_param(c, /scale width|largura/i), 100 + 250 * S);
        }
        c = fx(L, 'dblur'); if (c) { set(P(c, /^(direction|dire[cç][aã]o|angle|[aâ]ngulo)$/i, 0), 90); var bl = fe_param(c, /length|comprimento/i); if (bl) { set(bl, 30); } else { set(fe_param(c, /^(amount|quantidade)$/i), 20); } }
        crop(L, 0, 0, (1 - ex) * 100, 0, Math.round(R * 0.25));
    } else if (look === 'ondas') {
        L = layer();
        c = fx(L, 'wave'); if (c) { set(P(c, /wave height|altura/i, 1), 18 * S); set(P(c, /wave width|largura/i, 2), Math.max(40, R * 0.5)); set(P(c, /direction|dire[cç][aã]o/i, 3), 90); set(P(c, /speed|velocidade/i, 4), 0); set(P(c, /antialias|suaviza/i, 7), 0); }
        c = fx(L, 'wave'); if (c) { set(P(c, /wave height|altura/i, 1), 18 * S); set(P(c, /wave width|largura/i, 2), Math.max(40, R * 0.5)); set(P(c, /direction|dire[cç][aã]o/i, 3), 0); set(P(c, /speed|velocidade/i, 4), 0); set(P(c, /antialias|suaviza/i, 7), 0); }
        chroma(L, CH);
    } else if (look === 'ondulado') {
        L = layer();
        c = fx(L, 'turb'); if (c) { set(P(c, /^(amount|quantidade)$/i, 1), 35 * S); set(P(c, /^(size|tamanho)$/i, 2), 180); }
        blur(L, 6 * S);
        chroma(L, CH * 0.5);
    } else if (look === 'cone') {
        L = layer();
        c = fx(L, 'twirl'); if (c) { set(P(c, /^(angle|[aâ]ngulo)$/i, 0), 45 * S); set(P(c, /radius|raio/i, 1), 90); pt(c, /center|centro/i, 2, X, Y); }
        L = layer('borda', 70);
        c = tf(L); if (c) { var sc2 = fe_tfScale(c); set(sc2, 108); set(fe_param(c, /^(rotation|rota[cç][aã]o)$/i), 6 * S); }
        blur(L, 14 * S);
        chroma(L, CH);
    } else if (look === 'esferico') {
        L = layer();
        c = fx(L, 'lens'); if (c) { set(P(c, /curvature|curvatura/i, 0), -25 * S); }
        L = layer('borda', 55); blur(L, 18 * S);
    } else if (look === 'fantasma') {
        L = layer('', 45);
        c = tf(L); if (c) { set(fe_tfScale(c), 100 + 22 * S); pt(c, /^(anchor|ponto de ancoragem|âncora|ancoragem)/i, 0, X, Y); pt(c, /^(position|posi[cç][aã]o)$/i, 1, X, Y); }
        blur(L, 16);
        chroma(L, CH);
    } else if (look === 'foco') {
        L = layer('desfoque');
        blur(L, 22 * S);
        crop(L, X * 100, 0, 0, 0, Math.round(R * 0.4));
        L = layer('fantasma', 40);
        c = tf(L); if (c) { pt(c, /^(position|posi[cç][aã]o)$/i, 1, 0.5 + 0.08 * S, 0.5); }
        blur(L, 12);
        crop(L, X * 100, 0, 0, 0, Math.round(R * 0.4));
    } else if (look === 'icosaedro' || look === 'octaedro') {
        var corners = look === 'octaedro' ? [[0, 0, 55, 45, 1, 1], [55, 0, 0, 45, -1, 1], [0, 60, 55, 0, 1, -1], [55, 60, 0, 0, -1, -1]] : [[0, 0, 62, 40, 1, 1], [70, 35, 0, 0, -1, -1], [0, 70, 50, 0, 1, -1]];
        for (k = 0; k < corners.length; k++) {
            var q = corners[k];
            L = layer('faceta ' + (k + 1));
            c = tf(L); if (c) { pt(c, /^(position|posi[cç][aã]o)$/i, 1, 0.5 + q[4] * 0.06 * S, 0.5 + q[5] * 0.05 * S); }
            blur(L, 3);
            chroma(L, Math.max(CH, 0.4) * (look === 'octaedro' ? 2 : 1));
            crop(L, q[0], q[1], q[2], q[3], 8);
        }
    } else {
        fe_err('Este vidro (' + (a.lookName || look) + ') só funciona no modo Render fiel.');
    }
    if (!made) { fe_err('Não consegui criar a camada de vidro.'); }
    var miss = [], mk; for (mk in missing) { if (missing.hasOwnProperty(mk)) { miss.push(mk); } }
    return { layers: made, missing: miss };
};
